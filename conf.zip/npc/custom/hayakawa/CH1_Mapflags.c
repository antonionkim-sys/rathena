hem_fild	mapflag	NOBRANCH
ygg_edge	mapflag	NOBRANCH
ygg_roots	mapflag	NOBRANCH
hem_fild	mapflag	NOMEMO
ygg_edge	mapflag	NOMEMO
ygg_roots	mapflag	NOMEMO
ygg_fruit	mapflag	NOBRANCH
ygg_fruit	mapflag	NOMEMO
uknw_ruin	mapflag	NOBRANCH
uknw_ruin	mapflag	NOMEMO
uknw_ruin2	mapflag	NOBRANCH
uknw_ruin2	mapflag	NOMEMO
ch1_geffen	mapflag	NOBRANCH
ch1_geffen	mapflag	NOMEMO
ch1_gef_in	mapflag	NOBRANCH
ch1_gef_in	mapflag	NOMEMO
ch1_gef_in	mapflag	NOTELEPORT
ch1_vrgef1	mapflag	NOBRANCH
ch1_vrgef2	mapflag	NOBRANCH
ch1_vrgef1	mapflag	NOMEMO
ch1_vrgef1	mapflag	NOTELEPORT
ch1_gef_in	mapflag	NOTELEPORT
mu_fild01	mapflag	NOBRANCH
mu_fild01	mapflag	NOMEMO
ch1_sf01	mapflag	NOBRANCH
ch1_sf02	mapflag	NOBRANCH
ch1_sf03	mapflag	NOBRANCH
ch1_sf01	mapflag	NOMEMO
ch1_sf02	mapflag	NOMEMO
ch1_sf03	mapflag	NOMEMO
ch1_sf01	mapflag	NOTELEPORT
ch1_sf02	mapflag	NOTELEPORT
ch1_sf03	mapflag	NOTELEPORT
ch1_sf02	mapflag	NOSAVE	SavePoint
ch1_sf03	mapflag	NOSAVE	SavePoint
hem_dun01	mapflag	NOBRANCH
hem_dun01	mapflag	NOMEMO
hem_dun02	mapflag	NOSAVE	SavePoint
hem_dun02	mapflag	NOBRANCH
hem_dun02	mapflag	NOMEMO
ch1_gfn01	mapflag	NOTELEPORT
ch1_gfn01	mapflag	NOSAVE	SavePoint
ch1_gfn01	mapflag	NOBRANCH
ch1_gfn03	mapflag	NOTELEPORT
ch1_gfn03	mapflag	NOSAVE	SavePoint
ch1_gfn03	mapflag	NOBRANCH
1@ch1a	mapflag	NOSAVE	SavePoint
1@ch1a	mapflag	NOTELEPORT
1@ch1a	mapflag	NOMEMO
1@ch1a	mapflag	NOBRANCH
1@ch1a	mapflag	PARTYLOCK
1@ch1b	mapflag	NOSAVE	SavePoint
1@ch1b	mapflag	NOTELEPORT
1@ch1b	mapflag	NOMEMO
1@ch1b	mapflag	NOBRANCH
1@ch1b	mapflag	PARTYLOCK
hem_dun02	mapflag	SPECIALPOPUP	11
ch1_gfn01	mapflag	SPECIALPOPUP	11
ch1_gfn03	mapflag	SPECIALPOPUP	11
