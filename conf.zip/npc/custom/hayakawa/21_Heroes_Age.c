//===== rAthena Script ===========================================|
//= Episode 21 - Age of Heroes                                   =|
//===== By: ======================================================|
//= crazyarashi                                                  =|
//===== Current Version: =========================================|
//= 1.0 Initial Version                                          =|
//= 1.1 Initial Bugs Cleanup                                     =|
//= 1.2 October 202 - EP21 Update                                =|
//= 1.3 Minor quest bug fixes                                    =|
//================================================================|

jor_tail,233,41,3	script	Diver Fapa#ep21ex01	4_EP19_IWIN_DIVER,{
	if(isbegin_quest(18233) < 2){
		npctalk "Diver Fapa : The water was cold again today...","",bc_self;
		end;
	}
	if(BaseLevel < 230){
		mes "[Diver Fapa]";
		mes "I've been feeling something strange over there lately.";
		mes "That place is the Scale Island, I'm thinking of going there soon.";
		next;
		mes "^4D4DFFThis quest is only for those who are level 230 or above.^000000";
		close;
	}
	if(isbegin_quest(18233) == 2 && isbegin_quest(18334) == 0){
		cutin "ep19_iwin_diver02.png",2;
		mes "[Diver Fapa]";
		mes "Oh, adventurer.";
		mes "You came just in time.";
		mes "Just wait a moment, the others will also be here soon.";
		next;
		select("What's going on?");
		cutin "ep19_iwin_diver01.png",2;
		mes "[Diver Fapa]";
		mes "Huh? Didn't you hear? We were planning to go investigate the tiny island over there called the Scale Island.";
		mes "Adventurer, aren't you going to come with us?";
		next;
		cloaknpc("Nillem#ep21nlm01",false,getcharid(0));
		cloaknpc("Aurelie#ep21orl01",false,getcharid(0));
		cloaknpc("Lehar#ep21rhr01",false,getcharid(0));
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Oh, adventurer! Percect timing, I was just about to come and find you.";
		mes "We are going to the Scale Island, you should come with us!";
		next;
		cutin "ep172_nillem01.png",1;
		mes "[Nillem]";
		mes "Oh, dear customer~ Is that really you?";
		mes "I've always provided you the teleport services from the Cat on a Bullet, aren't you happy to see me?";
		next;
		select("Nillem, why are you here?");
		cutin "ep172_nillem02.png",1;
		mes "[Nillem]";
		mes "I'm here because you need me for various reasons, maybe?";
		mes "Haha, after the dimensional rift occured, various things were going here and there, right?";
		next;
		cutin "ep172_nillem02.png",1;
		mes "[Nillem]";
		mes "It's difficult to respond on time if a rift or a similar phenomena suddenly occured, that's why I did some research to predict where it will occur.";
		next;
		cutin "ep172_nillem03.png",1;
		mes "[Nillem]";
		mes "Who am I? I am the genius wizard Nillem-☆";
		mes "But why you asked? It's for the sake of my dear customer who works tirelessly for the safety of the continent, isn't that obvious?";
		next;
		cutin "ep19_lehar07.png",2;
		mes "[Lehar]";
		mes "Eh.... Are you serious. Simply for that.";
		next;
		cutin "ep172_nillem01.png",1;
		mes "[Nillem]";
		mes "Of course, what do you think I do? Anyways, I came here because I detected a similar mana wavelength when the rift occured.";
		mes "Entering the rumored Isgard, and meeting the rumored guardians...!";
		next;
		cutin "ep19_aurelie02.png",0;
		mes "[Aurelie]";
		mes "Can we end the greetings and go?";
		mes "The mana wavelength of that place is unusual.";
		mes "We need to check if it's related to the barrier's seal.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Yes. Shall we go now?";
		mes "Wizard. Is that the place where you felt the wavelength?";
		next;
		cutin "ep172_nillem02.png",1;
		mes "[Nillem]";
		mes "Correct. Leon and Aurelie also confirmed it a while ago back in the Ice Castle.";
		mes "Are we not going?";
		next;
		select("Aren't you going to ask my opinion?");
		cutin "ep172_nillem03.png",1;
		mes "[Nillem]";
		mes "Come on~ There is no need to ask. I already the know the answer.";
		mes "This is something urgent, we can take care of it now and think about it later. Let's go now~. Let's go quickly~☆";
		next;
		cutin "ep19_iwin_diver02.png",2;
		mes "[Diver Fapa]";
		mes "Shall we go to the Scale Island?";
		mes "Should we leave now?";
		setquest 18334;
		close2;
		pcblock(true);
		cutin "",255;
		npctalk "Finally.","Nillem#ep21nlm01",bc_self;
		npctalk "Please.","Aurelie#ep21orl01",bc_self;
		npctalk "Let's go!","Lehar#ep21rhr01",bc_self;
		sleep2 1000;
		cloaknpc("Nillem#ep21nlm01",true,getcharid(0));
		cloaknpc("Aurelie#ep21orl01",true,getcharid(0));
		cloaknpc("Lehar#ep21rhr01",true,getcharid(0));
        npctalk "Diver Fapa : How about you?","",bc_self;
		pcblock(false);
        if(select("I'll go now.","I'll go later.") == 2)
        	npctalk "I'll be here for a while, just let me know when you want to go to Scale Island.","",bc_self;
		else {
			npctalk "Diver Fapa : Let's go.","",bc_self;
			warp "jor_crk",137,137;
		}
		end;
	}
	cutin "ep19_iwin_diver02.png",2;
	mes "[Diver Fapa]";
    mes "Are you going to Scale Island?";
	next;
	if(select("Go to Scale Island.","No.") == 2){
	    mes "[Diver Fapa]";
	    mes "I'll be here for a while, just let me know when you want to go to Scale Island.";
	    close3;
    } else {
		cutin "",255;
		npctalk "Diver Fapa : Let's go.","",bc_self;
		warp "jor_crk",137,137;
	}
	end;

OnInit:
    questinfo QTYPE_QUEST,QMARK_YELLOW,"BaseLevel >= 230 && isbegin_quest(18233) == 2 && isbegin_quest(18334) == 0";
end;
}

jor_tail,230,42,5	duplicate(dummynpc)	Nillem#ep21nlm01	4_M_NILLEM
jor_tail,232,44,4	duplicate(dummynpc)	Aurelie#ep21orl01	4_EP19_AURELIE
jor_tail,235,44,4	duplicate(dummynpc)	Lehar#ep21rhr01	4_EP19_LEHAR

jor_crk,139,141,3	script	Diver Fapa#ep21ex02	4_EP19_IWIN_DIVER,{
	mes "[Diver Fapa]";
	mes "Are you finish investigating? Do you want to go return?";
	mes "To the airship? Ice Castle? Where do you want to go?";
	cutin "ep19_iwin_diver02.png",2;
	next;
	switch(select("To the airship.","To Ice Castle.","I'm staying.")){
		case 1:
			mes "[Diver Fapa]";
			mes "I'll take you near the airship.";
			close2;
			cutin "",255;
			warp "jor_tail",232,43;
			end;

		case 2:
			mes "[Diver Fapa]";
			mes "I'll take you near the Ice Castle.";
			close2;
			cutin "",255;
			warp "icecastle",145,85;
			end;

		case 3:
			mes "[Diver Fapa]";
			mes "Okay. I'll wait here.";
			close3;
	}
	end;
}

jor_crk,137,138,0	script	#ep21pt1evt01	HIDDEN_WARP_NPC,3,3,{
    end;

OnTouch:
	if(isbegin_quest(18334) == 1){
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "It has been a while I have been here to Scale Island.";
		mes "I used to do a lot of things here in the past.";
		mes "What do you think Nillem? How does it feel to be here?";
		next;
		cutin "ep172_nillem05.png",1;
		mes "[Nillem]";
		mes "Aurelie, can't you feel that?";
		mes "This isn't a normal mana wavelength.";
		mes "We need to investigate it quickly..!";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Huh? Nyar is over there!";
		mes "There must be something there?";
		next;
		cutin "ep19_aurelie04.png",0;
		mes "[Aurelie]";
		mes "Nyar? Let's go over there quickly.";
		next;
		cutin "ep172_nillem01.png",1;
		mes "[Nillem]";
		mes "Huh? Who's Nyar? What is that?";
		mes "Hey, wait for me!";
		close2;
		cutin "",255;
		navigateto("jor_crk",105,108);
		end;
	}
	if(isbegin_quest(18355) == 1){
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Oh? Lady Aurelie!!";
		next;
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "Oh dear? I was just on my way to check the sudden change in mana....";
		mes "Could it be?";
		next;
		cutin "ep19_lehar02.png",2;
		mes "[Lehar]";
		mes "I think we did it!";
		mes "Nyar has recovered Jormungandr's power that Lasgand was supposed to absorb.";
		next;
		cutin "ep19_lehar04.png",2;
		mes "[Lehar]";
		mes "But we couldn't stop the curse.";
		mes "And destroy Lasgand's egg.";
		next;
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "Isn't that fine?";
		mes "If you had destroyed it, it might have caused a catastrophe that could destroy the continent.";
		mes "And that thing has been providing it's own power for a long time, isn't it?";
		next;
		cutin "ep172_nillem02.png",1;
		mes "[Nillem]";
		mes "With the way you're talking, it seems like the timeline is properly connected.";
		mes "Specifically the consistency of the events that happened.";
		next;
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "That seems the case.";
		mes "I'll go check on Lasgand's seal. Court mage, what will you do?";
		next;
		cutin "ep172_nillem02.png",1;
		mes "[Nillem]";
		mes "I'll be sealing the rift with Nyar.";
		mes "We can't just leave that gap as it is.";
		next;
		cutin "ep19_aurelie02.png",0;
		mes "[Aurelie]";
		mes "Then, can we head out and leave this to you?";
		mes "Let's go see what happened to Lasgand.";
		mes "This time, let's finish it for good.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Sounds like a plan!";
		completequest 18355;
		setquest 18356;
		close2;
		cutin "",255;
		warp "jor_twig",122,160;
	}
end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18355) == 1";
end;
}

jor_crk,105,108,3	script	Nyar#ep21nya01	4_EP20_NYAR,{
	if(isbegin_quest(18334) == 0) end; //Shouldn't happen
	if(isbegin_quest(18334) == 1){
		pcblock(true);
		cloaknpc("Lehar#ep21rhr02",false,getcharid(0));
		cloaknpc("Nillem#ep21nlm02",false,getcharid(0));
		cloaknpc("Aurelie#ep21orl02",false,getcharid(0));
		sleep2 500;
		npctalk "Lehar : It's Nyar! Why are you here? I mean you can be wherever you want.. Whoa, what is that?","Lehar#ep21rhr02",bc_self;
		sleep2 500;
		npctalk "Nillem : That's amazing.. Wah, what's that!!!","Nillem#ep21nlm02",bc_self;
		sleep2 500;
		pcblock(false);
		npctalk "Aurelie : ...A rift...","Aurelie#ep21orl02",bc_self;
		cutin "ep19_aurelie03.png",0;
		mes "[Aurelie]";
		mes "It seems the cause of the unusual mana wavelength is this.";
		mes "How did such a rift opened?";
		next;
		cutin "ep20_nyar05.png",1;
		mes "[Nyar]";
		mes "Mrow.. Meow.";
		next;
		cutin "ep19_aurelie03.png",0;
		mes "[Aurelie]";
		mes "Is the dimensional boundaries collapsing?";
		mes "The rift has already formed....";
		next;
		cutin "ep20_nyar04.png",1;
		mes "[Nyar]";
		mes "Meow Meow Purr";
		next;
		cutin "ep19_aurelie03.png",0;
		mes "[Aurelie]";
		mes "... Not only the dimensional boundaries, but time and parallel dimensions too...?";
		mes "The effect of the dimensional rift...?";
		mes "What is happening?";
		next;
		cutin "ep172_nillem02.png",1;
		mes "[Nillem]";
		mes "Uhm. Hey, that cat, are you talking to it?";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "It's Nyar. The ruler of Isgard!";
		mes "Have you heard of Nyar? The demigod who protected our world!";
		next;
		cutin "ep172_nillem01.png",2;
		mes "[Nillem]";
		mes "...Ah, hmm...? No.. Yes?";
		mes "I see? So that's how it is?!";
		next;
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "You're quick to pick up, Wizard.";
		mes "Shall we continue our conversation?";
		mes "Is the mana that you have detected similar to the dimensional rift?";
		next;
		cutin "ep172_nillem01.png",2;
		mes "[Nillem]";
		mes "Yes. That's right. The mana wavelength from the dimensional rift that I've detected was exactly like this.";
		mes "But, I think the shape of this rift is different...";
		next;
		cutin "ep20_nyar02.png",1;
		mes "[Nyar]";
		mes "Meow. Meow. Me-meow.";
		next;
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "Eh? The moment when the rift is about to occur?";
		mes "It can be connected to a specific place and time in the past? What?!";
		next;
		cutin "ep20_nyar03.png",1;
		mes "[Nyar]";
		mes "Meow meow~ Me~~ow~~~";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "What is Nyar saying?";
		next;
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "It seems that we've just found a way to deal with Lasgand.";
		mes "Nyar will be our lead from now on.";
		mes "Nyar wants to take us to a specific point in the past.";
		next;
		select("What do you mean?");
		cutin "ep172_nillem01.png",2;
		mes "[Nillem]";
		mes "Ah~ From what you've said earlier, this Lasgand is currently being restrained somewhere, correct?";
		mes "So you're going to connect this rift to a point before Lasgand gained power?";
		next;
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "As expected from the wizard, you're quick to understand.";
		mes "Nyar will handle connecting the rift. I will handle the point where you will return.";
		mes "We need someone with strong magical powers who will handle from the other point.";
		next;
		cutin "ep172_nillem03.png",2;
		mes "[Nillem]";
		mes "It's my time to shine!";
		mes "Please, let me do it!";
		mes "I've also used dimensional rifts to go to the past before~!";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Uhm... what about me? Should I go too?";
		mes "I need to talk to my mother and aunt to get their permission...";
		next;
		cutin "ep20_nyar02.png",1;
		mes "[Nyar]";
		mes "Meow...Meow...";
		next;
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "Yes. We don't have time for that. We need to go to a specific time and place before the rift occured.";
		mes "I will relay a message to your family Lehar. Would that be fine?";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "It's so sudden, maybe? What about you adventurer???";
		next;
		select("I'll jump in right away.","This is why I'm here.","Obvious question. Of course I'm going!");
		cutin "ep172_nillem02.png",1;
		mes "[Nillem]";
		mes "As expected from the dear adventurer! This is what I've been waiting for!";
		mes "So, what should we do? Should we just wait..?";
		close2;
		cutin "ep172_nillem01.png",255;
		npctalk "Meow~!","Nyar#ep21nya01",bc_self;
		sleep2 400;
		specialeffect2 EF_BLUELINE;
		sleep2 500;
		specialeffect EF_BLUELINE,AREA,"Nillem#ep21nlm02";
		sleep2 300;
		specialeffect EF_BLUELINE,AREA,"Lehar#ep21rhr02";
		npctalk "Woah!","Lehar#ep21rhr02",bc_self;
		sleep2 1400;
		npctalk "Eek!","Nillem#ep21nlm02",bc_self;
		specialeffect EF_COLDTHROW2,AREA,"Lehar#ep21rhr02";
		sleep2 400;
		cloaknpc("Lehar#ep21rhr02",true,getcharid(0));
		specialeffect EF_COLDTHROW2,AREA,"Nillem#ep21nlm02";
		sleep2 400;
		cloaknpc("Nillem#ep21nlm02",true,getcharid(0));
		sleep2 1000;
		npctalk "Have a safe trip~! I will relay the news to the others~!","Aurelie#ep21orl02",bc_self;
		sleep2 2000;
		specialeffect2 EF_COLDTHROW2;
		completequest 18334;
		setquest 18335;
		cloaknpc("Aurelie#ep21orl02",true,getcharid(0));
		warp "jor_crk_p",108,106;
		end;
	}
	if(isbegin_quest(18360) == 1){
		cloaknpc("Lehar#ep21rhr02",false,getcharid(0));
		cloaknpc("Nillem#ep21nlm02",false,getcharid(0));
		cloaknpc("Aurelie#ep21orl02",false,getcharid(0));
		cutin "ep172_nillem03.png",1;
		mes "[Nillem]";
		mes "Ah, you're all here!";
		mes "Let's cut to the chase, we failed to close the rift.";
		next;
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "You failed to close it even with Nyar's power?";
		mes "Attempting to manually close a rift has never done before, has it?";
		next;
		cutin "ep172_nillem02.png",1;
		mes "[Nillem]";
		mes "...It was the first that it was attempted.";
		mes "But more importantly, what we did as alternative was cut off parts from different timelines and force them together, correct?";
		next;
		mes "[Nillem]";
		mes "It seemed that it cause some side effects....";
		mes "The rifts seem to have locked it from the day we left.";
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "Locked, what do you mean?";
		mes "Isn't time supposed to flow forward?";
		next;
		cutin "ep172_nillem04.png",1;
		mes "[Nillem]";
		mes "Hm... It's like a certain day keeps repeating, how should I put it?";
		mes "Instead of time moving to the next day, the same day repeats over and over.";
		next;
		cutin "ep172_nillem02.png",1;
		mes "[Nillem]";
		mes "It's the day we left the timeline.";
		mes "....";
		next;
		select("Was it before the Final Battle?");
		cutin "ep172_nillem05.png",1;
		mes "[Nillem]";
		mes "Exactly. The time has stopped.";
		mes "Our ancestors and heroes are still likely fighting that intense battle, over.. and over again.";
		next;
		mes "[Nillem]";
		mes "They might know how many times it has happened.";
		mes "Of course, small changes might occur.";
		next;
		cutin "ep172_nillem06.png",1;
		mes "[Nillem]";
		mes "The kind of change is from small choices, like meal times or taking a nap.";
		mes "Aside from those trivial changes, the larger ones keeps repeating the same way.";
		next;
		cutin "ep172_nillem02.png",1;
		mes "[Nillem]";
		mes "Like the death of Tan...";
		next;
		cutin "ep19_aurelie03.png",0;
		mes "[Aurelie]";
		mes "It might be the aftermath of forcing a timeline change and merging it.";
		mes "or perhaps it's the result of dimensional boundaries collapsing into each other...";
		next;
		mes "[Aurelie]";
		mes "It could also be that when the Gaebolg curse was broken, the eternity curse aspect lingered causing this phenomenon.";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Eternity?";
		mes "Haven't we ended the curse!";
		next;
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "The concept of eternity was part of the curse. Breaking the curse may not have resulted in such a happy ending where everything just magically vanishes forever.";
		mes "Especially when there's a rift like this....";
		next;
		cutin "ep172_nillem02.png",1;
		mes "[Nillem]";
		mes "Well? Should we investigate further to be sure?";
		mes "Regardless, the rift will remain as we failed to close it.";
		next;
		cutin "ep172_nillem01.png",1;
		mes "[Nillem]";
		mes "With Nyar's permission, we can enter and exit as we please.";
		mes "I'm planning to come and go from time to time.";
		mes "Adventurer, how do you feel about this kind of time travel?";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "I'll go check it too!";
		mes "Something about it doesn't sit right with me...";
		next;
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "Hm. Do what you feel is best.";
		mes "There might be some strange phenomenons, like a day eternally repeating itself.";
		next;
		cutin "ep172_nillem04.png",1;
		mes "[Nillem]";
		mes "Well, if you think about it, isn't it like experiencing a day written in history?";
		mes "It's something like, a virtual tour of a history book.";
		next;
		cutin "ep172_nillem03.png",1;
		mes "[Nillem]";
		mes "Speaking of which, adventurer, would you like to see something?";
		mes "Your name has appeared here-☆";
		next;
		cutin "",255;
		mes "Rune-Midgarts founding history";
		mes ".. Excerpt...";
		mes "On that day, the thirteen heroes gathered to defeat the great serpent known as Jormungandr.";
		mes "Tris, Tan, Maristella, Yohan, Ivan, Richard, Laura, Galaxia, Gunter, Wilhelm, Reinhardt, Nadoyo, and " + strcharinfo(0) + ".";
		mes "This battle became the foundation of the kingdom...";
		mes ".. Excerpt...";
		mes "However, there was no records remains of " + strcharinfo(0) + ", who vanished like a mirage, thus making the story of the twelve heroes of the final battle is what remains.";
		mes "..End...";
		next;
		cutin "ep19_lehar02.png",2;
		mes "[Lehar]";
		mes "Wow.. Adventurer, your name is in the history books...!";
		mes "That's amazing! But why isn't lady Aurelie's name there?";
		next;
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "I asked them to leave me out.";
		mes "Leon and I had assist with the sealing of Isgard, so we couldn't appear on the founding ceremony.";
		mes "The existence of Rgans. We had to keep the secret sealed in Isgard.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Ahh... I see.";
		mes "Wouldn't it be a problem that the adventurer's name was recorded?";
		next;
		cutin "ep172_nillem04.png",1;
		mes "[Nillem]";
		mes "It's not a problem at all, in fact it's a proof that we successfully connected the timeline.";
		mes "What better evidence could be there than this record? Haha!";
		next;
		cutin "ep19_aurelie04.png",0;
		mes "[Aurelie]";
		mes "Indeed. Adventurer. You did well.";
		mes "I hope the winds of freedom blow wherever your journey takes you.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Oh, adventurer. Take this.";
		mes "These are rewards that I received for working hard, they'll be more useful to you.";
		next;
		cutin "ep172_nillem02.png",1;
		mes "[Nillem]";
		mes "Oh, here's mine too!";
		mes "I'm sure you can use them for something amazing!";
		completequest 18360;
		getitem "Ep21_Wigner_Ticket",70;
		getexp 674207720,119990110;
		add_reputation_points(13,60);
		close3;
	}
	cutin "ep20_nyar03.png",1;
	mes "[Nyar]";
	mes "Meow?";
	next;
	if(select("Send me to Scale Island of the past.","It's nothing.") == 2){
		cutin "ep20_nyar03.png",1;
		mes "[Nyar]";
		mes "Maw..";
		close3;
	}
	cutin "ep20_nyar03.png",1;
	mes "[Nyar]";
	mes "Meow!";
	close2;
	cutin "",255;
	warp "jor_crk_p",108,106;
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18334) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18360) == 1";
end;
}

jor_crk,107,108,3	script(CLOAKED)	Lehar#ep21rhr02	4_EP19_LEHAR,{
	npctalk "Rifts are always fascinating to see.","",bc_self;
	end;
}

jor_crk,103,106,3	script(CLOAKED)	Nillem#ep21nlm02	4_M_NILLEM,{
	npctalk "This kind of scenery is what adventurers always see.","",bc_self;
	end;
}

jor_crk,109,108,3	script(CLOAKED)	Aurelie#ep21orl02	4_EP19_AURELIE,{
	npctalk "Is this rift a sign of something?","",bc_self;
	end;
}

jor_crk_p,105,108,4	script	Nyar#ep21nya02	4_EP20_NYAR,{
	if(isbegin_quest(18335) == 0) end; // Shouldn't happen
	if(isbegin_quest(18335) == 1){
		cloaknpc("Nillem#ep21nlm03",false,getcharid(0));
		cloaknpc("Lehar#ep21rhr03",false,getcharid(0));
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "What happened, it was so sudden...";
		mes "Nyar, can't you give us a warning next time?";
		next;
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "Oh... wonderful. I've just witnessed such a marvel!";
		mes "Nyar? Nyar!! Nyar!!!!";
		next;
		cutin "ep20_nyar02.png",1;
		mes "[Nyar]";
		mes "Hiss!";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "My oh my. Our dear Nyar seems to be angry.";
		mes "So, where are we? Weren't we just investigating the signs of the right and just got pulled into somewhere~?";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Wizard, aren't we on the same Scale Island as we where before?";
		mes "The rift is still here.";
		mes "But, I don't think it's not as cold as it was? Didn't it snow a lot earlier?";
		next;
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "Hm, The flow of mana is different.";
		mes "As Aurelie mentioned, this must be the past.";
		mes "It was the exact moment when the rift opened!";
		next;
		cutin "ep20_nyar02.png",1;
		mes "[Nyar]";
		mes "Mreow. Meow.";
		next;
		cutin "ep172_nillem03.png",0;
		mes "[Nillem]";
		mes "Aha, I see!";
		mes "No wonder I'm having this jitters, is it really from that time?";
		mes "This is the event where the foundation of Rune-Midgarts is established! Am I correct?";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Huh... established?";
		mes "So... this is the time when we are still fighting the Jormungandr cult?";
		next;
		cutin "ep20_nyar03.png",1;
		mes "[Nyar]";
		mes "Mrow. Mew. Greeow. Greow.";
		next;
		select("What is Nyar saying... am I the only one who doesn't understand?");
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Woah, impressive. You must have had quite an experience?";
		mes "Even a 3 year old knows the story of Jormungandr's defeat and the country's founding, right?";
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "From what I've heard from the guardians, Lasgand was created using the power of Jormungandr.";
		mes "He accumulated such a strong power that you failed to defeat him and were forced to seal him~";
		next;
		cutin "ep172_nillem03.png",0;
		mes "[Nillem]";
		mes "And now, this is the chance to defeat Lasgand? What does that mean!";
		mes "Nyar connected the rift to the point before Lasgand inherited Jormungandr's power!";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Ah... so, we just need to defeat Lasgand before he gains his power?";
		next;
		select("Should we just defeat Lasgand?");
		cutin "ep20_nyar02.png",1;
		mes "[Nyar]";
		mes "Meow.. Nya... Mru..";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Wh-.. why? Wasn't that our purpose?";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "We can't get just get too involved with the past, correct?";
		mes "Events must happen as they should be, we can only meddle slightly, something like removing a season on food, right?";
		next;
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "For example, We could divert the power that was supposed to be transferred to Lasgand...haha..wahaha!";
		mes "Thinking about it, doesn't it give you chills?";
		next;
		mes "[Nillem]";
		mes "Ahh.. this must be what the adventurer feels...!";
		mes "Alright. I understand what we have to do.";
		next;
		mes "[Nillem]";
		mes "Nyar will be handling the connection and I will handle the point from this rift with my magic, returning here should be a hitch-☆";
		mes "Am I right, Nyar?";
		next;
		cutin "ep20_nyar05.png",1;
		mes "[Nyar]";
		mes "Meow. Mew~!";
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "So where do we go from here and what should we do?";
		mes "Should we just charge and attack the Jormungandr cult?";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "I don't know exactly where, but there should be a base for those who rose to fight the Jormungandr cult, didn't you learn that in your history lessons?";
		next;
		select("...I'm not sure'...");
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "Dear adventurer, what a passionate youth you've had.";
		mes "You were already making history while others were taking history lessons.";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Ahh~ After the divine war, there was a great battle against the Jormungandr cult and it devastated the north!";
		mes "Isgard is beyond that place... Are we at the event of the final battle??";
		next;
		select("So where should we go? Should we find Lasgand?");
		cutin "ep20_nyar04.png",1;
		mes "[Nyar]";
		mes "Meooow.. mraw. Meow.";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Yes. we need to investigate the exact time, and the place we need to go.";
		mes "Hm. Shouldn't we find a way to get off this island first?";
		next;
		cutin "ep20_nyar02.png",1;
		mes "[Nyar]";
		mes "Myak!";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Wait! There are people over there.";
		mes "What should we do?";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "What do you mean, what should we do! Calm down!";
		mes "We are volunteers here to support the resistance agains the cult. Got it?";
		next;
		cutin "ep172_nillem03.png",0;
		mes "[Nillem]";
		mes "Let's approach them slowly with your hands on the sides.";
		mes "I'm sure it'll be a wonderful meeting-☆";
		completequest 18335;
		setquest 18336;
		questinfo_refresh;
		close3;
	}
	if(isbegin_quest(18336) == 1){
		npctalk "Meow~","",bc_self;
		end;
	}
	if(isbegin_quest(18353) == 1){
		cloaknpc("Nillem#ep21nlm03",false,getcharid(0));
		cloaknpc("Lehar#ep21rhr03",false,getcharid(0));
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "So that's how the name of the first king came to be...";
		mes "It wasn't just his surname because he's the leader of the Gaebolg.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Indeed. To think that he changed his name to focus the curse on himself...";
		mes ".... Anyways, Lasgand hatched and created his other kins with his own blood.";
		next;
		mes "[Lehar]";
		mes "Now that I think about it, it was like he was distributing his own power.";
		mes "It's gradually weakening him....";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "That Lasgand fellow must be pretty weak by now, right?";
		mes "The impeccable power of Jormungandr was reclaimed by Nyar.";
		next;
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "We resolved everything.";
		mes "Now we just need to go and give Lasgand a good beating~!";
		next;
		cutin "ep20_nyar03.png",1;
		mes "[Nyar]";
		mes "Meow Meow Purrr";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "No, no.";
		mes "You can't simply leave like that.";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Ah! Heine? Oh, right. We need to return the tablet.";
		mes "and then head to Lunaforma to help a bit more... It's almost meal time...!";
		next;
		cutin "ep172_nillem05.png",0;
		mes "[Nillem]";
		mes "Should I head back to Alberta and do a bit more preservation magic?";
		next;
		cutin "ep21_ilse_heine02.png",1;
		mes "[Ilse El Heine]";
		mes "No, no, no. It would be better if you guys just quietly disappear.";
		mes "Before that, there's one thing I need you to do.";
		next;
		mes "[Ilse El Heine]";
		mes "Can you swap this tablet with the one hidden in the Lunaforma dock?";
		mes "I prepared a new equipment for you, so go ahead and take it.";
		next;
		cutin "ep21_ilse_heine04.png",1;
		mes "[Ilse El Heine]";
		mes "It's a gift from me, so just go ahead and accept it.";
		mes "Leave this tablet in the bushes near the dock.";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Sure thing. Consider it done.";
		mes "It was an honor the meet the sage of Comodo.";
		next;
		cutin "ep21_ilse_heine03.png",1;
		mes "[Ilse El Heine]";
		mes "It was a great journey for me as well.";
		completequest 18353;
		setquest 18354;
		close3;
	}
	cutin "ep20_nyar02.png",1;
	mes "[Nyar]";
	mes "Meow-";
	next;
	if(select("Return to the original time.","Pet Nyar.") == 2){
		cutin "ep20_nyar03.png",1;
		mes "[Nyar]";
		mes "Mrrrr meow.";
		close3;
	}
	cutin "ep20_nyar03.png",1;
	mes "[Nyar]";
	mes "..Mew..";
	close2;
	cutin "",255;
	warp "jor_crk",108,105;
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18335) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18353) == 1";
end;
}

jor_crk_p,103,106,4	script(CLOAKED)	Nillem#ep21nlm03	4_M_NILLEM,{
	if(isbegin_quest(18353) == 1){
		cutin "ep172_nillem02.png",1;
		mes "[Nillem]";
		mes "The dock that Heine mentioned is just a short ride away on the small boat just below this place.";
		close3;
	}
	end;
}

jor_crk_p,107,106,3	script(CLOAKED)	Lehar#ep21rhr03	4_EP19_LEHAR,{
	if(isbegin_quest(18353) == 1){
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Let's hurry and go quietly. The thought of finally being able to take a shot at Lasgand is so exciting!";
		close3;
	}
	end;
}

jor_crk_p,100,95,5	script	#ep21pt1evt02	HIDDEN_WARP_NPC,5,5,{
	end;

OnTouch:
	if(isbegin_quest(18336) == 1){
		cloaknpc("Nillem#ep21nlm03",false,getcharid(0));
		cloaknpc("Lehar#ep21rhr03",false,getcharid(0));
		cloaknpc("Ivan#ep21_ivan01",false,getcharid(0));
		cutin "ep21_nadoyo06.png",1;
		mes "[Hooded Person]";
		mes "There are a number of person who wish to leave the cult, I will bring you the result next time.";
		mes "Shall we meet at this place again?";
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Bold Young Man]";
		mes "There is no better place to avoid the eyes of the cult.";
		mes "But this sudden rift suddenly appearing is a bit concerning...";
		next;
		cutin "ep21_nadoyo06.png",1;
		mes "[Hooded Person]";
		mes "It would be better to report it to Aurelie or Heine.";
		mes "The next shift is coming, I must go now!";
		close2;
		pcblock(true);
		cutin "",255;
		npctalk "??? : ...Hmm.. What is this rift?","Ivan#ep21_ivan01",bc_self;
		sleep2 1000;
		pcblock(false);
		emotion ET_QUESTION,getnpcid(0,"Ivan#ep21_ivan01");
		cutin "ep21_ivan02.png",0;
		mes "[Bold Young Man]";
		mes "Who's there!";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Uh..Uhm?";
		mes "Hellp?";
		mes "My name is Lehar. and this wizard over here is Nillem...";
		next;
		cutin "ep21_ivan06.png",0;
		mes "[Bold Young Man]";
		mes "Hah... I didn't ask for your names.";
		mes "What are you doing here? Why are you in this place?";
		next;
		select("We're warriors.","We're adventurers..","Just a passerby..");
		cutin "ep172_nillem02.png",1;
		mes "[Nillem]";
		mes "Oh wait, please! We're not suspicious people.";
		mes "Do you happen to know where the Gaebolg army is?";
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Bold Young Man]";
		mes "Why do you ask?";
		next;
		cutin "ep172_nillem01.png",1;
		mes "[Nillem]";
		mes "Is it not obvious? Look at us!";
		mes "We came to the north to join the fight against the Jormungandr cult, but we lost...";
		next;
		cutin "ep19_lehar02.png",2;
		mes "[Lehar]";
		mes "Ah ahhh that's right. We came here to fight.";
		mes "Look! Just like you, I'm also a servant of Odin";
		next;
		cutin "ep21_ivan04.png",0;
		mes "[Ivan]";
		mes "Is that so...?";
		mes "I understand. My name is Ivan.";
		mes "So you got lost while looking for the Gaebolg base?";
		next;
		cutin "ep172_nillem02.png",1;
		mes "[Nillem]";
		mes "Wow.. it's Ivan. Are you Ivan of Wigner?";
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "You know me?";
		mes "...How do you know me?";
		next;
		cutin "ep172_nillem03.png",1;
		mes "[Nillem]";
		mes "I just heard rumors from all over the place.";
		mes "The Wigner merchants are the best in the continent!";
		next;
		select("Right! Yes! I agree!");
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "Hm... anyway, are you here to join the resistance against the Jormungandr cult?";
		mes "I'll guide you... you better not make a fuss.";
		next;
		cutin "ep19_lehar02.png",2;
		mes "[Lehar]";
		mes "Sure. Of course. Should I tie my hands together?";
		next;
		cutin "ep21_ivan06.png",0;
		mes "[Ivan]";
		mes "You don't have to do that. Just follow me for now.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "(Did I do well?)";
		next;
		cutin "ep172_nillem03.png",1;
		mes "[Nillem]";
		mes "(You did great. We met a big shot as soon as we arrived. Ah.. My heart is racing...)";
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "What are you doing?";
		mes "This way.";
		completequest 18336;
		setquest 18337;
		close2;
		cutin "",255;
		cloaknpc("Ivan#ep21_ivan01",true,getcharid(0));
		warp "luna_sf1",258,147;
		end;
	}
	if(isbegin_quest(18337) == 1){
		cloaknpc("Ivan#ep21_ivan01",false,getcharid(0));
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "Why are you still here?";
		mes "I feel like grabbing you and just hand you to the soldiers.";
		mes "Tsk, This way.";
		close2;
		cutin "",255;
		warp "luna_sf1",258,147;
		end;
	}
end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18336) == 1";
end;
}

jor_crk_p,95,93,3	duplicate(dummynpc)	Ivan#ep21_ivan01	4_EP21_IVAN

luna_sf1,258,151,3	script(CLOAKED)	Ivan#ep21_ivan02	4_EP21_IVAN,{
	if(isbegin_quest(18337) == 1){
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Uhm... Excuse me, where are we...?";
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "This place? We're at the coast near the cult.";
		mes "It's called the Raised Land, it's on the southern side.";
		next;
		cutin "ep172_nillem01.png",1;
		mes "[Nillem]";
		mes "Oh! Is this the famous Raised Land?";
		mes "No wonder the terrain is so jagged.";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Huh? Have you been here before?";
		next;
		cutin "ep172_nillem03.png",1;
		mes "[Nillem]";
		mes "Of course not. It's my first time here. It's a crater that rose from the ground when Jormungandr fell from the sky~.";
		mes "I didn't think expect that we would go here, maybe? But I was kind of looking forward to it-☆";
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "You'll get tired coming in and out of this place when you join the resistance.";
		mes "Beyond this is the last village of the cult, their final stronghold.";
		next;
		cutin "ep19_lehar02.png",2;
		mes "[Lehar]";
		mes "What! Are we in the right place?";
		mes "Are we going to attack the cult's village?";
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "...No. We are heading to the Gaebolg's base. It's called Lunaforma.";
		mes "We stopped by here to check on something.";
		mes "Here they come.";
		next;
		cloaknpc("Resistance Soldier#ep21pt1ex01",false,getcharid(0));
		cutin "ep21_soldier_a.png",2;
		mes "[Resistance Soldier]";
		mes "Oh, Sir Ivan!";
		mes "You have arrived! I have to report something!";
		mes "It's as you said, there has been an increase in deserters from the cult's village.";
		next;
		mes "[Resistance Soldier]";
		mes "We have guided the new recruits to Lunaforma, but a lot were isolated because of the nearby monsters...";
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "We need to support them. I understand. I will go find them.";
		mes "Can you take these people to the commander?";
		mes "They're here to join the resistance.";
		next;
		cutin "ep21_soldier_a.png",2;
		mes "[Resistance Soldier]";
		mes "I understand. I will guide them!";
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "Follow the soldier. I'll see you in the base.";
		next;
		cloaknpc("Ivan#ep21_ivan02",true,getcharid(0));
		mes "[Resistance Soldier]";
		mes "Hey, you three! Follow me this way.";
		cutin "ep21_soldier_a.png",2;
		close2;
		cutin "",255;
		warp "jor_mbase",38,152;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18337) == 1";
end;
}

luna_sf1,258,147,3	script	#ep21p01evt03	HIDDEN_WARP_NPC,3,3,{
	end;

OnTouch:
	if(isbegin_quest(18337) == 1)
		cloaknpc("Ivan#ep21_ivan02",false,getcharid(0));
end;
}

luna_sf1,255,149,5	duplicate(dummynpc)	Resistance Soldier#ep21pt1ex01	4_EP21_SOLDIER_A

jor_mbase,52,151,0	script	#hw_ep21_pn01	HIDDEN_WARP_NPC,4,4,{
    end;

OnTouch:
	if(isbegin_quest(23243) == 1){
		cloaknpc("Tan#ep21_pn_tan01",false,getcharid(0));
		end;
	}
	if(isbegin_quest(23242) == 1){
		cloaknpc("Resistance Soldier#ep21_pn_sol",false,getcharid(0));
		cloaknpc("Nyar#ep21_pn_nyar01",false,getcharid(0));
		cloaknpc("Lehar#ep21_pn_rehar01",false,getcharid(0));
		cloaknpc("Nillem#ep21_pn_nillem01",false,getcharid(0));
		cloaknpc("Tan#ep21_pn_tan01",false,getcharid(0));
		end;
	}
	if(isbegin_quest(23241) == 1){
		cloaknpc("Resistance Soldier#ep21_pn_sol",false,getcharid(0));
		cloaknpc("Nyar#ep21_pn_nyar01",false,getcharid(0));
		cloaknpc("Lehar#ep21_pn_rehar01",false,getcharid(0));
		cloaknpc("Nillem#ep21_pn_nillem01",false,getcharid(0));
		cloaknpc("Tris#ep21_pn_tris01",false,getcharid(0));
		cloaknpc("Tan#ep21_pn_tan01",false,getcharid(0));
		end;
	}
	if(isbegin_quest(18337) == 1 || isbegin_quest(23240) == 1){
		cloaknpc("Freyja Follower#ep21_pr_0",false,getcharid(0));
		cloaknpc("Freyja Follower#ep21_pr_1",false,getcharid(0));
		cloaknpc("Freyja Follower#ep21_pr_2",false,getcharid(0));
		cloaknpc("Freyja Follower#ep21_pr_3",false,getcharid(0));
		cloaknpc("Freyja Follower#ep21_pr_4",false,getcharid(0));
		cloaknpc("Resistance Soldier#ep21_pn_sol",false,getcharid(0));
		cloaknpc("Nyar#ep21_pn_nyar01",false,getcharid(0));
		cloaknpc("Lehar#ep21_pn_rehar01",false,getcharid(0));
		cloaknpc("Nillem#ep21_pn_nillem01",false,getcharid(0));
		cloaknpc("Tris#ep21_pn_tris01",false,getcharid(0));
		cloaknpc("Tan#ep21_pn_tan01",false,getcharid(0));
		end;
	}
end;
}

jor_mbase,39,152,0	duplicate(#hw_ep21_pn01)	#hw_ep21_pn02	HIDDEN_WARP_NPC,4,4

jor_mbase,54,155,3	script(CLOAKED)	Resistance Soldier#ep21_pn_sol	4_EP21_SOLDIER_A,{
	if(isbegin_quest(18337) == 1){
		cutin "ep21_soldier_a.png",2;
		mes "[Resistance Soldier]";
		mes "This is the base of the Gaebolg Resistance, Lunaforma.";
		next;
		mes "[Resistance Soldier]";
		mes "Before sending you to the headquarters, I need to report to the captains first. Wait here for a moment";
		next;
		mes "[Resistance Soldier]";
		mes "Neither of them don't have much free time, so you should consider that you might have to wait a while. ...Huh?";
		next;
		mes "[Resistance Soldier]";
		mes "What's the ruckus, the captain and the vice-captain is right over there.";
		next;
		cutin "",255;
		mes "[Freyja Follower]";
		mes "We need to settle things today. Even if you are the resistance, we won't allow you to insult Freyja any longer!";
		next;
		mes "[Resistance Soldier]";
		mes "...At the moment, it is not a situation where I can report, please wait here for a moment.";
		npctalk "Resistance Soldier: What's going on?","",bc_self;
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "This base is more impressive than what I had imagine. It seems the fight with the cult has already reached the final stage and the system is already in place. But, what is happening...";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "I can't hear them very well, are those people arguing? As soon as they arrived, what is with the ruckus...";
		next;
		cutin "ep172_nillem03.png",0;
		mes "[Nillem]";
		mes "Hm, isn't it during these times when Freyja followers are still in residing in Rune-Midgarts?";
		next;
		mes "[Nillem]";
		mes "And with my genius predictions, I can confidently say that the seperation is near judging from their tone!";
		next;
		mes "[Nillem]";
		mes "Which means, this is a perfect opportunity to witness something that wasn't even recorded in history books. Don't miss it and observe carefully☆";
		next;
		cutin "ep19_lehar07.png",2;
		mes "[Lehar]";
		mes "I don't think this wont end with just a simple argument, what can we say to such serious people?";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Well, will they even listen if we tried to intervene? We should just listen, we should avoid any kind of trouble.";
		next;
		cutin "ep19_lehar07.png",2;
		mes "[Lehar]";
		mes "I can't argue with that, but I want to disagree...";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Argh, forget it. We should find out the reason why they're arguing to understand the situation that we're in.";
		next;
		mes "[Lehar]";
		mes "Since we're from the future, if we bring up a sensitive topic, it would be troublesome for us.";
		next;
		mes "[Lehar]";
		mes "It's clear that there is a deep emotional gap between the Odin and Freyja followers that persists even to the present.";
		next;
		cutin "ep20_nyar05.png",1;
		mes "[Nyar]";
		mes "Meow.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Don't you agree, Nyar? Let's be quiet and listen.";
		completequest 18337;
		setquest 23240;
		questinfo_refresh;
		close3;
	}
	if(isbegin_quest(23240) == 1){
		cutin "ep21_soldier_a.png",2;
		mes "[Resistance Soldier]";
		mes "The situation isn't good, so please wait a moment.";
		close3;
	}
	if(isbegin_quest(23241) == 1){
		cutin "ep21_soldier_a.png",2;
		mes "[Resistance Soldier]";
		mes "Hey! Come over here.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Is everything all sorted out? It's unfortunate that our first meeting with them is during a high tension situation.";
		next;
		mes "[Lehar]";
		mes "If you think it through, they're the captain and vice-captain, the highest rank of the system. Even if we made a good impression on the soldiers or with Ivan, it would be meaningless if we get rejected here.";
		next;
		mes "[Lehar]";
		mes "If we're treated as suspicious, I doubt we'll just be dragged out of here. We need them to hear us out...";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Relax, you're worrying too much.";
		npctalk "Lehar: Maybe I'm just too cautious?","Lehar#ep21_pn_rehar01",bc_self;
		next;
		cutin "ep21_soldier_a.png",2;
		mes "[Resistance Soldier]";
		mes "Sir Ivan has ordered me to bring a group that wants to join the resistance. Based on their attire, he said that they do not appear to be a member of the Jormungandr cult.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Hello. My name is Lehar. As mentioned, we have come to join the resistance, we want to assist you weaken the cult.";
		mes "...As you can see, we're followers of Odin!";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "I'm the wizard Nillem☆ and this adventurer here is, " + strcharinfo(0) + ". We're not suspicious people at all!";
		npctalk "Lehar: Don't say anything weird!","Lehar#ep21_pn_rehar01",bc_self;
		npctalk "Tris: Hahaha!","Tris#ep21_pn_tris01",bc_self;
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Nice to meet you. I'm Tris, the captain of the Gaebolg resistance. This is Tan, the vice-captain.";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes ".......";
		next;
		cutin "ep21_tris05.png",2;
		mes "[Tris]";
		mes "Tan, why don't you say hello?";
		next;
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "Okay.";
		next;
		cutin "ep21_tris09.png",2;
		mes "[Tris]";
		mes "Tan is the bit shy. Please don't take it personally. He means no harm~";
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "This seems beyond of just being shy...";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "If you're joining the resistance, I'm sure you know the cult is at a significant disadvantage right now.. the outcome depends heavily on the strategies that we will come up with.";
		next;
		cutin "ep21_tris03.png",2;
		mes "[Tris]";
		mes "Since we're in such a critical time, We're more than glad to welcome you in the resistance. Perfect timing!";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "I'm confident that we'll win, with this much people who share our cause. Thank you for coming.";
		next;
		mes "[Tris]";
		mes "We're quite short-handed around here, so it's great that you've come.. There are so many areas that needs filling, I wonder where should I send you...";
		next;
		mes "[Tris]";
		mes "At first, we were really short on manpower so those who are free did whatever they could do, but now the Gaebolg resistance is fairly organized.";
		next;
		mes "[Tris]";
		mes "It's better if everyone makes the most out of their talent, I think we'll need some time to get to know you first. It would be a waste to assign paperworks to someone strong, right?";
		next;
		mes "[Tris]";
		mes "Well... it's probably best if you head to the Richard Mercenary Group first. People with combat skills are always needed.";
		next;
		mes "[Tris]";
		mes "You can receive basic training, get accustomed to the atmosphere of the resistance... yes, it sounds great! So, shall we head to the mercenary group together right now?";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Are you going youself? It's not that important, leave it to someone else.";
		next;
		cutin "ep21_tris07.png",2;
		mes "[Tris]";
		mes "Now that you've mentioned it, I won't have the time to get my armor repaired later... Then, I'll let Tan here take you to the mercenary group. That should work, right?";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Why? No. Why should I...";
		next;
		cutin "ep21_tris09.png",2;
		mes "[Tris]";
		mes "Huh? This isn't a request, it's an order from your captain. Move along, vice-captain Tan!";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Wait, Tris!";
		next;
		cutin "ep21_tris09.png",2;
		mes "[Tris]";
		mes "I have a lot of work to do, so off I go! I'll go check on them later, so make sure you actually take them there~";
		next;
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "Sigh...";
		completequest 23241;
		setquest 23242;
		questinfo_refresh;
		close2;
		cutin "",255;
		cloaknpc("Tris#ep21_pn_tris01",true,getcharid(0));
		end;
	}
	if(isbegin_quest(23242) > 0){
		cutin "ep21_soldier_a.png",2;
		mes "[Resistance Soldier]";
		mes "Do you have any questions?";
		next;
		switch(select("Freyja Followers Conflict","Local Specialties","None.")){
			case 1:
				mes "[Resistance Soldier]";
				mes "You really don't know anything about the followers of Freyja? Where did you even come from...";
				next;
				mes "[Resistance Soldier]";
				mes "They are the people who believe in the deity Freyja. Although they follow a different deity, they aren't all that different from us.";
				next;
				mes "[Resistance Soldier]";
				mes "The resistance has promoted Odin which caused the Freyja's position to fall, to them it highlighted a fanatic aspect. Though it wasn't like that even from the beginning.";
				break;

			case 2:
				mes "[Resistance Soldier]";
				mes "As for specialties... It's probably the seafood caught in the surrounding sea is the most common.";
				next;
				mes "[Resistance Soldier]";
				mes "Some fish are poisonous, so be careful not to eat just any fish. Antidotes are scarce around here.";
				break;

			case 3:
				mes "[Resistance Soldier]";
				mes "Understood.";
				break;
		}
		close3;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18337) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23241) == 1";
end;
}

jor_mbase,56,152,3	script(CLOAKED)	Tris#ep21_pn_tris01	4_EP21_TRIS,{
	if(isbegin_quest(18337) == 1){
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Heine said that if we wait here, a group of benefactors will come, when are they coming?";
		next;
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "Benefactors... ";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "We have been tricked like this more than once, why do you still believe him every time?";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Heine is always vague, but he has never been wrong, right?";
		next;
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "I'm just saying, he knows everything but he never explain it properly on purpose, it's annoying...";
		close3;
	}
	if(isbegin_quest(23240) == 1){
		mes "[Freyja Follower]";
		mes "We have been patient for a long time because we know the importance of the people's assurance and unity, but we can't take it any longer.";
		next;
		mes "[Freyja Follower]";
		mes "They Jormungandr cult is already cornered, but aren't you rallying only using Odin's name alone?";
		next;
		mes "[Freyja Follower]";
		mes "At this rate, all the achievements will be credited solely to the name of Odin, we must regain Freya's rightful glory before it's too late.";
		next;
		mes "[Freyja Follower]";
		mes "We will not back down today. We need answers.";
		next;
		cutin "ep21_tris03.png",2;
		mes "[Tris]";
		mes "I do not entirely disagree with the position of the Freyja followers, but I think this is a matter that requires careful consideration.";
		next;
		mes "[Tris]";
		mes "The resistance is constantly pondering ways to satisfy the Freyja followers without disrupting the current system. It's just taking time to find the best solution, but we haven't forgotten.";
		next;
		mes "[Tris]";
		mes "It's true that the matter has been postponed because the battle with the cult takes priority, now is a critical time to strategize and defeat the cult.";
		next;
		mes "[Tris]";
		mes "If you could give us a little more time, at least until the next battle is over, we'll have the time to sit down and talk calmly...";
		next;
		cutin "",255;
		mes "[Freyja Follower]";
		mes "Do you think we'll be fooled by that again? When is the best time you speak of? Haven't you postponed the last time exactly like this?";
		next;
		mes "[Freyja Follower]";
		mes "We must settle things today. If we don't do this, Odin will surely become the only deity that the people will follow.";
		next;
		mes "[Freyja Follower]";
		mes "Although it's far from compensation for our patience, we could have a compromise if you'll give us a settlement untouched by the cult.";
		next;
		cutin "ep21_tris03.png",2;
		mes "[Tris]";
		mes "Say we did that, it will bring another chaos after the liberation. We need a thorough discussion about the people with all the necessary members.";
		next;
		cutin "",255;
		mes "[Freyja Follower]";
		mes "Freyja is the only deity who fought on the side of humans, and you simply expect us to just stand by while you people ignore such deity?";
		next;
		mes "[Freyja Follower]";
		mes "We cannot accept that the resistance is using this war as means to promote Odin and maintain power. We will no longer follow the resistance.";
		next;
		mes "[Freyja Follower]";
		mes "You will surely pay the price for turning a blind eye to the truth for momentary gains!";
		next;
		cutin "ep21_tris03.png",2;
		mes "[Tris]";
		mes "Wait, let's talk a little more...!";
		next;
		cutin "",255;
		mes "[Freyja Follower]";
		mes "No! We have nothing more to say. Handle everything yourselves!";
		next;
		cloaknpc("Freyja Follower#ep21_pr",true,getcharid(0));
		cloaknpc("Freyja Follower#ep21_pr",true,getcharid(0));
		cloaknpc("Freyja Follower#ep21_pr",true,getcharid(0));
		cloaknpc("Freyja Follower#ep21_pr",true,getcharid(0));
		cloaknpc("Freyja Follower#ep21_pr",true,getcharid(0));
		cutin "ep21_tris02.png",2;
		mes "[Tris]";
		mes "...I don't think we should just let them go.";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Let them do as they please. ";
		next;
		mes "[Tan]";
		mes "The battle with the cult is not over yet, and I'm sick of seeing both sides care for their own safety...";
		next;
		cutin "ep21_tris02.png",2;
		mes "[Tris]";
		mes "As the resistance grows in size, there's so much more to worry about. Is there really no way to satisfy everyone...";
		next;
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "I'm tired...";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "The story of Freyja and Odin's followers reaching it's peak and the Freyjas followers began to search for a new frontier.";
		next;
		mes "[Lehar]";
		mes "So this is how it happened... Everyone is on the edge, we better stay calm and stay out of their way. Let's give them enough time to organize their thoughts.";
		completequest 23240;
		setquest 23241;
		questinfo_refresh;
		close3;
	}
	if(isbegin_quest(23241) == 1){
		cutin "ep21_tris02.png",2;
		mes "[Tris]";
		mes "It's because I'm lacking...";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Stop with the unnecessary self-depracation.";
		next;
		cutin "ep21_tris02.png",2;
		mes "[Tris]";
		mes "Haha... thank you for worrying about me.";
		close3;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23240) == 1";
end;
}

jor_mbase,57,150,3	script(CLOAKED)	Tan#ep21_pn_tan01	4_EP21_TAN,{
	if(isbegin_quest(18337) == 1){
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "Curse this, I knew this would happen. Like benefactors would magically appear...";
		close3;
	}
	if(isbegin_quest(23240) == 1){
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "It hasn't been a day yet, It's already getting tiresome...";
		next;
		mes "[Freyja Follower]";
		mes "You, did I heard that correctly?";
		cutin "",255;
		next;
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "Sigh...";
		close3;
	}
	if(isbegin_quest(23241) == 1){
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "It hasn't been a day yet, It's already getting tiresome...";
		close3;
	}
	if(isbegin_quest(23242) == 1){
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Sigh...";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "What is he thinking, just accepting anyone without a hint of suspicion.";
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "We can hear you...";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "I'm saying it so you can hear it. The only reason we're accepting you is because Tris decided it, but not for any special reason.";
		next;
		mes "[Tan]";
		mes "Just to be clear, I don't like you. Strangers with hidden agendas will only result in trouble... If you're going to dropout halfway, better quit now.";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Oh, you're too harsh. I get hurt easily, you know?";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "I don't know why you suddenly volunteered to join, but if you came here with such careless attitude, go back to where you came from right now.";
		next;
		mes "[Tan]";
		mes "We're not so desperate here to that we'd hold on to useless hands.";
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "Do you know how much we've been through several share of life and death battles? Aren't you looking down on us?";
		next;
		cutin "ep21_tan02.png",2;
		mes "[Tan]";
		mes "How reassuring... If you manage to not drop out of the Richard Mercenary Group, I might reconsider my initial judgement.";
		next;
		cutin "ep21_tan01.png",2;
		mes "[Tan]";
		mes "We're heading to the <NAVI>[Richard Mercenary Group]<INFO>jor_mbase,313,106,0,101,0</INFO></NAVI>. As Tris ordered, you'd help out there first.";
		next;
		if(select("We'll go right away.","Wait a moment.") == 1){
			mes "[Tan]";
			mes "Follow me, I'll leave you behind if you failed to keep up.";
			navigateto("jor_mbase",313,106);
		} else {
			cutin "ep21_tan02.png",2;
			mes "[Tan]";
			mes "What a hassle...";
		}
		completequest 23242;
		setquest 23243;
		questinfo_refresh;
		close3;
	}
	if(isbegin_quest(23243) == 1){
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "We're heading to the <NAVI>[Richard Mercenary Group]<INFO>jor_mbase,313,106,0,101,0</INFO></NAVI>. I'll leave you behind if you failed to keep up.";
		close3;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23242) == 1";
end;
}

jor_mbase,47,148,5	script(CLOAKED)	Nyar#ep21_pn_nyar01	4_EP20_NYAR,{
	cutin "ep20_nyar03.png",1;
	mes "[Nyar]";
	mes "Meow.";
	close3;
}

jor_mbase,46,151,5	script(CLOAKED)	Lehar#ep21_pn_rehar01	4_EP19_LEHAR,{
	if(isbegin_quest(18337) == 1){
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "This is Lunaforma, the resistance's base! It smells salty like we are on a beach.";
		next;
		mes "[Lehar]";
		mes "I can hear people fighting, looks like it's coming from the seaside... Is it only me?";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Those people over there, no matter how much you look at it, they are fighting, right?";
		close3;
	}
	if(isbegin_quest(23240) == 1){
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "It's ironic whether it's perfect timing or just bad luck, to arrive such a time just before they start arguing...";
		next;
		mes "[Lehar]";
		mes "I want to greet them, but it worries me since everyone is on the edge.";
		close3;
	}
	if(isbegin_quest(23241) == 1){
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "It ended just like that...";
		next;
		mes "[Lehar]";
		mes "Witnessing it firsthand, I think I can understand the feelings of the Freyja Followers during these times.";
		close3;
	}
	if(isbegin_quest(23241) == 2){
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "The vice-captain, isn't he a bit too harsh?";
		next;
		mes "[Lehar]";
		mes "Grrrr! No matter what the resistance throws at me, I'm going to do it perfectly and make him eat his words!";
		close3;
	}
	end;
}

jor_mbase,47,154,5	script(CLOAKED)	Nillem#ep21_pn_nillem01	4_M_NILLEM,{
	if(isbegin_quest(18337) == 1){
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "There were some ups and downs, but we finally arrived. Who knew getting to the resistance base would be such a challenge~";
		close3;
	}
	if(isbegin_quest(23240) == 1){
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "Shh, quiet! Now is not the time, even if it's you. Opportunities like this don't come by easily, so listen carefully, got it?";
		next;
		cutin "ep172_nillem03.png",0;
		mes "[Nillem]";
		mes "There's nothing more entertaining in this world than watching a fire from across the river☆";
		close3;
	}
	if(isbegin_quest(23241) == 1){
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "The Freyja Followers during this era couldn't possibly imagine what their descendants would go through in the future, could they?";
		next;
		mes "[Nillem]";
		mes "It's an exaggeration, but... it makes me think that humans are just swept by the flow of history. Ah, how frightening.";
		close3;
	}
	if(isbegin_quest(23242) == 1){
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Hm, Tan... who could it be? There's no way I'd overlook as someone as high as vice-captain.";
		next;
		mes "[Nillem]";
		mes "No matter how much I try to remember, there's definitely no such name in the history books. There's no way my memory could be wrong.";
		next;
		cutin "ep172_nillem06.png",0;
		mes "[Nillem]";
		mes "Oh?";
		mes "...Ah?";
		mes "Oh, Aha...";
		mes "So that's what happened?";
		next;
		select("What is it?");
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "Ahaha, so there was something like that. Sigh~ It seems like the genius wizard Nillem has solved yet another mystery! What should I do with all this intelligence.";
		next;
		select("What?");
		cutin "ep172_nillem03.png",0;
		mes "[Nillem]";
		mes "Hahaha, it's a secret~☆";
		close3;
	}
	end;
}

jor_mbase,51,152,5	script(CLOAKED)	Freyja Follower#ep21_pr_0	4_M_MASK1,{
	if(isbegin_quest(18337) == 1)
    	npctalk "How long must we endure for the name of Odin!","",bc_self;
    end;
}

jor_mbase,51,150,7	script(CLOAKED)	Freyja Follower#ep21_pr_1	4_M_MASK1,{
	if(isbegin_quest(18337) == 1)
    	npctalk "We can't wait any longer!","",bc_self;
    end;
}

jor_mbase,52,148,7	script(CLOAKED)	Freyja Follower#ep21_pr_2	4_M_MASK,{
	if(isbegin_quest(18337) == 1)
    	npctalk "We will not let you disgrace Freyja any longer!","",bc_self;
    end;
}

jor_mbase,53,150,7	script(CLOAKED)	Freyja Follower#ep21_pr_3	4_F_MASK,{
	if(isbegin_quest(18337) == 1)
    	npctalk "Glory to Freyja!","",bc_self;
    end;
}

jor_mbase,53,153,5	script(CLOAKED)	Freyja Follower#ep21_pr_4	4_F_MASK1,{
	if(isbegin_quest(18337) == 1)
    	npctalk "Do you intend to erase the existence of Freyja!","",bc_self;
    end;
}

jor_mbase,313,106,0	script	#ep21_startpoint	HIDDEN_WARP_NPC,3,3,{
	end;
	
OnTouch:
	if(isbegin_quest(23243) == 1){
		cutin "ep21_tan01.png",0;
		mes "[Tan]";
		mes "Up ahead is the ^e5555emercenary group's^000000 office.";
		mes "Tell the man named ^e5555eRichard^000000 that I sent you, and he'll tell you what to do next.";
		cloaknpc("Tan#ep21_start",false,getcharid(0));
		cloaknpc("Lehar#ep21_start",false,getcharid(0));
		cloaknpc("Nillem#ep21_start",false,getcharid(0));
		next;
		cutin "ep21_tan05.png",0;
		mes "[Tan]";
		mes "For now, I'll just observe to see where you can be useful.";
		emotion ET_STARE,getnpcid(0,"Tan#ep21_start");
		next;
		mes "[Tan]";
		mes "I hope you would stay put and don't go poking around.";
		npctalk "Nillem : Please treat us nicely.","Nillem#ep21_start",bc_self;
		emotion ET_HUK,getnpcid(0,"Lehar#ep21_start");
		emotion ET_HUK,getnpcid(0,"Nillem#ep21_start");
		emotion ET_HUK,getcharid(3);
		next;
		cutin "ep19_lehar06.png",2;
		mes "[Lehar]";
		mes "Richard…";
		mes "Do you mean Richard, the mercenary king?";
		npctalk "Lehar : I read about him in a book!!","Lehar#ep21_start",bc_self;
		cutin "ep19_lehar07.png",2;
		next;
		mes "[Lehar]";
		mes "It's kind of thrilling to keep encountering historical figures… Let's go quickly!";
		emotion ET_COOL,getnpcid(0,"Lehar#ep21_start");
		completequest 23243;
		setquest 24000;
		close2;
		cutin "",255;
		navigateto("mbase_in",289,124);
		cloaknpc("Tan#ep21_start",true,getcharid(0));
		cloaknpc("Lehar#ep21_start",true,getcharid(0));
		cloaknpc("Nillem#ep21_start",true,getcharid(0));
		end;
	}
	if(isbegin_quest(24000) == 1){
		cloaknpc("Tan#ep21_start",false,getcharid(0));
		cutin "ep21_tan01.png",0;
		mes "[Tan]";
		mes "Up ahead is the ^e5555emercenary group's^000000 office.";
		mes "Tell the man named ^e5555eRichard^000000 that I sent you, and he'll tell you what to do next.";
		close2;
		cutin "",255;
		cloaknpc("Tan#ep21_start",true,getcharid(0));
		navigateto("mbase_in",289,124);
		end;
	}
end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23243) == 1";
end;
}

jor_mbase,313,106,3	duplicate(dummynpc)	Tan#ep21_start	4_EP21_TAN
jor_mbase,312,103,7	duplicate(dummynpc)	Lehar#ep21_start	4_EP19_LEHAR
jor_mbase,310,105,7	duplicate(dummynpc)	Nillem#ep21_start	4_M_NILLEM

mbase_in,289,124,0	script	#ep21_mercgroup	HIDDEN_WARP_NPC,5,5,{
	end;

OnTouch:
	if(isbegin_quest(18360) < 2)
		cloaknpc("Lee#ep21_addquest",true,getcharid(0));
	if(isbegin_quest(24000) == 1){
		cloaknpc("Valdaris#ep21_mercgroup",true,getcharid(0));
		cloaknpc("Mercenary Member#ep21_mercgroup1",true,getcharid(0));
		cloaknpc("Mercenary Member#ep21_mercgroup2",true,getcharid(0));
		cloaknpc("Mercenary Member#ep21_mercgroup3",true,getcharid(0));
		cloaknpc("Mercenary Member#ep21_mercgroup4",true,getcharid(0));
		cloaknpc("Mercenary Member#ep21_mercgroup5",true,getcharid(0));
		cloaknpc("Mercenary Member#ep21_mercgroup6",true,getcharid(0));
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Is anyone here?";
		cloaknpc("Lehar#ep21_mercgroupent",false,getcharid(0));
		cloaknpc("Nillem#ep21_mercgroupent",false,getcharid(0));
		next;
		cutin "ep19_lehar02.png",2;
		mes "[Lehar]";
		mes "Hello?";
		next;
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "What's this place~!";
		mes "Is there anyone here?";
		mes "It looks like everyone's out.";
		mes "Isn't this place empty?";
		emotion ET_STARE_ABOUT,getnpcid(0,"Nillem#ep21_mercgroupent");
		next;
		cutin "ep19_lehar07.png",2;
		mes "[Lehar]";
		mes "Maybe?";
		mes "Sigh~ They told us to come here…";
		mes "What should we do?";
		mes "Should we just wait here?";
		mes "Maybe someone will come if we wait for some time?";
		emotion ET_CRY,getnpcid(0,"Lehar#ep21_mercgroupent");
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Is it fine if we stayed in an empty office?";
		next;
		cutin "ep19_lehar07.png",2;
		mes "[Lehar]";
		mes "Tan told us to come here, so…";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "That's true, but…";
		mes "It feels a bit off…";
		next;
		cutin "ep19_lehar07.png",2;
		mes "[Lehar]";
		mes "We don't have anywhere else to go.";
		mes "We might get kicked out if we wander around.";
		next;
		cutin "ep19_lehar04.png",2;
		mes "[Lehar]";
		mes "Truthfully, I'm also thinking that we might as well wander around instead of wasting our time here, right? At first that's what I thought";
		mes "But it doesn't seem like they completely trust us yet, if we wander around and lose what little trust they have, we might get in trouble with my Aunt who isn't even here. So let's just stay put for a while.";
		emotion ET_HUK,getnpcid(0,"Lehar#ep21_mercgroupent");
		next;
		cutin "ep172_nillem03.png",0;
		mes "[Nillem]";
		mes "Yes… you're right.";
		mes "I get it, so let's calm down and breath.";
		mes "You might pass out.";
		emotion ET_PROFUSELY_SWAT,getnpcid(0,"Nillem#ep21_mercgroupent");
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Let's sit over there for a bit<FONT SIZE = 14>…Huh?</FONT>";
		npctalk "Nillem : Huh?","Nillem#ep21_mercgroupent",bc_self;
		cloaknpc("???#ep21_mercgroup",false,getcharid(0));
		specialeffect EF_RG_COIN7,AREA,"???#ep21_mercgroup";
		next;
		cloaknpc("???#ep21_mercgroup",true,getcharid(0));
		removespecialeffect EF_RG_COIN7,AREA,"???#ep21_mercgroup";
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "What's wrong?";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Hm… I thought…";
		mes "Nevermind.";
		mes "Maybe it's just my imagination?";
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "If it's nothing, please stop saying ‘huh?’.";
		next;
		cutin "ep172_nillem04.png",2;
		mes "[Nillem]";
		mes "<FONT SIZE = 14>Huh…?</FONT>";
		cloaknpc("???#ep21_mercgroup",false,getcharid(0));
		specialeffect EF_RG_COIN7,AREA,"???#ep21_mercgroup";
		next;
		cloaknpc("???#ep21_mercgroup",true,getcharid(0));
		removespecialeffect EF_RG_COIN7,AREA,"???#ep21_mercgroup";
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "?";
		next;
		cutin "ep172_nillem03.png",0;
		mes "[Nillem]";
		mes "Wait… something feels off about this space…";
		npctalk "Nillem : It's strange.","Nillem#ep21_mercgroupent",bc_self;
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Something off?";
		mes "Is something here?";
		mes "I don't see anything…";
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "Hm… there, look closely.";
		mes "There's something strange.";
		mes "It's something faint…";
		cloaknpc("???#ep21_mercgroup",false,getcharid(0));
		specialeffect EF_RG_COIN7,AREA,"???#ep21_mercgroup";
		next;
		cloaknpc("???#ep21_mercgroup",true,getcharid(0));
		removespecialeffect EF_RG_COIN7,AREA,"???#ep21_mercgroup";
		cutin "ep19_lehar02.png",2;
		mes "[Lehar]";
		mes "Heh~";
		mes "If you're trying to scame me since no one's here, I'm sorry to disappoint you, but I'm not afraid of ghosts.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "If a ghost appears, I'll blow them away with my holy powers!!!";
		mes "<FONT SIZE = 14>Bring it on!!!</FONT>";
		next;
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "I'm not kidding… just now, did you see it?";
		mes "The blanket moved a little…";
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "<FONT SIZE = 16><B>Eeeek!!!</B></FONT>";
		npctalk "Nillem : Eeeek!!!","Nillem#ep21_mercgroupent",bc_self;
		npctalk "Lehar : Waaaah!!!","Lehar#ep21_mercgroupent",bc_self;
		emotion ET_HUK,getnpcid(0,"Nillem#ep21_mercgroupent");
		emotion ET_HUK,getnpcid(0,"Lehar#ep21_mercgroupent");
		cloaknpc("???#ep21_mercgroup",false,getcharid(0));
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "<FONT SIZE = 16><B>Waaaah!!!</B></FONT>";
		npctalk "Lehar : What… what's that!","Lehar#ep21_mercgroupent",bc_self;
		next;
		cutin "ep21_gunter01.png",2;
		mes "[???]";
		mes "…?";
		emotion ET_QUESTION,getnpcid(0,"???#ep21_mercgroup");
		next;
		mes "[???]";
		mes "What…";
		next;
		mes "[???]";
		mes "So noisy…";
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "<FONT SIZE = 14>Wh… what's that!!!</FONT>";
		next;
		cutin "ep21_gunter01.png",2;
		mes "[???]";
		mes "?";
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "<FONT SIZE = 14><B>^e5555e- Heal -^000000</B></FONT>";
		specialeffect EF_HEAL2,AREA,"???#ep21_mercgroup";
		emotion ET_SURPRISE,getnpcid(0,"???#ep21_mercgroup");
		next;
		removespecialeffect EF_HEAL2,AREA,"???#ep21_mercgroup";
		cutin "ep21_gunter01.png",2;
		mes "[???]";
		mes "??";
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "^4e4e4e(It's probably not a ghost if healing doesn't deal damage.)^000000";
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "^4e4e4e(Phew… it's probably human, right? But if he's in this room, then is he the Mercenary King Richard?)^000000";
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "^4e4e4e(He looks a smaller than the description of the books I saw in the library… history does tend to exaggerate things sometimes… we're not sure, so should we ask? At the least he is not attacking us…)^000000";
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "^4e4e4e(" + strcharinfo(0) + ".";
		mes strcharinfo(0) + ", ask him.";
		mes "Quickly.)^000000";
		completequest 24000;
		setquest 24001;
		questinfo_refresh;
		close2;
		cutin "",255;
		navigateto("mbase_in",292,127);
		end;
	}
	if(isbegin_quest(24001) == 1){
		cloaknpc("Lehar#ep21_mercgroupent",false,getcharid(0));
		cloaknpc("Nillem#ep21_mercgroupent",false,getcharid(0));
		cloaknpc("???#ep21_mercgroup",false,getcharid(0));
		cloaknpc("Valdaris#ep21_mercgroup",true,getcharid(0));
		cloaknpc("Mercenary Member#ep21_mercgroup1",true,getcharid(0));
		cloaknpc("Mercenary Member#ep21_mercgroup2",true,getcharid(0));
		cloaknpc("Mercenary Member#ep21_mercgroup3",true,getcharid(0));
		cloaknpc("Mercenary Member#ep21_mercgroup4",true,getcharid(0));
		cloaknpc("Mercenary Member#ep21_mercgroup5",true,getcharid(0));
		cloaknpc("Mercenary Member#ep21_mercgroup6",true,getcharid(0));
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "<FONT SIZE = 16><B>Eeeek!!!</B></FONT>";
		npctalk "Nillem : Eeeek!!!","Nillem#ep21_mercgroupent",bc_self;
		npctalk "Lehar : Waaaah!!!","Lehar#ep21_mercgroupent",bc_self;
		emotion ET_HUK,getnpcid(0,"Nillem#ep21_mercgroupent");
		emotion ET_HUK,getnpcid(0,"Lehar#ep21_mercgroupent");
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "<FONT SIZE = 16><B>Waaaah!!!</B></FONT>";
		npctalk "Lehar : What… what's that!","Lehar#ep21_mercgroupent",bc_self;
		next;
		cutin "ep21_gunter01.png",2;
		mes "[???]";
		mes "…?";
		emotion ET_QUESTION,getnpcid(0,"???#ep21_mercgroup");
		next;
		mes "[???]";
		mes "What…";
		next;
		mes "[???]";
		mes "So noisy…";
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "<FONT SIZE = 14>Wh… what's that!!!</FONT>";
		next;
		cutin "ep21_gunter01.png",2;
		mes "[???]";
		mes "?";
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "<FONT SIZE = 14><B>^e5555e- Heal -^000000</B></FONT>";
		specialeffect EF_HEAL2,AREA,"???#ep21_mercgroup";
		emotion ET_SURPRISE,getnpcid(0,"???#ep21_mercgroup");
		next;
		removespecialeffect EF_HEAL2,AREA,"???#ep21_mercgroup";
		cutin "ep21_gunter01.png",2;
		mes "[???]";
		mes "??";
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "^4e4e4e(It's probably not a ghost if healing doesn't deal damage.)^000000";
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "^4e4e4e(Phew… it's probably human, right? But if he's in this room, then is he the Mercenary King Richard?)^000000";
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "^4e4e4e(He looks a smaller than the description of the books I saw in the library… history does tend to exaggerate things sometimes… we're not sure, so should we ask? At the least he is not attacking us…)^000000";
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "^4e4e4e(" + strcharinfo(0) + ".";
		mes strcharinfo(0) + ", ask him.";
		mes "Quickly.)^000000";
		close2;
		cutin "",255;
		navigateto("mbase_in",292,127);
		end;
	}
	if(isbegin_quest(24002) == 1){
		mes "- There's no one here. Let's go to <NAVI>[Richard's Room]<INFO>mbase_in,113,120,0,101,0</INFO></NAVI>. -";
		close2;
		navigateto("mbase_in",113,120);
		end;
	}
	if(isbegin_quest(24004) == 1){
		cloaknpc("Valdaris#ep21_mercgroup",true,getcharid(0));
		cloaknpc("???#ep21_Valdaris",false,getcharid(0));
		cloaknpc("Lehar#ep21_mercgroupent",false,getcharid(0));
		cloaknpc("Nillem#ep21_mercgroupent",false,getcharid(0));
		cutin "ep21_valdaris01.png",2;
		mes "[???]";
		mes "Where's the captain?";
		next;
		npctalk "Mercenary Member : Vice-captain Valdaris, there's a huge pile of paperwork again today.","Mercenary Member#ep21_mercgroup1",bc_self;
		npctalk "Mercenary Member : Vice-captain, why did you come back so late!!","Mercenary Member#ep21_mercgroup5",bc_self;
		npctalk "Mercenary Member : Please check the supplies!!","Mercenary Member#ep21_mercgroup6",bc_self;
		cutin "ep21_soldier_a.png",2;
		mes "[Mercenary Member]";
		mes "He's not here.";
		next;
		cutin "ep21_soldier_b.png",2;
		mes "[Mercenary Member]";
		mes "I haven't seen him.";
		next;
		cutin "ep21_valdaris03.png",2;
		mes "[Valdaris]";
		mes "<FONT SIZE = 14><B>Where in the world has that person gone this time!</B></FONT>";
		emotion ET_FRET,getnpcid(0,"???#ep21_Valdaris");
		next;
		mes "[Valdaris]";
		mes "Then, has anyone seen Nerius?";
		next;
		cutin "ep21_soldier_b.png",2;
		mes "[Mercenary Member]";
		mes "<FONT SIZE = 14><B>No!</B></FONT>";
		next;
		cutin "ep21_valdaris03.png",2;
		mes "[Valdaris]";
		mes "Sigh…";
		emotion ET_HNG,getnpcid(0,"???#ep21_Valdaris");
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "There was no one here earlier, how come there are some people around suddenly?";
		mes "Maybe we should've just waited here…";
		next;
		cutin "ep21_valdaris01.png",2;
		mes "[Valdaris]";
		mes "Ah!";
		mes "Over here.";
		mes "I apologize for the wait.";
		next;
		mes "[Valdaris]";
		mes "If Tan sent you, you'll need go through the registration process.";
		mes "Please fill out the ^e5555eform^000000 over there and hand it to me once you're done.";
		npctalk "Valdaris : If you have any questions while filling out, feel free to ask.","???#ep21_Valdaris",bc_self;
		cloaknpc("???#ep21_Valdaris",true,getcharid(0));
		cloaknpc("Valdaris#ep21_mercgroup",false,getcharid(0));
		next;
		cutin "ep21_valdaris02.png",2;
		mes "[Valdaris]";
		mes "If you have any questions while filling out, feel free to ask.";
		completequest 24004;
		setquest 24005;
		questinfo_refresh;
		close2;
		cloaknpc("Lehar#ep21_mercgroupent",true,getcharid(0));
		cloaknpc("Nillem#ep21_mercgroupent",true,getcharid(0));
		cutin "",255;
		navigateto("mbase_in",299,126);
		end;
	}
	if(isbegin_quest(24005) == 1){
		mes "Let's fill out the ^e5555eform^000000 and hand it to Valdaris.";
		close;
		navigateto("mbase_in",299,126);
		end;
	}
end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24000) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24004) == 1";
end;
}

mbase_in,292,127,3	script(CLOAKED)	???#ep21_mercgroup	4_EP21_GUNTER,{
	if(isbegin_quest(24001) == 1){
		select("We came to see the Mercenary King Richard.");
		cutin "ep21_gunter01.png",2;
		mes "[???]";
		mes "…";
		next;
		select("Tan sent us.");
		mes "[???]";
		mes "…";
		mes "He's not here.";
		next;
		cutin "ep19_lehar04.png",2;
		mes "[Lehar]";
		mes "Then where?";
		next;
		cutin "ep21_gunter01.png",2;
		mes "[???]";
		mes "I don't know.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Then, do you know when Richard might return?";
		mes "We really need to meet him.";
		next;
		cutin "ep21_gunter01.png",2;
		mes "[???]";
		mes "…";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "If you don't know when he'll return, is it alright if we wait here?";
		mes "It's difficult for us to go somewhere else.";
		next;
		cutin "ep21_gunter01.png",2;
		mes "[???]";
		mes "…";
		mes "Central barracks.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "What?";
		mes "Central barracks?";
		next;
		cutin "ep21_gunter01.png",2;
		mes "[???]";
		mes "The room on the right end…";
		next;
		mes "[???]";
		mes "It's Richard's room…";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Uhm… Thank you…";
		emotion ET_ANGER,getnpcid(0,"Lehar#ep21_mercgroupent");
		emotion ET_ANGER,getnpcid(0,"Nillem#ep21_mercgroupent");
		next;
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "Let's head over there.";
		mes "Surely~ They won't mind us going there, right?";
		completequest 24001;
		setquest 24002;
		close2;
		cutin "",255;
		cloaknpc("???#ep21_mercgroup",true,getcharid(0));
		cloaknpc("Lehar#ep21_mercgroupent",true,getcharid(0));
		cloaknpc("Nillem#ep21_mercgroupent",true,getcharid(0));
		navigateto("mbase_in",113,120);
		end;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24001) == 1";
end;
}

mbase_in,286,124,6	duplicate(dummynpc)	Lehar#ep21_mercgroupent	4_EP19_LEHAR
mbase_in,288,126,4	duplicate(dummynpc)	Nillem#ep21_mercgroupent	4_M_NILLEM

mbase_in,113,120,0	script	#in_richard	WARPNPC,2,2,{
	if(isbegin_quest(24013) > 0){
		warp "mbase_in",166,126;
		end;
	}
	if(isbegin_quest(24002) == 1 || isbegin_quest(24003) == 1){
		mes "- Knock Knock -";
		cloaknpc("Lehar#ep21_frontroom",false,getcharid(0));
		cloaknpc("Nillem#ep21_frontroom",false,getcharid(0));
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "There's no response here either.";
		mes "Is there no one here?";
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "<FONT SIZE = 14>We can't just simply leave again this time!</FONT>";
		mes "The next room! Let's check the next room, someone might be there.";
		if(isbegin_quest(24002) == 1){
			completequest 24002;
			setquest 24003;
			questinfo_refresh;
		}
		close2;
		cutin "",255;
		navigateto("mbase_in",113,114);
		end;
	}
	mes "- The door is locked. -";
	close;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24002) == 1";
end;
}

mbase_in,109,117,6	duplicate(dummynpc)	Lehar#ep21_frontroom	4_EP19_LEHAR
mbase_in,109,115,6	duplicate(dummynpc)	Nillem#ep21_frontroom	4_M_NILLEM

mbase_in,113,114,0	script	#in_galaxia	WARPNPC,2,2,{
	if(isbegin_quest(24016) > 0){
		warp "mbase_in",165,81;
		end;
	}
	if(isbegin_quest(24003) == 1){
		mes "^ff3366<FONT SIZE = 16><B>>> >>Restricted Area<< <<</B></FONT>";
		mes "<FONT SIZE = 16><B>Entry for authorized personnel only.</B></FONT>";
		mes "<FONT SIZE = 16><B>Entering may cause you serious injury.</B></FONT>^000000";
		cloaknpc("Lehar#ep21_frontroom",false,getcharid(0));
		cloaknpc("Nillem#ep21_frontroom",false,getcharid(0));
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Oh… wow…";
		mes "What an intimidating warning right after knocking…";
		emotion ET_HUK,getnpcid(0,"Lehar#ep21_frontroom");
		emotion ET_HUK,getnpcid(0,"Nillem#ep21_frontroom");
		emotion ET_HUK,getcharid(3);
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "<FONT SIZE = 14>Why are you getting scared!</FONT>";
		mes "<FONT SIZE = 14>We're not so weak that we'd get scared by something like this!</FONT>";
		next;
		cutin "ep19_lehar02.png",2;
		mes "[Lehar]";
		mes "Nillem, you're the one who screamed <FONT SIZE = 14><B>waaaaah</B></FONT> earlier!";
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "It's not what you think!";
		mes "It's because I was startled!";
		next;
		mes "[Nillem]";
		mes "Anyways, it says it's for authorized personnel only, so shouldn't we go get permission first to go in!?";
		next;
		cloaknpc("???#ep21_frontroom",false,getcharid(0));
		cutin "",255;
		mes "- Knock Knock -";
		next;
		mes "[???]";
		mes "Who are you?";
		emotion ET_SURPRISE,getnpcid(0,"Lehar#ep21_frontroom");
		emotion ET_SURPRISE,getnpcid(0,"Nillem#ep21_frontroom");
		emotion ET_SURPRISE,getcharid(3);
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "We are looking for the Mercenary King Richard.";
		mes "Do you know where he might be?";
		npctalk "Nillem : Oh! Someone's here!","Nillem#ep21_frontroom",bc_self;
		next;
		cutin "",255;
		mes "[???]";
		mes "Richard?";
		mes "Wait a moment.";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Her voice is calm, unlike that scary warning sign.";
		mes "It seems that we can communicate.";
		emotion ET_CRY,getnpcid(0,"Lehar#ep21_frontroom");
		next;
		cutin "ep172_nillem03.png",0;
		mes "[Nillem]";
		mes "How low did your expectations go.";
		emotion ET_SWEAT,getnpcid(0,"Nillem#ep21_frontroom");
		next;
		cutin "",255;
		mes "- Crack -";
		next;
		cutin "ep21_valdaris01.png",2;
		mes "[???]";
		mes "Who are you?";
		mes "I don't think I've seen you before. What brings you to Richard?";
		next;
		select("Tan sent us.");
		mes "[???]";
		mes "Tan?";
		mes "Hm…";
		next;
		mes "[???]";
		mes "Did Tan tell you to come here?";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Ah!";
		mes "Not exactly. He told us to go to the mercenary office, but when we got there, the person in there sent us here.";
		npctalk "Nillem : Why is she starting so intently…","Nillem#ep21_frontroom",bc_self;
		next;
		cutin "ep21_valdaris01.png",2;
		mes "[???]";
		mes "Alright.";
		mes "Then, let's head back to the ^e5555eoffice^000000, I need to fill out some paperworks first.";
		mes "Follow me.";
		completequest 24003;
		setquest 24004;
		close2;
		cloaknpc("Lehar#ep21_frontroom",true,getcharid(0));
		cloaknpc("Nillem#ep21_frontroom",true,getcharid(0));
		cloaknpc("???#ep21_frontroom",true,getcharid(0));
		cutin "",255;
		navigateto("mbase_in",289,124);
		end;
	}
	if(isbegin_quest(24004) == 1){
		mes "- The door is locked.";
		mes " I should go back to the ^e5555emercenary group's office^000000 -";
		close2;
		navigateto("mbase_in",289,124);
		end;
	}
	mes "^ff3366<FONT SIZE = 16><B>>> >>Restricted Area<< <<</B></FONT>";
	mes "<FONT SIZE = 16><B>Entry for authorized personnel only.</B></FONT>";
	mes "<FONT SIZE = 16><B>Entering may cause you serious injury.</B></FONT>^000000";
	close;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24003) == 1";
end;
}

mbase_in,111,116,3	duplicate(dummynpc)	???#ep21_frontroom	4_EP21_VALDARIS

mbase_in,299,126,3	script	Pile of Documents#ep21	4_EP18_PAPERS,{
	if(isbegin_quest(24005) == 1){
		mes "<B>[Richard Mercenary Group Application Form]</B>";
		mes "<B>Name :</B>";
		mes "<B>Job :</B>";
		mes "<B>Specialty :</B>";
		mes "<B>Reason for application :</B>";
		cloaknpc("Lehar#ep21_mercgroup",false,getcharid(0));
		cloaknpc("Nillem#ep21_mercgroup",false,getcharid(0));
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "We didn't come here to become mercenaries, you know?";
		next;
		cutin "ep21_valdaris01.png",2;
		mes "[Valdaris]";
		mes "If Tan sent you to our mercenary group without any further instruction, then this is the correct procedure.";
		next;
		mes "[Valdaris]";
		mes "Even though it says mercenary group form, it's because we're using old forms.";
		next;
		cutin "ep21_valdaris02.png",2;
		mes "[Valdaris]";
		mes "Everyone who wants to join the ^e5555eGaebolg^000000. Resistance fills out that form, so don't worry about the mercenary part.";
		next;
		cutin "",255;
		select("Fill out the form.");
		mes "- I have finished filling up the form.";
		mes "- Let's hand it to ^e5555eValdaris^000000 -";
		completequest 24005;
		setquest 24006;
		questinfo_refresh;
		close2;
		navigateto("mbase_in",302,123);
		end;
	}
	if(isbegin_quest(24006) == 1){
		mes "- I have finished filling up the form.";
		mes "- Let's hand it to ^e5555eValdaris^000000 -";
		close2;
		navigateto("mbase_in",302,123);
		end;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24005) == 1";
end;
}

mbase_in,302,123,3	script	Valdaris#ep21_mercgroup	4_EP21_VALDARIS,{
	if(isbegin_quest(24006) == 1){
		cutin "ep21_valdaris01.png",2;
		mes "[Valdaris]";
		mes "Has everyone finished filling up?";
		cloaknpc("Lehar#ep21_mercgroup",false,getcharid(0));
		cloaknpc("Nillem#ep21_mercgroup",false,getcharid(0));
		next;
		mes "[Valdaris]";
		mes "Name : Lehar";
		mes "Job : Inquisitor";
		mes "Inquisitor?";
		mes "I've never heard of that job before, what kind of job is it?";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "<FONT SIZE = 14>Pardon?</FONT>";
		mes "Oh… Uhm… you really don't know?";
		mes "<B>Inquisitors is an agent of the true faith, Odin. Mainly fight evil with our fist imbuded with divine power…</B>";
		emotion ET_HUK,getnpcid(0,"Lehar#ep21_mercgroup");
		next;
		cutin "ep21_valdaris01.png",2;
		mes "[Valdaris]";
		mes "It's an unfamiliar job title, but I guess such jobs exist somewhere.";
		mes "However, it's easier to manage if you write down a job title that others can recognize…";
		next;
		mes "[Valdaris]";
		mes "Hm… with fist… I'll change it to fighter.";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "<FONT SIZE = 14><B>What?!</B></FONT>";
		mes "<B>Fighter?</B>";
		mes "Atleast change it to Monk… can't you change it to monk?";
		mes "or atleast change it to Priest!!";
		emotion ET_HUK,getnpcid(0,"Lehar#ep21_mercgroup");
		next;
		cutin "ep21_valdaris02.png",2;
		mes "[Valdaris]";
		mes "Oh! Monk.";
		mes "Then, let's change it to monk.";
		mes "For a monk, isn't your outfit a bit too flashy?";
		next;
		cutin "ep19_lehar04.png",2;
		mes "[Lehar]";
		mes "Well, it just kind of ended up this way.";
		mes "Sob.";
		next;
		cutin "ep21_valdaris02.png",2;
		mes "[Valdaris]";
		mes "Alright. Mo…nk…";
		mes "Next, Nillem.";
		mes "Job : Wizard.";
		mes "Specialty : Spacial… magic.";
		mes "Reason for application : Because I was told to.";
		emotion ET_HUM,getnpcid(0,"Valdaris#ep21_mercgroup");
		next;
		cutin "ep21_valdaris01.png",2;
		mes "[Valdaris]";
		mes "Hm, no issues here.";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Huh?";
		mes "Is that a valid reason?";
		next;
		cutin "ep21_valdaris01.png",2;
		mes "[Valdaris]";
		mes "Yes, it's okay.";
		mes "It's more suspicious if you wrote a long-winded reason in this situation.";
		next;
		mes "[Valdaris]";
		mes "Now, next is " + strcharinfo(0) + ".";
		mes "Job : " + jobname(Class) + "…";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "Let's just go with " + jobname(BaseJob) + ".";
		next;
		cutin "ep21_valdaris02.png",2;
		mes "[Valdaris]";
		mes "Alright.";
		mes "Everything seems fine on paper.";
		next;
		mes "[Laura Valdaris]";
		mes "Welcome to the Richard Mercenary Group.";
		mes "I'm Laura Valdaris, the vice-captain of the mercenary group.";
		mes "I look forward to working with you.";
		next;
		cutin "ep21_valdaris03.png",2;
		mes "[Laura Valdaris]";
		mes "As for the captain, Richard, he's currently unavailable... but if you stay around, you'll meet him eventually.";
		mes "Probably.";
		emotion ET_SCRATCH,getnpcid(0,"Valdaris#ep21_mercgroup");
		next;
		cutin "ep21_valdaris02.png",2;
		mes "[Laura Valdaris]";
		mes "I'm in charge in majority of the internal affairs, so if anything comes up, just let me know.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "It was surprisingly easy to get through, I guess the form is just for formality.";
		next;
		cutin "ep21_valdaris02.png",2;
		mes "[Laura Valdaris]";
		mes "You're not entirely wrong, but there's a lot of information we can gather from such a simple document.";
		next;
		cutin "ep21_tan01.png",0;
		mes "[Tan]";
		mes "So, what do you think?";
		npctalk "Valdaris : Tan, where were you?","Valdaris#ep21_mercgroup",bc_self;
		cloaknpc("Tan#ep21_mercgroup",false,getcharid(0));
		completequest 24006;
		setquest 24007;
		questinfo_refresh;
		close2;
		cutin "",255;
		navigateto("mbase_in",302,122);
		end;
	}
	if(isbegin_quest(24007) == 1){
		cloaknpc("Lehar#ep21_mercgroup",false,getcharid(0));
		cloaknpc("Nillem#ep21_mercgroup",false,getcharid(0));
		cutin "ep21_valdaris02.png",2;
		mes "[Valdaris]";
		mes "Alright.";
		mes "Everything seems fine on paper.";
		next;
		mes "[Laura Valdaris]";
		mes "Welcome to the Richard Mercenary Group.";
		mes "I'm Laura Valdaris, the vice-captain of the mercenary group.";
		mes "I look forward to working with you.";
		next;
		cutin "ep21_valdaris03.png",2;
		mes "[Laura Valdaris]";
		mes "As for the captain, Richard, he's currently unavailable... but if you stay around, you'll meet him eventually.";
		mes "Probably.";
		emotion ET_SCRATCH,getnpcid(0,"Valdaris#ep21_mercgroup");
		next;
		cutin "ep21_valdaris02.png",2;
		mes "[Laura Valdaris]";
		mes "I'm in charge in majority of the internal affairs, so if anything comes up, just let me know.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "It was surprisingly easy to get through, I guess the form is just for formality.";
		next;
		cutin "ep21_valdaris02.png",2;
		mes "[Laura Valdaris]";
		mes "You're not entirely wrong, but there's a lot of information we can gather from such a simple document.";
		next;
		cutin "ep21_tan01.png",0;
		mes "[Tan]";
		mes "So, what do you think?";
		npctalk "Valdaris : Tan, where were you?","Valdaris#ep21_mercgroup",bc_self;
		cloaknpc("Tan#ep21_mercgroup",false,getcharid(0));
		close2;
		cutin "",255;
		navigateto("mbase_in",302,122);
		end;
	}
	if(isbegin_quest(24008) == 1){
		cutin "ep21_valdaris02.png",2;
		mes "[Laura Valdaris]";
		mes "Follow me, this way.";
		close2;
		cutin "",255;
		navigateto("jor_mbase",316,117);
		end;
	}
	if(isbegin_quest(18360) < 2) end;
	if(isbegin_quest(24019) == 0){
		mes "[Laura Valdaris]";
		mes "…You're back?";
		mes "You've been through a lot… and thank you for protecting everyone.";
		emotion ET_THINK,getnpcid(0,"Valdaris#ep21_mercgroup");
		cutin "ep21_valdaris01.png",2;
		next;
		mes "[Laura Valdaris]";
		mes "…Honestly, it still feels unreal.";
		mes "It feels like he's still watching over us…";
		mes "Sob…";
		next;
		mes "[Laura Valdaris]";
		mes "Everyone is sad… but Tan would have wanted us to move forward and continue living on, right?";
		next;
		mes "[Laura Valdaris]";
		mes "It's not over yet.";
		mes "First, I need to check if there are any places at the base where the help of the mercenaries are needed.";
		next;
		mes "[Laura Valdaris]";
		mes strcharinfo(0) + ", please meet the ^e5555emercenaries^000000 around the base.";
		setquest 24019;
		close2;
		cutin "",255;
		navigateto("jor_mbase",300,151);
		end;
	}
	if(isbegin_quest(24019) > 0 && isbegin_quest(24023) < 1){
		cutin "ep21_valdaris01.png",2;
		mes "[Laura Valdaris]";
		mes "It's not over yet.";
		mes "First, I need to check if there are any places at the base where the help of the mercenaries are needed.";
		next;
		mes "[Laura Valdaris]";
		mes strcharinfo(0) + ", please meet the ^e5555emercenaries^000000 around the base.";
		close3;
	}
	if(isbegin_quest(24023) == 1){
		cutin "ep21_valdaris01.png",2;
		mes "[Laura Valdaris]";
		mes "How was it?";
		next;
		mes "[Laura Valdaris]";
		mes "Hm… as expected, it's a total mess.";
		mes "Organizing tasks, training the mercenaries, dispatching them… and more…";
		emotion ET_HNG,getnpcid(0,"Valdaris#ep21_mercgroup");
		next;
		mes "[Laura Valdaris]";
		mes "There's so much to do.";
		mes strcharinfo(0)+", when you have a free time, please help out with the mercenary work as well.";
		completequest 24023;
		questinfo_refresh;
		getitem "Ep21_Wigner_Ticket",10;
		getexp 91298960,5995000;
		add_reputation_points(13,5);
		close3;
	}
	if(isbegin_quest(24023) < 2) end;
	callsub(OnCheckComplete);
	switch(select("Any kind of help!","Fresh food!","Clamshell for injuries!","For the children.","Clean Finish(1)","Clean Finish(2)","Accept all request","Quit.")){
		case 1:
			.@qid = 24024;
			.@cid = 24030;
			break;
		case 2:
			.@qid = 24031;
			.@cid = 24032;
			break;
		case 3:
			.@qid = 24033;
			.@cid = 24034;
			break;
		case 4:
			.@qid = 24035;
			.@cid = 24036;
			break;
		case 5:
			.@qid = 24037;
			.@cid = 24038;
			break;
		case 6:
			.@qid = 24039;
			.@cid = 24040;
			break;
		case 7:
			cutin "ep21_valdaris02.png",2;
			mes "[Laura Valdaris]";
			mes "There are a number of request that needs to be done…";
			mes "Are you sure you want to take it all?";
			mes "^ff3366If you receive or completed one of today's task, it won't be available^000000, so please check it.";
			next;
			if(select("Accept.","Quit.") == 2){
				cutin "ep21_valdaris02.png",2;
				mes "[Laura Valdaris]";
				mes "Alright.";
				mes "Didn't you know the basic principle of a mercenary is to earn is to work?";
				close3;
			}
            mes "[Laura Valdaris]";
            mes "I'm counting on you.";
            setarray .@qid,24024,24031,24033,24035,24037,24039;
            setarray .@cid,24030,24032,24034,24036,24038,24040;
            for(.@i = 0; .@i < getarraysize(.@qid); .@i++){
                switch(checkquest(.@cid[.@i],PLAYTIME)){
                    case -1:
                        break;
                    case 0:
                    case 1:
                        continue;
                    case 2:
                        erasequest .@cid[.@i];
                        break;
                }
                if ( !isbegin_quest(.@qid[.@i]) )
                    setquest .@qid[.@i];
            }
            close3;

		case 8:
			cutin "ep21_valdaris02.png",2;
			mes "[Laura Valdaris]";
			mes "Alright.";
			mes "Didn't you know the basic principle of a mercenary is to earn is to work?";
			close3;	
	}
	callsub(OnCheckCD,.@cid);
	callsub(OnCheckQuest,.@qid);
	next;
	if(select("Accept.","Quit.") == 2){
		cutin "ep21_valdaris02.png",2;
		mes "[Laura Valdaris]";
		mes "Alright.";
		mes "Didn't you know the basic principle of a mercenary is to earn is to work?";
		close3;
	}
	mes "[Laura Valdaris]";
	mes "I'm counting on you.";
	setquest .@qid;
	close3;

OnCheckComplete:
	if(isbegin_quest(24029) == 1){
		for(.@i = 24024; .@i <= 24029; .@i++)
			erasequest .@i;
		setquest 24030;
		getitem "Ep21_Wigner_Ticket",2;
		getexp 18259800,11999000;
		add_reputation_points(13,2);
		.@hasfinished = true;
	}
	if(isbegin_quest(24031) == 1 && countitem("aegis_1001644") >= 10 && countitem("aegis_1001647") >= 10){
		delitem "aegis_1001644",10;
		delitem "aegis_1001647",10;
		erasequest 24031;
		setquest 24032;
		getitem "Ep21_Wigner_Ticket",5;
		getexp 44165840,30878120;
		add_reputation_points(13,5);
		.@hasfinished = true;
	}
	if(checkquest(24033,HUNTING) == 2){
		erasequest 24033;
		setquest 24034;
		getitem "Ep21_Wigner_Ticket",5;
		getexp 56433200,38243300;
		add_reputation_points(13,5);
		.@hasfinished = true;
	}
	if(checkquest(24035,HUNTING) == 2){
		erasequest 24035;
		setquest 24036;
		getitem "Ep21_Wigner_Ticket",5;
		getexp 52650240,36855100;
		add_reputation_points(13,5);
		.@hasfinished = true;
	}
	if(checkquest(24037,HUNTING) == 2){
		erasequest 24037;
		setquest 24038;
		getitem "Ep21_Wigner_Ticket",10;
		getexp 754884100,550828100;
		add_reputation_points(13,5);
		.@hasfinished = true;
	}
	if(checkquest(24039,HUNTING) == 2){
		erasequest 24039;
		setquest 24040;
		getitem "Ep21_Wigner_Ticket",10;
		getexp 840885900,580775500;
		add_reputation_points(13,5);
		.@hasfinished = true;
	}
	if(.@hasfinished){
		cutin "ep21_valdaris02.png",2;
		mes "[Laura Valdaris]";
		mes "Good work.";
		mes "It seems like you're getting quite used to the work of the mercenary group.";
		close3;
	}
	return;
end;

OnCheckQuest:
	switch(getarg(0)){
		case 24024:
			if(isbegin_quest(24024) == 0 || isbegin_quest(24024) > 0 && isbegin_quest(24029) == 0){
				cutin "ep21_valdaris01.png",2;
				mes "[Laura Valdaris]";
				mes "Please check the ^e5555emercenary applicants^000000 in Lunaforma.";
				mes "If you find anyone promising after reviewing the application, feel free to send them here.";
				mes "Let's start by bringing in ^e5555e5 people^000000 today.";
				if(isbegin_quest(24024) == 0) return;
				close3;
			}
			break;
		case 24031:
			if(isbegin_quest(24031) == 0 || isbegin_quest(24031) == 1 && countitem("aegis_1001644") < 10 || countitem("aegis_1001647") < 10){
				cutin "ep21_valdaris02.png",2;
				mes "[Laura Valdaris]";
				mes "When you're on your low point, there's nothing better than good food!";
				mes "Please bring me ^e5555e10 Skipskipper Fin and 10 Thick Flesh^000000 from the Raised Land.";
				mes "I'll cook something up that'll get even the laziest captain jumping with energy.";
				if(isbegin_quest(24031) == 0) return;
				close3;
			}
			break;
		case 24033:
			if(isbegin_quest(24033) == 0 || isbegin_quest(24033) == 1 && checkquest(24033,HUNTING) < 2){
				cutin "ep21_valdaris02.png",2;
				mes "[Laura Valdaris]";
				mes "Please hunt ^e5555e50 Iron Clams^000000.";
				mes "Iron Clam's meat is delicious, and their shells contain ingredients that help with healing injuries, making them useful for creating potions.";
				mes "Those creatures are very useful.";
				if(isbegin_quest(24033) == 0) return;
				close3;
			}
			break;
		case 24035:
			if(isbegin_quest(24035) == 0 || isbegin_quest(24035) == 1 && checkquest(24035,HUNTING) < 2){
				cutin "ep21_valdaris02.png",2;
				mes "[Laura Valdaris]";
				mes "Please hunt ^e5555e50 Vellelings^000000.";
				mes "If you boil and dry them well, they turn into a sweet and chewy snack, the kids love them.";
				mes "They could use a little bit of joy.";
				if(isbegin_quest(24035) == 0) return;
				close3;
			}
			break;

		case 24037:
			if(isbegin_quest(24037) == 0 || isbegin_quest(24037) == 1 && checkquest(24037,HUNTING) < 2){
				cutin "ep21_valdaris04.png",2;
				mes "[Laura Valdaris]";
				mes "I'd appreciate it if you can clean up the ^e5555eJormungandr Cult Temple, Gimli's 1st Floor^000000.";
				mes "No matter how much we deal with them, they keep crawling out from somewhere.";
				mes "Ugh… those detestable creatures!";
				if(isbegin_quest(24037) == 0) return;
				close3;
			}
			break;
		case 24039:
			if(isbegin_quest(24039) == 0 || isbegin_quest(24039) == 1 && checkquest(24039,HUNTING) < 2){
				cutin "ep21_valdaris04.png",2;
				mes "[Laura Valdaris]";
				mes "I'd appreciate it if you can clean up the ^e5555eJormungandr Cult Temple, Gimli's 2nd Floor^000000.";
				mes "No matter how much we deal with them, they keep crawling out from somewhere.";
				mes "Ugh… those detestable creatures!";
				if(isbegin_quest(24039) == 0) return;
				close3;
			}
			break;	
	}
	return;
end;

OnCheckCD:
	switch(checkquest(getarg(0),PLAYTIME)){
		case -1:
			return;

		case 0:
		case 1:
			cutin "ep21_valdaris02.png",2;
			mes "[Laura Valdaris]";
			mes "Don't overwork yourself.";
			mes "Can you come back tomorrow instead?";
			close3;

		case 2:
			erasequest getarg(0);
			return;
	}
end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24006) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18360) == 2 && isbegin_quest(24019) == 0";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24023) == 1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24023) == 2 && isbegin_quest(24024) == 0 && checkquest(24030,PLAYTIME) == 2";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24023) == 2 && isbegin_quest(24031) == 0 && checkquest(24032,PLAYTIME) == 2";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24023) == 2 && isbegin_quest(24033) == 0 && checkquest(24034,PLAYTIME) == 2";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24023) == 2 && isbegin_quest(24035) == 0 && checkquest(24036,PLAYTIME) == 2";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24023) == 2 && isbegin_quest(24037) == 0 && checkquest(24038,PLAYTIME) == 2";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24023) == 2 && isbegin_quest(24039) == 0 && checkquest(24040,PLAYTIME) == 2";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24023) == 2 && isbegin_quest(24024) == 0 && checkquest(24030,PLAYTIME) == -1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24023) == 2 && isbegin_quest(24031) == 0 && checkquest(24032,PLAYTIME) == -1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24023) == 2 && isbegin_quest(24033) == 0 && checkquest(24034,PLAYTIME) == -1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24023) == 2 && isbegin_quest(24035) == 0 && checkquest(24036,PLAYTIME) == -1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24023) == 2 && isbegin_quest(24037) == 0 && checkquest(24038,PLAYTIME) == -1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24023) == 2 && isbegin_quest(24039) == 0 && checkquest(24040,PLAYTIME) == -1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24029) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24031) == 1 && countitem(\"aegis_1001644\") >= 10 && countitem(\"aegis_1001647\") >= 10";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"checkquest(24033,HUNTING) == 2";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"checkquest(24035,HUNTING) == 2";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"checkquest(24037,HUNTING) == 2";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"checkquest(24039,HUNTING) == 2";
end;
}

mbase_in,298,121,3	script	Lee#ep21_addquest	4_EP21_LEE,{
	if(isbegin_quest(18360) < 2) {
		cloaknpc(strnpcinfo(0),true,getcharid(0));
		end;
	}
	if(isbegin_quest(24041) == 0){
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "Oh~ " + strcharinfo(0) + ", was it?";
		mes "I heard you're helping the mercenary out?";
		mes "Is the workload manageable?";
		next;
		if ( BaseLevel < 240 ) {
			cutin "",255;
			mes "^ff0000※ This quest is for level 240 or above.^000000";
			close;
		}
		select("It's okay.","It's busy.");
		mes "[Lee]";
		mes "Laura has been praising how helpful you have been.";
		mes "She said that we are able to get by thanks to you…";
		cutin "ep21_lee01.png",2;
		cloaknpc("Gunter#ep21_addquest",false,getcharid(0));
		cloaknpc("Galaxia#ep21_addquest",false,getcharid(0));
		npctalk "Gunter : *Nods*","Gunter#ep21_addquest",bc_self;
		npctalk "Galaxia Nerius : *Nods*","Galaxia#ep21_addquest",bc_self;
		next;
		mes "[Lee]";
		mes "See? Even them agrees that you're an essential part of the Gaebolg.";
		npctalk "Gunter : Correct!","Gunter#ep21_addquest",bc_self;
		npctalk "Galaxia Nerius : I agree!","Galaxia#ep21_addquest",bc_self;
		next;
		select("Why are you suddenly praising me?");
		cutin "ep21_galaxia_a.png",2;
		mes "[Galaxia Nerius]";
		mes "See, I told you the adventurer will doubt us if we said it like that~";
		next;
		cutin "ep21_lee03.png",2;
		mes "[Lee]";
		mes "Sigh.";
		next;
		cutin "ep21_lee01.png",2;
		mes "[Lee]";
		mes "Why didn't it work?";
		mes "Well, I might as well tell the truth.";
		next;
		mes "[Lee]";
		mes "We're planning to infiltrate Jorscalp this time.";
		mes "We are looking for people that will go with us…";
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "Thanks to these two, there are absolutely no volunteers who were willing to join us.";
		mes "Say, how about you go with us?";
		npctalk "Galaxia Nerius : It's not because of me!","Galaxia#ep21_addquest",bc_self;
		npctalk "Gunter : That's… a lie.","Gunter#ep21_addquest",bc_self;
		next;
		select("Jorscalp?");
		cutin "ep21_lee01.png",2;
		mes "[Lee]";
		mes "Jorscalp is like an extension of the Jormungandr's Gimli... The cult priests are all strange, but the priests over there are even stranger.";
		next;
		mes "[Lee]";
		mes "Your task is not complicated, while me and Gunter are investigating Jorscalp, we'll have you take care of nearby cult members.";
		next;
		mes "[Lee]";
		mes "We could also gather some examples for our training manual while we are there.";
		next;
		cutin "ep21_galaxia_a.png",2;
		mes "[Galaxia Nerius]";
		mes "What about me?";
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "Galaxia… Just stay here, I'll send you a signal when we need you.";
		next;
		cutin "ep21_galaxia_a.png",2;
		mes "[Galaxia Nerius]";
		mes "I understand.";	
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "We can risk bringing Galaxia to Jorscalp, if we let her go wild in there, she will attract too much attention. So, we'll bring you instead, " + strcharinfo(0) + ". It will make our investigation easier.";
		next;
		mes "[Lee]";
		mes "Going in groups is too risky.";
		mes "Once you feel like everything is resolved, meet us back here.";
		mes "Is that clear?";
		setquest 24041;
		completequest 24041;
		next;
		mes "[Lee]";
		mes "Alright~";
		mes "We will head there later before you.";
	} else {
		callsub(OnCheckComplete);
		cutin "ep21_lee01.png",2;
		mes "[Lee]";
		mes "Hi~";
		mes "What can I do for you?";
	}
	next;
	switch(select("Participate on all mission.","[240]Distract Members in Yorscalp's 1st Floor(Daily)","[240]Create an Uproar in Yorscalp's 1st Floor(Weekly)","[250]Distract Members in Yorscalp's 2nd Floor(Daily)","[250]Create an Uproar in Yorscalp's 2nd Floor(Weekly)","Quit.")){
		case 1:
			mes "[Lee]";
			mes "Okay!";
			mes "Aren't we an impatient one?";
			mes "I'll make sure that ^ff3366you don't have to go to missions you've already participated on^000000.";
			break;
			
		case 2:
			callsub(OnCheckLevel,240);
			.@cid = 24043;
			callsub(OnCheckCD,.@cid);
			mes "[Lee]";
			mes "Then, can you take care of about ^e5555e300 members on the 1st floor of Jorscalp^000000?";
			mes "That should give us enough time to investigate the place.";
			.@qid = 24042;
			break;
			
		case 3:
			callsub(OnCheckLevel,240);
			.@cid = 24045;
			callsub(OnCheckCD,.@cid);
			mes "[Lee]";
			mes "Then, can you take care of about ^e5555e1500 members on the 1st floor of Jorscalp^000000?";
			mes "That should give us enough time to investigate the place.";
			.@qid = 24044;
			break;
			
		case 4:
			callsub(OnCheckLevel,250);
			.@cid = 24047;
			callsub(OnCheckCD,.@cid);
			mes "[Lee]";
			mes "Then, can you take care of about ^e5555e300 members on the 2nd floor of Jorscalp^000000?";
			mes "That should give us enough time to investigate the place.";
			.@qid = 24046;
			.@cid = 24047;
			break;
			
		case 5:
			callsub(OnCheckLevel,250);
			.@cid = 24049;
			callsub(OnCheckCD,.@cid);
			mes "[Lee]";
			mes "Then, can you take care of about ^e5555e1500 members on the 2nd floor of Jorscalp^000000?";
			mes "That should give us enough time to investigate the place.";
			.@qid = 24048;
			.@cid = 24049;
			break;
			
		case 6:
			cutin "ep21_lee02.png",2;
			mes "[Lee]";
			mes "Okay~";
			mes "We'll go on our own.";
			close3;
	}
	next;
	if (select("Accept.","Quit.") == 2){
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "Okay~";
		mes "We'll go on our own.";
		close3;
	}
	if (!.@qid) {
        setarray .@qid,24042,24044,24046,24048;
        setarray .@cid,24043,24045,24047,24049;
        for(.@i = 0; .@i < getarraysize(.@qid); .@i++){
            switch(checkquest(.@cid[.@i],PLAYTIME)){
                case -1:
                    break;
                case 0:
                case 1:
                    continue;
                case 2:
                    erasequest .@cid[.@i];
                    break;
            }
            if ( !isbegin_quest(.@qid[.@i]) )
                setquest .@qid[.@i];
        }
	} else {
		if(isbegin_quest(.@qid) == 0 ) {
			cutin "ep21_lee02.png",2;
			mes "[Lee]";
			mes "Great decision!";
			mes "Then, shall we go?";
			setquest .@qid;
			close3;
		}
		if(isbegin_quest(.@qid) > 0) {
			mes "[Lee]";
			switch(.@qid){
				case 24042:
					mes "Oh, have you taken care of ^e5555e300 members on the 1st floor of Jorscalp^000000?";
					break;
				case 24044:
					mes "Oh, have you taken care of ^e5555e1500 members on the 1st floor of Jorscalp^000000?";
					break;
				case 24046:
					mes "Oh, have you taken care of ^e5555e300 members on the 2nd floor of Jorscalp^000000?";
					break;
				case 24048:
					mes "Oh, have you taken care of ^e5555e1500 members on the 2nd floor of Jorscalp^000000?";
					break;
			}
			mes "That should give us enough time to investigate the place..";
			close3;
		}
	}
	end;
	
OnCheckLevel:
	if ( BaseLevel >= getarg(0) ) return;
	mes "[Lee]";
	mes "It seems that this is will be too difficult for you.";
	mes "Should I give you another task?";
	mes "^ff0000※ This quest is for level " + getarg(0) + " or above.^000000";
	close3;
	
OnCheckCD:
	switch(checkquest(getarg(0),PLAYTIME)){
		case -1:
			return;

		case 0:
		case 1:
			mes "[Lee]";
			mes "Oh!";
			mes "That's enough for today!";
			mes "You should relax for a bit!";
			close3;

		case 2:
			erasequest getarg(0);
			return;
	}
end;
	
OnCheckComplete:
    setarray .@qid,24042,24044,24046,24048;
    setarray .@cid,24043,24045,24047,24049;
	setarray .@reputation,5,25,5,25;
	setarray .@exp,393000000,1655000000,448000000,1968000000;
	setarray .@amount,10,50,10,50;
	for ( .@i = 0; .@i < getarraysize(.@qid); ++.@i ) {
		if ( !isbegin_quest(.@qid[.@i]) ) continue;
		if ( checkquest(.@qid[.@i],HUNTING) < 2 ) continue;
		erasequest .@qid[.@i];
		setquest .@cid[.@i];
		.@total_item += .@amount[.@i];
		.@total_rep += .@reputation[.@i];
		.@total_exp = .@exp[.@i];
	}
	if ( .@total_item ) {
		getitem "Ep21_Wigner_Ticket",.@total_item;
		getexp .@total_exp,0;
		add_reputation_points(13, .@total_rep);
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "Phew~";
		mes "We were able to come back in one piece.";
		mes "You're not hurt anywhere, are you?";
		close3;
	}
	return;

OnInit:
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(18360) == 2 && isbegin_quest(24041) == 0 && BaseLevel >= 240";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24041) > 0 && isbegin_quest(24042) == 0 && checkquest(24043,PLAYTIME) == -1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24041) > 0 && isbegin_quest(24044) == 0 && checkquest(24045,PLAYTIME) == -1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24041) > 0 && isbegin_quest(24046) == 0 && checkquest(24047,PLAYTIME) == -1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24041) > 0 && isbegin_quest(24048) == 0 && checkquest(24049,PLAYTIME) == -1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24041) > 0 && isbegin_quest(24042) == 0 && checkquest(24043,PLAYTIME) == 2";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24041) > 0 && isbegin_quest(24044) == 0 && checkquest(24045,PLAYTIME) == 2";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24041) > 0 && isbegin_quest(24046) == 0 && checkquest(24047,PLAYTIME) == 2";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(24041) > 0 && isbegin_quest(24048) == 0 && checkquest(24049,PLAYTIME) == 2";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"checkquest(24042,HUNTING) == 2";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"checkquest(24044,HUNTING) == 2";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"checkquest(24046,HUNTING) == 2";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"checkquest(24048,HUNTING) == 2";
end;
}

mbase_in,297,118,2	duplicate(dummynpc)	Galaxia#ep21_addquest	4_EP21_GALAXIA_A
mbase_in,293,118,2	duplicate(dummynpc)	Gunter#ep21_addquest	4_EP21_GUNTER

mbase_in,302,122,3	script(CLOAKED)	Tan#ep21_mercgroup	4_EP21_TAN,{
	if(isbegin_quest(24007) == 1){
		cutin "ep21_valdaris01.png",2;
		mes "[Laura Valdaris]";
		mes "Tan.";
		mes "It seems you're quite concerned, coming all the way to the mercenary office yourself?";
		next;
		cutin "ep21_tan02.png",0;
		mes "[Tan]";
		mes "^4e4e4e(They have significant power, the Gaebolg Resistance will suffer greatly if they cause any trouble.)^000000";
		next;
		cutin "ep21_valdaris01.png",2;
		mes "[Laura Valdaris]";
		mes "^4e4e4e(They're all strong, especially that wizard Nillem.";
		mes "He wrote spacial magic as his specialty.";
		mes "He seems to be a similar lineage to Heine, if they're a spy from the cult, they could be extremely dangerous.)^000000";
		next;
		cutin "ep21_tan01.png",0;
		mes "[Tan]";
		mes "^4e4e4e(If you take a look at the Odin's Insigna on Lehar's outfit makes me think they're probably not from the cult…";
		mes "their true identity is still unclear.";
		mes "it's hard to trust them immediately.)^000000";
		next;
		cutin "ep21_valdaris01.png",2;
		mes "[Laura Valdaris]";
		mes "^4e4e4e(You won't send them here to the mercenary group if they were someone we could easily screen.";
		mes "and considering the people who joined so far, Odin's insignia might not mean much, but for the cult it's an intolerable insult.)^000000";
		next;
		mes "[Laura Valdaris]";
		mes "^4e4e4e(There was no response from the contract magic embedded in the form.)^000000";
		next;
		cutin "ep21_tan01.png",0;
		mes "[Tan]";
		mes "^4e4e4e(That's a relief.)^000000";
		next;
		cutin "ep21_valdaris01.png",2;
		mes "[Laura Valdaris]";
		mes "^4e4e4e(I made some minor adjustments to the contract magic that we use in the mercenary group, it's not perfect, but I think it's enough to raise some suspicions.)^000000";
		next;
		mes "[Laura Valdaris]";
		mes "^4e4e4e(If they have the ability to bypass the contract magic, there wouldn't be any way to tell if they're ally or foe at this point.)^000000";
		next;
		cutin "ep21_tan01.png",0;
		mes "[Tan]";
		mes "^4e4e4e(That's why I'm planning to keep an eye on them for a while.)^000000";
		next;
		cutin "ep21_valdaris01.png",2;
		mes "[Laura Valdaris]";
		mes "^4e4e4e(That's a good idea.";
		mes "Given their strength, they'll have a great impact one way or another.)^000000";
		next;
		mes "[Laura Valdaris]";
		mes "^4e4e4e(Let's see if they will bring us hope or despair.";
		mes "But I do pray that it's hope though…)^000000";
		next;
		cutin "ep21_tan02.png",0;
		mes "[Tan]";
		mes "^4e4e4e(Yes… that would be nice…)^000000";
		next;
		cutin "ep21_tan01.png",0;
		mes "[Tan]";
		mes "That's all I need to know.";
		mes "Please take care of training the new mercenaries.";
		next;
		cutin "ep21_valdaris02.png",2;
		mes "[Laura Valdaris]";
		mes "Leave it to me.";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Training?";
		mes "Right now?";
		next;
		cutin "ep21_valdaris01.png",2;
		mes "[Laura Valdaris]";
		mes "It's just a figure of speech. You can start training freely once you're more familiar with the life here.";
		mes "For now, it would be best to give you a ^e5555ebase tour^000000.";
		next;
		mes "[Laura Valdaris]";
		mes "Gunter, could you do it?";
		cloaknpc("???#ep21_mercgroup",false,getcharid(0));
		emotion ET_HUK,getnpcid(0,"???#ep21_mercgroup");
		next;
		cutin "ep21_gunter01.png",2;
		mes "[Gunter]";
		mes "…";
		mes "No.";
		cloaknpc("???#ep21_mercgroup",true,getcharid(0));
		next;
		cutin "ep21_valdaris03.png",2;
		mes "[Laura Valdaris]";
		mes "…";
		emotion ET_FRET,getnpcid(0,"Valdaris#ep21_mercgroup");
		next;
		mes "[Laura Valdaris]";
		mes "<FONT SIZE = 14>Sigh…</FONT>";
		next;
		cutin "ep21_valdaris01.png",2;
		mes "[Laura Valdaris]";
		mes "Alright, I'll take you myself.";
		next;
		cutin "ep21_soldier_b.png",2;
		mes "[Mercenary Member]";
		mes "Should I handle the base tour?";
		next;
		cutin "ep21_valdaris01.png",2;
		mes "[Laura Valdaris]";
		mes "No, it's fine.";
		mes "Since Tan is particularly concerned about them, I'll handle it myself.";
		mes "Keep an eye on the office, and if the captain or Nerius returns, make sure to make them stay.";
		next;
		cutin "ep21_soldier_b.png",2;
		mes "[Mercenary Member]";
		mes "Aye.";
		mes "But do you think we'll be able to make them stay if either of them come back?";
		next;
		cutin "ep21_valdaris03.png",2;
		mes "[Laura Valdaris]";
		mes "Hm…";
		mes "It's unlikely…";
		next;
		cutin "ep21_valdaris01.png",2;
		mes "[Laura Valdaris]";
		mes "Then, just tell them that I'm looking for them.";
		mes "and if you see Lee, let me know.";
		next;
		cutin "ep21_soldier_b.png",2;
		mes "[Mercenary Member]";
		mes "Aye.";
		next;
		cutin "ep21_valdaris02.png",2;
		mes "[Laura Valdaris]";
		mes "Follow me, this way.";
		next;
		cutin "ep21_soldier_b.png",2;
		mes "[Mercenary Member]";
		mes "<FONT SIZE = 14><B>Take care.</B></FONT>";
		completequest 24007;
		setquest 24008;
		close2;
		cloaknpc("Lehar#ep21_mercgroup",true,getcharid(0));
		cloaknpc("Nillem#ep21_mercgroup",true,getcharid(0));
		cloaknpc("Tan#ep21_mercgroup",true,getcharid(0));
		cutin "",255;
		navigateto("jor_mbase",316,117);
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24007) == 1";
end;	
}

mbase_in,289,124,3	duplicate(dummynpc)	???#ep21_valdaris	4_EP21_VALDARIS

mbase_in,289,120,5	duplicate(dummynpc2)	Mercenary Member#ep21_mercgroup1	4_EP21_SOLDIER_A
mbase_in,299,119,3	duplicate(dummynpc2)	Mercenary Member#ep21_mercgroup2	4_EP21_SOLDIER_A
mbase_in,302,127,1	duplicate(dummynpc2)	Mercenary Member#ep21_mercgroup3	4_EP21_SOLDIER_A
mbase_in,296,128,3	duplicate(dummynpc2)	Mercenary Member#ep21_mercgroup4	4_EP21_SOLDIER_B
mbase_in,285,127,4	duplicate(dummynpc2)	Mercenary Member#ep21_mercgroup5	4_EP21_SOLDIER_B
mbase_in,291,123,3	duplicate(dummynpc2)	Mercenary Member#ep21_mercgroup6	4_EP21_SOLDIER_B

mbase_in,298,124,4	duplicate(dummynpc)	Lehar#ep21_mercgroup	4_EP19_LEHAR
mbase_in,299,123,2	duplicate(dummynpc)	Nillem#ep21_mercgroup	4_M_NILLEM

jor_mbase,316,117,0	script	#ep21_valdaris1	HIDDEN_WARP_NPC,2,2,{
	end;

OnTouch:
	switch(atoi(replacestr(strnpcinfo(2),"ep21_valdaris",""))){
		case 1:
			if(isbegin_quest(24008) == 1 || isbegin_quest(24009) == 1){
				cutin "ep21_valdaris01.png",2;
				mes "[Laura Valdaris]";
				mes "This base was built in a rush, so there's not much to show, but let's go take a quick tour.";
				cloaknpc("Lehar#ep21_tour1",false,getcharid(0));
				cloaknpc("Nillem#ep21_tour1",false,getcharid(0));
				cloaknpc("Valdaris#ep21_tour1",false,getcharid(0));
				if(isbegin_quest(24008) == 1){
					completequest 24008;
					setquest 24009;
				}
				close2;
				cutin "",255;
				cloaknpc("Lehar#ep21_tour1",true,getcharid(0));
				cloaknpc("Nillem#ep21_tour1",true,getcharid(0));
				cloaknpc("Valdaris#ep21_tour1",true,getcharid(0));
				navigateto("jor_mbase",316,100);
				end;
			}
			break;

		case 2:
			if(isbegin_quest(24009) == 1){
				cutin "ep21_valdaris01.png",2;
				mes "[Laura Valdaris]";
				mes "This is where we store the supplies brought in by the merchant guild.";
				mes "They're not here to do business, they generously provide us with supplies.";
				cloaknpc("Lehar#ep21_tour2",false,getcharid(0));
				cloaknpc("Nillem#ep21_tour2",false,getcharid(0));
				cloaknpc("Valdaris#ep21_tour2",false,getcharid(0));
				next;
				mes "[Laura Valdaris]";
				mes "The ^e5555eWigner Merchant Guild^000000 handles the procurement of goods and the ^e5555eWalter Fleet^000000 manage the transportation. If you're interested in logistics, this area also needs a hand.";
				next;
				mes "[Laura Valdaris]";
				mes "You don't have to join the merchant guild or the fleet, if you're not keen on ships, it could be a good option for you since we sometimes dispatch mercenaries for land transport. ";
				mes "Besides that, there's a lot of ^e5555eareas that needs extra hands^000000, there's a lot of work that needs to be done.";
				completequest 24009;
				setquest 24010;
				questinfo_refresh;
				close2;
				cloaknpc("Lehar#ep21_tour2",true,getcharid(0));
				cloaknpc("Nillem#ep21_tour2",true,getcharid(0));
				cloaknpc("Valdaris#ep21_tour2",true,getcharid(0));
				cutin "",255;
				navigateto("jor_mbase",243,120);
				end;
			}
			if(isbegin_quest(24010) == 1){
				cutin "ep21_valdaris01.png",2;
				mes "[Laura Valdaris]";
				mes "The ^e5555eWigner Merchant Guild^000000 handles the procurement of goods and the ^e5555eWalter Fleet^000000 manage the transportation. If you're interested in logistics, this area also needs a hand.";
				cloaknpc("Lehar#ep21_tour2",false,getcharid(0));
				cloaknpc("Nillem#ep21_tour2",false,getcharid(0));
				cloaknpc("Valdaris#ep21_tour2",false,getcharid(0));
				next;
				mes "[Laura Valdaris]";
				mes "You don't have to join the merchant guild or the fleet, if you're not keen on ships, it could be a good option for you since we sometimes dispatch mercenaries for land transport. ";
				mes "Besides that, there's a lot of ^e5555eareas that needs extra hands^000000, there's a lot of work that needs to be done.";
				close2;
				cloaknpc("Lehar#ep21_tour2",true,getcharid(0));
				cloaknpc("Nillem#ep21_tour2",true,getcharid(0));
				cloaknpc("Valdaris#ep21_tour2",true,getcharid(0));
				cutin "",255;
				navigateto("jor_mbase",243,120);
				end;
			}
			break;

		case 3:
			if(isbegin_quest(24010) == 1){
				cutin "ep21_valdaris01.png",2;
				mes "[Laura Valdaris]";
				mes "This area is the temporary visitors area…";
				cloaknpc("Lehar#ep21_tour3",false,getcharid(0));
				cloaknpc("Nillem#ep21_tour3",false,getcharid(0));
				cloaknpc("Valdaris#ep21_tour3",false,getcharid(0));
				next;
				cutin "ep21_worker_kb_09.png",2;
				mes "[Kid]";
				mes "<FONT SIZE = 16><B>Sister Valdaris!!!</B></FONT>";
				cloaknpc("Kid#ep21_tour3_1",false,getcharid(0));
				cloaknpc("Kid#ep21_tour3_2",false,getcharid(0));
				cloaknpc("Kid#ep21_tour3_3",false,getcharid(0));
				cloaknpc("Kid#ep21_tour3_4",false,getcharid(0));
				cloaknpc("Kid#ep21_tour3_5",false,getcharid(0));
				cloaknpc("Kid#ep21_tour3_6",false,getcharid(0));
				next;
				cutin "ep21_worker_kg_06.png",0;
				mes "[Kid]";
				mes "<FONT SIZE = 14><B>Sister Valdaris, we finished cleaning.</B></FONT>";
				mes "<FONT SIZE = 14><B>Can we play now?</B></FONT>";
				next;
				cutin "ep21_valdaris02.png",2;
				mes "[Laura Valdaris]";
				mes "You cleaned up,  great job.";
				mes "What did I say before you play?";
				emotion ET_BEST,getnpcid(0,"Valdaris#ep21_tour3");
				next;
				cutin "ep21_worker_kb_06.png",2;
				mes "[Kid]";
				mes "<FONT SIZE = 14><B>Don't disturb the adults!</B></FONT>";
				mes "<FONT SIZE = 14><B>Don't play on near the places where things are stacked high.</B></FONT>";
				mes "<FONT SIZE = 14><B>Don't play on the beach!</B></FONT>";
				mes "<FONT SIZE = 14><B>Wash your hands and feet after playing!</B></FONT>";
				next;
				cutin "ep21_valdaris02.png",2;
				mes "[Laura Valdaris]";
				mes "Good.";
				mes "Promise me you'll play safely.";
				mes "And return to your camps before it gets too late.";
				emotion ET_GOODBOY,getnpcid(0,"Valdaris#ep21_tour3");
				next;
				cutin "ep21_worker_kb_02.png",2;
				mes "[Kids]";
				mes "<FONT SIZE = 16><B>Yes~</B></FONT>";
				npctalk "Kid : Yes~","Kid#ep21_tour3_1",bc_self;
				npctalk "Kid : Okay.","Kid#ep21_tour3_2",bc_self;
				npctalk "Kid : Yeah!","Kid#ep21_tour3_3",bc_self;
				npctalk "Kid : Yep~","Kid#ep21_tour3_4",bc_self;
				npctalk "Kid : Okaay~","Kid#ep21_tour3_5",bc_self;
				npctalk "Kid : Yes!!","Kid#ep21_tour3_6",bc_self;
				emotion ET_THROB,getnpcid(0,"Kid#ep21_tour3_1");
				emotion ET_THROB,getnpcid(0,"Kid#ep21_tour3_2");
				emotion ET_THROB,getnpcid(0,"Kid#ep21_tour3_3");
				emotion ET_THROB,getnpcid(0,"Kid#ep21_tour3_4");
				emotion ET_THROB,getnpcid(0,"Kid#ep21_tour3_5");
				emotion ET_THROB,getnpcid(0,"Kid#ep21_tour3_6");
				next;
				cutin "ep19_lehar05.png",2;
				mes "[Lehar]";
				mes "Why are there children in a place like this?";
				next;
				cutin "ep21_valdaris03.png",2;
				mes "[Laura Valdaris]";
				mes "Those children are not a part of the mercenary group, most of them were ^e5555erescued from the Jormungandr cult^000000.";
				next;
				mes "[Laura Valdaris]";
				mes "The ^e5555eWigner Merchant Guild^000000 handles majority of the work related to the rescued individuals, but those who have been brainwashed or coaxed stays here to some extent before we send them back to their homeland.";
				npctalk "Nillem : You really do all sort of things here.","Nillem#ep21_tour3",bc_self;
				next;
				mes "[Laura Valdaris]";
				mes "Sending someone who was involved with the cult back to their homeland is dangerous.";
				mes "<B>Even if they're just children.</B>";
				next;
				mes "[Laura Valdaris]";
				mes "It's easier to manage people who wants to join the mercenary to fight the cult than the,";
				npctalk "Laura Valdaris : The're excellent allies.","Valdaris#ep21_tour3",bc_self;
				next;
				mes "[Laura Valdaris]";
				mes "young childrens who were either kidnapped or brought by their own parents…";
				mes "It's a tough call.";
				emotion ET_HUM2,getnpcid(0,"Valdaris#ep21_tour3");
				next;
				mes "[Laura Valdaris]";
				mes "<FONT SIZE = 14><B>…</B></FONT>";
				mes "<FONT SIZE = 14><B>Sigh…</B></FONT>";
				mes "I'm doing my best to resolve it.";
				emotion ET_HNG,getnpcid(0,"Valdaris#ep21_tour3");
				next;
				mes "[Laura Valdaris]";
				mes "Then let's head to the ^e5555etraining ground^000000.";
				completequest 24010;
				setquest 24011;
				questinfo_refresh;
				close2;
				cutin "",255;
				cloaknpc("Lehar#ep21_tour3",true,getcharid(0));
				cloaknpc("Nillem#ep21_tour3",true,getcharid(0));
				cloaknpc("Valdaris#ep21_tour3",true,getcharid(0));
				cloaknpc("Kid#ep21_tour3_1",true,getcharid(0));
				cloaknpc("Kid#ep21_tour3_2",true,getcharid(0));
				cloaknpc("Kid#ep21_tour3_3",true,getcharid(0));
				cloaknpc("Kid#ep21_tour3_4",true,getcharid(0));
				cloaknpc("Kid#ep21_tour3_5",true,getcharid(0));
				cloaknpc("Kid#ep21_tour3_6",true,getcharid(0));
				navigateto("jor_mbase",145,108);
				end;
			}
			if(isbegin_quest(24011) == 1){
				cloaknpc("Lehar#ep21_tour3",false,getcharid(0));
				cloaknpc("Nillem#ep21_tour3",false,getcharid(0));
				cloaknpc("Valdaris#ep21_tour3",false,getcharid(0));
				cutin "ep21_valdaris01.png",2;
				mes "[Laura Valdaris]";
				mes "The ^e5555eWigner Merchant Guild^000000 handles majority of the work related to the rescued individuals, but those who have been brainwashed or coaxed stays here to some extent before we send them back to their homeland.";
				npctalk "Nillem : You really do all sort of things here.","Nillem#ep21_tour3",bc_self;
				next;
				mes "[Laura Valdaris]";
				mes "Sending someone who was involved with the cult back to their homeland is dangerous.";
				mes "<B>Even if they're just children.</B>";
				next;
				mes "[Laura Valdaris]";
				mes "It's easier to manage people who wants to join the mercenary to fight the cult than the,";
				npctalk "Laura Valdaris : The're excellent allies.","Valdaris#ep21_tour3",bc_self;
				next;
				mes "[Laura Valdaris]";
				mes "young childrens who were either kidnapped or brought by their own parents…";
				mes "It's a tough call.";
				emotion ET_HUM2,getnpcid(0,"Valdaris#ep21_tour3");
				next;
				mes "[Laura Valdaris]";
				mes "<FONT SIZE = 14><B>…</B></FONT>";
				mes "<FONT SIZE = 14><B>Sigh…</B></FONT>";
				mes "I'm doing my best to resolve it.";
				emotion ET_HNG,getnpcid(0,"Valdaris#ep21_tour3");
				next;
				mes "[Laura Valdaris]";
				mes "Then let's head to the ^e5555etraining ground^000000.";
				close2;
				cutin "",255;
				cloaknpc("Lehar#ep21_tour3",true,getcharid(0));
				cloaknpc("Nillem#ep21_tour3",true,getcharid(0));
				cloaknpc("Valdaris#ep21_tour3",true,getcharid(0));
				navigateto("jor_mbase",145,108);
				end;				
			}
			break;

		case 4:
			if(isbegin_quest(24011) == 1){
				cutin "ep21_valdaris01.png",2;
				mes "[Valdaris]";
				mes "This training ground is technically an area for the mercenary group, but it's a public training ground used by many people.";
				cloaknpc("Lehar#ep21_tour4",false,getcharid(0));
				cloaknpc("Nillem#ep21_tour4",false,getcharid(0));
				cloaknpc("Valdaris#ep21_tour4",false,getcharid(0));
				cloaknpc("???#ep21_tour4_lee",false,getcharid(0));
				next;
				mes "[Valdaris]";
				mes "You're welcome to use it freely while you're with the mercenary group…";
				next;
				cutin "",255;
				mes "[???]";
				mes "<FONT SIZE = 60><B>Waaaah!!!!</B></FONT>";
				next;
				cutin "ep21_soldier_a.png",2;
				mes "[???]";
				mes "<FONT SIZE = 16><B>Nice Work!!!</B></FONT>";
				next;
				cutin "ep21_soldier_b.png",2;
				mes "[???]";
				mes "<FONT SIZE = 16><B>Great!! That's right!!!!</B></FONT>";
				next;
				cutin "",255;
				mes "[???]";
				mes "<FONT SIZE = 20><B>Ah!!!!!!!</B></FONT>";
				next;
				cutin "ep21_soldier_b.png",2;
				mes "[???]";
				mes "<FONT SIZE = 14><B>Take him down!!!</B></FONT>";
				next;
				cutin "ep21_soldier_a.png",2;
				mes "[???]";
				mes "<FONT SIZE = 16><B>300 Zeny for broken arms!!!</B></FONT>";
				next;
				cutin "ep21_soldier_b.png",2;
				mes "[???]";
				mes "<FONT SIZE = 16><B>I say 500 Zeny for a broken leg!!!</B></FONT>";
				next;
				cutin "ep21_lee02.png",2;
				mes "[???]";
				mes "Anyone betting on a concussion?";
				mes "They payout is huge if you win~";
				next;
				cutin "ep21_soldier_a.png",2;
				mes "[???]";
				mes "<FONT SIZE = 14><B>300 Zeny for broken ribs!</B></FONT>";
				next;
				cutin "ep21_lee03.png",2;
				mes "[???]";
				mes "His ribs is already broken, betting on that is too boring~";
				mes "Besides that, the odds are too low even if you win, you might not get your Zeny back.";
				emotion ET_OK,getnpcid(0,"???#ep21_tour4_lee");
				next;
				cutin "ep21_valdaris05.png",2;
				mes "[Laura Valdaris]";
				mes "<FONT SIZE = 16><B>What is going on here!!!</B></FONT>";
				emotion ET_HUK,getnpcid(0,"Valdaris#ep21_tour4");
				next;
				cutin "ep21_soldier_a.png",2;
				mes "[???]";
				mes "<FONT SIZE = 16><B>Ack, it's ma'am Valdaris!!</B></FONT>";
				emotion ET_HUK,getnpcid(0,"Mercenary Member#ep21_tour4_1");
				emotion ET_HUK,getnpcid(0,"Mercenary Member#ep21_tour4_2");
				emotion ET_HUK,getnpcid(0,"Mercenary Member#ep21_tour4_3");
				emotion ET_HUK,getnpcid(0,"Mercenary Member#ep21_tour4_4");
				emotion ET_HUK,getnpcid(0,"Mercenary Member#ep21_tour4_5");
				emotion ET_HUK,getnpcid(0,"Mercenary Member#ep21_tour4_6");
				emotion ET_HUK,getnpcid(0,"Mercenary Member#ep21_tour4_7");
				emotion ET_HUK,getnpcid(0,"???#ep21_tour4_lee");
				next;
				cutin "ep21_soldier_b.png",2;
				mes "[???]";
				mes "<FONT SIZE = 14><B>The vice-captain!</B></FONT>";
				next;
				cutin "ep21_soldier_a.png",2;
				mes "[???]";
				mes "<FONT SIZE = 14><B>Run!!!</B></FONT>";
				next;
				cutin "ep21_valdaris05.png",2;
				mes "[Laura Valdaris]";
				mes "<FONT SIZE = 14><B>Move aside!</B></FONT>";
				mes "<FONT SIZE = 14><B>What are you doing!</B></FONT>";
				completequest 24011;
				setquest 24012;
				close2;
				cutin "",255;
				cloaknpc("Lehar#ep21_tour4",true,getcharid(0));
				cloaknpc("Nillem#ep21_tour4",true,getcharid(0));
				cloaknpc("Valdaris#ep21_tour4",true,getcharid(0));
				navigateto("jor_mbase",135,108);
				end;
			}
			if(isbegin_quest(24012) == 1){
				cloaknpc("Lehar#ep21_tour4",false,getcharid(0));
				cloaknpc("Nillem#ep21_tour4",false,getcharid(0));
				cloaknpc("Valdaris#ep21_tour4",false,getcharid(0));
				cloaknpc("???#ep21_tour4_lee",false,getcharid(0));
				cutin "ep21_valdaris05.png",2;
				mes "[Laura Valdaris]";
				mes "<FONT SIZE = 16><B>What is going on here!!!</B></FONT>";
				emotion ET_HUK,getnpcid(0,"Valdaris#ep21_tour4");
				next;
				cutin "ep21_soldier_a.png",2;
				mes "[???]";
				mes "<FONT SIZE = 16><B>Ack, it's ma'am Valdaris!!</B></FONT>";
				emotion ET_HUK,getnpcid(0,"Mercenary Member#ep21_tour4_1");
				emotion ET_HUK,getnpcid(0,"Mercenary Member#ep21_tour4_2");
				emotion ET_HUK,getnpcid(0,"Mercenary Member#ep21_tour4_3");
				emotion ET_HUK,getnpcid(0,"Mercenary Member#ep21_tour4_4");
				emotion ET_HUK,getnpcid(0,"Mercenary Member#ep21_tour4_5");
				emotion ET_HUK,getnpcid(0,"Mercenary Member#ep21_tour4_6");
				emotion ET_HUK,getnpcid(0,"Mercenary Member#ep21_tour4_7");
				emotion ET_HUK,getnpcid(0,"???#ep21_tour4_lee");
				next;
				cutin "ep21_soldier_b.png",2;
				mes "[???]";
				mes "<FONT SIZE = 14><B>The vice-captain!</B></FONT>";
				next;
				cutin "ep21_soldier_a.png",2;
				mes "[???]";
				mes "<FONT SIZE = 14><B>Run!!!</B></FONT>";
				next;
				cutin "ep21_valdaris05.png",2;
				mes "[Laura Valdaris]";
				mes "<FONT SIZE = 14><B>Move aside!</B></FONT>";
				mes "<FONT SIZE = 14><B>What are you doing!</B></FONT>";
				close2;
				cutin "",255;
				cloaknpc("Lehar#ep21_tour4",true,getcharid(0));
				cloaknpc("Nillem#ep21_tour4",true,getcharid(0));
				cloaknpc("Valdaris#ep21_tour4",true,getcharid(0));
				navigateto("jor_mbase",135,108);
				end;
			}
			break;

		case 5:
			if(isbegin_quest(24012) == 1){
				cutin "ep21_richard03.png",0;
				mes "[???]";
				mes "<FONT SIZE = 18><B>Aaah!!!</B></FONT>";
				mes "<FONT SIZE = 16><B>Stop it!!!</B></FONT>";
				cloaknpc("Lehar#ep21_tour5",false,getcharid(0));
				cloaknpc("Nillem#ep21_tour5",false,getcharid(0));
				cloaknpc("Valdaris#ep21_tour5",false,getcharid(0));
				cloaknpc("???#ep21_tour5_richard",false,getcharid(0));
				cloaknpc("???#ep21_tour5_nerius",false,getcharid(0));
				next;
				mes "[???]";
				mes "<FONT SIZE = 14><B>Ugh!</B></FONT>";
				specialeffect EF_SPREADATTACK,AREA,"???#ep21_tour5_richard";
				next;
				removespecialeffect EF_SPREADATTACK,AREA,"???#ep21_tour5_richard";
				mes "[???]";
				mes "<FONT SIZE = 16><B>Hey, you crazy bastards!!</B></FONT>";
				mes "<FONT SIZE = 16><B>Can't you see I'm casting!!!</B></FONT>";
				mes "<FONT SIZE = 16><B>Stop betting and break them up!!!</B></FONT>";
				specialeffect EF_ITEM_CURSE,AREA,"???#ep21_tour5_richard";
				specialeffect EF_MAP_MAGICZONE2,AREA,"???#ep21_tour5_nerius";
				specialeffect EF_WHITEBODY,AREA,"???#ep21_tour5_nerius";
				emotion ET_HELP,getnpcid(0,"???#ep21_tour5_richard");
				next;
				removespecialeffect EF_ITEM_CURSE,AREA,"???#ep21_tour5_richard";
				mes "[???]";
				mes "<FONT SIZE = 18><B>Tch!!!</B></FONT>";
				specialeffect EF_SPINEDBODY2,AREA,"???#ep21_tour5_richard";
				specialeffect EF_NPC_BURNT,AREA,"???#ep21_tour5_richard";
				next;
				removespecialeffect EF_MAP_MAGICZONE2,AREA,"???#ep21_tour5_nerius";
				specialeffect EF_BEGINSPELL_YB,AREA,"???#ep21_tour5_richard";
				mes "[???]";
				mes "<FONT SIZE = 16><B>Yah!!!</B></FONT>";
				next;
				removespecialeffect EF_SPINEDBODY2,AREA,"???#ep21_tour5_richard";
				removespecialeffect EF_BEGINSPELL_YB,AREA,"???#ep21_tour5_richard";
				mes "[???]";
				mes "<FONT SIZE = 14><B>Graah!!!!!!</B></FONT>";
				specialeffect EF_MANHOLE,AREA,"???#ep21_tour5_richard";
				next;
				specialeffect EF_FIREWALL2,AREA,"???#ep21_tour5_richard";
				specialeffect EF_DANCE_BLADE_ATK,AREA,"???#ep21_tour5_richard";
				cutin "ep21_valdaris05.png",2;
				mes "[Laura Valdaris]";
				mes "<FONT SIZE = 16><B>Stop it!!!</B></FONT>";
				mes "<FONT SIZE = 18><B>^e5555eNerius!!!^000000</B></FONT>";
				emotion ET_HUK,getnpcid(0,"Valdaris#ep21_tour5");
				next;
				removespecialeffect EF_NPC_BURNT,AREA,"???#ep21_tour5_richard";
				specialeffect EF_ERASER_CUTTER,AREA,"???#ep21_tour5_richard";
				mes "[Laura Valdaris]";
				mes "<FONT SIZE = 16><B>Lee!!!!</B></FONT>";
				mes "<FONT SIZE = 16><B>What are you doing, why aren't you breaking them up!!</B></FONT>";
				next;
				cutin "ep21_lee03.png",2;
				mes "[Lee]";
				mes "Tsk! It was just getting interesting.";
				emotion ET_HNG,getnpcid(0,"???#ep21_tour4_lee");
				next;
				removespecialeffect EF_WHITEBODY,AREA,"???#ep21_tour5_nerius";
				removespecialeffect EF_MANHOLE,AREA,"???#ep21_tour5_richard";
				removespecialeffect EF_FIREWALL2,AREA,"???#ep21_tour5_richard";
				removespecialeffect EF_DANCE_BLADE_ATK,AREA,"???#ep21_tour5_richard";
				removespecialeffect EF_ERASER_CUTTER,AREA,"???#ep21_tour5_richard";
				cutin "ep21_lee01.png",2;
				mes "[Lee]";
				mes "Gala~";
				mes "Stop.";
				next;
				cutin "ep21_lee02.png",2;
				mes "[Lee]";
				mes "If you keep hitting him, the captain will really die.";
				mes "Laura will get angry~";
				next;
				cutin "ep21_richard03.png",0;
				mes "[Richard]";
				mes "<FONT SIZE = 14>…</FONT>";
				mes "<FONT SIZE = 14>Kah…</FONT>";
				mes "<FONT SIZE = 14><B>*Cough*!!!</B></FONT>";
				next;
				mes "[Richard]";
				mes "I thought I was going to *cough*… die.";
				emotion ET_KEK,getnpcid(0,"???#ep21_tour5_richard");
				next;
				cutin "ep21_richard02.png",0;
				mes "[Richard]";
				mes "Sigh~";
				mes "As expected, the only one who really cares about me is Lara!";
				next;
				cutin "ep21_valdaris03.png",2;
				mes "[Laura Valdaris]";
				mes "It's Laura not Lara.";
				next;
				cutin "ep21_valdaris04.png",2;
				mes "[Laura Valdaris]";
				mes "<FONT SIZE = 14><B>No that's not the point, what are you doing here!</B></FONT>";
				next;
				cutin "ep21_richard02.png",0;
				mes "[Richard]";
				mes "Ah~";
				mes "Nothing much.";
				mes "We were just playing around a little bit.";
				mes "Don't be so angry.";
				next;
				cutin "ep21_valdaris04.png",2;
				mes "[Laura Valdaris]";
				mes "<FONT SIZE = 14><B>How is that playing around, you were beaten up so badly!!</B></FONT>";
				next;
				cutin "ep21_richard03.png",0;
				mes "[Richard]";
				mes "My head is still ringing, could you stop yelling?";
				next;
				cutin "ep21_lee02.png",2;
				mes "[Lee]";
				mes "Oh~ It's a concussion!";
				npctalk "Mercenary Member : Ahh!!","Mercenary Member#ep21_tour4_1",bc_self;
				npctalk "Mercenary Member : There goes my bet!","Mercenary Member#ep21_tour4_4",bc_self;
				npctalk "Mercenary Member : What a waste!","Mercenary Member#ep21_tour4_7",bc_self;
				next;
				cutin "ep21_valdaris05.png",2;
				mes "[Laura Valdaris]";
				mes "<FONT SIZE = 14><B>Everyone, stop!</B></FONT>";
				emotion ET_FRET,getnpcid(0,"Valdaris#ep21_tour5");
				next;
				cutin "ep21_valdaris03.png",2;
				mes "[Laura Valdaris]";
				mes "Captain, let's go to your room first.";
				mes "You need to get treated quickly.";
				next;
				mes "[Laura Valdaris]";
				mes "We'll discuss the details there…";
				mes "Nerius, please support the captain.";
				next;
				cutin "ep21_richard03.png",0;
				mes "[Richard]";
				mes "<FONT SIZE = 16><B>Ouch, ouch, ouch, ouch!!</B></FONT>";
				mes "<FONT SIZE = 16><B>My ribs!!</B></FONT>";
				mes "<FONT SIZE = 16><B>Don't pull my arms!</B></FONT>";
				emotion ET_KEK,getnpcid(0,"???#ep21_tour5_richard");
				next;
				cutin "ep21_valdaris03.png",2;
				mes "[Laura Valdaris]";
				mes "<B>Broken ribs, a ringing head, and injured everywhere I guess we have to carry you to your room very carefully, like a princess~~.</B>";
				npctalk "Laura Valdaris : We~ll do~ne great job!","Valdaris#ep21_tour5",bc_self;
				next;
				cutin "ep21_richard03.png",0;
				mes "[Richard]";
				mes "No, that's embarrassing…";
				next;
				cutin "ep21_valdaris03.png",2;
				mes "[Laura Valdaris]";
				mes "<FONT SIZE = 14><B>It's supposed to be embarrassing.</B></FONT>";
				next;
				cutin "ep21_lee02.png",2;
				mes "[Lee]";
				mes "Wah~ Laura is really angry.";
				mes "I better run away quickly.";
				next;
				cutin "ep21_valdaris03.png",2;
				mes "[Laura Valdaris]";
				mes "<FONT SIZE = 14><B>Lee!</B></FONT>";
				mes "Why are you running away.";
				mes "You're coming with us too!";
				completequest 24012;
				setquest 24013;
				close2;
				cutin "",255;
				cloaknpc("Lehar#ep21_tour5",true,getcharid(0));
				cloaknpc("Nillem#ep21_tour5",true,getcharid(0));
				cloaknpc("Valdaris#ep21_tour5",true,getcharid(0));
				cloaknpc("???#ep21_tour5_richard",true,getcharid(0));
				cloaknpc("???#ep21_tour5_nerius",true,getcharid(0));
				cloaknpc("???#ep21_tour4_lee",true,getcharid(0));
				navigateto("mbase_in",167,128);
				end;
			}
			if(isbegin_quest(24013) == 1){
				cloaknpc("Lehar#ep21_tour5",false,getcharid(0));
				cloaknpc("Nillem#ep21_tour5",false,getcharid(0));
				cloaknpc("Valdaris#ep21_tour5",false,getcharid(0));
				cloaknpc("???#ep21_tour5_richard",false,getcharid(0));
				cloaknpc("???#ep21_tour5_nerius",false,getcharid(0));
				cloaknpc("???#ep21_tour4_lee",false,getcharid(0));
				cutin "ep21_valdaris03.png",2;
				mes "[Laura Valdaris]";
				mes "Captain, let's go to your room first.";
				mes "You need to get treated quickly.";
				next;
				mes "[Laura Valdaris]";
				mes "We'll discuss the details there…";
				mes "Nerius, please support the captain.";
				next;
				cutin "ep21_richard03.png",0;
				mes "[Richard]";
				mes "<FONT SIZE = 16><B>Ouch, ouch, ouch, ouch!!</B></FONT>";
				mes "<FONT SIZE = 16><B>My ribs!!</B></FONT>";
				mes "<FONT SIZE = 16><B>Don't pull my arms!</B></FONT>";
				emotion ET_KEK,getnpcid(0,"???#ep21_tour5_richard");
				next;
				cutin "ep21_valdaris03.png",2;
				mes "[Laura Valdaris]";
				mes "<B>Broken ribs, a ringing head, and injured everywhere I guess we have to carry you to your room very carefully, like a princess~~.</B>";
				npctalk "Laura Valdaris : We~ll do~ne great job!","Valdaris#ep21_tour5",bc_self;
				next;
				cutin "ep21_richard03.png",0;
				mes "[Richard]";
				mes "No, that's embarrassing…";
				next;
				cutin "ep21_valdaris03.png",2;
				mes "[Laura Valdaris]";
				mes "<FONT SIZE = 14><B>It's supposed to be embarrassing.</B></FONT>";
				next;
				cutin "ep21_lee02.png",2;
				mes "[Lee]";
				mes "Wah~ Laura is really angry.";
				mes "I better run away quickly.";
				next;
				cutin "ep21_valdaris03.png",2;
				mes "[Laura Valdaris]";
				mes "<FONT SIZE = 14><B>Lee!</B></FONT>";
				mes "Why are you running away.";
				mes "You're coming with us too!";
				close2;
				cutin "",255;
				cloaknpc("Lehar#ep21_tour5",true,getcharid(0));
				cloaknpc("Nillem#ep21_tour5",true,getcharid(0));
				cloaknpc("Valdaris#ep21_tour5",true,getcharid(0));
				cloaknpc("???#ep21_tour5_richard",true,getcharid(0));
				cloaknpc("???#ep21_tour5_nerius",true,getcharid(0));
				cloaknpc("???#ep21_tour4_lee",true,getcharid(0));
				navigateto("mbase_in",167,128);
				end;
			}
			break;		
	}
end;

OnInit:
	.@id = atoi(replacestr(strnpcinfo(2),"ep21_valdaris",""));
	.@qid = 24007 + .@id;
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(" + (24007 + .@id) +") == 1";
end;
}

jor_mbase,316,100,0	duplicate(#ep21_valdaris1)	#ep21_valdaris2	HIDDEN_WARP_NPC,2,2
jor_mbase,243,120,0	duplicate(#ep21_valdaris1)	#ep21_valdaris3	HIDDEN_WARP_NPC,2,2
jor_mbase,145,108,0	duplicate(#ep21_valdaris1)	#ep21_valdaris4	HIDDEN_WARP_NPC,2,2
jor_mbase,135,108,0	duplicate(#ep21_valdaris1)	#ep21_valdaris5	HIDDEN_WARP_NPC,2,2

jor_mbase,317,114,1	duplicate(dummynpc)	Lehar#ep21_tour1	4_EP19_LEHAR
jor_mbase,318,116,1	duplicate(dummynpc)	Nillem#ep21_tour1	4_M_NILLEM
jor_mbase,315,120,4	duplicate(dummynpc)	Valdaris#ep21_tour1	4_EP21_VALDARIS

jor_mbase,315,102,6	duplicate(dummynpc)	Lehar#ep21_tour2	4_EP19_LEHAR
jor_mbase,316,103,6	duplicate(dummynpc)	Nillem#ep21_tour2	4_M_NILLEM
jor_mbase,318,102,3	duplicate(dummynpc)	Valdaris#ep21_tour2	4_EP21_VALDARIS

jor_mbase,244,119,5	duplicate(dummynpc)	Lehar#ep21_tour3	4_EP19_LEHAR
jor_mbase,245,122,5	duplicate(dummynpc)	Nillem#ep21_tour3	4_M_NILLEM
jor_mbase,247,120,3	duplicate(dummynpc)	Valdaris#ep21_tour3	4_EP21_VALDARIS
jor_mbase,244,114,7	duplicate(dummynpc)	Kid#ep21_tour3_1	4_EP21_WORKER_KID_A
jor_mbase,247,115,7	duplicate(dummynpc)	Kid#ep21_tour3_2	4_EP21_WORKER_KID_A
jor_mbase,245,118,7	duplicate(dummynpc)	Kid#ep21_tour3_3	4_EP21_WORKER_KID_A
jor_mbase,246,118,7	duplicate(dummynpc)	Kid#ep21_tour3_4	4_EP21_WORKER_KID_B
jor_mbase,248,119,1	duplicate(dummynpc)	Kid#ep21_tour3_5	4_EP21_WORKER_KID_B
jor_mbase,245,116,7	duplicate(dummynpc)	Kid#ep21_tour3_6	4_EP21_WORKER_KID_B

jor_mbase,145,105,3	duplicate(dummynpc)	Lehar#ep21_tour4	4_EP19_LEHAR
jor_mbase,143,106,3	duplicate(dummynpc)	Nillem#ep21_tour4	4_M_NILLEM
jor_mbase,143,110,3	duplicate(dummynpc)	Valdaris#ep21_tour4	4_EP21_VALDARIS
jor_mbase,134,111,3	duplicate(dummynpc)	???#ep21_tour4_lee	4_EP21_LEE
jor_mbase,136,106,2	duplicate(dummynpc2)	Mercenary Member#ep21_tour4_1	4_EP21_SOLDIER_A
jor_mbase,134,107,2	duplicate(dummynpc2)	Mercenary Member#ep21_tour4_2	4_EP21_SOLDIER_B
jor_mbase,139,112,3	duplicate(dummynpc2)	Mercenary Member#ep21_tour4_3	4_EP21_SOLDIER_A
jor_mbase,136,110,3	duplicate(dummynpc2)	Mercenary Member#ep21_tour4_4	4_EP21_SOLDIER_B
jor_mbase,135,112,3	duplicate(dummynpc2)	Mercenary Member#ep21_tour4_5	4_EP21_SOLDIER_A
jor_mbase,138,113,3	duplicate(dummynpc2)	Mercenary Member#ep21_tour4_6	4_EP21_SOLDIER_B
jor_mbase,132,106,2	duplicate(dummynpc2)	Mercenary Member#ep21_tour4_7	4_EP21_SOLDIER_B

jor_mbase,135,111,3	duplicate(dummynpc)	Lehar#ep21_tour5	4_EP19_LEHAR
jor_mbase,138,110,3	duplicate(dummynpc)	Nillem#ep21_tour5	4_M_NILLEM
jor_mbase,133,109,3	duplicate(dummynpc)	Valdaris#ep21_tour5	4_EP21_VALDARIS
jor_mbase,131,110,5	duplicate(dummynpc)	???#ep21_tour5_richard	4_EP21_RICHARD
jor_mbase,132,111,3	duplicate(dummynpc)	???#ep21_tour5_nerius	4_EP21_GALAXIA_A

mbase_in,166,126,0	script	#ep21_richardroom	HIDDEN_WARP_NPC,1,1,{
	end;

OnTouch:
	if(isbegin_quest(24013) == 1 || isbegin_quest(24014) == 1 || isbegin_quest(24015) == 1){
		cloaknpc("Valdaris#ep21_richardroom",false,getcharid(0));
		cloaknpc("Lehar#ep21_richardroom",false,getcharid(0));
		cloaknpc("Nillem#ep21_richardroom",false,getcharid(0));
		cloaknpc("Lee#ep21_richardroom",false,getcharid(0));
		cloaknpc("Gunter#ep21_richardroom",false,getcharid(0));
		if(isbegin_quest(24013) == 1)
			cloaknpc("Nerius#ep21_richardroom1",false,getcharid(0));
		if(isbegin_quest(24014) == 1 || isbegin_quest(24015) == 1)
			cloaknpc("Nerius#ep21_richardroom2",false,getcharid(0));
	}
end;
}

mbase_in,167,128,3	script(CLOAKED)	Valdaris#ep21_richardroom	4_EP21_VALDARIS,{
	if(isbegin_quest(24013) == 1){
		cutin "ep21_valdaris03.png",2;
		mes "[Laura Valdaris]";
		mes "Sigh, seriously.";
		mes "What were you trying to do.";
		next;
		cutin "ep21_richard03.png",0;
		mes "[Richard]";
		mes "<FONT SIZE = 16><B>Ouch!!!!!</B></FONT>";
		mes "<FONT SIZE = 14><B>It hurts, take it easy!</B></FONT>";
		npctalk "Richard : I'm going to die!!!!!","Richard#ep21_richardroom",bc_self;
		emotion ET_KEK,getnpcid(0,"Richard#ep21_richardroom");
		next;
		cutin "ep21_valdaris04.png",2;
		mes "[Laura Valdaris]";
		mes "<B>I already expected that you won't stay still in the office.</B>";
		next;
		cutin "ep21_valdaris05.png",2;
		mes "[Laura Valdaris]";
		mes "<FONT SIZE = 16><B>But why!</B></FONT>";
		mes "<FONT SIZE = 18><B>Why!</B></FONT>";
		mes "<FONT SIZE = 16><B>Why were you getting beaten up in the training grounds!</B></FONT>";
		mes "<FONT SIZE = 14>And you Nerius.</FONT>";
		mes "<FONT SIZE = 14>Why were you beating the captain!</FONT>";
		next;
		cutin "ep21_galaxia_a.png",2;
		mes "[Nerius]";
		mes "…";
		next;
		cutin "ep21_lee03.png",2;
		mes "[Lee]";
		mes "Come on~";
		mes "Laura, don't yell so much.";
		mes "You're scaring Gala.";
		emotion ET_PROFUSELY_SWAT,getnpcid(0,"Lee#ep21_richardroom");
		next;
		cutin "ep21_valdaris04.png",2;
		mes "[Laura Valdaris]";
		mes "<FONT SIZE = 16><B>And you, Lee!</B></FONT>";
		mes "<FONT SIZE = 16><B>Instead of stopping them, you started betting on them!!!</B></FONT>";
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "It's not everyday you see something entertaining.";
		next;
		cutin "ep21_valdaris03.png",2;
		mes "[Laura Valdaris]";
		mes "<FONT SIZE = 16><B>Argh…</B></FONT>";
		mes "<FONT SIZE = 14>Sigh……………</FONT>";
		emotion ET_HNG,getnpcid(0,"Valdaris#ep21_richardroom");
		next;
		cutin "ep21_galaxia_a.png",2;
		mes "[Nerius]";
		mes "…";
		next;
		cutin "ep21_valdaris03.png",2;
		mes "[Laura Valdaris]";
		mes "Nerius, please take off your armor since the blood on it is dripping on the floor.";
		next;
		cutin "ep21_galaxia_a.png",2;
		mes "[Nerius]";
		mes "Okay";
		emotion ET_OK,getnpcid(0,"Nerius#ep21_richardroom2");
		cloaknpc("Nerius#ep21_richardroom1",true,getcharid(0));
		cloaknpc("Nerius#ep21_richardroom2",false,getcharid(0));
		next;
		cutin "ep21_valdaris01.png",2;
		mes "[Laura Valdaris]";
		mes "Do you understand?";
		mes "Nerius.";
		mes "You can't hit your comrades like that.";
		next;
		cutin "ep21_galaxia02.png",2;
		mes "[Nerius]";
		mes "But…";
		mes "^e5555eRichard^000000 ordered me to attack him…";
		emotion ET_PROFUSELY_SWAT,getnpcid(0,"Nerius#ep21_richardroom2");
		next;
		cutin "ep21_valdaris03.png",2;
		mes "[Laura Valdaris]";
		mes "What does that mean.";
		mes "He told you to attack him.";
		emotion ET_HUK,getnpcid(0,"Richard#ep21_richardroom");
		completequest 24013;
		setquest 24014;
		questinfo_refresh;
		close2;
		cutin "",255;
		navigateto("mbase_in",168,126);
		end;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24013) == 1";
end;
}

mbase_in,168,126,3	script	Richard#ep21_richardroom	4_EP21_RICHARD,{
	if(isbegin_quest(24014) == 1){
		cutin "ep21_richard02.png",0;
		mes "[Richard]";
		mes "<FONT SIZE = 14><B>Oh~</B></FONT>";
		mes "Okay!";
		mes "Lara~ Listen to me.";
		mes "Even you would like this one.";
		emotion ET_SMILE,getnpcid(0,"Richard#ep21_richardroom");
		next;
		cutin "ep21_valdaris03.png",2;
		mes "[Laura Valdaris]";
		mes "What?";
		next;
		cutin "ep21_richard02.png",0;
		mes "[Richard]";
		mes "We're been so busy lately.";
		next;
		cutin "ep21_valdaris03.png",2;
		mes "[Laura Valdaris]";
		mes "<FONT SIZE = 14><B>Knowing that, you still left your post just like that?</B></FONT>";
		next;
		cutin "ep21_richard03.png",0;
		mes "[Richard]";
		mes "<FONT SIZE = 10>No.</FONT>";
		mes "Don't get mad and just listen.";
		emotion ET_PROFUSELY_SWAT,getnpcid(0,"Richard#ep21_richardroom");
		next;
		cutin "ep21_richard01.png",0;
		mes "[Richard]";
		mes "Since we joined the Gaebolg, the number of people is increasing by the day, but we don't get skilled individuals who just come in to make a living like before, we're getting everything from kids who needs to learn how to read, to people who wants to be a merchant, and others who are simply being dumped into the mercenary group.";
		emotion ET_HUK,getnpcid(0,"Valdaris#ep21_richardroom");
		next;
		mes "[Richard]";
		mes "With that in mind, I had an idea to create something we're a basic mercenary combat book, something we're best at. Anyone can learn it easily without the need of someone to teach them, then we can focus more on other areas";
		emotion ET_HUK,getnpcid(0,"Valdaris#ep21_richardroom");
		next;
		cutin "ep21_richard02.png",0;
		mes "[Richard]";
		mes "If we have a book, we could even hold classes or something.";
		mes "Lee said that he would help creating the illustrations.";
		next;
		cutin "ep21_valdaris04.png",2;
		mes "[Laura Valdaris]";
		mes "<B>What's wrong with you all of a sudden.</B>";
		emotion ET_HUK,getnpcid(0,"Valdaris#ep21_richardroom");
		next;
		cutin "ep21_richard02.png",0;
		mes "[Richard]";
		mes "Huh?";
		mes "What do you mean?";
		next;
		cutin "ep21_valdaris03.png",2;
		mes "[Laura Valdaris]";
		mes "Why are you suddenly thinking about great things.";
		mes "Did Nerius really hit you that hard on the head?";
		mes "<FONT SIZE = 10>It might really be a concussion…</FONT>";
		npctalk "Laura Valdaris : Ah… surprising…","Valdaris#ep21_richardroom",bc_self;
		next;
		cutin "ep21_richard03.png",0;
		mes "[Richard]";
		mes "What do you mean.";
		mes "Is that an insult or a compliment?";
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "Isn't this the highest compliment you've heard from Laura?";
		next;
		cutin "ep21_richard02.png",0;
		mes "[Richard]";
		mes "<FONT SIZE = 14><B>Hehe.</B></FONT>";
		mes "Is it really?";
		emotion ET_THINK,getcharid(3);
		emotion ET_THINK,getnpcid(0,"Lehar#ep21_richardroom");
		emotion ET_THINK,getnpcid(0,"Nillem#ep21_richardroom");
		next;
		mes "[Richard]";
		mes "Anyway, I think it would be good to make books for teaching the children…";
		next;
		cutin "ep21_richard01.png",0;
		mes "[Richard]";
		mes "Especially for merchant training, I don't have any idea about that, we could ask Wigner to either help create the book or send someone to teach.";
		next;
		cutin "ep21_valdaris01.png",2;
		mes "[Laura Valdaris]";
		mes "Hm…";
		mes "That sounds more like an academy than a mercenary group…";
		mes "But, it's a great idea.";
		next;
		cutin "ep21_valdaris03.png",2;
		mes "[Laura Valdaris]";
		mes "It's a great idea, but what does it have to do with you getting hit by Nerius?";
		next;
		cutin "ep21_richard02.png",0;
		mes "[Richard]";
		mes "It's to accurately illustrate the proper combat stances, it's best to draw from real-life examples.";
		mes "Galaxia and I were simply the models for the illustration.";
		next;
		mes "[Richard]";
		mes "Alright, Galaxia.";
		mes "Next time, don't hit me so hard and just pretend to hit me so Lee can draw the illustration properly.";
		emotion ET_GOODBOY,getnpcid(0,"Richard#ep21_richardroom");
		next;
		cutin "ep21_richard03.png",0;
		mes "[Richard]";
		mes "And since the <FONT SIZE = 14>ribs breaks easily, don't even come close to a comrade's ribs or collarbones.</FONT>";
		next;
		cutin "ep21_galaxia04.png",2;
		mes "[Galaxia Nerius]";
		mes "<FONT SIZE = 14>Yes.</FONT>";
		mes "Got it!";
		mes "I won't break them.";
		next;
		cutin "ep21_galaxia02.png",2;
		mes "[Galaxia Nerius]";
		mes "Richard ordered me to attack him using the basics…";
		mes "I thought he wanted to fight me like how we first met.";
		next;
		cutin "ep21_richard02.png",0;
		mes "[Richard]";
		mes "<FONT SIZE = 16><B>Hahahahaha!</B></FONT>";
		mes "<FONT SIZE = 14><B>I'm joking~</B></FONT>";
		next;
		mes "[Richard]";
		mes "<FONT SIZE = 14><B>Why would I want to fight you, who was perfectly fine after getting directly hit by ballistas.</B></FONT>";
		next;
		mes "[Richard]";
		mes "By the way, Lee!";
		mes "After all the beatings that I took, did you get any good illustration?";
		mes "Show me what you've drawn.";
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "<FONT SIZE = 14><B>Of course!</B></FONT>";
		completequest 24014;
		setquest 24015;
		questinfo_refresh;
		close2;
		cutin "",255;
		navigateto("mbase_in",166,124);
		end;
	}
	if(isbegin_quest(24015) == 1){
		cloaknpc("Valdaris#ep21_richardroom",false,getcharid(0));
		cloaknpc("Lehar#ep21_richardroom",false,getcharid(0));
		cloaknpc("Nillem#ep21_richardroom",false,getcharid(0));
		cloaknpc("Lee#ep21_richardroom",false,getcharid(0));
		cloaknpc("Gunter#ep21_richardroom",false,getcharid(0));
		cloaknpc("Nerius#ep21_richardroom2",false,getcharid(0));
		cutin "ep21_richard02.png",0;
		mes "[Richard]";
		mes "By the way, Lee!";
		mes "After all the beatings that I took, did you get any good illustration?";
		mes "Show me what you've drawn.";
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "<FONT SIZE = 14><B>Of course!</B></FONT>";
		close2;
		cutin "",255;
		navigateto("mbase_in",166,124);
		end;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24014) == 1";
end;
}

mbase_in,166,124,3	script(CLOAKED)	Lee#ep21_richardroom	4_EP21_LEE,{
	if(isbegin_quest(24015) == 1){
		cutin "ep21_lee02.png",2;
		cutin "ep21_battle_cut",4;
		mes "[Lee]";
		mes "<FONT SIZE = 14><B>Tada~</B></FONT>";
		next;
		cutin "ep21_richard01.png",0;
		mes "[Richard]";
		mes "Is that what you drew earlier?";
		next;
		cutin "ep21_valdaris03.png",2;
		mes "[Laura Valdaris]";
		mes "No matter how I look at it, it's just an illustration of you getting beaten up.";
		next;
		cutin "ep21_richard02.png",0;
		mes "[Richard]";
		mes "<FONT SIZE = 14><B>Don't you like it?</B></FONT>";
		emotion ET_HUK,getnpcid(0,"Valdaris#ep21_richard");;
		emotion ET_HUK,getcharid(3);
		next;
		cutin "ep21_valdaris03.png",2;
		mes "[Laura Valdaris]";
		mes "<FONT SIZE = 14><B>What?</B></FONT>";
		mes "Well, it's well illustrated, but…";
		npctalk "Laura Valdaris : Are you serious?","Valdaris#ep21_richard",bc_self;
		next;
		cutin "ep21_richard02.png",0;
		mes "[Richard]";
		mes "Is it well illustrated enough that beginners can easily understand it?";
		mes "I think it's perfect for the ^e5555e<B>Close Combat - Pounding</B>^000000 section!";
		npctalk "Richard : Look at my dynamic pose.","Richard#ep21_richardroom",bc_self;
		next;
		cutin "ep21_valdaris01.png",2;
		mes "[Laura Valdaris]";
		mes "???";
		mes "Am I the only one who thinks that Lee is bullying the captain?";
		next;
		cutin "ep21_battle_cut.bmp",11;
		cutin "ep172_barmund_b01.png",0;
		mes "[???]";
		mes "Let's hope it turns into a great book.";
		next;
		cutin "ep21_lee01.png",2;
		mes "[Lee]";
		mes "Captain.";
		mes "Have you thought of a caption for the illustration?";
		next;
		cutin "ep21_richard03.png",0;
		mes "[Richard]";
		mes "Huh?";
		mes "I'm not good at that!";
		mes "I'll show it to you, but someone else should write the content.";
		next;
		cutin "ep21_lee03.png",2;
		mes "[Lee]";
		mes "Taking a beating from Gala without dying is impressive but. You're not really much of a help… ";
		emotion ET_HNG,getnpcid(0,"Lee#ep21_richardroom");
		next;
		cutin "ep172_barmund_b03.png",0;
		mes "[???]";
		mes "Can I help too?";
		mes "I'm good at writing.";
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "Really?";
		mes "It would be great if you could help us!";
		next;
		cutin "ep21_valdaris03.png",2;
		mes "[Laura Valdaris]";
		mes "Sigh…";
		emotion ET_ANGER,getnpcid(0,"Valdaris#ep21_richardroom");
		next;
		mes "[Laura Valdaris]";
		mes "As you've probably noticed, this is ^e5555eRichard, captain of the mercenary group^000000.";
		next;
		mes "[Laura Valdaris]";
		mes "It's hard to explain, but despite how he is,";
		mes "The mercenary group is doing well.";
		next;
		cutin "ep21_richard02.png",0;
		mes "[Richard]";
		mes "Lara~";
		mes "Are you talking about me?";
		next;
		mes "[Richard]";
		mes "<FONT SIZE = 14><B>oh!</B></FONT>";
		mes "<FONT SIZE = 14><B>I haven't seen your faces before.</B></FONT>";
		mes "<FONT SIZE = 14><B>Did you just join the mercenary group?</B></FONT>";
		mes "<FONT SIZE = 14><B>Let's get along!</B></FONT>";
		next;
		cutin "ep21_valdaris01.png",2;
		mes "[Laura Valdaris]";
		mes "^4e4e4e(Tan asked me to keep an eye on these people.";
		mes "They are very talented and powerful.)^000000";
		next;
		cutin "ep21_richard03.png",0;
		mes "[Richard]";
		mes "Why are you whispering like that, it's tickling my ears.";
		next;
		cutin "ep21_richard02.png",0;
		mes "[Richard]";
		mes "You and Tan really have trust issues.";
		next;
		cutin "ep21_valdaris04.png",2;
		mes "[Laura Valdaris]";
		mes "…";
		emotion ET_FRET,getnpcid(0,"Valdaris#ep21_richardroom");
		next;
		cutin "ep21_richard03.png",0;
		mes "[Richard]";
		mes "…";
		emotion ET_SWEAT,getnpcid(0,"Richard#ep21_richardroom");
		next;
		cutin "ep21_valdaris02.png",2;
		mes "[Laura Valdaris]";
		mes strcharinfo(0) + ", Nillem, Lehar.";
		mes "^e5555eLee^000000 will you show you the rest.";
		next;
		cutin "ep21_lee03.png",2;
		mes "[Lee]";
		mes "<FONT SIZE = 14><B>Why me?</B></FONT>";
		next;
		cutin "ep21_valdaris02.png",2;
		mes "[Laura Valdaris]";
		mes "First, let's move ^e5555eGala's armor^000000 to her room first…";
		mes "We'll meet again later.";
		next;
		cutin "ep21_richard03.png",0;
		mes "[Richard]";
		mes "<FONT SIZE = 14><B>Ouch!</B></FONT>";
		mes "You're not planning to let me go, are you?";
		emotion ET_PROFUSELY_SWAT,getnpcid(0,"Richard#ep21_richardroom");
		next;
		cutin "ep21_valdaris04.png",2;
		mes "[Laura Valdaris]";
		mes "<B>Captain, you and I have a lot to talk about~ </B>";
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "Sorry, captain.";
		mes "Let's take the armor to Gala's room first.";
		next;
		cutin "ep21_galaxia03.png",2;
		mes "[Galaxia Nerius]";
		mes "<FONT SIZE = 14><B>Bye Richard~</B></FONT>";
		mes "<B>I'll carry the helmet!</B>";
		emotion ET_BLABLA,getnpcid(0,"Nerius#ep21_richardroom2");
		next;
		cutin "ep21_lee03.png",2;
		mes "[Lee]";
		mes "<B>Hey!</B>";
		mes "Gala!!";
		mes "Don't hold the helmet too hard!";
		mes "It's hard to repair when it gets dented.";
		next;
		cutin "ep21_richard03.png",0;
		mes "[Richard]";
		mes "<FONT SIZE = 16><B>You traitors!!!</B></FONT>";
		emotion ET_OTL,getnpcid(0,"Richard#ep21_richard");
		npctalk "Richard : Help me!!!","Richard#ep21_richard",bc_self;
		completequest 24015;
		setquest 24016;
		questinfo_refresh;
		close2;
		cutin "",255;
		cloaknpc("Lehar#ep21_richardroom",true,getcharid(0));
		cloaknpc("Nillem#ep21_richardroom",true,getcharid(0));
		cloaknpc("Nerius#ep21_richardroom2",true,getcharid(0));
		cloaknpc("Lee#ep21_richardroom",true,getcharid(0));
		cloaknpc("Gunter#ep21_richardroom",true,getcharid(0));
		navigateto("mbase_in",167,79);
		end;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24015) == 1";
end;
}

mbase_in,164,123,6	duplicate(dummynpc)	Lehar#ep21_richardroom	4_EP19_LEHAR
mbase_in,165,128,6	duplicate(dummynpc)	Nillem#ep21_richardroom	4_M_NILLEM
mbase_in,171,124,3	duplicate(dummynpc)	Gunter#ep21_richardroom	4_EP21_GUNTER
mbase_in,169,124,3	duplicate(dummynpc)	Nerius#ep21_richardroom1	4_EP21_GALAXIA_A
mbase_in,169,124,3	duplicate(dummynpc)	Nerius#ep21_richardroom2	4_EP21_GALAXIA_B

mbase_in,167,79,3	script	Lee#ep21_galaxiaroom	4_EP21_LEE,{
	if(isbegin_quest(24016) == 1){
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "I'm glad we didn't caught up in the nagging!";
		mes "Thanks to you guys!";
		cloaknpc("Lehar#ep21_galaxia",false,getcharid(0));
		cloaknpc("Nillem#ep21_galaxia",false,getcharid(0));
		emotion ET_SMILE,getnpcid(0,"Lee#ep21_galaxiaroom");
		npctalk "Lee : Phew~ That was dangerous!","Lee#ep21_galaxiaroom",bc_self;
		next;
		cutin "ep21_lee01.png",2;
		mes "[Lee]";
		mes "Since we've met in the training grounds earlier, should we continue from there?";
		mes "Let's clean up Gala's armor first.";
		mes "It will rust if we leave the blood on it.";
		npctalk "Lee : Phew~ It's annoying but I have no choice.","Lee#ep21_galaxiaroom",bc_self;
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Let mme help.";
		mes "Is it okay that we left Richard alone?";
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "Oh, it's just the usual nagging, you don't have to worry that much.";
		npctalk "Galaxia Nerius : Lara is scary.","Nerius#ep21_galaxia",bc_self;
		npctalk "Gunter : I'd rather be beaten than be nagged.","Gunter#ep21_galaxia",bc_self;
		next;
		cutin "ep19_lehar07.png",2;
		mes "[Lehar]";
		mes "By the way… you're Nerius, right?";
		npctalk "Lehar : you're different from what I imagined…","Lehar#ep21_galaxia",bc_self;
		next;
		cutin "ep21_galaxia03.png",2;
		mes "[Galaxia Nerius]";
		mes "Yes.";
		mes "I'm Galaxia.";
		next;
		cutin "ep21_lee01.png",2;
		mes "[Lee]";
		mes "Do you know Gala?";
		mes "Well it's not a surprise, since you look like a rich young man.";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Oh!";
		mes "That's not how it is, I've just heard of the ^e5555eNerius family^000000 before.";
		emotion ET_PROFUSELY_SWAT,getnpcid(0,"Lehar#ep21_galaxia");
		next;
		cutin "ep21_galaxia01.png",2;
		mes "[Galaxia Nerius]";
		mes "<B>The Nerius family was ruined by the Jormungandr cult.</B>";
		mes "I'm the only one left.";
		next;
		cutin "ep19_lehar04.png",2;
		mes "[Lehar]";
		mes "Oh…";
		mes "I'm sorry.";
		emotion ET_HUK,getnpcid(0,"Lehar#ep21_galaxia");
		npctalk "Nillem : What are you going to do with this atmosphere.","Nillem#ep21_galaxia",bc_self;
		next;
		cutin "ep21_galaxia02.png",2;
		mes "[Galaxia Nerius]";
		mes "For what?";
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "Let's stop talking about such gloomy things and have fun.";
		mes "Listen~";
		mes "Isn't the way we first met hilarious?";
		next;
		cutin "ep21_lee01.png",2;
		mes "[Lee]";
		mes "There are lots of victims of the cult in the mercenary group.";
		mes "If we receive some intel about some people, we handle them even if there was no specific request to us.";
		next;
		mes "[Lee]";
		mes "I first met Gala when we got some intel and went to a small village called Ishara, she was wearing a blood-stained armor and she was practically radiating killing intent.";
		next;
		mes "[Lee]";
		mes "A lot of civilians were lying on the ground that day… and I think some of the mercenaries collapsed just from the pressure?";
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "That's understandable…";
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "So naturally, we thought she was the spy from the intel and attacked her!";
		next;
		cutin "ep21_lee03.png",2;
		mes "[Lee]";
		mes "<FONT SIZE = 14><B>We almost got wiped out.</B></FONT>";
		mes "I thought to myself, is the mercenary group going to end like this?";
		mes "I think there were atleast a few dozen of us?";
		emotion ET_BLABLA,getnpcid(0,"Lee#ep21_galaxiaroom");
		emotion ET_HUK,getnpcid(0,"Lehar#ep21_galaxia");
		emotion ET_HUK,getnpcid(0,"Nillem#ep21_galaxia");
		emotion ET_HUK,getcharid(3);
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "Even now, the mercenaries who got hit by Gala freeze up when they see her.";
		npctalk "Nillem : You said we shouldn't talk about gloomy things!!!","Nillem#ep21_galaxia",bc_self;
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "You're lucky you didn't get seriously hurt, huh?";
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "The last thing I remember is Gala charging at us with several ballista bolts stuck to her…";
		mes "The captain's stomach had a hole in it, right?";
		mes "Gunter's limbs, were all broken.";
		emotion ET_BLABLA,getnpcid(0,"Lee#ep21_galaxiaroom");
		emotion ET_HUK,getnpcid(0,"Lehar#ep21_galaxia");
		emotion ET_HUK,getnpcid(0,"Nillem#ep21_galaxia");
		emotion ET_HUK,getcharid(3);
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "Sc…ary…";
		next;
		cutin "ep21_lee03.png",2;
		mes "[Lee]";
		mes "I woke up 5 days later.";
		mes "Was it 5 days again?";
		mes "<B>I got hit so hard that I can't remember clearly.</B>";
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "The one who held out until the end was Gunter and the captain…";
		mes "The captain tried to find an opening and told Gunter to escape, that was the moment we found out that she wasn't part of the cult.";
		next;
		mes "[Lee]";
		mes "When she finally spoked, Gala just embarrassingly said 'I'm not part of the cult' after our brutal fight.";
		npctalk "Lee : Cute.","Lee#ep21_galaxiaroom",bc_self;
		next;
		mes "[Lee]";
		mes "It turns out that the people that were on the ground were part of the cult that was disguised as civilians, and Gala dealt with them before we even got to the place.";
		next;
		cutin "ep21_lee01.png",2;
		mes "[Lee]";
		mes "We had some serious injuries on our side and was in critical condition… but… nobody actually died.";
		mes "We cleared up the misunderstanding, and Gala joined us and started working for the mercenary group.";
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "So you just pretended it was a misunderstanding… and that's it?";
		npctalk "Lehar : You almost died…","Lehar#ep21_galaxia",bc_self;
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "<FONT SIZE = 14>Isn't that how mercenary works?</FONT>";
		mes "A power like Gala doesn't come by easily.";
		mes "It's more important that she could ^ff3366'break the cult's skull!'^000000 just like how she broke mine!";
		next;
		cutin "ep21_galaxia02.png",2;
		mes "[Galaxia Nerius]";
		mes "Lee was in bed for ^e5555e<B>3 months</B>^000000… with a broken skull.";
		emotion ET_HUK,getnpcid(0,"Lehar#ep21_galaxia");
		emotion ET_HUK,getnpcid(0,"Nillem#ep21_galaxia");
		emotion ET_HUK,getcharid(3);
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "Oh…";
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "I was ready to die from the moment I decided to take <B>revenge on the cult</B>, that level of injury is to be expected~";
		next;
		mes "[Lee]";
		mes "Look at the bright side, Gala carried me to the infirmary and visited me almost every day, now we're bestfriends!";
		npctalk "Galaxia Nerius : Lee gave me a friendship necklace.","Nerius#ep21_galaxia",bc_self;
		npctalk "Gunter : She visited me too.","Gunter#ep21_galaxia",bc_self;
		next;
		cutin "ep19_lehar04.png",2;
		mes "[Lehar]";
		mes "Uhm… but…";
		mes "Didn't Nerius got hit by a ballista too?";
		emotion ET_PROFUSELY_SWAT,getnpcid(0,"Lehar#ep21_galaxia");
		next;
		cutin "ep21_lee01.png",2;
		mes "[Lee]";
		mes "Oh~";
		mes "I heard that she carried me while she had a ballista bolt stuck on her, maybe?";
		npctalk "Lee : I don't really know, I lost consciousness.","Lee#ep21_galaxia",bc_self;
		next;
		cutin "ep21_galaxia02.png",2;
		mes "[Galaxia Nerius]";
		mes "I wasn't fine too.";
		mes "I had a hole on my face.";
		mes "Also here and here.";
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "Are you sure it's not just a mole?";
		next;
		cutin "ep19_lehar04.png",2;
		mes "[Lehar]";
		mes "You even got hit in the head?";
		mes "How are you even alive…";
		emotion ET_HUK,getnpcid(0,"Lehar#ep21_galaxia");
		next;
		cutin "ep21_galaxia02.png",2;
		mes "[Galaxia Nerius]";
		mes "You just need to train really hard.";
		next;
		cutin "ep19_lehar04.png",2;
		mes "[Lehar]";
		mes "Ah… yes…";
		npctalk "Lehar : No, normally it's impossible..","Lehar#ep21_galaxia",bc_self;
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "I've cleaned up the armor as we were chatting, shall we head out now?";
		next;
		cutin "ep21_galaxia01.png",2;
		mes "[Galaxia Nerius]";
		mes "Lee, where are yopu going?";
		next;
		cutin "ep21_lee01.png",2;
		mes "[Lee]";
		mes "Laura told me to continue the rest of the ^e5555ebase tour^000000.";
		next;
		cutin "ep21_galaxia01.png",2;
		mes "[Galaxia Nerius]";
		mes "I want to go too.";
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "Okay.";
		mes "Then, put your armor back on.";
		mes "Let's go.";
		completequest 24016;
		setquest 24017;
		close2;
		cutin "",255;
		navigateto("jor_mbase",163,196);
		end;
	}
	if(isbegin_quest(24017) == 1){
		cloaknpc("Lehar#ep21_galaxia",false,getcharid(0));
		cloaknpc("Nillem#ep21_galaxia",false,getcharid(0));
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "I've cleaned up the armor as we were chatting, shall we head out now?";
		next;
		cutin "ep21_galaxia01.png",2;
		mes "[Galaxia Nerius]";
		mes "Lee, where are you going?";
		next;
		cutin "ep21_lee01.png",2;
		mes "[Lee]";
		mes "Laura told me to continue the rest of the ^e5555ebase tour^000000.";
		next;
		cutin "ep21_galaxia01.png",2;
		mes "[Galaxia Nerius]";
		mes "I want to go too.";
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "Okay.";
		mes "Then, put your armor back on.";
		mes "Let's go.";
		close2;
		cutin "",255;
		navigateto("jor_mbase",163,196);
		end;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24016) == 1";
end;
}

mbase_in,165,80,6	duplicate(dummynpc)	Lehar#ep21_galaxia	4_EP19_LEHAR
mbase_in,166,84,6	duplicate(dummynpc)	Nillem#ep21_galaxia	4_M_NILLEM
mbase_in,168,85,3	duplicate(dummynpc2)	Gunter#ep21_galaxia	4_EP21_GUNTER
mbase_in,168,82,3	duplicate(dummynpc2)	Nerius#ep21_galaxia	4_EP21_GALAXIA_B

jor_mbase,164,196,0	script	#hw_ep21_pn11	HIDDEN_WARP_NPC,4,4,{
	end;

OnTouch:
	if(isbegin_quest(24017) == 1 || isbegin_quest(24018) == 1){
		cloaknpc("Lehar#ep21_pn_rehar02",false,getcharid(0));
		cloaknpc("Nillem#ep21_pn_nillem02",false,getcharid(0));
		cloaknpc("Tris#ep21_pn_tris02",false,getcharid(0));
		end;
	}
	if(isbegin_quest(23244) == 1 || isbegin_quest(23245) == 1 || isbegin_quest(23246) == 1 || isbegin_quest(23247) == 1 || isbegin_quest(23248) == 1)
		cloaknpc("Tris#ep21_pn_tris02",false,getcharid(0));
	if(isbegin_quest(23245) == 1 || isbegin_quest(23246) == 1 || isbegin_quest(23247) == 1 || isbegin_quest(23248) == 1)
		cloaknpc("Heine Tablet#ep21_pn",false,getcharid(0));	
end;
}

jor_mbase,169,199,0	duplicate(#hw_ep21_pn11)	#hw_ep21_pn11-2	HIDDEN_WARP_NPC,4,4

jor_mbase,163,196,0	script	#ep21_tour6	HIDDEN_WARP_NPC,2,2,{
	end;
	
OnTouch:
	if(isbegin_quest(24017) == 1){
		cloaknpc("Lehar#ep21_pn_rehar02",false,getcharid(0));
		cloaknpc("Nillem#ep21_pn_nillem02",false,getcharid(0));
		cloaknpc("Tris#ep21_pn_tris02",false,getcharid(0));
		cloaknpc("Lee#ep21_tour6",false,getcharid(0));
		cloaknpc("Nerius#ep21_tour6",false,getcharid(0));
		cloaknpc("Gunter#ep21_tour6",false,getcharid(0));
		cutin "ep21_lee01.png",2;
		mes "[Lee]";
		mes "From here to there is the mercenary training grounds.";
		mes "It's called the training grounds, but it's really just open area where we can do intensive training.";
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "There's a chance that you might hurt a passerby when doing intensive training, so it's better to do it in a secluded area~ I guess that's about it?";
		next;
		cutin "ep21_lee01.png",2;
		mes "[Lee]";
		mes "And behind the barracks are the lodging.";
		next;
		mes "[Lee]";
		mes "Across from that is the store.";
		mes "Beyond that is the cafeteria.";
		next;
		mes "[Lee]";
		mes "It's a combat outpost, so facilities are limited.";
		mes "You'll get used to it over time.";
		next;
		cutin "ep21_lee02.png",2;
		mes "[Lee]";
		mes "Tan!";
		mes "Is this enough for the tour?";
		cloaknpc("Tan#ep21_tour6",false,getcharid(0));
		cutin "ep21_tan01.png",0;
		next;
		mes "[Tan]";
		mes "Yes.";
		next;
		cutin "ep21_tan02.png",0;
		mes "[Tan]";
		mes "Richard and Galaxia didn't mention anything, so this should be enough for now.";
		next;
		cutin "ep21_tan01.png",0;
		mes "[Tan]";
		mes "Then, go see ^e5555eTris^000000.";
		completequest 24017;
		setquest 24018;
		questinfo_refresh;
		getitem "Ep21_Wigner_Ticket",30;
		getexp 547793770,239980220;
		add_reputation_points(13,30);
		close2;
		cutin "",255;
		cloaknpc("Lee#ep21_tour6",true,getcharid(0));
		cloaknpc("Nerius#ep21_tour6",true,getcharid(0));
		cloaknpc("Gunter#ep21_tour6",true,getcharid(0));
		cloaknpc("Tan#ep21_tour6",true,getcharid(0));
		navigateto("jor_mbase",168,200);
		end;
	}
end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24017) == 1";
end;
}

jor_mbase,168,200,5	script(CLOAKED)	Tris#ep21_pn_tris02	4_EP21_TRIS,{
	if(isbegin_quest(24017) == 1){
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Are you still getting a tour of the facilities? It's refreshing here~";
		close3;
	}
	if(isbegin_quest(24018) == 1){
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Welcome, great job. How was the work in Richard Mercenary Group?";
		next;
		if(select("Bearable.","It was hard.") == 1){
			cutin "ep21_tris06.png",2;
			mes "[Tris]";
			mes "Bearable? Really? Almost no one said that, you guys are pretty amazing, aren't you?";
			next;
			cutin "ep21_tris08.png",2;
			mes "[Tris]";
			mes "I'm sure you'd be a great help to the resistance. Once again, welcome.";	
		} else {
			cutin "ep21_tris08.png",2;
			mes "[Tris]";
			mes "Haha, was Richard a bit rough? You're going to do less strenuous work from now on, so relax a bit.";
			next;
			cutin "ep21_tris07.png",2;
			mes "[Tris]";
			mes "Huh? It wasn't physically tiring? Didn't you go through physical training?";
		}
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Let's see, while you were with the Richard Mercenary Group, I've thought about your placement considering everyones opinion and circumstances.";
		next;
		mes "[Tris]";
		mes "Luckily, Alberta requested a wizard, so that made the decision easier. Nillem, please join the group heading to Alberta.";
		next;
		cutin "ep21_tris09.png",2;
		mes "[Tris]";
		mes "That would be good for Nillem, right? Since most of the wizards that I've met don't seem to like physical activity.";
		next;
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "I finally have the chance to show you my true talents. You've got a great eye★";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Haha! I'm glad you like it. I'll be counting on you.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Where should I go?";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Lehar, you'll go help the Wigner Merchant Guild. They're involved in relief efforts for people who escaped the cult.";
		next;
		mes "[Tris]";
		mes "I didn't hear what exactly what job they'll give you... but it should be less strenuous than training with the Richard Mercenary Group.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Yes, it seem like a good fit for me. I'll do my best!";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "And for the adventurer, I have someone to introduce before assigning your work. Nillem and Lehar, you can head out now. Adventurer, wait here for a moment.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "I didn't expect us to split up so soon... I think it's better for us to show our dedication and earn their trust first.";
		next;
		mes "[Lehar]";
		mes "Tris is very kind, but Tan still has a sharp gaze... I guess working with the Richard Mercenary Group wasn't enough for him.";
		next;
		mes "[Lehar]";
		mes "Let's do our best to gather information, let's exchange what we've learn when we meet again. ";
		next;
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "I, Nillem will show you my outmost competence. You'll praise me when I return☆";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "I hope that's really the case! Adventurer, Nillem and I will head out first, let's meet again later.";
		cloaknpc("Lehar#ep21_pn_rehar02",true,getcharid(0));
		cloaknpc("Nillem#ep21_pn_nillem02",true,getcharid(0));
		completequest 24018;
		setquest 23244;
		questinfo_refresh;
		close3;
	}
	if(isbegin_quest(23244) == 1){
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Did I made you wait long? To officially celebrate you becoming a member of the Gaebolg Resistance, I'm going to introduce you to someone very important.";
		next;
		if(select("There's no one here?","Is that person you, Tris?") == 1){
			mes "[Tris]";
			mes "No no, That person is right here. I'll show you right now, so pay attention!";
		} else {
			cutin "ep21_tris10.png",2;
			mes "[Tris]";
			mes "Hahaha, are you flattering me? You don't need to give me a special treatment just because I'm the captain.";
			next;
			cutin "ep21_tris09.png",2;
			mes "[Tris]";
			mes "The person I'm introducing isn't me, that person is right here.";
		}
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Hello, Heine? Can you hear me?";
		cloaknpc("Heine Tablet#ep21_pn",false,getcharid(0));
		next;
		cutin "",255;
		mes "[Voice From The Device]";
		mes "Yes. Go ahead.";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "This person is ^4d4dffIlse El Heine^000000. To be specific, this is Heine's Tablet, and the person speaking right now is the real Heine. Say Hello!";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "Hello...?";
		next;
		mes "[Voice From The Device]";
		mes "Alright.";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Heine provides magical items to the resistance. He's a great wizard, the sage of Comodo, our control tower and our savior...";
		next;
		cutin "ep21_tris09.png",2;
		mes "[Tris]";
		mes "...among other things, he plays a very important role! I'd like to tell you all Heine's connection to the resistance but they is a very busy day.";
		next;
		mes "[Tris]";
		mes "I'll tell you next time when I get the chance! Heine's amazing magic has been a great help to us. " + strcharinfo(0) + ", you'll be surprised to hear it!";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Oh! This is one of the essence of Heine's magical talent, the Heine Tablet.";
		next;
		mes "[Tris]";
		mes "With this~ Heine may be far away in Comodo, but with this we can communicate with him as if he's right next to us. Of course, only if Heine answers~";
		next;
		mes "[Tris]";
		mes "Even though it can't transport objects, being able to send messages or talk to Heine without having to go to Comodo is really convenient!";
		next;
		mes "[Tris]";
		mes "The reason I'm introducing you to Heine now, is because...";
		next;
		mes "[Tris]";
		mes "the task for you is to go to Alberta to receive the goods that Heine sent!";
		next;
		cutin "ep21_tris10.png",2;
		mes "[Tris]";
		mes "Oh, have I been talking too much? You just came back from the mercenaries and haven't had the chance to rest yet.";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "There's still some time before you leave for Alberta, come and tell me when you're ready to do Heine's task!";
		completequest 23244;
		setquest 23245;
		questinfo_refresh;
		close3;
	}
	if(isbegin_quest(23245) == 1){
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Are you ready? Then stand over there. Yes, right there. Now, stay where you are.";
		next;
		mes "[Tris]";
		mes "If I move it here... Heine, how is it? Can you see well?";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "More or less.";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "My friend here is going to Alberta to receive the goods today, take a good look. Since it's an unfamiliar face, you might get confused.";
		next;
		cutin "ep21_ilse_heine04.png",1;
		mes "[Ilse El Heine]";
		mes "It's not like I'm going to meet them in person, why do I need to take a look?";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Oh! You're right. Haha, But still, it's good to get to know each other! I have a good feeling that they'll be around for a while.";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "I'm not so sure about that... but, you might be right. It seems like we'll be doing something significant together.";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Right? This person is " + strcharinfo(0) + "... that's correct, right? It's important to know the name of your colleagues, so you better remember it Heine! I'll introduce you to Nillem and Lehar later!";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "Alright, anyways... Haven't you departed from Lunaforma to Alberta yet? When is your scheduled departure?";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Well, we're still getting ready... I'm not sure when we'll be finished. Is it urgent? Should we depart earlier?";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "No, It's nothing like that, but seeing that persons face reminded me of something else I need. Suddenly.";
		next;
		cutin "ep21_ilse_heine02.png",1;
		mes "[Ilse El Heine]";
		mes "Now that we're acquainted, was it " + strcharinfo(0) + "? I'd like you to get something.";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "What is it that you need?";
		next;
		cutin "ep21_ilse_heine02.png",1;
		mes "[Ilse El Heine]";
		mes "A Bright Eye. 1 is enough.";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "If it's a Bright Eye, there's an extra in our storage. I'll tell them to add in when they prepare the supplies. Is that all you need?";
		next;
		cutin "ep21_ilse_heine06.png",1;
		mes "[Ilse El Heine]";
		mes "No! It has to be a fresh one. It needs to be " + strcharinfo(0) + " who gets it personally without relying on anyone else. Got it? Okay.";
		next;
		cutin "ep21_tris07.png",2;
		mes "[Tris]";
		mes "uhm, is it really that important...?";
		next;
		cutin "ep21_ilse_heine06.png",1;
		mes "[Ilse El Heine]";
		mes "Isn't it obvious? I'm busy, so don't make me repeat myself. Do as I say, if you send something that's been something sitting in the storage, you'll regret it. I will check it!";
		next;
		cutin "ep21_tris06.png",2;
		mes "[Tris]";
		mes "Heine~~! He hung up after just saying what he needed again!";
		completequest 23245;
		setquest 23246;
		questinfo_refresh;
		close3;
	}
	if(isbegin_quest(23246) == 1){
		cutin "ep21_tris02.png",2;
		mes "[Tris]";
		mes "Sigh, I really don't want to make you go alone, but Heine can be a bit peculiar...";
		next;
		cutin "ep21_tris11.png",2;
		mes "[Tris]";
		mes "I don't understand it, but there's alway a reason when he acts like that. He just doesn't explain it...";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "He's not doing this to bother you. You can trust me on that!";
		next;
		cutin "ep21_tris10.png",2;
		mes "[Tris]";
		mes "Heine's magic is great, even if you make the smallest mistake from his instructions, he'll notice it right away and lecture you about it.";
		next;
		mes "[Tris]";
		mes "So please bear with it for a little while!";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "You can obtain a Bright Eye from hunting a Skipskipper on the southern part of the Raised Land.";
		next;
		mes "[Tris]";
		mes "Heine said that you only need to bring 1, so hunting about 10 Skipskipper should be enough.";
		next;
		mes "[Tris]";
		mes "The southern part of the Raised Land is nearby. Hunt 10 Skipskippers and bring me 1 <ITEM>[Bright Eye]<INFO>1001641</INFO></ITEM>!";
		navigateto("jor_raise2",50,30);
		completequest 23246;
		setquest 23247;
		close3;
	}
	if(isbegin_quest(23247) == 1){
		if(checkquest(23247,HUNTING) < 2){
			cutin "ep21_tris01.png",2;
			mes "[Tris]";
			mes "The southern part of the Raised Land is nearby. Hunt 10 Skipskippers and bring me 1 <ITEM>[Bright Eye]<INFO>1001641</INFO></ITEM>!";
			navigateto("jor_raise2",50,30);
			close3;
		}
		if(countitem("EP21_Bright_Eye") < 1){
			cutin "ep21_tris01.png",2;
			mes "[Tris]";
			mes "Hm? We need 1 Bright Eye. Make sure to bring it back and don't lose it!";
			next;
			mes "The southern part of the Raised Land is nearby. Hunt 10 Skipskippers and bring me 1 <ITEM>[Bright Eye]<INFO>1001641</INFO></ITEM>!";
			navigateto("jor_raise2",50,30);
			close3;
		}
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "You're back! It must have been freezing, right? Good job, really good job~ ";
		next;
		mes "[Tris]";
		mes "While you were away, Heine contacted me again, and he told me to ask you to go to Alberta as well.";
		next;
		mes "[Tris]";
		mes "I'm sorry that you have to go through this twice. It didn't matter how much I persuade him! Heine insisted that you have to be the one that go.";
		next;
		mes "[Tris]";
		mes "The resistance relies on Heine a lot, that's why I couldn't refuse. We're the one who would be at a disadvantage without him.";
		next;
		cutin "ep21_tris10.png",2;
		mes "[Tris]";
		mes "Could you please humor Hiene's whims one last time? Please go to <NAVI>[Alberta]<INFO>jor_albe,192,209,0,101,0</INFO></NAVI>. I'm counting on you!";
		navigateto("jor_raise2",50,30);
		delitem "EP21_Bright_Eye",1;
		completequest 23247;
		setquest 23248;
		getitem "Ep21_Wigner_Ticket",30;
		getexp 547793770,239980220;
		add_reputation_points(13,35);
		close3;
	}
	if(isbegin_quest(23248) == 1){
		cutin "ep21_tris10.png",2;
		mes "[Tris]";
		mes "Could you please humor Hiene's whims one last time? Please go to <NAVI>[Alberta]<INFO>jor_albe,192,209,0,101,0</INFO></NAVI>. I'm counting on you!";
		navigateto("jor_raise2",50,30);
		close3;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24018) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23244) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23245) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23246) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"checkquest(23247,HUNTING) == 2 && countitem(\"EP21_Bright_Eye\") > 0";
end;
}

jor_mbase,159,196,5	script(CLOAKED)	Lehar#ep21_pn_rehar02	4_EP19_LEHAR,{
	if(isbegin_quest(24018) == 1){
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "...What exactly did we learn from the mercenary group?";
		next;
		mes "[Lehar]";
		mes "Meeting with the people from the mercenary group feels like a long yet short dream...";
		close3;
	}
	end;
}

jor_mbase,158,195,5	script(CLOAKED)	Nillem#ep21_pn_nillem02	4_M_NILLEM,{
	if(isbegin_quest(24018) == 1){
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "The resistance isn't such a stiff organization! It was fun.";
		next;
		mes "[Nillem]";
		mes "I feel relieved! I feel like I can do well no matter where I'm assigned☆";
		close3;
	}
	end;
}

jor_mbase,171,200,3	script(CLOAKED)	Heine Tablet#ep21_pn	4_EP21_HEINE_TAB,{
	mes "The tablet's screen is off. It seems the connection has been cut. I'm not sure how to operate it...";
	close;
}

jor_mbase,165,198,3	duplicate(dummynpc)	Lee#ep21_tour6	4_EP21_LEE
jor_mbase,166,197,3	duplicate(dummynpc)	Nerius#ep21_tour6	4_EP21_GALAXIA_A
jor_mbase,167,203,3	duplicate(dummynpc)	Gunter#ep21_tour6	4_EP21_GUNTER
jor_mbase,161,194,5	duplicate(dummynpc)	Tan#ep21_tour6	4_EP21_TAN

jor_albe,192,202,0	script	#ep21_rw01	HIDDEN_WARP_NPC,5,5,{
	end;
	
OnTouch:
	if(isbegin_quest(23248) == 1){
		cloaknpc("Epesto Walter Megas#ep",false,getcharid(0));
		cloaknpc("Nillem#ep21_rw01",false,getcharid(0));
	}
end;
}

jor_albe,192,209,3	script(CLOAKED)	Nillem#ep21_rw01	4_M_NILLEM,{
	if(isbegin_quest(23248) == 1){
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Ugh, I'm dizzy…… Can we take a little break?";
		next;
		cutin "ep21_epesto01.png",2;
		mes "[Walter Sailor]";
		mes "What, we just had a break, and now you want another one!";
		mes "These wizards are so weak…….";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "It's not that I'm weak, it's just that you're too strong!";
		mes "Sigh, do you even realize that you're wasting the talent of a great wizard over trivial tasks?";
		next;
		cutin "ep21_epesto02.png",2;
		mes "[Walter Sailor]";
		mes "What did you say……?";
		mes "Are you saying our work is trivial, insignificant, and mot important……?";
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "That's not how I said it!";
		mes "What I mean is, I, the great wizard Nillem~ could do so much more, my magic is waste to use up on simple preservation spells.";
		next;
		cutin "ep21_epesto01.png",2;
		mes "[Walter Sailor]";
		mes "It's a wizards job to use magic, why would it be a waste!";
		mes "You've got enough energy to complain, I'll work you like a cow!";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Words……, I can't communicate with it.";
		mes "Oh, dear? Dear adventurer~!!";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "What's happening here.";
		mes "You're really working hard…….";
		next;
		cutin "ep21_epesto03.png",2;
		mes "[Walter Sailor]";
		mes "Why are you suddenly calling for your dear!";
		mes "……Huh? Who are you.";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "I'm " + strcharinfo(0) + ", sent by Gaebolg at Heine's request.";
		next;
		cutin "ep21_epesto01.png",2;
		mes "[Walter Sailor]";
		mes "Oh, is that so?";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Wahahaha, Dear adventurer~ I'm struggling too much, don't you think?";
		mes "They treated this delicate wizard like a machine, they're overworking me~!";
		next;
		cutin "ep21_epesto01.png",2;
		mes "[Walter Sailor]";
		mes "Enough, that's enough!";
		mes "Head down that way, there's a storage room full of supplies there, so why don't you take your weak self down there!";
		next;
		cutin "ep172_nillem03.png",0;
		mes "[Nillem]";
		mes "I have been suffering like this…….";
		mes "Let's talk about the details later. Dear adventurer☆";
		next;
		cutin "ep21_epesto01.png",2;
		cloaknpc("Nillem#ep21_rw01",true,getcharid(0));
		mes "[Walter Sailor]";
		mes "So, you said you were sent by the Gaebolg to help?";
		mes "I'm Epesto Walter Megas. Call me Megas.";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "Walter? Are you the captain of the Walter Fleet?";
		next;
		cutin "ep21_epesto01.png",2;
		mes "[Epesto Walter Megas]";
		mes "Nothing like that. Tsk, don't worry about that and focus on the work you came to do.";
		mes "Can you go to the beach? If you tell them Megas sent you, they'll give you some work to do.";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "Do I have to go to work right away? U'm sure there's a reason Heine called for me.";
		mes "Since it's my first time in Alberta, I thought I should introduce myself to a Walter sailor…….";
		next;
		cutin "ep21_epesto02.png",2;
		mes "[Epesto Walter Megas]";
		mes "……Is that even necessary?";
		mes "Are you really that important?";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "Not exactly, but still…….";
		next;
		cutin "ep21_epesto01.png",2;
		mes "[Epesto Walter Megas]";
		mes "Jeez, you people are someone who enjoys wasting energy on pointless things.";
		mes "Don't think about it, just go to the <NAVI>[beach]<INFO>jor_albe.gat,239,115,0,101,0</INFO></NAVI> and find some work.";
		next;
		cutin "ep21_epesto03.png",2;
		mes "[Epesto Walter Megas]";
		mes "Don't get distracted and work diligently.";
		completequest 23248;
		setquest 16820;
		questinfo_refresh;
		close3;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23248) == 1";
end;
}

jor_albe,190,211,5	script(CLOAKED)	Epesto Walter Megas#ep	4_EP21_EPESTO,{
	if(isbegin_quest(23248) == 1){
		cutin "ep21_epesto02.png",2;
		mes "[Walter Sailor]";
		mes "Don't dawdle around, and work like a cow!";
		close3;
	}
	if(isbegin_quest(16820) == 1){
		cutin "ep21_epesto02.png",2;
		mes "[Epesto Walter Megas]";
		mes "Hurry up and get to work. Don't think about chatting with me!";
		close3;
	}
}

jor_albe,234,119,0	script	#ep21_rw02	HIDDEN_WARP_NPC,5,5,{
	end;

OnTouch:
	if(isbegin_quest(16804) == 1 || isbegin_quest(16810) == 1){
		cloaknpc("Yohan#ep21_rw01",false,getcharid(0));
		end;
	}
	if(isbegin_quest(16820) == 1 || isbegin_quest(16805) == 1){
		cloaknpc("Yohan#ep21_rw01",false,getcharid(0));
		cloaknpc("Important Cargo#ep21_rw01",false,getcharid(0));
		cloaknpc("Cargo#ep21_rw01",false,getcharid(0));
		cloaknpc("Cargo#ep21_rw02",false,getcharid(0));
		cloaknpc("Victor#ep21_rw01",false,getcharid(0));
		cloaknpc("Ullya#ep21_rw01",false,getcharid(0));
		end;
	}
end;
}

jor_albe,239,115,3	script(CLOAKED)	Yohan#ep21_rw01	4_EP21_YOHAN,{
	if(isbegin_quest(16820) == 1){
		cutin "ep21_yohan01.png",2;
		mes "[Walter Sailor]";
		mes "All the cargo there…… Victor, load it onto that cart.";
		npctalk "Victor : I've loaded almost everything, don't worry about it kid!","Victor#ep21_rw01",bc_self;
		next;
		mes "[Walter Sailor]";
		mes "Ullya, have you check the empty spaces in warehouse 3? Please check the inventory of the new cargos.";
		npctalk "Ullya : Warehouse 3 is about 35% full right now. I'll check the inventory again!","Ullya#ep21_rw01",bc_self;
		next;
		mes "[Walter Sailor]";
		mes "And…….";
		mes "Oh, who might you be……?";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "Oh, I, um,…… I'm here to help out.";
		mes "Megas told me to come here.";
		next;
		cutin "ep21_yohan01.png",2;
		mes "[Walter Sailor]";
		mes "Oh, sir Megas. Understood. Well then…… for starters, could you help me move these boxes here?";
		next;
		cutin "ep21_yohan02.png",2;
		mes "[Walter Sailor]";
		mes "Please take this box to the guild warehouse, as for the other one…… deliver it to the market near the pier.";
		mes "Ah!";
		next;
		cutin "ep21_yohan01.png",2;
		mes "[Walter Sailor]";
		mes "And that one…… is an important cargo, so don't touch it.";
		mes "It's something that an outsider shouldn't handle.";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "Even though I'm a part of the Gaebolg, am I still considered an outsider?";
		next;
		cutin "ep21_yohan01.png",2;
		mes "[Walter Sailor]";
		mes "Even if you're a part of the Gaebolg, that doesn't make you a Walter sailor…….";
		mes "So you shouldn't carelessly touch important cargos.";
		next;
		mes "[Walter Sailor]";
		mes "The places where you need to deliver the goods are…… as mentioned, <NAVI>[market near the pier]<INFO>jor_albe.gat,148,235,0,101,0</INFO></NAVI> and <NAVI>[guild warehouse]<INFO>jalbe_in.gat,22,63,0,101,0</INFO></NAVI>.";
		mes "Then, after you've finished ";
		next;
		mes "[Walter Sailor]";
		mes "My name is Yohan……, If you need anything, look for me.";
		completequest 16820;
		setquest 16802;
		setquest 16803;
		questinfo_refresh;
		cloaknpc("Cargo#ep21_rw01",true,getcharid(0));
		cloaknpc("Cargo#ep21_rw02",true,getcharid(0));
		close3;
	}
	if(isbegin_quest(16804) == 1){
		if(isbegin_quest(16805) == 0){
			cutin "ep21_yohan01.png",2;
			mes "[Yohan]";
			mes "Oh……, You're. Did everything went smoothly?";
			mes "The market folks and the warehouse ladies mentioned that you did well for your first time.";
			next;
			mes "[Yohan]";
			mes "Well……, It's a simple task afterall.";
			mes "It is tiring but simple…….";
			next;
			cutin "ep21_yohan02.png",2;
			mes "[Yohan]";
			mes "Next is…… let's see, with all the supplies coming and going lately, the port and nearby streets have gotten a bit dirty.";
			mes "There are dirt piles everywhere, making the road unpleasant to see…….";
			next;
			cutin "ep21_yohan01.png",2;
			mes "[Yohan]";
			mes "Please take a look around the port and nearby streets and clean up the dirt piles on the ground. Let' see…… it will look much better if you can clean up these four spots.";
			next;
			cloaknpc("Nillem#ep21_rw02",false,getcharid(0));
			cutin "ep172_nillem02.png",0;
			mes "[Nillem]";
			mes "What, are you making " + strcharinfo(0) + " clean the ground?";
			mes "You people, not only you're wasting my abilities but you're also wasting the adventurers abiltiies too, unbelievable!";
			next;
			cutin "ep172_nillem03.png",0;
			mes "[Nillem]";
			mes "Why aren't we discussing the more important cargo this time?";
			mes "Is it okay for your time to be wasted on trivial tasks like this?";
			npctalk "Nillem : There's no way it is!","Nillem#ep21_rw02",bc_self;
			next;
			cutin "ep21_yohan02.png",2;
			mes "[Yohan]";
			mes "…….";
			next;
			cutin "ep21_yohan03.png",2;
			mes "[Yohan]";
			mes "………….";
			next;
			cutin "ep21_yohan01.png",2;
			mes "[Yohan]";
			mes "Look, I think you're misunderstanding something. ……You can't do anything with someone you can't trust.";
			mes "Can't you think of this as a process of building trust?";
			next;
			cutin "",255;
			if(select("Stop Nillem.","Complain to Yohan.") == 2){
				cutin "ep21_yohan01.png",2;
				mes "[Yohan]";
				mes "……So that's how you feel.";
				next;
				cutin "ep21_yohan03.png",2;
				mes "[Yohan]";
				mes "Then, there's no need for you to work. Rest up.";
				mes "It seems there's nothing more for you to do in Alberta…….";
				next;
				cutin "",255;
				if(select("It was just a slip of tongue, I'll work.","I'll take a good rest.") == 2){
					cutin "ep21_yohan03.png",2;
					mes "[Yohan]";
					mes "Yes. Please rest well.";
					mes "I'll call you again when something comes up later.";
					next;
					cutin "ep172_nillem02.png",0;
					mes "[Nillem]";
					mes "Oh…… I think, I made a mistake…….";
					mes "Are you okay with this? Should I talk to Yohan about it?";
					erasequest 16802;
					erasequest 16803;
					erasequest 16804;
					setquest 16802;
					setquest 16803;
					setquest 16805;
					close2;
					cutin "",255;
					cloaknpc("Nillem#ep21_rw02",true,getcharid(0));
					end;
				}
			}
			cutin "ep172_nillem02.png",0;
			mes "[Nillem]";
			mes "Eh, are you really okay with this? Even if it's about building trust, the work is too hard.";
			next;
			cutin "ep172_nillem04.png",0;
			mes "[Nillem]";
			mes "……Well, if that's what you want, I guess there's no helping it. I'll go finish what I was doing~ See you☆";
			completequest 16804;
			setquest 16805;
			completequest 16805;
			cloaknpc("Nillem#ep21_rw02",true,getcharid(0));
			next;
			cutin "ep21_yohan01.png",2;
			mes "[Yohan]";
			mes "I'll mark the places you need to clean on the map. If you can't remember, just check your map.";
			mes "As much as possible…… I want you to clean it thoroughly, but take your time.";
			setquest 16806;
			setquest 16807;
			setquest 16808;
			setquest 16809;
			cloaknpc("Pile of Dirt#ep21_rw01",false,getcharid(0));
			cloaknpc("Pile of Dirt#ep21_rw02",false,getcharid(0));
			cloaknpc("Pile of Dirt#ep21_rw03",false,getcharid(0));
			cloaknpc("Pile of Dirt#ep21_rw04",false,getcharid(0));
			close;
		}
		if(isbegin_quest(16805) == 1){
			cutin "ep21_yohan01.png",2;
			mes "[Yohan]";
			mes "How are you feeling……. Did you get enough rest?";
			next;
			cutin "",255;
			if(select("Ask Yohan for necessary work.","I'm resting well.") == 2){
				cutin "ep21_yohan03.png",2;
				mes "[Yohan]";
				mes "……That's nice. I'm a bit envious.";
				close3;
			}
			cutin "ep21_yohan01.png",2;
			mes "[Yohan]";
			mes "There's no necessary work that I can give you, " + strcharinfo(0) + "…….";
			mes "You can rest a bit longer.";
			next;
			cutin "",255;
			if(select("I'll gratefully take some rest.","I need something to do.") == 1){
				cutin "ep21_yohan03.png",2;
				mes "[Yohan]";
				mes "……That's nice. I'm a bit envious.";
				close3;
			}
			cutin "ep21_yohan02.png",2;
			mes "[Yohan]";
			mes "You don't usually do trivial tasks…… do you?";
			next;
			cutin "ep21_yohan01.png",2;
			mes "[Yohan]";
			mes "Alright, if you're that willing to work, I won't stop you.";
			mes "Then…… we've got more cargo that has been brought from the ship.";
			next;
			mes "[Yohan]";
			mes "I'd appreciate it if you could move the cargo.";
			mes "One should be delivered to market near the pier, and the other one to the guild warehouse.";
			next;
			mes "[Yohan]";
			mes "Again, on the <NAVI>[market near the pier]<INFO>jor_albe.gat,148,235,0,101,0</INFO></NAVI> and the <NAVI>[guild warehouse]<INFO>jalbe_in.gat,22,63,0,101,0</INFO></NAVI>.";
			mes "It's a simple task, but can you handle it?";
			next;
			cutin "",255;
			if(select("I'll be back soon.","I'll think about it a bit more.") == 2){
				cutin "ep21_yohan01.png",2;
				mes "[Yohan]";
				mes "Oh, okay…….";
				mes "When you're done thinking about it, please talk to me again.";
				close3;
			}
			cutin "ep21_yohan01.png",2;
			mes "[Yohan]";
			mes "I'll leave it to you.";
			mes "Be careful not to hurt your back while you're at it.";
			erasequest 16802;
			erasequest 16803;
			erasequest 16804;
			setquest 16802;
			setquest 16803;
			completequest 16805;
			cloaknpc("Cargo#ep21_rw01",true,getcharid(0));
			cloaknpc("Cargo#ep21_rw02",true,getcharid(0));
			close3;
		}
		if(isbegin_quest(16805) == 2){
			cutin "ep21_yohan01.png",2;
			mes "[Yohan]";
			mes "Oh……, You're. Did everything went smoothly?";
			mes "The market folks and the warehouse ladies mentioned that you did well for your first time.";
			next;
			mes "[Yohan]";
			mes "Well……, It's a simple task afterall.";
			mes "It is tiring but simple…….";
			next;
			cutin "ep21_yohan02.png",2;
			mes "[Yohan]";
			mes "Next is…… let's see, with all the supplies coming and going lately, the port and nearby streets have gotten a bit dirty.";
			mes "There are dirt piles everywhere, making the road unpleasant to see…….";
			next;
			cutin "ep21_yohan01.png",2;
			mes "[Yohan]";
			mes "Please take a look around the port and nearby streets and clean up the dirt piles on the ground. Let' see…… it will look much better if you can clean up these four spots.";
			next;
			cutin "",255;
			if(select("I'll be back soon.","I'll think about it a bit more.") == 2){
				cutin "ep21_yohan01.png",2;
				mes "[Yohan]";
				mes "Oh, okay…….";
				mes "When you're done thinking about it, please talk to me again.";
				close3;
			}
			cutin "ep21_yohan01.png",2;
			mes "[Yohan]";
			mes "Alright, I'll mark the places you need to clean on the map. If you can't remember, just check your map.";
			mes "As much as possible…… I want you to clean it thoroughly, but take your time.";
			completequest 16804;
			setquest 16806;
			setquest 16807;
			setquest 16808;
			setquest 16809;
			cloaknpc("Pile of Dirt#ep21_rw01",false,getcharid(0));
			cloaknpc("Pile of Dirt#ep21_rw02",false,getcharid(0));
			cloaknpc("Pile of Dirt#ep21_rw02",false,getcharid(0));
			cloaknpc("Pile of Dirt#ep21_rw04",false,getcharid(0));
			close3;
		}
	}
	if(isbegin_quest(16810) == 1){
		cutin "ep21_yohan02.png",2;
		mes "[Yohan]";
		mes "Oh, you're finished…… with the cleaning. The port does seem cleaner now.";
		mes "Thank you for your hard work. Then…….";
		next;
		cutin "ep21_yohan01.png",2;
		mes "[Yohan]";
		mes "Could you go inside the guild building over there? Do you remember the guild warehouse that you delivered cargo to?";
		next;
		mes "[Yohan]";
		mes "This time, head to the <NAVI>[room on the opposite side of the warehouse]<INFO>jalbe_in.gat,67,95,0,101,0</INFO></NAVI>. The reason…… you'll find out once you get there.";
		completequest 16810;
		setquest 16811;
		close3;
	}
	if(isbegin_quest(16811) == 1){
		cutin "ep21_yohan01.png",2;
		mes "[Yohan]";
		mes "Could you go inside the guild building over there? Do you remember the guild warehouse that you delivered cargo to?";
		next;
		mes "[Yohan]";
		mes "This time, head to the <NAVI>[room on the opposite side of the warehouse]<INFO>jalbe_in.gat,67,95,0,101,0</INFO></NAVI>. The reason…… you'll find out once you get there.";
		close3;
	}
	cutin "ep21_yohan02.png",2;
	mes "[Yohan]";
	mes "……Oh, yes? Did you call for me?";
	mes "I see, I'm counting on you.";
	close3;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(16820) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(16804) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(16810) == 1";
end;
}

jor_albe,236,116,3	script(CLOAKED)	Nillem#ep21_rw02	4_M_NILLEM,{
	cutin "ep172_nillem03.png",0;
	mes "[Nillem]";
	mes "Did you call me? Some about an important cargo?";
	mes "honestly, I've been so busy casting small spells here and there, that I haven't been able to do something else…….";
	next;
	cutin "ep172_nillem04.png",0;
	mes "[Nillem]";
	mes "If there's any information, I'll let you know!";
	mes "Let's work for now, Sigh……. Let's do our best.";
	close3;
}

jor_albe,234,110,3	script(CLOAKED)	Victor#ep21_rw01	4_M_05,{
	mes "[Victor]";
	mes "Come to think of it, I keep hearing about the ghost ship stories more?";
	next;
	mes "[Victor]";
	mes "Oh, I was just talking to myself. Don't worry about it.";
	close;
}

jor_albe,236,117,5	script(CLOAKED)	Ullya#ep21_rw01	1_F_MERCHANT_01,{
	mes "[Ullya]";
	mes "The supplies arrived at warehouse 3 on the 17th of last month, 2 days ago, and yesterday.";
	mes "There's still plenty of space! No worries!";
	close;
}

jor_albe,231,111,3	script(CLOAKED)	Important Cargo#ep21_rw01	4_STEELBOX,{
	cutin "ep21_yohan02.png",2;
	mes "[Yohan]";
	mes "Oh, that's an important cargo……. It needs to handled carefully by a skilled worker.";
	next;
	cutin "ep21_yohan01.png",2;
	mes "[Yohan]";
	mes "It's not something I can entrust to an outsider. Please put it down.";
	close3;
}

jor_albe,242,118,3	script(CLOAKED)	Cargo#ep21_rw01	4_WOODBOX,{
	cutin "ep21_yohan01.png",2;
	mes "[Yohan]";
	mes "Oh, if you don't have anything else to do, can you move that cargo…….";
	mes "Can you carry it? Come here and I'll tell you where to take it";
	close3;
}

jor_albe,241,116,3	duplicate(Cargo#ep21_rw01)	Cargo#ep21_rw02	4_WOODBOX

jor_albe,148,235,5	script	Walter Sailor#ep21_rw01	4_F_MONK,{
	if(isbegin_quest(16802) == 1){
		mes "[Walter Sailor]";
		mes "Ah, over here, come this way! Did you bring the goods?";
		mes "Carefully place it right here beside me.";
		next;
		cloaknpc("Cargo#ep21_rw03",false,getcharid(0));
		mes "[Walter Sailor]";
		mes "It's heavy, so watch your back.";
		mes "Yes, there. Easy does it.";
		next;
		mes "[Walter Sailor]";
		mes "Haha! This is our first time meeting, yeah? It seems like this is your first time helping with guild warehouse work, but you're doing good.";
		next;
		mes "[Walter Sailor]";
		mes "A lot of people don't like these kind of small tasks, saying they're too trivial.";
		next;
		mes "[Walter Sailor]";
		mes "But if you don't start with these small tasks, you can't climb to the higher ranks.";
		mes "Everyone starts the same! That's captain Walter's rule.";
		next;
		//= Official check is different and can be a source of progression bug
		completequest 16802;
		if(isbegin_quest(16803) != 2){
			mes "[Walter Sailor]";
			mes "We're done with the cargo that needed to be delivered here!";
			mes "You still have the cargo for the guild warehouse, right? Please go ahead and deliver it!";
		} else {
			setquest 16804;
			mes "[Walter Sailor]";
			mes "Have you finished delivering the goods?";
			mes "Then head over to <NAVI>[Yohan]<INFO>jor_albe.gat,239,115,0,101,0</INFO></NAVI>, and report that you're all done. Thank you for your hard work.";
		}
		close;
	}
	mes "[Walter Sailor]";
	mes "Welcome. Is there something you're looking for?";
	close;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(16802) == 1";
end;
}

jor_albe,151,235,3	script(CLOAKED)	Cargo#ep21_rw03	4_WOODBOX,{
	mes "[Walter Sailor]";
	mes "That box is heavy. You might get hurt if you lift it carelessly.";
	mes "Be careful!";
	close;
}

jalbe_in,22,63,3	script	Walter Sailor#ep21_rw02	2_M_SWORDMASTER,{
	if(isbegin_quest(16803) == 1){
		mes "[Walter Sailor]";
		mes "Who. You're a face I haven't seen before.";
		mes "What, you were sent from Gaebolg? Here to work?";
		next;
		mes "[Walter Sailor]";
		mes "Did you bring the goods? Well, looks like you brought them properly.";
		mes "Put it down over there. Just stack it up there.";
		next;
		cloaknpc("Cargo#ep21_rw04",false,getcharid(0));
		mes "[Walter Sailor]";
		mes "Hmp, those people sent from the Gaebolg act so highly because they think Alberta is some backwater……";
		mes "Oh, I'm not talking abot you. Why, did I hit a nerve?";
		next;
		//= Official check is different and can be a source of progression bug
		completequest 16803;
		if(isbegin_quest(16802) != 2){
			mes "[Walter Sailor]";
			mes "Have you stacked it up? Then you're done here.";
			mes "What are you doing? There's still more to do. Go bring it to the market near the pier.";
		} else {	
			mes "[Walter Sailor]";
			mes "It looks like you're not all talk.";
			mes "What are you doing? If you're finished with your task, shouldn't you go talk to <NAVI>[Yohan]<INFO>jor_albe.gat,239,115,0,101,0</INFO></NAVI>? Hurry up and go.";
			setquest 16804;
		}
		close;
	}
	mes "[Walter Sailor]";
	mes "Do we look like we're playing here? They must not be from a merchant guild.";
	mes "There's no task more important than check inventories. Some people see that as us playing around.";
	close;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(16803) == 1";
end;
}

jalbe_in,21,66,3	script(CLOAKED)	Cargo#ep21_rw04	4_WOODBOX,{
	mes "[Walter Sailor]";
	mes "No need to touch it again once you stacked it. Don't mess with it.";
	close;
}

jor_albe,154,210,0	script	#ep21_rw03	HIDDEN_WARP_NPC,5,5,{
	end;
	
OnTouch:
	.@id = atoi(replacestr(strnpcinfo(2),"ep21_rw0",""));
	if(isbegin_quest(16803 + .@id) != 1) end;
	cloaknpc("Pile of Dirt#ep21_rw0" + (.@id - 2),false,getcharid(0));
end;
}

jor_albe,208,136,0	duplicate(#ep21_rw03)	#ep21_rw04	HIDDEN_WARP_NPC,5,5
jor_albe,170,139,0	duplicate(#ep21_rw03)	#ep21_rw05	HIDDEN_WARP_NPC,5,5

jor_albe,190,178,0	script	#ep21_rw06	HIDDEN_WARP_NPC,5,5,{
	end;

OnTouch:
	if(isbegin_quest(16816) == 1 || isbegin_quest(16817) == 1){
		cloaknpc("Maristella Walter#ep21_rw03",false,getcharid(0));
		cloaknpc("Tan#ep21_rw01",false,getcharid(0));
		cloaknpc("Yohan#ep21_rw03",false,getcharid(0));
		cloaknpc("Iana Operta#ep21_rw02",false,getcharid(0));
		end;
	}
	if(isbegin_quest(16819) == 1){
		cloaknpc("Wigner Executive#ep21_rw01",false,getcharid(0));
		end;
	}
	if(isbegin_quest(16819) == 2){
		cloaknpc("Nillem#ep21_rw04",false,getcharid(0));
		end;
	}
	.@id = atoi(replacestr(strnpcinfo(2),"ep21_rw0",""));
	if(isbegin_quest(16803 + .@id) != 1) end;
	cloaknpc("Pile of Dirt#ep21_rw0" + (.@id - 2),false,getcharid(0));
end;
}

jor_albe,195,179,3	script	Nillem#ep21_rw04	4_M_NILLEM,{
	if(isbegin_quest(16819) < 2) end;
	if(isbegin_quest(16821) == 0){
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "……Something's strange.";
		mes "The traces of the ghost ship, the Old Walter…… it hasn't disappeared yet.";
		next;
		cutin "ep21_maristella03.png",1;
		mes "[Maristella Walter]";
		mes "What do you mean by that? We clearly saw the Walter vanish into the moonlight…….";
		mes "After we disembarked, it gradually faded before our eyes.";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Oh, I'm not saying that you're lying~ Relax, relax.";
		mes "The thing that I'm suspecting, is the unknown woman…… she might be involved.";
		next;
		mes "[Nillem]";
		mes "To investigate it further, I think we need to board the Old Walter that's currently going around again.";
		next;
		mes "[Nillem]";
		mes "I'll open a portal that will take us near the Old Walter.";
		mes "From there, can you take over captain?";
		next;
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "……We need find out what's going on.";
		mes "Even if it's impossible, I'll give it a try.";
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "You got Nillem here, there's no way it won't work☆";
		mes "Can we head out now? Or, do you need a little more time?";
		next;
		cutin "",255;
		if(select("I can depart now.","I'll depart later.") == 2){
			cutin "ep172_nillem03.png",0;
			mes "[Nillem]";
			mes "Okay! I will stay here and continue observing it.";
			mes "If you have any urgent matters, please go ahead and take care of it first.";
			close3;
		}
		cutin "ep172_nillem03.png",0;
		mes "[Nillem]";
		mes "Alright! Then come back after a while.";
		mes "I'll prepare a portal to the coordinates closest to the Old Walter.";
		setquest 16821;
		close3;
	}
	if(isbegin_quest(16821) == 1){
		.@party_id = getcharid(1);
		if(!.@party_id){
			cutin "ep172_nillem02.png",0;
			mes "[Nillem]";
			mes "Did you forget to create a party? Party is a must.";
			mes "Are you going alone? Just think of it as formality, yes, formality.";
			close3;
		}
		.@md_name$ = "Mysterious Ghost Ship";
		switch(select("Set Coordinates","Explore the Old Walter","Explore Later")){
			case 1:
				cutin "ep172_nillem04.png",0;
				mes "[Nillem]";
				mes "Okay☆ I already set the coordinates!";
				mes "Just wait a moment, tell me to 'Explore the Old Walter' to proceed.";
				.@id = instance_create(.@md_name$);
				switch(.@id){
					case -1:
					case -2:
					case -3:
					case -4:
						instance_warning(2,.@md_name$);
						break;
					default:
						setinstancevar('daily,true,.@id);
						break;
				}
				close3;
				
			case 2:
				if(instance_enter(.@md_name$) != IE_OK){
					cutin "ep172_nillem02.png",0;
					mes "[Nillem]";
					mes "I've locked in the coordinates…… Now all that's left is to open the portal.";
					mes "Give me a moment, talk to me again later. It's almost ready.";
					close3;
				}
				if(isbegin_quest(16825) == 0)
					setquest 16825;
				mapannounce "jor_albe", strcharinfo(0) + " is boarding the Mysterious Ghost Ship.", bc_map, "0x00FF99";
				end;
				
				
			case 3:
				cutin "ep172_nillem02.png",0;
				mes "[Nillem]";
				mes "Alright. I will continue observing from here.";
				mes "If you have any urgent matters, please go ahead and take care of it first.";
				close3;	
		}
	}
	if(isbegin_quest(16822) == 1){
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Welcome back! Did you notice anything strange?";
		mes "Ah, perhaps you didn't realize it while inside. I'm quite capable after all.";
		next;
		mes "[Nillem]";
		mes "While you were exploring the old Walter, I was able to check the flow of mana.";
		mes "It seems that…… it's being influenced by the Heart of Ymir fragment.";
		next;
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "Heart of Ymir fragment?";
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "Yes. It seems a fragment of Ymir's heart was drifting on the sea.";
		mes "Remember that you mentioned what you saw in the past when you first boarded the Walter.";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "You mentioned the captain was talking to someone you didn't recognize.";
		mes "The person is probably the culprit, the one who altered the appearance of the captain and the old walter.";
		next;
		mes "[Nillem]";
		mes "Himmelmez…… That's the one who altered the old walter, and the mana from the fragment of the Heart of Ymir.";
		next;
		mes "[Nillem]";
		mes "When the real Old Walter disappeared, this replica began wandering the sea, mimicking its form.";
		mes "It's action and pattern are likely similar. You didn't notice anything different, don't you?";
		next;
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "Ah, there was one difference. My father, the captain was in a state where he completely lost his reasoning.";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Ah, that makes sense! The replica couldn't imitate the true essence of it.";
		mes "It's just a replica after all.";
		next;
		mes "[Nillem]";
		mes "Once the mana dissipates over time and blends with mana of nature, it will eventually disappear.";
		mes "Of course, even a genius like me don't know how long it will take.";
		next;
		cutin "ep172_nillem03.png",0;
		mes "[Nillem]";
		mes "But if we directly disperse the mana, it might disappear faster.";
		mes "It's probably better than just letting it wander the sea, don't you think?";
		next;
		cutin "ep21_maristella03.png",1;
		mes "[Maristella Walter]";
		mes "……Yes, I think you're right.";
		mes "It's probably better than just letting it wander the sea, don't you think?";
		next;
		cutin "ep21_maristella02.png",1;
		mes "[Maristella Walter]";
		mes "Will you lend us a hand? "+strcharinfo(0)+".";
		next;
		cutin "",255;
		select("Of course.");
		cutin "ep172_nillem03.png",0;
		mes "[Nillem]";
		mes "Yes. Thanks to your initial exploration in it and you dispersing the mana, it temporarily disappeared for now.";
		mes "Perhaps by daw, we'll be able to check it again.";
		next;
		cutin "ep21_maristella02.png",1;
		mes "[Maristella Walter]";
		mes "Let's meet here again after dawn.";
		mes "I'll be waiting.";
		completequest 16822;
		close3;
	}
	if(isbegin_quest(16822) < 2) end;
	switch(checkquest(16823,PLAYTIME)){
		case -1:
			break;
			
		case 0:
		case 1:
			cutin "ep172_nillem03.png",0;
			mes "[Nillem]";
			mes "The replica of the Old Walter disappeared for now.";
			mes "It seems your efforts to disperse the mana were effective.";
			next;
			cutin "ep172_nillem04.png",0;
			mes "[Nillem]";
			mes "Take a break for now and come back after dawn~";
			close3;
			
		case 2:
			erasequest 16823;
			break;
	}
	cutin "ep172_nillem03.png",0;
	mes "[Nillem]";
	mes "Shall we head out to explore the memory fragments of the Old Walter once again?";
	mes "I'll create the portal for you.";
	next;
	.@party_id = getcharid(1);
	if(!.@party_id){
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Did you forget to create a party? Party is a must.";
		mes "Are you going alone? Just think of it as formality, yes, formality.";
		close3;
	}
	cutin "",255;
	.@md_name$ = "Mysterious Ghost Ship";
	switch(select("Set Coordinates","Explore the Old Walter","Explore Later")){
		case 1:
			cutin "ep172_nillem04.png",0;
			mes "[Nillem]";
			mes "Okay☆ I already set the coordinates!";
			mes "Just wait a moment, tell me to 'Explore the Old Walter' to proceed.";
			.@id = instance_create(.@md_name$);
			switch(.@id){
				case -1:
				case -2:
				case -3:
				case -4:
					instance_warning(2,.@md_name$);
					break;
				default:
					setinstancevar('daily,true,.@id);
					break;
			}
			close3;
			
		case 2:
			if(instance_enter(.@md_name$) != IE_OK){
				cutin "ep172_nillem02.png",0;
				mes "[Nillem]";
				mes "I've locked in the coordinates…… Now all that's left is to open the portal.";
				mes "Give me a moment, talk to me again later. It's almost ready.";
				close3;
			}
			setquest 16823;
			if(isbegin_quest(16824) == 0)
				setquest 16824;
			if(isbegin_quest(16824) == 0)
				setquest 16826;
			mapannounce "jor_albe", strcharinfo(0) + " is boarding the Mysterious Ghost Ship.", bc_map, "0x00FF99";
			end;
			
			
		case 3:
			cutin "ep172_nillem02.png",0;
			mes "[Nillem]";
			mes "Alright. I will continue observing from here.";
			mes "If you have any urgent matters, please go ahead and take care of it first.";
			close3;	
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(16819) == 2 && isbegin_quest(16821) == 0";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(16821) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(16822) == 1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(16822) == 2 && checkquest(16823,PLAYTIME) == -1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(16822) == 2 && checkquest(16823,PLAYTIME) == 2";
end;
}

function	script	ep21_clean_check	{
	for(.@i = 16806; .@i <= 16809; .@i++)
		if(isbegin_quest(.@i) != 2) return false;
	return true;
}

jor_albe,151,210,3	script(CLOAKED)	Pile of Dirt#ep21_rw01	4_SOIL,{
	.@id = atoi(replacestr(strnpcinfo(2),"ep21_rw0",""));
	if(isbegin_quest(16805 + .@id) != 1) end;
	switch(.@id){
		case 1:
			mes "[" + strcharinfo(0) + "]";
			mes "The ground looks dirty…….";
			mes "Let's clean it up!";
			npctalk "Resident : Come to think of it, they say the ghost ship has appeared again?","Alberta Resident#ep21_rw01",bc_self;
			next;
			mes "[" + strcharinfo(0) + "]";
			mes "As a job, I should clean it up perfectly!";
			npctalk "Resident : Is that true? ……That rumor. I mean captain Walter…… Oh, why are you eavesdropping?","Alberta Resident#ep21_rw02",bc_self;
			progressbar_npc "FFFF00",3;
			next;
			cloaknpc("Pile of Dirt#ep21_rw01",true,getcharid(0));
			completequest 16806;
			if(ep21_clean_check()) break;
			mes "[" + strcharinfo(0) + "]";
			mes "There are still areas that needs cleaning.";
			mes "Let's take a look around the pier.";
			close;
			
		case 2:
			mes "[" + strcharinfo(0) + "]";
			mes "The ground is full of dust. Let's clean it up.";
			next;
			npctalk "Resident : Things feel a bit uneasy recently…… It's scary!","Alberta Resident#ep21_rw03",bc_self;
			mes "[" + strcharinfo(0) + "]";
			mes "Since I've decided to do this, I might as well make it spotless.";
			progressbar_npc "FFFF00",3;
			next;
			cloaknpc("Pile of Dirt#ep21_rw02",true,getcharid(0));
			completequest 16807;	
			if(ep21_clean_check()) break;
			mes "[" + strcharinfo(0) + "]";
			mes "I haven't cleaned up all four spots yet…….";
			mes "Let's take a closer look around.";
			close;
			
		case 3:
			mes "[" + strcharinfo(0) + "]";
			mes "A pile of dust is blocking the road. Let's clean it up.";
			npctalk "Resident : It's a relief that our village is quiet!","Alberta Resident#ep21_rw04",bc_self;
			next;
			mes "[" + strcharinfo(0) + "]";
			mes "This is making it inconvenient to pass through. Let's clean it thorougly.";
			progressbar_npc "FFFF00",3;
			next;
			cloaknpc("Pile of Dirt#ep21_rw03",true,getcharid(0));
			completequest 16808;
			if(ep21_clean_check()) break;
			mes "[" + strcharinfo(0) + "]";
			mes "I feel like I'm not done cleaning yet.";
			mes "There were supposed to be four spots. Let's take a closer look around.";
			close;
		
		case 4:
			mes "[" + strcharinfo(0) + "]";
			mes "A pile of dust is blocking the way. Let's clean it up";
			next;
			mes "[" + strcharinfo(0) + "]";
			mes "Moving my body like this feels refreshing♬";
			progressbar_npc "FFFF00",3;
			next;
			cloaknpc("Pile of Dirt#ep21_rw04",true,getcharid(0));
			completequest 16809;
			if(ep21_clean_check()) break;
			mes "[" + strcharinfo(0) + "]";
			mes "Have I cleaned everything? It feels like I've missed a spot.";
			mes "Let's take another look at the area.";
			close;
	}
	mes "[" + strcharinfo(0) + "]";
	mes "I think the port looks pretty clean now .";
	mes "I've cleaned all four spots as <NAVI>[Yohan]<INFO>jor_albe.gat,239,115,0,101,0</INFO></NAVI> instructed…… It's time to head back.";
	setquest 16810;
	close;
	
OnInit:
	.@id = atoi(replacestr(strnpcinfo(2),"ep21_rw0",""));
	.@qid = 16805 + .@id;
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(" + .@qid + ") == 1";
end;
}

jor_albe,211,136,3	duplicate(Pile of Dirt#ep21_rw01)	Pile of Dirt#ep21_rw02	4_SOIL
jor_albe,167,139,3	duplicate(Pile of Dirt#ep21_rw01)	Pile of Dirt#ep21_rw03	4_SOIL
jor_albe,190,175,3	duplicate(Pile of Dirt#ep21_rw01)	Pile of Dirt#ep21_rw04	4_SOIL

jalbe_in,66,108,0	script	#ep21_rw07	HIDDEN_WARP_NPC,2,2,{
	end;
	
OnTouch:
	if(isbegin_quest(16811) == 1){
		cloaknpc("Iana Operta#ep21_rw",false,getcharid(0));
		end;
	}
	if(isbegin_quest(16814) == 1){
		cloaknpc("Iana Operta#ep21_rw",false,getcharid(0));
		cloaknpc("Yohan#ep21_rw02",false,getcharid(0));
		cloaknpc("Maristella Walter#ep21_rw",false,getcharid(0));
	}
end;
}

jalbe_in,67,95,1	script(CLOAKED)	Iana Operta#ep21_rw	4_EP21_IANA,{
	if(isbegin_quest(16811) == 1){
		cutin "ep21_iana01.png",1;
		mes "[Walter Merchant]";
		mes "Oho, finally here? " + strcharinfo(0) + ", right?";
		mes "I told you Yohan to send you here.";
		next;
		cutin "ep21_iana04.png",1;
		mes "[Walter Merchant]";
		mes "The reason that I call you? There's no other reason than me giving you an errand, correct?";
		mes "I want you to deliver these letters.";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "Letter delivery…… got it.";
		mes "Where and to whom should I deliver these letters?";
		next;
		cutin "ep21_iana01.png",1;
		mes "[Walter Merchant]";
		mes "Here are two letters! One is for <NAVI>[Professor Sanguin]<INFO>jalbe_in.gat,29,28,0,101,0</INFO></NAVI>. The chairman of Alberta's small business association.";
		next;
		mes "[Walter Merchant]";
		mes "The other one should be delivered to <NAVI>[Edel's Teahouse]<INFO>jalbe_in.gat,126,54,0,101,0</INFO></NAVI>. Find the owner, Patissier Edel, the president of Alberta women's association .";
		next;
		cutin "ep21_iana02.png",1;
		mes "[Iana Operta]";
		mes "Just tell them both the letters are from Iana of the Walter Merchants, and they'll understand.";
		mes "Obviously, do not open them!";
		next;
		mes "[Iana Operta]";
		mes "And make sure to get a reply.";
		mes "It doesn't matter if it's verbal or a written one, but you must bring back a reply.";
		next;
		cutin "ep21_iana04.png",1;
		mes "[Iana Operta]";
		mes "Now, hurry up and go!";
		mes "Don't be late! Speed, accuracy, and don't forget…… courtesy! Tehehe, off you go!";
		completequest 16811;
		setquest 16812;
		setquest 16813;
		close3;
	}
	if(isbegin_quest(16814) < 1){
		cutin "ep21_iana04.png",1;
		mes "[Iana Operta]";
		mes "My advice, do you remember it? Speed, accuracy, and courtesy!";
		mes "Go on and hurry up!";
		close3;
	}
	if(isbegin_quest(16814) == 1){
		cutin "ep21_iana03.png",1;
		mes "[Iana Operta]";
		mes "You're late~! Did you do your job properly?";
		mes "Let me see, Let me see the reply!";
		next;
		cutin "",255;
		if(select("Convey Edel's message.","Hand over Sanguin's letter.") == 1){
			cutin "ep21_iana01.png",1;
			mes "[Iana Operta]";
			mes "So Edel gave a verbal response.";
			mes "Where where, let me hear it!";
			next;
			cutin "",255;
			select("Recite what you've memorized.");
			cutin "ep21_iana01.png",1;
			mes "[Iana Operta]";
			mes "Ah, the Alberta women's association supports and endorses us. That's great.";
			next;
			cutin "ep21_iana04.png",1;
			mes "[Iana Operta]";
			mes "And from what I've heard, aren't you good at making an impression?";
			mes "You're doing well even without being thought. Good good, Well done!";
			next;
			cutin "",255;
			mes "[" + strcharinfo(0) + "]";
			mes "What did she mean when she said that I'd be seeing her often?";
			next;
			cutin "ep21_iana01.png",1;
			mes "[Iana Operta]";
			mes "Well, you're not part of the merchants, so it won't be that often.";
			mes "But now that you've helped out here, met Yohan, Megas, and introduced yourself to me.";
			next;
			cutin "ep21_iana04.png",1;
			mes "[Iana Operta]";
			mes "Aren't becoming quite a key figure? Ahaha.";
			mes "Alright, where's the next reply?";
			next;
			cutin "",255;
			select("Hand over Sanguin's letter.");
			cutin "ep21_iana01.png",1;
			mes "[Iana Operta]";
			mes "Good. You also brought the reply from the Small Business Association as well.";
			mes "Oh, The professor is very kind.";
			next;
			cutin "",255;
			mes "[" + strcharinfo(0) + "]";
			mes "He mentioned that I was in the letter?";
			mes "Thank you.";
			next;
			cutin "ep21_iana01.png",1;
			mes "[Iana Operta]";
			mes "*Smirk*, did you think that I was just making you run errands.";
			mes "It's nothing much. He also wrote that you've been doing your job very diligently.";
			next;
			mes "[Iana Operta]";
			mes "I hope that, me and the people could be of help to you.";
			mes "And of course, I hope you'll be of help to us too.";
		} else {
			cutin "ep21_iana01.png",1;
			mes "[Iana Operta]";
			mes "Good. You also brought the reply from the Small Business Association as well.";
			mes "Oh, The professor is very kind.";
			next;
			cutin "",255;
			mes "[" + strcharinfo(0) + "]";
			mes "He mentioned that I was in the letter?";
			mes "Thank you.";
			next;
			cutin "ep21_iana01.png",1;
			mes "[Iana Operta]";
			mes "*Smirk*, did you think that I was just making you run errands.";
			mes "It's nothing much. He also wrote that you've been doing your job very diligently.";
			next;
			mes "[Iana Operta]";
			mes "I hope that, me and the people could be of help to you.";
			mes "And of course, I hope you'll be of help to us too.";
			next;
			cutin "ep21_iana04.png",1;
			mes "[Iana Operta]";
			mes "Alright, let's see if you also brought the other reply properly?";
			next;
			cutin "",255;
			select("Relay Edel's message.");
			cutin "ep21_iana01.png",1;
			mes "[Iana Operta]";
			mes "Ah, the Alberta women's association supports and endorses us. That's great.";
			next;
			cutin "ep21_iana04.png",1;
			mes "[Iana Operta]";
			mes "And from what I've heard, aren't you good at making an impression?";
			mes "You're doing well even without being thought. Good good, Well done!";
			next;
			cutin "",255;
			mes "[" + strcharinfo(0) + "]";
			mes "What did she mean when she said that I'd be seeing her often?";
			next;
			cutin "ep21_iana01.png",1;
			mes "[Iana Operta]";
			mes "Well, you're not part of the merchants, so it won't be that often.";
			mes "But now that you've helped out here, met Yohan, Megas, and introduced yourself to me.";
			next;
			cutin "ep21_iana04.png",1;
			mes "[Iana Operta]";
			mes "Aren't becoming quite a key figure? Ahaha.";
		}
		next;
		cutin "ep21_maristella01.png",1;
		mes "[Walter Sailor]";
		mes "I'm glad you got good responses from both places.";
		mes "They have a lot of influence, the women's association and small business association.";
		next;
		cutin "ep21_iana04.png",1;
		mes "[Iana Operta]";
		mes "I agree with you, Mari.";
		mes "Edel is excellent at gathering information from local rumors.";
		mes "And the professor, is simply a major figure in Alberta!";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "By the way, who is that person?";
		next;
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "Oh, I apologize for the late introducetion.";
		mes "I'm Maristella Walter. The current captain of the Walter Merchant Fleet.";
		next;
		cutin "ep21_maristella02.png",1;
		mes "[Maristella Walter]";
		mes "I've heard about you.";
		mes "I understand that you've been working hard on our behalf.";
		next;
		cutin "ep21_yohan01.png",2;
		mes "[Yohan]";
		mes "Well…… you've done a good job.";
		mes "I suppose…….";
		next;
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "I suppose, you're a tough critic, Yohan.";
		mes "I understand that it might have been a simple task, and you probably kept wondering if that was the right thing to do.";
		next;
		mes "[Maristella Walter]";
		mes "But you've completed it admirably.";
		mes "……I believe that the simplest task often reveals the person the most.";
		next;
		cutin "ep21_maristella02.png",1;
		mes "[Maristella Walter]";
		mes "Me too, when my father was still in charge of the merchant fleet, I also started by learning the crew's simple tasks.";
		next;
		cutin "ep21_iana04.png",1;
		mes "[Iana Operta]";
		mes "Ahaha, when I first joined. I was told to start by cleaning the deck, and it shocked me.";
		mes "Back then, Mari and I used to fight a lot. You are pretty tame, " + strcharinfo(0) + " compared to us.";
		next;
		cutin "ep21_maristella03.png",1;
		mes "[Maristella Walter]";
		mes "Embarassing old stories…….";
		mes "Anyway, I think it's time we discuss the matter at hand.";
		next;
		cutin "ep172_nillem02.png",0;
		cloaknpc("Nillem#ep21_rw03",false,getcharid(0));
		cloaknpc("Epesto Walter Megas#ep2",false,getcharid(0));
		mes "[Nillem]";
		mes "Ah! I, feel like I'm going to collapse…….";
		mes "My legs are shaking……, I'm almost out of magic power…….";
		next;
		cutin "ep21_epesto01.png",2;
		mes "[Epesto Walter Megas]";
		mes "So weak, these land mutts!";
		mes "Just when we're about to discuss the important matter that you wanted, are you going to faint now?";
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "You, expect me to talk about something important after exhausting me like this……!";
		mes "Alright! I'll power through it! Let's hear it!";
		next;
		cutin "ep21_epesto03.png",2;
		mes "[Epesto Walter Megas]";
		mes "Hmp, Your stamina might be like a newborn Peco Peco, but you've got a strong spirit.";
		mes "Alright, captain. Let's get down to business.";
		next;
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "Okay. You may have heard the rumors that've been circulating lately.";
		mes "A story about a 'ghost ship' that's been wandering around the seas.";
		next;
		cutin "",255;
		if(select("I've heard of it.","It's the first for me.") == 1){
			cutin "ep21_maristella01.png",1;
			mes "[Maristella Walter]";
			mes "Yes, I thought that you might have heard of it already. It's been the talk of the town lately.";
		} else {
			cutin "ep21_maristella01.png",1;
			mes "[Maristella Walter]";
			mes "There's likely a lot of people around here talking about……";
			mes "But they might have been reserved in front of an outsider.";
		}
		next;
		mes "[Maristella Walter]";
		mes "For sailors, ghost ship stories are common.";
		mes "That alone is not particularly special, but…….";
		next;
		mes "[Maristella Walter]";
		mes "This ghost ship has a significant characteristic.";
		mes "From what I've heard, it hasn't caused any damage to our ships.";
		next;
		cutin "",255;
		select("If it's not our ship, then?");
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "It's the cult.";
		mes "It seems to be intentionally targeting only the cult's ships.";
		next;
		mes "[Maristella Walter]";
		mes "I've received several eyewitness reports, the ships these sailors were on seemed to be ignored, it was if they're invisible.";
		next;
		mes "[Maristella Walter]";
		mes "There was a report that claimed that the ghost ship saved them from being captured by the cult.";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Oh, it's almost like the ghost ship is on our side.";
		next;
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "Exactly. but…… I have some suspicions.";
		mes "I suspect that…… this ghost ship might be a ship we already know.";
		next;
		cutin "ep21_iana02.png",1;
		mes "[Iana Operta]";
		mes "The chances are slim, but…….";
		next;
		cutin "ep21_yohan03.png",2;
		mes "[Yohan]";
		mes "But, if it's really Walter's…… then we can't just leave it be!";
		next;
		cutin "",255;
		select("Isn't Walter right here?");
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "That ship is now called the 'Old Walter'…….";
		mes "It was the ship commanded by my father, Captain Howell Megas Walter.";
		next;
		mes "[Maristella Walter]";
		mes "As the clashes with the cult's ships increased, I took charge of the transport ships while my father volunteered to take on the role of the escort.";
		next;
		cutin "ep21_maristella03.png",1;
		mes "[Maristella Walter]";
		mes "And that ship…… it was lost at sea after drawing the cult's attention away while sending us in a different route to protect the transport ship.";
		next;
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "Ever since, I've been looking for the Walter.";
		mes "But now, with the rumors of a ghost ship attacking only the cult's ships…….";
		next;
		cutin "ep21_iana02.png",1;
		mes "[Iana Operta]";
		mes "It's certainly worth investigating.";
		mes "But as you know, we have other things at hand.";
		next;
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "Indeed, rather than chasing after a ghost ship whose location is unknown.";
		mes "We need to prioritize the goods that we need to transport.";
		next;
		mes "[Maristella Walter]";
		mes "But you " + strcharinfo(0) + ", have more freedom to move than we do.";
		mes "The ship that might be the Walter…… I would like to ask you to track down that ghost ship.";
		next;
		cutin "ep21_maristella02.png",1;
		mes "[Maristella Walter]";
		mes "We're about to sail for Lunaforma with the supplies that we've promised.";
		mes "If you could gather information there, It would be greatly appreciated.";
		next;
		cutin "",255;
		select("I'll try to gather information.");
		cutin "ep21_maristella02.png",1;
		mes "[Maristella Walter]";
		mes "Thank you……!";
		mes "I'll be counting in you in Lunaforma.";
		next;
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "I'll ask Megas to take care of things in Alberta for a while.";
		mes "Iana, Yohan, " + strcharinfo(0) + ". Let's head to Lunaforma.";
		next;
		cutin "ep21_soldier_a.png",2;
		cloaknpc("Lunaforma Messenger#ep21_rw",false,getcharid(0));
		mes "[Messenger]";
		mes "Excuse me. We have just arrived from Lunaforma.";
		next;
		cutin "ep21_iana01.png",1;
		mes "[Iana Operta]";
		mes "Perfect timing! We were just about to get ready to depart.";
		next;
		cutin "ep21_soldier_a.png",2;
		mes "[Messenger]";
		mes "Oh, that is great.";
		mes "By the way, I have some news that captain Walter might find interesting.";
		next;
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "What is it?";
		next;
		cutin "ep21_soldier_a.png",2;
		mes "[Messenger]";
		mes "The people that escaped from the cult that have arrived in Lunaforma.";
		mes "Among them, there may be those who have witnessed the ghost ship.";
		next;
		mes "[Messenger]";
		mes "You have been waiting for news about the ghost ship, right?";
		mes "When you arrive in Lunaforma, you should hear what they have to say.";
		next;
		cutin "ep21_maristella02.png",1;
		mes "[Maristella Walter]";
		mes "News of escapees and new information are both welcome. Thank you.";
		mes "So, " + strcharinfo(0) + ", can I let you handle the information gathering in Lunaforma?";
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "If it's information gathering, I can help too.";
		mes "Hah, I feel like I've really mastered preservation magic☆";
		next;
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "I'll leave you to it. Nillem and " + strcharinfo(0) + ".";
		mes "Shall we head to docks and go to <NAVI>[Lunaforma]<INFO>jor_mbase.gat,233,277,0,101,0</INFO></NAVI>?";
		completequest 16814;
		setquest 16815;
		getitem "Ep21_Wigner_Ticket",40;
		getexp 730391700,359970330;
		add_reputation_points(13,40);
		close3;
	}
	if(isbegin_quest(16815) == 1){
		cutin "ep21_iana04.png",1;
		mes "[Iana Operta]";
		mes "Ahaha, isn't brave little Mari just adorable?";
		mes "I swear, people don't appreciate how cute Mari is~";
		npctalk "Maristella Walter : What are you talking about…….","Maristella Walter#ep21_rw",bc_self;
		close3;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(16811) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(16814) == 1";
end;
}

jalbe_in,73,97,3	script(CLOAKED)	Yohan#ep21_rw02	4_EP21_YOHAN,{
	cutin "ep21_yohan04.png",2;
	mes "[Yohan]";
	mes "Me…… well, I just do my best at what I'm ordered to do.";
	mes "Rather than me taking initiative on something…… It's better.";
	next;
	cutin "ep21_yohan03.png",2;
	mes "[Yohan]";
	mes "I want to avoid making mistakes…….";
	close3;
}

jalbe_in,71,95,1	script(CLOAKED)	Maristella Walter#ep21_rw	4_EP21_MARISTELLA,{
	cutin "ep21_maristella01.png",1;
	mes "[Maristella Walter]";
	mes "You're reliable. I look forward to your cooperation, " + strcharinfo(0) + ".";
	next;
	cutin "ep21_maristella02.png",1;
	mes "[Maristella Walter]";
	mes "You've built enough trust with us, Alberta will have it's turn to repay you.";
	close3;
}

jalbe_in,69,101,5	script(CLOAKED)	Epesto Walter Megas#ep2	4_EP21_EPESTO,{
	cutin "ep21_epesto03.png",2;
	mes "[Epesto Walter Megas]";
	mes "Have a safe trip.";
	mes "Don't worry about Alberta.";
	close3;
}

jalbe_in,72,101,5	script(CLOAKED)	Nillem#ep21_rw03	4_M_NILLEM,{
	cutin "ep172_nillem04.png",0;
	mes "[Nillem]";
	mes "Ahaha, I can now cast preservation magic with just my left toe.";
	mes "Haven't I mastered it completely? Ahem!";
	close3;
}

jalbe_in,66,101,5	script(CLOAKED)	Lunaforma Messenger#ep21_rw	4_EP21_SOLDIER_A,{
	cutin "ep21_soldier_a.png",2;
	mes "[Messenger]";
	mes "Hello, I have arrived with news from Lunaforma.";
	close3;
}

jalbe_in,126,54,3	script	Patissier Edel#ep21_rw	4_F_02,{
	if(isbegin_quest(16812) == 1){
		mes "[" + strcharinfo(0) + "]";
		mes "What a pretty shop…….";
		next;
		mes "[" + strcharinfo(0) + "]";
		mes "Excuse me. Is this Edel Teahouse?";
		mes "I'm here to see Patissier Edel.";
		next;
		mes "[Patissier Edel]";
		mes "Oh, you've come to the right place. I'm Patissier Edel.";
		mes "Hm, I don't believe we've met before. Where are you from and what brings you here?";
		next;
		mes "[" + strcharinfo(0) + "]";
		mes "You are the president of Alberta women's association, right?";
		mes "I have been sent by Iana of the Walter Merchants.";
		next;
		mes "[Patissier Edel]";
		mes "You're a still new. But you seem well-informed.";
		mes "I understand where you're from now. So, what brings you here?";
		next;
		if(select("I'm here as a debt collector.","She asked me to deliver a letter.") == 1){
			mes "[Patissier Edel]";
			mes "A debt? What. I haven't borrowed any money from the Walter Merchants.";
			mes "Even if it's a misunderstanding, I'm a little embarrassing. What's going on here.";
			next;
			mes "[" + strcharinfo(0) + "]";
			mes "Oh, I made a mistake for a second. Actually I'm here because…….";
			mes "I was asked to deliver a letter.";
			next;
			mes "[Patissier Edel]";
			mes "Ah, yes. I was expecting a letter.";
			mes "Such mistakes are quite embarrassing, so please be more careful in the future.";
		} else {
			mes "[Patissier Edel]";
			mes "I see. I was expecting a letter.";
			mes "Thank you for bringing it to me.";
		}
		next;
		mes "[Patissier Edel]";
		mes "Thank you for doing such trivial errand.";
		mes "Now, let's see what the letter says.";
		next;
		mes "[Patissier Edel]";
		mes "Hmm…….";
		mes "Did Iana asked you to get me reply?";
		next;
		select("That's right.");
		mes "[Patissier Edel]";
		mes "I'll give you a verbal reply, so please remember it and relay my message.";
		mes "Can you do it?";
		next;
		select("Don't worry about it.");
		mes "[Patissier Edel]";
		mes "Alright, here's my reply.";
		next;
		mes "[Patissier Edel]";
		mes "I've recieved your letter. Thank you fro the swift decision and all your efforts.";
		mes "The Alberta women's association fully support and endorse this decision.";
		next;
		mes "[Patissier Edel]";
		mes "The person who delivered the letter seems very reliable.";
		mes "Iana really has an eye for a person worthy of trust.";
		next;
		mes "[Patissier Edel]";
		mes "You introducing this person to me might mean that I'll be seeing more of this person in the future with the Walter Merchants.";
		mes "I look forward to seeing Iana again at the next meeting.";
		next;
		mes "[Patissier Edel]";
		mes "Well, that's it.";
		mes "Did you remember everything?";
		next;
		completequest 16812;
		if(isbegin_quest(16813) != 2){
			mes "[Patissier Edel]";
			mes "Do you have other errands to do?";
			mes "A capable person like you must be busy. I wish I had the time to offer you a cup of tea.";
		} else {
			mes "[Patissier Edel]";
			mes "Are you finished with your errands?";
			mes "You must head back to <NAVI>[Iana]<INFO>jalbe_in.gat,67,95,0,101,0</INFO></NAVI>. I wish I had the time to offer you a cup of tea.";
			setquest 16814;
		}
		close;
	}
	mes "[Patissier Edel]";
	mes "Welcome to Edel Teahouse.";
	mes "Please enjoy the tea, music, and the books to your heart's content.";
	close;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(16812) == 1";
end;
}

jalbe_in,29,28,3	script	Professor Sanguin#ep21_rw01	1_M_JOBTESTER,{
	if(isbegin_quest(16813) == 1){
		mes "[Professor Sanguin]";
		mes "Hm? This is my first time seeing you. What brings you here?";
		next;
		mes "[" + strcharinfo(0) + "]";
		mes "Hello , are you Professor Sanguin, the chairman of the Alberta Small Business Association?";
		mes "I've come to deliver a letter to you. It's from Iana Operta of the Walter Merchants.";
		next;
		mes "[Professor Sanguin]";
		mes "From lady Iana. I was expecting a reply. May I have the letter?";
		next;
		select("Hand over the letter");
		mes "[Professor Sanguin]";
		mes "Let's see…….";
		mes "Oh? The one who brought the letter, may I ask your name?";
		next;
		mes "[" + strcharinfo(0) + "]";
		mes "Oh, It's " + strcharinfo(0) + "……?";
		next;
		mes "[Professor Sanguin]";
		mes "I see, your name was mentioned in the letter.";
		mes "So, you're from the Gaebolg.";
		next;
		mes "[Professor Sanguin]";
		mes "There's other content in the letter, but it's a private one…….";
		mes "It seems lady Iana has been very attentive.";
		next;
		mes "[" + strcharinfo(0) + "]";
		mes "(Has she……? It feels like I'm just being used for a bunch of errands)";
		next;
		mes "[Professor Sanguin]";
		mes "Then, I'll a reply. Could you wait a moment?";
		mes "I'll write it quickly, so please have a seat and enjoy a cup of tea.";
		next;
		mes "[Professor Sanguin]";
		mes "…………";
		next;
		mes "[Professor Sanguin]";
		mes "……………………";
		next;
		mes "[Professor Sanguin]";
		mes "…………………………………………";
		next;
		mes "[Professor Sanguin]";
		mes "There, it's done. Here's the letter with my seal…….";
		mes "Please deliver it to lady Iana.";
		next;
		completequest 16813;
		if(isbegin_quest(16812) != 2){
			mes "[Professor Sanguin]";
			mes "Do you still have other places to go? Please be careful on your way.";
		} else {
			mes "[Professor Sanguin]";
			mes "Are you heading back to lady <NAVI>[Iana]<INFO>jalbe_in.gat,67,95,0,101,0</INFO></NAVI> now? Please be careful on your way";
			setquest 16814;
		}
		close;
	}
	mes "[Professor Sanguin]";
	mes "Oh, do you have business with me? ";
	mes "I'm a little busy right now. If you don't mind, could you come back later?";
	close;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(16813) == 1";
end;
}

jor_mbase,233,277,0	script	#ep21p604	HIDDEN_WARP_NPC,5,5,{
	end;
	
OnTouch:
	if(isbegin_quest(23247) < 1) end;
	if(isbegin_quest(8893) < 2) {
		cloaknpc("Ivan#ep21p601",false,getcharid(0));
		end;
	}
	if(isbegin_quest(18360) == 2 && isbegin_quest(8914) == 0)
		cloaknpc("Ivan#ep21p604",false,getcharid(0));
end;
}

jor_mbase,233,277,5	script(CLOAKED)	Ivan#ep21p601	4_EP21_IVAN,{
	if(isbegin_quest(16815) == 0){
		cutin "ep21_ivan03.png",0;
		mes "[Ivan]";
		mes "Oh~ Everything is fine over here for now.";
		mes "I'll call you if we need anything. Thanks.";
		npctalk "Mamari : Everything is fine. Ivan just needs to finish with the calculation now.","Mamari#ep21p6",bc_self;
		close3;
	}
	if(isbegin_quest(16815) == 1){
		cutin "ep21_ivan01.png",0;
		mes "[Ivan]";
		mes "Ah, you're here, you're here!";
		mes "You arrived just in time. We are almost done preparing the meal.";
		mes "Help with the service.";
		next;
		if(select("Ask about the ghost ship...","I'm still busy.") == 2){
			cutin "ep21_ivan02.png",0;
			mes "[Ivan]";
			mes "That's a shame. We really need you now. Come back anytime. I would appreciate it.";
			close3;
		}
		cutin "ep21_ivan06.png",0;
		mes "[Ivan]";
		mes "A ghost ship! Ah, the ghost ship.";
		next;
		cutin "ep21_ivan04.png",0;
		mes "[Ivan]";
		mes "The people we rescued from the cult arrived just recently.";
		mes "We assigned them temporary lodging and provided first air to the injured.";
		mes "Now that the food is ready. We need to feed them.";
		next;
		cloaknpc("Lehar#ep21p600",false,getcharid(0));
		cutin "ep19_lehar02.png",2;
		mes "[Lehar]";
		mes "Ivan, the food is ready!";
		next;
		cutin "ep21_ivan01.png",0;
		mes "[Ivan]";
		mes "Lehar! Your friend, " + strcharinfo(0) + " is here.";
		mes "Take " + (Sex ? "him" : "her") + " to wash hands and help with the meal service.";
		next;
		cutin "ep19_lehar02.png",2;
		mes "[Lehar]";
		mes "Okay!";
		mes "Come, Let's go over there. Let's wash our hands...";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "And let's get to work.";
		cloaknpc("Lehar#ep21p600",true,getcharid(0));
		completequest 16815;
		setquest 8882;
		questinfo_refresh;
		close3;
	}
	if(isbegin_quest(8882) == 1){
		cutin "ep21_ivan03.png",0;
		mes "[Ivan]";
		mes "For now, I'd like you to assist <NAVI>[Lehar]<INFO>jor_mbase,214,316,0,101,0</INFO></NAVI> with the meal service.";
		close3;
	}
	if(isbegin_quest(8886) == 1){
		cutin "ep21_ivan03.png",0;
		mes "[Ivan]";
		mes "Lyriq is over <NAVI>[there]<INFO>jor_mbase,185,311,0,101,0</INFO></NAVI>.";
		close3;
	}
	if(isbegin_quest(8889) == 1){
		cloaknpc("Lehar#ep21p601",true,getcharid(0));
		cloaknpc("Lehar#ep21p603",true,getcharid(0));
		cloaknpc("Lehar#ep21p600",false,getcharid(0));
		cutin "ep21_ivan01.png",0;
		mes "[Ivan]";
		mes "Oh, you're here, you're here!";
		mes "Perfect timing.";
		next;
		select("Are we preparing for the next meal?");
		cutin "ep21_ivan03.png",0;
		mes "[Ivan]";
		mes "Ah~ I wish that were the case, but it's not.";
		cutin "ep21_ivan02.png",0;
		mes "While you were talking with little Lyriq, we had some discussions of our own.";
		next;
		cutin "ep21_ivan05.png",0;
		mes "[Ivan]";
		mes "We shared the results of the counseling with the others who returned with you and held a meeting.";
		mes "Besides the ghost ship sightings, there are an increase in numbers of people wanting to escape the cult, and the fact that the cult is also struggling to procure supplies.";
		npctalk "Ivan : Lehar, were you there during the counseling?","Ivan#ep21p601",bc_self;
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "Then, captain Walter suggested... why not go to and rescue the escapees directly to get information about the sea.";
		mes "Of course, the captain herself is not going.";
		mes "Probably.";
		next;
		mes "[Ivan]";
		mes "But that's not what's important right now...";
		next;
		cutin "ep21_ivan01.png",0;
		mes "[Ivan]";
		mes "For this operation...";
		mes "I want to be part of it.";
		next;
		cutin "ep21_ivan05.png",0;
		mes "[Ivan]";
		mes "I mean... I could just keep overseeing the supplies and support like what I've been doing up until now.";
		next;
		mes "[Ivan]";
		mes "But listening to you and Lyriq made me think.";
		next;
		cutin "ep19_lehar06.png",2;
		mes "[Lehar]";
		mes "Oh!";
		mes "I said something embarrassing!";
		next;
		cutin "ep21_ivan01.png",0;
		mes "[Ivan]";
		mes "No. It was great.";
		next;
		mes "[Ivan]";
		mes "Hearing you talk...";
		mes "Since I'm out here already, I figured I should do something more meaningful... than just provide supplies and support, something I'm really good at.";
		next;
		select("Not everyone can do your job");
		cutin "ep21_ivan03.png",0;
		mes "[Ivan]";
		mes "I know what you mean.";
		mes "But...";
		mes "I want to do something that doesn't concern profit.";
		next;
		cutin "ep21_ivan04.png",0;
		mes "[Ivan]";
		mes "I want to show what I'm capable of with a weapon.";
		cutin "ep21_ivan05.png",0;
		cutin "ep21_ivan06.png",0;
		mes "Sigh, doing this is pointless.";
		next;
		cutin "ep21_ivan05.png",0;
		mes "[Ivan]";
		mes "I need to ask you something, " + strcharinfo(0) + ".";
		mes "I know you just got back, but could you head to Alberta on the next ship?";
		mes "I need you to deliver a package to my sister.";
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "Lalaila Wigner of the Wigner Guild.";
		completequest 8889;
		setquest 8890;
		close3;
	}
	if(isbegin_quest(8890) == 1){
		cloaknpc("Lehar#ep21p601",true,getcharid(0));
		cloaknpc("Lehar#ep21p603",true,getcharid(0));
		cloaknpc("Lehar#ep21p600",false,getcharid(0));
		cutin "ep21_ivan01.png",0;
		mes "[Ivan]";
		mes "Please deliver the package to my sister.";
		mes "Lehar? Lehar is eating. You'll have to go alone.";
		mes "Ahaha.";
		npctalk "Lehar : Well... nothing I can do about that. Supplies is also important.","Lehar#ep21p601",bc_self;
		close3;
	}
	if(isbegin_quest(8892) == 1){
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "...";
		mes "Did you come back?";
		next;
		cutin "ep21_ivan05.png",0;
		mes "[Ivan]";
		mes "Honestly, I'm not sure if I made the right decision.";
		mes "But I've placed my bet on you taking this to my sister and returning.";
		next;
		cutin "ep21_ivan04.png",0;
		mes "[Ivan]";
		mes "...";
		next;
		cutin "ep21_ivan03.png",0;
		mes "[Ivan]";
		mes "We're going to attempt to infiltrate through the <NAVI>[north of Raised Land]<INFO>jor_raise1,323,71,0,101,0</INFO></NAVI>.";
		mes "It'll be dangerous if we move in group, so let's meet up on the site.";
		mes "I'll see you there.";
		completequest 8892;
		setquest 8893;
		getitem "Ep21_Wigner_Ticket",40;
		getexp 547793770,239980220;
		add_reputation_points(13,40);
		close3;
	}
	if(isbegin_quest(8893) == 1){
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "Let's head out, if you're ready.";
		mes "We're going to attempt to infiltrate through the <NAVI>[north of Raised Land]<INFO>jor_raise1,323,71,0,101,0</INFO></NAVI>.";
		mes "It'll be dangerous if we move in group, so let's meet up on the site.";
		mes "I'll see you there.";
		close3;
	}
	if(isbegin_quest(18360) < 2) {
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "I wish everyone return safely.";
		close3;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(16815) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(8889) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(8892) == 1";
end;
}

jor_mbase,236,279,4	script(CLOAKED)	Lehar#ep21p600	4_EP19_LEHAR,{
	if(isbegin_quest(8889) == 1){
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "I'm sure your presence was a great comfort to Lyriq.";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "Did I do something?";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "A kind word from a stranger can do wonders for a child.";
		mes "Anyway... let's finish our conversation with Ivan.";
		close3;
	}
	if(isbegin_quest(8890) == 1){
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Supplies and support is important too.";
		mes "While you're off to Alberta, leave things here to me.";
		close3;
	}
	end;
}

jor_mbase,233,277,5	script(CLOAKED)	Ivan#ep21p604	4_EP21_IVAN,{
	if(isbegin_quest(18360) == 2 && isbegin_quest(8914) == 0){
		cloaknpc("Nillem#ep21p601",false,getcharid(0));
		cloaknpc("Lehar#ep21p604",false,getcharid(0));
		setquest 8914;
		cutin "ep21_ivan03.png",0;
		mes "[Ivan]";
		mes "Oh, you're just in time, " + strcharinfo(0) + ".";
		mes "We've been looking for you for a while.";
		next;
		cutin "ep21_ivan04.png",0;
		mes "[Ivan]";
		mes "I want you to give something to my sister before the final battle.";
		mes "I've been waiting for you ever since you went to Alberta...";
		next;
		select("Is it urgent?");
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "Yes. Not only that, you're the only one I can entrust this to.";
		mes "I'll leave this to you. Then, I have to to take care of something else... Sorry!";
		cloaknpc("Ivan#ep21p604",true,getcharid(0));
		next;
		cutin "ep172_nillem02.png",1;
		mes "[Nillem]";
		mes "......";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Hm...";
		mes "With Lasgand yet to be defeated, is there something new we can do on this timeline?";
		next;
		cutin "ep172_nillem01.png",1;
		mes "[Nillem]";
		mes "Hmm...";
		mes "We've confirmed that what we do in the past affects the future, right?";
		next;
		mes "[Nillem]";
		mes "Is there anything else that we can confirm here in the past?";
		mes "That letter, Isn't that something that wouldn't have existed if we weren't here?";
		next;
		cutin "ep172_nillem03.png",1;
		mes "[Nillem]";
		mes "Why don't we think about it too hard?";
		mes "I don't think we can change the future anymore than before.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "I agree.";
		mes "If this is one of those repeating day...";
		mes "I'll just do what my ancestor would want to do.";
		next;
		mes "[Lehar]";
		mes "Even if doesn't mean anything in history...";
		next;
		select("It means something to us");
		cutin "ep19_lehar02.png",2;
		mes "[Lehar]";
		mes "...That's good to hear.";
		next;
		cutin "ep172_nillem03.png",1;
		mes "[Nillem]";
		mes "Okay☆";
		mes "Let's go right away~!";
		cloaknpc("Nillem#ep21p601",true,getcharid(0));
		cloaknpc("Lehar#ep21p604",true,getcharid(0));
		close3;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18360) == 2 && isbegin_quest(8914) == 0";
end;
}

jor_mbase,236,279,4	duplicate(dummynpc)	Lehar#ep21p604	4_EP19_LEHAR
jor_mbase,234,280,3	duplicate(dummynpc)	Nillem#ep21p601	4_M_NILLEM

jor_mbase,214,316,0	script	#ep21p603	HIDDEN_WARP_NPC,7,7,{
	end;
	
OnTouch:
	if(isbegin_quest(8882) == 1 || isbegin_quest(8883) == 1 || isbegin_quest(8885) == 1 || isbegin_quest(8886) == 1){
		cloaknpc("Lehar#ep21p601",false,getcharid(0));
		cloaknpc("Mamara#ep21p6",false,getcharid(0));
		cloaknpc("Guwal#ep21p6",false,getcharid(0));
		if(isbegin_quest(8886) == 1)
			cloaknpc("Lehar#ep21p602",true,getcharid(0));
		end;
	}
	if(isbegin_quest(8884) == 1){
		cloaknpc("Lehar#ep21p601",false,getcharid(0));
		cloaknpc("Ivan#ep21p602",false,getcharid(0));
	}
end;
}

jor_mbase,214,316,3	script(CLOAKED)	Lehar#ep21p601	4_EP19_LEHAR,{
	if(isbegin_quest(8882) == 1){
		cutin "ep19_lehar02.png",2;
		mes "[Lehar]";
		mes "Wash your hands while you listen.";
		mes "I think I might have a talent for cooking rice in that big cauldron.";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "What are you talking about?";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "I don't really know either.";
		mes "When you and Nillem went off to work, I thought I'd be handling supplies, treating patients, or doing counseling here.";
		mes "That's more in line with my original mission...";
		next;
		cutin "ep19_lehar02.png",2;
		mes "[Lehar]";
		mes "But somehow, I ended up in charge of adding water to the cauldron...";
		mes "And the rice turned out perfectly.";
		next;
		mes "[Lehar]";
		mes "Since that moment, I've been in charge of cooking rice... I don't know how it works. Somehow when it comes to water, I have a sense for it...! Even now. Just like this...";
		mes "Look!";
		next;
		cutin "",255;
		cloaknpc("Believer#ep21p601",false,getcharid(0));
		cloaknpc("Believer#ep21p602",false,getcharid(0));
		cloaknpc("Believer#ep21p603",false,getcharid(0));
		cloaknpc("Believer#ep21p604",false,getcharid(0));
		cloaknpc("Mamari#no2",false,getcharid(0));
		cloaknpc("Mamari#ep21p6",true,getcharid(0));
		mes "Two people dressed in Wigner's uniform followed Lehar's instruction and lifted the cauldron lid, a thick steam started to spread out, covering everything around...";
		next;
		cloaknpc("Believer#ep21p605",false,getcharid(0));
		cloaknpc("Believer#ep21p606",false,getcharid(0));
		cloaknpc("Believer#ep21p607",false,getcharid(0));
		cloaknpc("Believer#ep21p608",false,getcharid(0));
		cloaknpc("Believer#ep21p609",false,getcharid(0));
		mes "When the steam cleared, Lehar could be seen cheerfully stirring the perfectly cooked shiny rice with a large wooden laddle.";
		next;
		mes "He looks very satisfied.";
		next;
		cloaknpc("Believer#ep21p610",false,getcharid(0));
		cloaknpc("Believer#ep21p611",false,getcharid(0));
		cloaknpc("Believer#ep21p612",false,getcharid(0));
		cloaknpc("Believer#ep21p613",false,getcharid(0));
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Just a little more... Let's let it steam for a bit longer.";
		mes "...It's done! Let's get started.";
		next;
		select("What should I do?");
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Help me serve the warp soup with the folks from the Wigner.";
		mes "Be careful, it's hot. Oh, make sure to tell the people coming by to be careful too. Nicely.";
		next;
		select("Leave it to me.");
		cutin "ep19_lehar02.png",2;
		mes "[Lehar]";
		mes "Aren't you reassuring?";
		mes "Then, I'm counting on you.";
		completequest 8882;
		setquest 8883;
		close3;
	}
	if(isbegin_quest(8883) == 1){
		cloaknpc("Mamari#no2",false,getcharid(0));
		cloaknpc("Believer#ep21p601",false,getcharid(0));
		cloaknpc("Believer#ep21p602",false,getcharid(0));
		cloaknpc("Believer#ep21p603",false,getcharid(0));
		cloaknpc("Believer#ep21p604",false,getcharid(0));
		cloaknpc("Believer#ep21p605",false,getcharid(0));
		cloaknpc("Believer#ep21p606",false,getcharid(0));
		cloaknpc("Believer#ep21p607",false,getcharid(0));
		cloaknpc("Believer#ep21p608",false,getcharid(0));
		cloaknpc("Believer#ep21p609",false,getcharid(0));
		cloaknpc("Believer#ep21p610",false,getcharid(0));
		cloaknpc("Believer#ep21p611",false,getcharid(0));
		cloaknpc("Believer#ep21p612",false,getcharid(0));
		cloaknpc("Believer#ep21p613",false,getcharid(0));
		cutin "ep19_lehar02.png",2;
		mes "[Lehar]";
		mes "Everyone, enjoy your meal~";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "Be careful, it's hot~";
		next;
		cloaknpc("Believer#ep21p601",true,getcharid(0));
		cloaknpc("Believer#ep21p602",true,getcharid(0));
		cloaknpc("Believer#ep21p603",true,getcharid(0));
		cloaknpc("Believer#ep21p604",true,getcharid(0));
		cloaknpc("Believer#ep21p605",true,getcharid(0));
		cloaknpc("Believer#ep21p606",true,getcharid(0));
		cloaknpc("Believer#ep21p607",true,getcharid(0));
		cloaknpc("Believer#ep21p608",true,getcharid(0));
		cloaknpc("Believer#ep21p609",true,getcharid(0));
		cloaknpc("Believer#ep21p610",true,getcharid(0));
		cloaknpc("Believer#ep21p611",true,getcharid(0));
		cloaknpc("Believer#ep21p612",true,getcharid(0));
		cloaknpc("Believer#ep21p613",true,getcharid(0));
		cloaknpc("Believer#ep21p614",false,getcharid(0));
		cloaknpc("Believer#ep21p615",false,getcharid(0));
		cloaknpc("Believer#ep21p616",false,getcharid(0));
		cloaknpc("Believer#ep21p617",false,getcharid(0));
		cloaknpc("Believer#ep21p618",false,getcharid(0));
		cloaknpc("Believer#ep21p619",false,getcharid(0));
		cloaknpc("Believer#ep21p620",false,getcharid(0));
		cloaknpc("Believer#ep21p621",false,getcharid(0));
		cutin "ep21_worker_m_01.png",2;
		mes "[Rescued Cult Member]";
		mes "May I have a little bit more rice?";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "The portions are set, it's important that everyone gets a meal.";
		mes "If there's anything left after the distribution, I'll make sure to give you more.";
		next;
		cutin "",255;
		mes "...";
		next;
		mes "...";
		mes "...";
		next;
		cloaknpc("Believer#ep21p614",true,getcharid(0));
		cloaknpc("Believer#ep21p615",true,getcharid(0));
		cloaknpc("Believer#ep21p616",true,getcharid(0));
		cloaknpc("Believer#ep21p617",true,getcharid(0));
		cloaknpc("Believer#ep21p618",true,getcharid(0));
		cloaknpc("Believer#ep21p619",true,getcharid(0));
		cloaknpc("Believer#ep21p620",true,getcharid(0));
		cloaknpc("Believer#ep21p621",true,getcharid(0));
		cloaknpc("Believer#ep21p622",false,getcharid(0));
		cloaknpc("Believer#ep21p623",false,getcharid(0));
		cloaknpc("Believer#ep21p624",false,getcharid(0));
		cloaknpc("Believer#ep21p625",false,getcharid(0));
		cloaknpc("Believer#ep21p626",false,getcharid(0));
		cloaknpc("Believer#ep21p627",false,getcharid(0));
		cloaknpc("Believer#ep21p628",false,getcharid(0));
		cloaknpc("Believer#ep21p629",false,getcharid(0));
		cloaknpc("Believer#ep21p630",false,getcharid(0));
		cloaknpc("Believer#ep21p631",false,getcharid(0));
		cutin "ep21_worker_f_07.png",2;
		mes "[Rescued Cult Member]";
		mes "Young folks, you're quite a hard worker.";
		mes "Thank you, thank you.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "You've been through a lot. For now, enjoy some warm food and rest.";
		next;
		cutin "",255;
		mes "...";
		next;
		mes "...";
		mes "...";
		next;
		cloaknpc("Believer#ep21p622",true,getcharid(0));
		cloaknpc("Believer#ep21p623",true,getcharid(0));
		cloaknpc("Believer#ep21p624",true,getcharid(0));
		cloaknpc("Believer#ep21p625",true,getcharid(0));
		cloaknpc("Believer#ep21p626",true,getcharid(0));
		cloaknpc("Believer#ep21p627",true,getcharid(0));
		cloaknpc("Believer#ep21p628",true,getcharid(0));
		cloaknpc("Believer#ep21p629",true,getcharid(0));
		cloaknpc("Believer#ep21p630",true,getcharid(0));
		cloaknpc("Believer#ep21p631",true,getcharid(0));
		cloaknpc("Believer#ep21p632",false,getcharid(0));
		cloaknpc("Believer#ep21p633",false,getcharid(0));
		cloaknpc("Believer#ep21p634",false,getcharid(0));
		cloaknpc("Believer#ep21p635",false,getcharid(0));
		cloaknpc("Believer#ep21p636",false,getcharid(0));
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "How many people are left?";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "One, two... five people.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Hm... It seems like someone had a little short earlier, but there's nothing we can do about it.";
		mes "Guwal, Mamara, Mamari. Let's have our meal...";
		next;
		cloaknpc("Ivan#ep21p601",true,getcharid(0));
		cloaknpc("Ivan#ep21p602",false,getcharid(0));
		cutin "ep21_ivan01.png",0;
		mes "[Ivan]";
		mes "Wow, just look at it shining. It's really different from what Guwal makes...";
		mes "Lehar, I'm so glad you came. Just look at the faces of the people here. They look so much better compared from when we rescued them. Can rice alone do that?";
		next;
		cutin "",255;
		mes "[Guwal]";
		mes "You're right, Ivan. I used to think rice is just something you cook...";
		mes "But after eating Lehar's rice these past few days, I don't feel as homesick anymore.";
		cloaknpc("Believer#ep21p632",true,getcharid(0));
		cloaknpc("Believer#ep21p633",true,getcharid(0));
		cloaknpc("Believer#ep21p634",true,getcharid(0));
		cloaknpc("Believer#ep21p635",true,getcharid(0));
		cloaknpc("Believer#ep21p636",true,getcharid(0));
		cloaknpc("Believer#ep21p637",false,getcharid(0));
		cloaknpc("Believer#ep21p638",false,getcharid(0));
		npctalk "Lehar : Okay, here you go.","Lehar#ep21p601",bc_self;
		next;
		cutin "ep21_ivan06.png",0;
		mes "[Ivan]";
		mes "Sorry for dragging you out here, Guwal. Mamara, Mamari.";
		mes "One day I promise, I'll make sure you can just relax and enjoy yourselves.";
		cloaknpc("Believer#ep21p637",true,getcharid(0));
		cloaknpc("Believer#ep21p638",true,getcharid(0));
		cloaknpc("Believer#ep21p639",false,getcharid(0));
		pctalk "Be careful, it's hot.";
		next;
		cutin "",255;
		mes "[Mamari]";
		mes "Honestly, I'm glad just seeing you lazing around, Ivan.";
		mes "I never understood what the leader saw in you to allow you to do this, but now I think I get it.";
		cloaknpc("Believer#ep21p639",true,getcharid(0));
		npctalk "Lehar : Everyone, please wash your trays after meal and keep them with you!","Lehar#ep21p601",bc_self;
		next;
		cutin "ep21_ivan05.png",0;
		mes "[Ivan]";
		mes "Well well... was that a compliment, or an insult?";
		completequest 8883;
		setquest 8884;
		close3;
	}
	if(isbegin_quest(8884) == 1){
	OnEvent:
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Then, let's have our meal now...";
		next;
		cutin "ep21_ivan03.png",0;
		mes "[Ivan]";
		mes "Yeah. Let's move over there for a bit?";
		mes "Guwal.";
		next;
		cutin "",255;
		mes "[Guwal]";
		mes "We'll be fine eating here, so go ahead.";
		next;
		cutin "ep21_ivan03.png",0;
		mes "[Ivan]";
		mes "Lehar, " + strcharinfo(0) + ". Grab your tray, and let's meet over there.";
		completequest 8884;
		setquest 8885;
		cloaknpc("Ivan#ep21p602",true,getcharid(0));
		cloaknpc("Ivan#ep21p603",false,getcharid(0));
		close3;	
	}
	if(isbegin_quest(8885) == 1){
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Ivan is currently laicized, so he's not directly involved in missionary work...";
		next;
		mes "[Lehar]";
		mes "I'm not sure why he left the order, Guwal told me that he lived a self-indulgent life.";
		mes "Then one day, he suddenly asked his sister, the guild leader, for a huge amount of money saying he was going to Lunaforma.";
		next;
		mes "[Lehar]";
		mes "They thought he was going to waste it again, but he said he was going to set up a soup kitchen and start gathering supplies.";
		next;
		cutin "ep19_lehar02.png",2;
		mes "[Lehar]";
		mes "It seems that... he decided to give up that kind of lifestyle.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "All the people who were rescued had a counseling with Ivan.";
		mes "Given my job, I sat in one of the counseling thinking what I learned might be useful.";
		mes "Fortunately, it turned out to be more helpful than expected.";
		next;
		mes "[Lehar]";
		mes "But there's something quite a few of them mentioned...";
		next;
		mes "[Lehar]";
		mes "They said they saw a ghost ship.";
		completequest 8885;
		setquest 8886;
		close3;
	}
	if(isbegin_quest(8886) == 1){
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Shall we have a meal with Ivan?";
		cloaknpc("Lehar#ep21p601",true,getcharid(0));
		cloaknpc("Lehar#ep21p602",false,getcharid(0));
		close3;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(8882) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(8883) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(8884) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(8885) == 1";
end;
}

jor_mbase,212,311,5	script(CLOAKED)	Ivan#ep21p602	4_EP21_IVAN,{
	if(isbegin_quest(8884) == 1){
		doevent "Lehar#ep21p601::OnEvent";
		end;
	}
	end;
}

jor_mbase,218,317,5	script(CLOAKED)	Mamara#ep21p6	4_M_HUMAN_02,{
	mes "[Mamara]";
	mes "You don't look like it, but you handle physical tasks quite well. That's a relief.";
	close;
}

jor_mbase,211,315,4	script(CLOAKED)	Guwal#ep21p6	4_M_HUMAN_02,{
	cutin "",255;
	mes "[Guwal]";
	mes "We are members of the Wigner Guild.";
	mes "Ivan insisted that it would be difficult to manage people who are mentally exhausted with just random volunteers, so we came along.";
	next;
	mes "[Guwal]";
	mes "You see those folks wearing the same uniform around us?";
	mes "They're all emergency relief experts.";
	next;
	mes "[Guwal]";
	mes "Ah~... Normally we'd wear something more practical to work...";
	mes "But we decided to wear the same uniform making us easy to spot.";
	mes "It's hard for others to recognize who we are, but if something happens, people can find us quickly.";
	next;
	mes "[Guwal]";
	mes "Why does the guild have emergency relief experts?";
	mes "When you have bases, outposts, and warehouses in many places, you inevitably get involved in staffing operations.";
	mes "Sometimes, unexpected natural disasters, famines, and droughts hits where we have business connections,...";
	next;
	mes "[Guwal]";
	mes "It takes some time for the leaders to handle those things.";
	mes "And sometimes there's just no money to work with...";
	mes "But if things stay like that, we would lose business too, that's why we help out on the side.";
	next;
	mes "[" + strcharinfo(0) + "]";
	mes "That's actually smart.";
	next;
	mes "[Guwal]";
	mes "Yeah, but it's not profitable at all!";
	mes "As Ivan would say. Hahaha...";
	next;
	mes "[Guwal]";
	mes "This is the first time we've come out this far!";
	mes "Thanks to this, everyone's gaining a lot of experience.";
	mes "Mamara was thrilled, saying he could write the whole operation as a guide manual.";
	next;
	mes "[Guwal]";
	mes "Ah~...";
	mes "The guild leader...";
	close;
}

jor_mbase,216,317,1	script(CLOAKED)	Mamari#no2	4_M_HUMAN_02,{
	npctalk "Mamari : Alright, let's finish this quickly and get back to work.","Mamari#no2",bc_self;
	end;
}

jor_mbase,213,314,1	duplicate(dummynpc)	Believer#ep21p601	4_EP21_WORKER_KID_A
jor_mbase,213,313,1	duplicate(dummynpc)	Believer#ep21p602	4_EP21_WORKER_KID_A
jor_mbase,213,312,7	duplicate(dummynpc)	Believer#ep21p603	4_EP21_M_WORKER_A
jor_mbase,215,310,7	duplicate(dummynpc)	Believer#ep21p604	4_EP21_M_WORKER_B
jor_mbase,216,309,7	duplicate(dummynpc)	Believer#ep21p605	4_EP21_F_WORKER_A
jor_mbase,217,309,1	duplicate(dummynpc)	Believer#ep21p606	4_EP21_M_WORKER_A
jor_mbase,219,308,1	duplicate(dummynpc)	Believer#ep21p607	4_EP21_M_WORKER_B
jor_mbase,220,308,1	duplicate(dummynpc)	Believer#ep21p608	4_EP21_F_WORKER_A
jor_mbase,221,308,5	duplicate(dummynpc)	Believer#ep21p609	4_EP21_F_WORKER_B
jor_mbase,223,308,1	duplicate(dummynpc)	Believer#ep21p610	4_EP21_M_WORKER_B
jor_mbase,225,310,1	duplicate(dummynpc)	Believer#ep21p611	4_EP21_WORKER_KID_A
jor_mbase,226,310,7	duplicate(dummynpc)	Believer#ep21p612	4_EP21_WORKER_KID_B
jor_mbase,227,310,1	duplicate(dummynpc)	Believer#ep21p613	4_EP21_WORKER_KID_A
jor_mbase,213,314,1	duplicate(dummynpc)	Believer#ep21p614	4_EP21_M_WORKER_A
jor_mbase,213,313,7	duplicate(dummynpc)	Believer#ep21p615	4_EP21_WORKER_KID_A
jor_mbase,213,312,7	duplicate(dummynpc)	Believer#ep21p616	4_EP21_WORKER_KID_A
jor_mbase,215,310,1	duplicate(dummynpc)	Believer#ep21p617	4_EP21_F_WORKER_A
jor_mbase,216,309,4	duplicate(dummynpc)	Believer#ep21p618	4_EP21_M_WORKER_A
jor_mbase,217,309,1	duplicate(dummynpc)	Believer#ep21p619	4_EP21_M_WORKER_B
jor_mbase,219,308,7	duplicate(dummynpc)	Believer#ep21p620	4_EP21_M_WORKER_A
jor_mbase,220,308,1	duplicate(dummynpc)	Believer#ep21p621	4_EP21_F_WORKER_B
jor_mbase,213,314,1	duplicate(dummynpc)	Believer#ep21p622	4_EP21_F_WORKER_B
jor_mbase,213,313,1	duplicate(dummynpc)	Believer#ep21p623	4_EP21_F_WORKER_B
jor_mbase,213,312,1	duplicate(dummynpc)	Believer#ep21p624	4_EP21_M_WORKER_B
jor_mbase,215,310,1	duplicate(dummynpc)	Believer#ep21p625	4_EP21_M_WORKER_B
jor_mbase,216,309,7	duplicate(dummynpc)	Believer#ep21p626	4_EP21_F_WORKER_A
jor_mbase,217,309,1	duplicate(dummynpc)	Believer#ep21p627	4_EP21_M_WORKER_A
jor_mbase,219,308,7	duplicate(dummynpc)	Believer#ep21p628	4_EP21_M_WORKER_A
jor_mbase,220,308,1	duplicate(dummynpc)	Believer#ep21p629	4_EP21_F_WORKER_B
jor_mbase,221,308,1	duplicate(dummynpc)	Believer#ep21p630	4_EP21_M_WORKER_A
jor_mbase,223,308,1	duplicate(dummynpc)	Believer#ep21p631	4_EP21_M_WORKER_B
jor_mbase,213,314,1	duplicate(dummynpc)	Believer#ep21p632	4_EP21_M_WORKER_A
jor_mbase,213,313,1	duplicate(dummynpc)	Believer#ep21p633	4_EP21_M_WORKER_A
jor_mbase,213,312,7	duplicate(dummynpc)	Believer#ep21p634	4_EP21_F_WORKER_B
jor_mbase,215,310,7	duplicate(dummynpc)	Believer#ep21p635	4_EP21_M_WORKER_A
jor_mbase,216,309,7	duplicate(dummynpc)	Believer#ep21p636	4_EP21_M_WORKER_B
jor_mbase,213,314,1	duplicate(dummynpc)	Believer#ep21p637	4_EP21_M_WORKER_A
jor_mbase,213,313,1	duplicate(dummynpc)	Believer#ep21p638	4_EP21_M_WORKER_B
jor_mbase,213,314,1	duplicate(dummynpc)	Believer#ep21p639	4_EP21_M_WORKER_B

jor_mbase,194,279,0	script	#21ms60	HIDDEN_WARP_NPC,5,5,{
	end;
	
OnTouch:
	if(isbegin_quest(8886) == 1){
		cloaknpc("Ivan#ep21p601",true,getcharid(0));
		cloaknpc("Ivan#ep21p602",true,getcharid(0));
		cloaknpc("Ivan#ep21p603",false,getcharid(0));
		cloaknpc("Lehar#ep21p602",true,getcharid(0));
		cloaknpc("Lehar#ep21p602",false,getcharid(0));
		end;
	}
	if(isbegin_quest(17773) == 1){
		cloaknpc("Tris#21ms60",false,getcharid(0));
		cloaknpc("Reinhardt#21ms60",false,getcharid(0));
		cloaknpc("Wilhelm#21ms60",false,getcharid(0));
		cloaknpc("Believer#21ms60",false,getcharid(0));
		cloaknpc("Believer#21ms61",false,getcharid(0));
		end;
	}
	if(isbegin_quest(17774) == 1){
		cloaknpc("Tris#21ms60",false,getcharid(0));
		cloaknpc("Reinhardt#21ms60",false,getcharid(0));
		cloaknpc("Wilhelm#21ms60",false,getcharid(0));
		cloaknpc("Believer#21ms62",false,getcharid(0));
		cloaknpc("Believer#21ms63",false,getcharid(0));
		cloaknpc("Believer#21ms65",false,getcharid(0));
		cloaknpc("Believer#21ms66",false,getcharid(0));
		cloaknpc("Believer#21ms67",false,getcharid(0));
		end;
	}
	if(isbegin_quest(17775) == 1){
		cloaknpc("Tris#21ms60",false,getcharid(0));
		cloaknpc("Reinhardt#21ms60",false,getcharid(0));
		cloaknpc("Wilhelm#21ms61",false,getcharid(0));
		cloaknpc("Believer#21ms64",false,getcharid(0));
		cloaknpc("Believer#21ms68",false,getcharid(0));
		cloaknpc("Believer#21ms69",false,getcharid(0));
		end;
	}
	if(isbegin_quest(17776) == 1){
		cloaknpc("Tris#21ms60",false,getcharid(0));
		cloaknpc("Reinhardt#21ms60",false,getcharid(0));
		cloaknpc("Wilhelm#21ms61",false,getcharid(0));
		end;
	}
end;
}

jor_mbase,189,282,5	script(CLOAKED)	Ivan#ep21p603	4_EP21_IVAN,{
	if(isbegin_quest(8886) == 1){
		mes "[Ivan]";
		mes "Oh, Lehar, " + strcharinfo(0) + ". Should we begin?";
		mes "Let's talk while we eat.";
		mes "You are asking about the ghost ship earlier, right?";
		next;
		cutin "ep21_ivan01.png",0;
		mes "[Ivan]";
		mes "Is that the kind of thing we should be discussing over a meal?";
		mes "What do you think?";
		next;
		if(select("I don't mind.","Well I am quite busy.") == 2)
		cutin "ep21_ivan03.png",0;
		mes "[Ivan]";
		mes "Sorry. We're always pressed for time.";
		mes "By the way... Did I introduced myself to you?";
		next;
		cutin "ep21_ivan04.png",0;
		mes "[Ivan]";
		mes "I'm Ivan Wigner, head of the investment department of the Wigner Merchants. Nice to meet you.";
		next;
		cutin "",255;
		mes "As Ivan extended his hands, you shook it reflexively. He firmly grasped your hand and gave it a couple of shakes.";
		next;
		cutin "ep21_ivan03.png",0;
		mes "[Ivan]";
		mes "By the way... " + strcharinfo(0) + ".";
		mes "I noticed you did well with the meal service earlier. Have you done this kind of work before?";
		mes "How about working under me for a while?";
		mes "Of course, you'll be compensated. Guwal will take care of it.";
		next;
		select("The story is more important now...");
		cutin "ep21_ivan06.png",0;
		mes "[Ivan]";
		mes "Oh, right!";
		mes "Sorry. I tend to get sidetracked.";
		mes "So, about the ghost ship.";
		next;
		cutin "ep21_ivan03.png",0;
		mes "[Ivan]";
		mes "This time, our friend here was a big help. As I renounced my vows, there's only so much a former priest can do in counseling the people who left the cult.";
		npctalk "Ivan : Wow, the soup tastes good today. What did you put in it, Lehar?","Ivan#ep21p603",bc_self;
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "I might not have run away before if there had been a few more people who could talk calmy like you...";
		npctalk "Lehar : I added the shrimp and seaweeds that Richard gave me.","Lehar#ep21p602",bc_self;
		next;
		mes "[Ivan]";
		mes "Anyway, during the counseling sessions, a few people brought up the ghost ship.";
		mes "I found it strange and made sure to record it, let' see...";
		npctalk "Ivan : I guess I need to give you a big thanks later.","Ivan#ep21p603",bc_self;
		next;
		mes "[Ivan]";
		mes "Eugene, Lyriq, Simian.";
		mes "They saw the ghost ship clearly.";
		mes "And 8 other people who saw a blurry ship, got scared, and either ran away or closed their eyes.";
		next;
		mes "[Ivan]";
		mes "Then there were 7 people who said they saw something else, like a giant whirlpool or an ice spire, instead of a ship.";
		next;
		cutin "ep21_ivan05.png",0;
		mes "[Ivan]";
		mes "Among those who have claimed to have seen it, only Lyriq used to be a sailer, he had been to the cult's ship several times before.";
		mes "He said it was strange even as he was telling the story. He couldn't identify what kind of ship it was.";
		mes "It was as if the ship cursed him to let others know about it.";
		npctalk "Ivan : The food is really delicious. I hope Lehar continues to be in charge of the meal in the future...","Ivan#ep21p603",bc_self;
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "That's why it's called the ghost ship...";
		npctalk "Lehar : The distribution part is also important. I really didn't know I had this kind of talent. I feel proud.","Lehar#ep21p602",bc_self;
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "It drove them crazy as it was attacking the cult's ships.";
		mes "Would you like to hear them from Lyriq directly?";
		mes "By the time we're done with our meal, they should be resting.";
		next;
		select("Introduce me");
		cutin "ep21_ivan01.png",0;
		mes "[Ivan]";
		mes "I thought you'd say that.";
		mes "Lehar. Thank you for preparing the food. Later, go with " + strcharinfo(0) + " to see Lyriq.";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "What about you, Ivan?";
		next;
		cutin "ep21_ivan03.png",0;
		mes "[Ivan]";
		mes "I have renounced my vows, I'm just a regular person now... I can't do missionary work.";
		mes "I will just do what I'm good at.";
		next;
		select("What is that you're good at?");
		cutin "ep21_ivan01.png",0;
		mes "[Ivan]";
		mes "Exactly what I'm doing.";
		mes "Doing things that don't result to profit.";
		next;
		cutin "ep21_ivan04.png",0;
		mes "[Ivan]";
		mes "Ahahaha. Earning zeny is my sister's job...";
		mes "My job is to spend it. It's always been that way.";
		next;
		cutin "ep21_ivan01.png",0;
		mes "[Ivan]";
		mes "So, have you finished your meal?";
		mes "Good job today. Now, I'm off to chop the rest of the firewood.";
		completequest 8886;
		setquest 8887;
		questinfo_refresh;
		cloaknpc("Ivan#ep21p603",true,getcharid(0));
		close3;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(8886) == 1";
end;
}

jor_mbase,193,282,3	script(CLOAKED)	Lehar#ep21p602	4_EP19_LEHAR,{
	if(isbegin_quest(8886) == 1){
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Hm... for a meal for emergency relief operations, this is pretty high quality.";
		close3;
	}
	if(isbegin_quest(8887) == 1){
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Let's go meet <NAVI>[Lyriq]<INFO>jor_mbase,185,311,0,101,0</INFO></NAVI>.";
		close3;
	}
	end;
}

jor_mbase,185,311,4	script	Lyriq#ep21p6	4_EP21_WORKER_KID_A,{
	if(isbegin_quest(8887) == 1){
		cloaknpc("Lehar#ep21p601",true,getcharid(0));
		cloaknpc("Lehar#ep21p602",true,getcharid(0));
		cloaknpc("Lehar#ep21p603",false,getcharid(0));
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Lyriq.";
		mes "Do you have a moment?";
		next;
		cutin "ep21_worker_kb_02.png",2;
		mes "[Lyriq]";
		mes "Oh, you scared me!";
		mes "Brother Lehar.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "This is my friend, " + strcharinfo(0) + ".";
		mes "A very strong adventurer.";
		next;
		cutin "ep21_worker_kb_01.png",2;
		mes "[Lyriq]";
		mes "Oh...";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "This is Lyriq.";
		mes "He is still young, but he is already a remarkable sailor...";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "Hello, Lyriq.";
		next;
		cutin "ep21_worker_kb_01.png",2;
		mes "[Lyriq]";
		mes "Hello, " + strcharinfo(0) + "!";
		mes "Uh, nice to meet you...";
		next;
		cutin "ep19_lehar02.png",2;
		mes "[Lehar]";
		mes "You call me brother, but you just call " + strcharinfo(0) + " by name?";
		next;
		select("Call me whatever you're comfortable with.");
		cutin "ep21_worker_kb_01.png",2;
		mes "[Lyriq]";
		mes "Okay...";
		mes "...";
		next;
		cutin "",255;
		mes "Lyriq hid behind Lehar.";
		next;
		mes "[" + strcharinfo(0) + "]";
		mes "Seems like he really likes you, Lehar.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Looks like it.";
		next;
		cutin "ep21_worker_kb_01.png",2;
		mes "[Lyriq]";
		mes "...You came to ask about something scary, didn't you?";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Lyriq, " + strcharinfo(0) + " is an awesome adventurer and you need to see it.";
		mes "You probably couldn't tell when the job is just serving soup, right?";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "Lehar's rice steaming and stirring was pretty impressive too.";
		next;
		cutin "ep19_lehar07.png",2;
		mes "[Lehar]";
		mes "Adventurer!";
		next;
		cutin "ep21_worker_kb_01.png",2;
		mes "[Lyriq]";
		mes "Ahaha.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Both " + strcharinfo(0) + " and me... are pretty capable when it comes to combat.";
		mes "Lyric, we're strong enough that you won't have to worry.";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "That's right.";
		next;
		cutin "ep21_worker_kb_01.png",2;
		mes "[Lyriq]";
		mes "...";
		next;
		mes "[Lyriq]";
		mes "I guess I could...";
		completequest 8887;
		setquest 8888;
		close3;
	}
	if(isbegin_quest(8888) == 1){
		cutin "ep21_worker_kb_01.png",2;
		mes "[Lyriq]";
		mes "...";
		mes "I saw it, the ghost ship.";
		mes "It was shrouded in fog... the fog seemed to be floating around it.";
		next;
		mes "[Lyriq]";
		mes "Before, I never get scared of ghost stories or anything like that.";
		mes "Even when me and my friends would tell scary stories or do a test of courage, I would always win.";
		next;
		mes "[Lyriq]";
		mes "I believed that I wasn't afraid of ghosts.";
		mes "But when I saw that, I was so scared that I just wanted to go home.";
		next;
		mes "[Lyriq]";
		mes "The sailor who was with me, told me to get inside quickly.";
		mes "But I was so scared... the ship was shaking, so I hold on to his legs and cried.";
		next;
		mes "[Lyriq]";
		mes "His legs were shaking too...";
		mes "The next thing I knew, we were already on the rescue ship.";
		next;
		mes "[Lyriq]";
		mes "The sailor was hurt a little but he was sleeping peacefully.";
		mes "They said he got injured while trying to protect me when I passed out...";
		next;
		mes "[Lyriq]";
		mes "...";
		mes "...";
		next;
		mes "[Lyriq]";
		mes "Next time I'm going to protect him.";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Thank you, Lyriq.";
		mes "It's almost time for rest. Have a nice rest.";
		next;
		cutin "ep21_worker_kb_01.png",2;
		mes "[Lyriq]";
		mes "Okay, brother Lehar.";
		mes "The rice was delicious. It was really good...";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Thank you.";
		next;
		mes "[Lehar]";
		mes "Adventurer.";
		mes "Shall we go talk to Ivan again?";
		completequest 8888;
		setquest 8889;
		questinfo_refresh;
		close3;
	}
	cutin "ep21_worker_kb_01.png",2;
	mes "[Lyriq]";
	mes "When... I grow up... I'm going to be like Brother Lehar.";
	mes "I won't become an adult who lies and deceives just because someone is younger.";
	close3;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(8887) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(8888) == 1";
end;
}

jor_mbase,184,307,7	script(CLOAKED)	Lehar#ep21p603	4_EP19_LEHAR,{
	if(isbegin_quest(8888) == 1){
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Go ahead and ask. I'm right here with you.";
		close3;
	}
	if(isbegin_quest(8889) == 1){
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "I'm sure your presence was a great comfort to Lyriq.";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "Did I do something?";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "A kind word from a stranger can do wonders for a child.";
		mes "Anyway... let's finish our conversation with Ivan.";
		close3;
	}
	end;
}

jalbe_in,56,138,5	script	Lalaila Wigner#ep21p60	4_EP21_LALAILA,{
	if(isbegin_quest(8890) == 0){
		mes "[Lalaila Wigner]";
		mes "Don't stand in the way of the staffs.";
		close;
	}
	if(isbegin_quest(8890) == 1){
		cutin "ep21_lalaila01.png",0;
		mes "[Lalaila Wigner]";
		mes "State your business here.";
		cutin "ep21_lalaila03.png",0;
		next;
		select("Give the package from Ivan.");
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "Ivan asked me to deliver this package.";
		next;
		cutin "ep21_lalaila01.png",0;
		mes "[Lalaila Wigner]";
		mes "Ivan... Ivan?";
		mes "What's this' about.";
		mes "Did he give you any other messages?";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "He just said, 'Take whatever my sister gives you and bring it back'...";
		next;
		cutin "ep21_lalaila03.png",0;
		mes "[Lalaila Wigner]";
		mes "Did he say what he wanted?";
		mes "He always asks for something as if he left something with me...";
		next;
		cutin "ep21_lalaila01.png",0;
		mes "[Lalaila Wigner]";
		mes "...";
		next;
		cutin "ep21_lalaila04.png",0;
		mes "[Lalaila Wigner]";
		mes "...";
		mes "... he did left something behind.";
		next;
		cutin "ep21_lalaila03.png",0;
		mes "[Lalaila Wigner]";
		mes "You, what's your name?";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "...it's " + strcharinfo(0) + ".";
		next;
		cutin "ep21_lalaila03.png",0;
		mes "[Lalaila Wigner]";
		mes "How is Ivan doing?";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "He's been taking on all the physical tasks...";
		next;
		cutin "ep21_lalaila02.png",0;
		mes "[Lalaila Wigner]";
		mes "Haha!";
		mes "When he was here, he wouldn't even listen when I told him to help out.";
		next;
		cutin "ep21_lalaila03.png",0;
		mes "[Lalaila Wigner]";
		mes "And?";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "According to Guwal, Mamara and Mamari, he is much better now.";
		next;
		cutin "ep21_lalaila02.png",0;
		mes "[Lalaila Wigner]";
		mes "Ivan probably knows that I sent them to keep an eye on him.";
		mes "It seems nothing major has happened, since I haven't received any reports from them.";
		next;
		cutin "ep21_lalaila03.png",0;
		mes "[Lalaila Wigner]";
		mes "And?";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "Well...";
		mes "He said that he wants to participate directly in the next mission.";
		next;
		cutin "ep21_lalaila04.png",0;
		mes "[Lalaila Wigner]";
		mes "...";
		next;
		cutin "ep21_lalaila01.png",0;
		mes "[Lalaila Wigner]";
		mes "...I wondered why I van would something like a package, it turns out he sent the samples of what he collected.";
		mes "It seems he doesn't plan on telling me himself now that he's come to his senses.";
		next;
		mes "[Lalaila Wigner]";
		mes "The thing he left behind...";
		mes "It's on the bookcase's bottom left shelf on the office next door.";
		mes "Take it.";
		next;
		cutin "ep21_lalaila03.png",0;
		mes "[Lalaila Wigner]";
		mes "I'll trust you to handle it.";
		completequest 8890;
		setquest 8891;
		close3;
	}
	if (isbegin_quest(8914) == 0) end;
	if ( isbegin_quest(8914) == 1 ) {
		cutin "ep21_lalaila01.png",1;
		mes "[Lalaila Wigner]";
		mes "Who?";
		mes "Oh, " + strcharinfo(0) + ".";
		next;
		cutin "ep21_lalaila03.png",1;
		mes "[Lalaila Wigner]";
		mes "Isn't the final battle today?";
		mes "What brought you here?";
		mes "Are you in need of any help?";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "Help?";
		next;
		cutin "ep21_lalaila03.png",1;
		mes "[Lalaila Wigner]";
		mes "I don't think you came here for that.";
		mes "It must be a request from someone else?";
		next;
		mes "[Lalaila Wigner]";
		mes "...Is it from Ivan?";
		next;
		cutin "ep21_lalaila02.png",1;
		mes "[Lalaila Wigner]";
		mes "What a rude person. It's not good to pass responsibility to another person.";
		mes "Tell me. What is it about?";
		next;
		if ( select("Ivan asked me to send a letter.","It's nothing like that.") == 2 ) {
			mes "[Lalaila Wigner]";
			mes "He's quite dull";
			mes "If it's a request from him, I'll be glad to do it.";
			mes "Well, there's nothing I can do about it.";
			close3;
		}
		mes "[Lalaila Wigner]";
		mes "A letter for me.";
		mes "From Ivan?";
		next;
		cutin "",255;
		mes "I handed the letter that Ivan asked me to bring her.";
		mes "...Now that I look at it, there are eyes drawn on the envelope.";
		next;
		mes "I think Lalaila Wigner sent the same letter to Captain Walter before...";
		npctalk "Lalaila Wigner : ...Huh?","Lalaila Wigner#ep21p60",bc_self;
		next;
		npctalk "Lalaila Wigner : This kid...!","Lalaila Wigner#ep21p60",bc_self;
		mes "[" + strcharinfo(0) + "]";
		mes "What happened?";
		next;
		cutin "ep21_lalaila04.png",1;
		mes "[Lalaila Wigner]";
		mes "Haha. I was just surprised...";
		mes "Hold on... It caught me off guard.";
		mes "Let's talk inside. It's not a big deal.";
		completequest 8914;
		setquest 8915;
		close2;
		warp "jalbe_in",71,177;
		cloaknpc("Lalaila Wigner#ep21p60-3", false, getcharid(0));
		end;
	}
	cutin  "ep21_lalaila02.png",1;
	mes "[Lalaila Wigner]";
	mes "I'll be waiting to hear the news of victory.";
	close3;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(8890) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(8914) == 1";
end;
}

jalbe_in,73,187,4	script	Dusty Box#ep21p601	CLEAR_NPC,{
	if(isbegin_quest(8891) == 1){
		mes "As Lalaila mentioned, there's a dusty box on the bottom shelf of the bookcase.";
		next;
		mes "Looking closely at the box's lid, there are a few fingerprints left where the dust hasn't fully wiped away.";
		mes "It seems it's being opened frequently.";
		next;
		if(select("Open the box.","Leave it.") == 2){
			mes "You're not quite ready to open it.";
			close;
		}
		mes "Inside the box is a pair of old but well-maintained knuckles.";
		next;
		mes "[" + strcharinfo(0) + "]";
		mes "Did Lalaila herself took care of these...?";
		next;
		cutin "ep21_lalaila04.png",0;
		cloaknpc("Lalaila Wigner#ep21p60-2",false,getcharid(0));
		mes "[Lalaila Wigner]";
		mes "Yes, Of course.";
		mes "Who else would I trust with something like this.";
		next;
		cutin "ep21_lalaila01.png",0;
		mes "[Lalaila Wigner]";
		mes "Given my line of work, there are times when I need to deal with such items.";
		mes "To appraise them, I also need to know how to maintain them in the best condition.";
		mes "I'm confident that I'm better at it than most adventurers.";
		next;
		cutin "ep21_lalaila04.png",0;
		mes "[Lalaila Wigner]";
		mes "Ivan must have known that, even though he told me to throw them away, I just couldn't bring myself to do it...";
		next;
		cutin "ep21_lalaila03.png",0;
		mes "[Lalaila Wigner]";
		mes "So, how do things look on your end?";
		mes "Of course, I've been receiving reports.";
		mes "Do you think we have a chance?";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "Yes.";
		next;
		cutin "ep21_lalaila02.png",0;
		mes "[Lalaila Wigner]";
		mes "Haha.";
		mes "I'll trust you.";
		next;
		mes "[Lalaila Wigner]";
		mes "Then, take this to Ivan.";
		mes "Also this...";
		next;
		cutin "",255;
		mes "Lalaila handed over an envelope.";
		next;
		cutin "ep21_lalaila01.png",0;
		mes "[Lalaila Wigner]";
		mes "This... please deliver it to captain Maristella Walter.";
		next;
		cutin "ep21_lalaila02.png",0;
		mes "[Lalaila Wigner]";
		mes "I'm busy at the moment. I can't leave the office.";
		mes "I'm counting on you.";
		next;
		cutin "ep21_lalaila04.png",0;
		mes "[Lalaila Wigner]";
		mes "Please help Ivan... and Captain Walter.";
		completequest 8891;
		setquest 8894;
		close3;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(8891) == 1";
end;
}

jalbe_in,71,189,5	duplicate(dummynpc)	Lalaila Wigner#ep21p60-2	4_EP21_LALAILA

jalbe_in,64,136,0	script	#ep21extra01	HIDDEN_WARP_NPC,1,1,{
	if ( isbegin_quest(8915) == 1 ) {
		cloaknpc("Lalaila Wigner#ep21p60-3", false, getcharid(0));
		end;
	}
	if ( isbegin_quest(8916) > 0 ) {
		cutin  "ep21_lalaila02.png",1;
		mes "[Lalaila Wigner]";
		mes "I'll be waiting to hear the news of victory.";
		close3;
	}
	end;
}

jalbe_in,71,174,1	script(CLOAKED)	Lalaila Wigner#ep21p60-3	4_EP21_LALAILA,{
	if ( isbegin_quest(8915) == 0 ) {
		cutin "ep21_lalaila04.png",1;
		mes "[Lalaila Wigner]";
		mes "Sigh...";
		next;
		cutin "",255;
		mes "Lalaila slumped onto the sofa.";
		next;
		cutin "ep21_lalaila04.png",1;
		mes "[Lalaila Wigner]";
		mes "Have you heard anything about this letter?";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "I've heard nothing. Ivan only told me that he waited for me to deliver this letter.";
		next;
		cutin "ep21_lalaila04.png",1;
		mes "[Lalaila Wigner]";
		mes "That Ivan, On the last minute, he sent me a letter asking me to join the final battle... And worst, he even sent a crucial member to deliver the message.";
		next;
		mes "[Lalaila Wigner]";
		mes "Why am I even talking like this now...";
		next;
		cutin "ep21_lalaila03.png",1;
		mes "[Lalaila Wigner]";
		mes "By the way, " + strcharinfo(0) + ". Do you know how our merchant guild grew this big?";
		next;
		switch(select("Because you're capable.","Because you're diligent.","Because Ivan is responsible for accounting.")){
			case 1:
				cutin "",255;
				mes "[" + strcharinfo(0) + "]";
				mes "...Because you're talented?";
				next;
				cutin "ep21_lalaila01.png",1;
				mes "[Lalaila Wigner]";
				mes "That's true but there's more to it...";
				break;
				
			case 2:
				cutin "",255;
				mes "[" + strcharinfo(0) + "]";
				mes "...Because you're diligent?";
				next;
				cutin "ep21_lalaila01.png",1;
				mes "[Lalaila Wigner]";
				mes "That's not wrong either, but diligence wouldn't have been enough to overcome problems.";
				break;
				
			case 3:
				cutin "",255;
				mes "[" + strcharinfo(0) + "]";
				mes "...Is it because of Ivan accounting skills...";
				next;
				cutin "ep21_lalaila01.png",1;
				mes "[Lalaila Wigner]";
				mes "I wish that were the case, but he really hates doing that...";
				mes "Even the work he is doing now, he wouldn't hesitate to stop when he is thrown into accounting work.";
				break;
		}
		next;
		cutin "ep21_lalaila04.png",1;
		mes "[Lalaila Wigner]";
		mes "I don't know much about the gods, but Ivan left when he was young to devote himself to them and knows more about them than I do.";
		next;
		mes "[Lalaila Wigner]";
		mes "Everyone is born with something unique, and he told me that mine is the fortune to overcome any kind of adversity.";
		mes "Since then, Ivan and I started drawing Nazar's Eye on our letters which is said to bring good luck.";
		next;
		mes "[Lalaila Wigner]";
		mes "As you know, dealing with numbers, no matter how talented or diligent you are, you will inevitably involve human interaction.";
		next;
		mes "[Lalaila Wigner]";
		mes "You see... I got into this work fully prepared for those moments and most of my choices were correct.";
		mes "There were times I suffered financial losses. But in the end I was able to correct those mistakes and chose the correct people to bring with me. In turn, those people helped me with my next steps.";
		next;
		mes "[Lalaila Wigner]";
		mes "At first, I thought Ivan's word meant that I was just lucky enough to run the guild without any kind of problems.";
		mes "But when he left the monastery. And started a charity and asked me for investment, I realized something.";
		next;
		cutin "ep21_lalaila03.png",1;
		mes "[Lalaila Wigner]";
		mes "I already had enough wealth, connections, and resources to readily approve his requests.";
		mes "And this case, will also expand my circle of connections.";
		next;
		mes "[Lalaila Wigner]";
		mes "And that it would also prevent further adversity.";
		mes "This guild wasn't built by me alone, I have a lot of gratitude to repay.";
		next;
		cutin "",255;
		mes "Lalaila gave out a huge sigh and smiled.";
		next;
		cutin "ep21_lalaila02.png",1;
		mes "[Lalaila Wigner]";
		mes "Tris always thank me for my cold, relentless advice whenever we meet, but I only could give those advice because Tris and everyone else stood by my side.";
		next;
		cutin "ep21_lalaila04.png",1;
		mes "[Lalaila Wigner]";
		mes "...Haha, I was surprised, I thought something might have happened and gave my heart a shock.";
		next;
		mes "[Lalaila Wigner]";
		mes "I apologize for burdening you with such long stories, we're not even close enough for that.";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "It's understandable that you were shocked...";
		next;
		cutin "ep21_lalaila01.png",1;
		mes "[Lalaila Wigner]";
		mes "Tell Ivan that I won't be going.";
		mes "I believe this is the correct choice.";
		next;
		cutin "ep21_lalaila02.png",1;
		mes "[Lalaila Wigner]";
		mes "But Lady Nazar is certainly will join him in this battle.";
		mes "I'm here thanks to Ivan, Mari, Richard and the others. But my duty is here.";
		next;
		mes "[Lalaila Wigner]";
		mes "I hope everyone would be reassured knowing that I'm here for them atleast.";
		next;
		mes "[Lalaila Wigner]";
		mes "And you too, " + strcharinfo(0) + ".";
		next;
		cutin "ep21_lalaila01.png",1;
		mes "[Lalaila Wigner]";
		mes "I think you might be the last person that became our companion because of the cult.";
		mes "Of course, I'll always welcome new companion, but I hope this will be truly the last one.";
		next;
		mes "[Lalaila Wigner]";
		mes "When everything is over, please return with Ivan and the others.";
		mes "Although we can't throw a grand celebration because of the remnants that remains, I'll be able to prepare a small feast.";
		next;
		select("Do you believe we will win?");
		cutin "ep21_lalaila02.png",1;
		mes "[Lalaila Wigner]";
		mes "Of course.";
		mes "My choices... are never wrong.";
		next;
		cutin "ep21_lalaila03.png",1;
		mes "[Lalaila Wigner]";
		mes "...This isn't the time for this. You should hurry back.";
		mes "Also... Give my regards to Mari, I mean Captain Walter as well.";
		next;
		cutin "ep21_lalaila02.png",1;
		mes "[Lalaila Wigner]";
		mes "May the fortune be with you.";
		completequest 8915;
		setquest 8916;
		close2;
		cloaknpc(strnpcinfo(0),true,getcharid(0));
		warp "jalbe_in",64,136;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(8915) == 1";
end;
}

jor_mbase,332,148,5	script(CLOAKED)	Ivan#ep21p605	4_EP21_IVAN,5,5,{
	if ( isbegin_quest(8916) == 1 ) {
		cutin "ep21_ivan03.png",1;
		mes "[Ivan]";
		mes "Ah, you've returned alone after all.";
		mes "I knew it.";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "If you knew I'd return alone, why did you send me?";
		mes "She was really worried about you.";
		next;
		cutin "ep21_ivan02.png",1;
		mes "[Ivan]";
		mes "What did she say?";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "She told me she is not coming. And she told me that it's the correct choice.";
		mes "But Lazy Nazar is definitely going to join you in this battle...";
		next;
		mes "[" + strcharinfo(0) + "]";
		mes "You, Mari...? Captain Walter, Richard, and the others helped her stay in Alberta, and she believe her role is there...";
		next;
		cutin "ep21_ivan02.png",1;
		mes "[Ivan]";
		mes "Her battlefield is there.";
		mes "I understand.";
		mes "Haha, It's an honor to have my name mentioned with the captain and the leader of the mercenaries.";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "Why didn't you go yourself?";
		next;
		cutin "ep21_ivan06.png",1;
		mes "[Ivan]";
		mes "If I went myself, she wouldn't have hesitated and followed me.";
		mes "That's just kind of person she is.";
		next;
		cutin "ep21_ivan05.png",1;
		mes "[Ivan]";
		mes "Since you're the one who went, she was able to think rationally.";
		next;
		cutin "ep21_ivan04.png",1;
		mes "[Ivan]";
		mes "I don't think she'd come... but I just want to consider her last time.";
		mes "I wanted to show her how much of difference she made.";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "She said she’d prepare something delicious and wait for us once it’s over, so let’s wrap this up quickly and go back..";
		next;
		cutin "ep21_ivan04.png",1;
		mes "[Ivan]";
		mes "Haha, you're saying like it's nothing, huh?";
		mes "Alright! That's the spirit " + strcharinfo(0) + ".";
		mes "Sorry for the sudden request. Thank you very much!";
		mes "The preparation is finished. Let's go!";
		completequest 8916;
		getitem "Ep21_Wigner_Ticket",10;
		cloaknpc("Ivan#ep21p605",true,getcharid(0));
		close3;
	}
	end;
}

jalbe_in,70,46,0	script	#ep21_rw08	HIDDEN_WARP_NPC,3,3,{
	end;
	
OnTouch:
	if(isbegin_quest(8894) == 1 || isbegin_quest(17769) == 1)
		cloaknpc("Maristella Walter#ep21_rw02",false,getcharid(0));
end;
}

jalbe_in,68,46,7	script(CLOAKED)	Maristella Walter#ep21_rw02	4_EP21_MARISTELLA,{
	if(isbegin_quest(8894) == 1){
		select("I have something for you.");
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "Yes? Are you talking to me?";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "Lalaila asked me to deliver a letter to you…….";
		next;
		cutin "ep21_maristella03.png",1;
		mes "[Maristella Walter]";
		mes "Oh, Lalaila…… Ahem! I mean, lady Nazar.";
		next;
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "Thank you.";
		next;
		cutin "ep21_maristella03.png",1;
		mes "[Maristella Walter]";
		mes "……….";
		next;
		cutin "ep21_maristella02.png",1;
		mes "[Maristella Walter]";
		mes "……*smiles*.";
		next;
		cutin "",255;
		mes "[" + strcharinfo(0) + "]";
		mes "(……??)";
		completequest 8894;
		setquest 8892;
		getitem "Ep21_Wigner_Ticket",10;
		getexp 91298960,59995050;
		add_reputation_points(13,5);
		close;
	}
	if(isbegin_quest(17769) == 1){
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "Alright. Now that we know the ships characteristics and where it was sighted, we can proceed to find it.";
		mes "It's about a seven day journey north from here. If we follow the coordinates, we should be able track it down.";
		next;
		cutin "ep21_maristella03.png",1;
		mes "[Maristella Walter]";
		mes "Blue three-eyed monster emerging from the fog at night…….";
		mes "We'll finally get to meet it.";
		next;
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "Let's set sail.";
		mes "Once all your preparations are complete, won't you meet me in the harbor?";
		next;
		cutin "ep21_maristella02.png",1;
		mes "[Maristella Walter]";
		mes "Then…… I'll head to the <NAVI>[harbor]<INFO>jor_albe.gat,191,186,0,101,0</INFO></NAVI> and wait there.";
		mes "Well, I could also use some time to think on my own as well.";
		completequest 17769;
		setquest 16816;
		close2;
		cutin "",255;
		cloaknpc("Maristella Walter#ep21_rw02",true,getcharid(0));
		end;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(8894) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17769) == 1";
end;
}

jor_raise1,323,71,0	script	#21ms00	HIDDEN_WARP_NPC,3,3,{
	end;
	
OnTouch:
	if(isbegin_quest(8893) == 1 || isbegin_quest(17761) == 1 || isbegin_quest(17765) == 1){
		pcblock(true);
		cloaknpc("Ivan#21ms00",false,getcharid(0));
		npctalk "This way!","Ivan#21ms00",bc_self;
		sleep2 900;
		cloaknpc("Ivan#21ms00",true,getcharid(0));
		pcblock(false);
		warp "luna_sf1",35,267;
	}
end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(8893) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17761) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17765) == 1";
end;
}

jor_raise1,321,71,3	duplicate(dummynpc)	Ivan#21ms00	EP21_NPC_IVAN

luna_sf1,35,267,0	script	#21ms01	HIDDEN_WARP_NPC,5,5,{
	end;

OnTouch:
	if(isbegin_quest(17761) == 1){
		cloaknpc("Wilhelm#21ms00",false,getcharid(0));
		end;
	}
	if(isbegin_quest(17765) == 1){
		cloaknpc("Wilhelm#21ms00",false,getcharid(0));
		cloaknpc("Carmigand#21ms00",false,getcharid(0));
		cloaknpc("Nadoyo#21ms00",false,getcharid(0));
		cloaknpc("Believer#21ms00",false,getcharid(0));
		cloaknpc("Believer#21ms01",false,getcharid(0));
		cloaknpc("Believer#21ms02",false,getcharid(0));
		cloaknpc("Believer#21ms03",false,getcharid(0));
		cloaknpc("Believer#21ms04",false,getcharid(0));
	}
end;
}

luna_sf1,49,268,3	script	Ivan#21ms01	EP21_NPC_IVAN,3,3,{
OnTouch:
	if(isbegin_quest(8893) == 1){
		cutin "ep21_ivan03.png",1;
		mes "[Ivan]";
		mes "Wow- we got some reliable people here. The new adventurer, and Tan as a watcher? Am I right?";
		next;
		cutin "ep21_tan02.png",2;
		mes "[Tan]";
		mes "Too many people is inconvenient.";
		next;
		cutin "ep21_ivan03.png",1;
		mes "[Ivan]";
		mes "What? Too many people for infiltrating? That makes sense. Are you here as a watcher or not? Are you here as an additional force?";
		mes "Oh, by the way. I see, it's Yohan is the one who came from the Walter's side.";
		npctalk "......","Tan#21ms00",bc_self;
		next;
		cutin "ep21_ivan01.png",1;
		mes "[Ivan]";
		mes "Oh! I'm not saying you're not enough! Don't get me wrong, please! I just thought the Walter's people are less intersted in action but would come for information. Aren't there a lot of people like that?";
		next;
		cutin "ep21_yohan01.png",0;
		mes "[Yohan]";
		mes "...They told me to come. They didn't have the resources to send anyone else.";
		next;
		cutin "ep21_ivan03.png",1;
		mes "[Ivan]";
		mes "The captain sent you? You had no choice. Nothing you can do. Just following orders.";
		mes "Look at you getting all gloomy. The lack of resources is just an excuse, they sent you because you're the right person for the job. Not everyone get sents to a place like this.";
		npctalk "......","Yohan#21ms00",bc_self;
		next;
		select("Is that a temple up ahead?");
		cutin "ep21_yohan01.png",0;
		mes "[Yohan]";
		mes "It looks exactly like a human temple... how sickening.";
		next;
		cutin "ep21_ivan03.png",1;
		mes "[Ivan]";
		mes "Yes. They probably designed it to resemble human structures to lure people in. People feel safe and drawn in to what they're familiar with.";
		mes "The inside must be more impressive, right? Let's go in. I'm getting curious.";
		npctalk "It's ordinary.","Tan#21ms00",bc_self;
		next;
		cutin "ep21_tan01.png",2;
		mes "[Tan]";
		mes "We don't know anything. Isn't this reckless?";
		next;
		cutin "ep21_ivan01.png",1;
		mes "[Ivan]";
		mes "We'll figure something out once we're inside.";
		next;
		select("Do we need to disguise ourselves?");
		cutin "ep21_ivan02.png",1;
		mes "[Ivan]";
		mes "Disguise...? As what? Jormungandr cultist? Don't we already look like them?";
		next;
		cutin "ep21_tan01.png",2;
		mes "[Tan]";
		mes "We have legs.";
		next;
		cutin "ep21_ivan01.png",1;
		mes "[Ivan]";
		mes "Oh, that's the issue? We don't need to necessarily put on scales.";
		npctalk "Well... there are also human believers too...","Yohan#21ms00",bc_self;
		next;
		cutin "ep21_ivan03.png",1;
		mes "[Ivan]";
		mes "It'll probably easier to meet human believers like this. Let's hurry. I'd like to get back before dinner. Today's menu is Payon's Spicy Pork Stir-Fry.";
		mes "Come, Let's go.";
		npctalk "......","Tan#21ms00",bc_self;
		completequest 8893;
		setquest 17752;
		close2;
		cutin "",255;
		end;
	}
	if(isbegin_quest(17752) == 1){
		npctalk "What are you doing? Let's go.","",bc_self;
		end;
	}
	if(isbegin_quest(17765) == 0){
		npctalk "Vice-captain, what do you see? Are you seeing something?","",bc_self;
		end;
	}
	if(isbegin_quest(17765) == 1){
		npctalk "I’m curious how Nadoyo managed to escape.","",bc_self;
		end;
	}
	if(isbegin_quest(17766) == 1){
		npctalk "Ugh, my whole body is aching.","",bc_self;
		end;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(8893) == 1";
end;
}

luna_sf1,51,267,3	script	Tan#21ms00	EP21_NPC_TAN,{
	if(isbegin_quest(8893) == 1){
		npctalk "It looks like Ivan has something to say.","",bc_self;
		end;
	}
	if(isbegin_quest(17752) == 1){
		npctalk "To the temple.","Tan#21ms00",bc_self;
		end;
	}
	if(isbegin_quest(17761) == 1){
		cutin "ep21_tan02.png",2;
		mes "[Tan]";
		mes "Are they already here.";
		close2;
		pcblock(true);
		cutin "",255;
		sleep2 900;
		npctalk "Do you think you can beat me in Go?","Ivan#21ms01",bc_self;
		sleep2 1000;
		pcblock(false);
		cloaknpc("Nadoyo#21ms00",false,getcharid(0));
		cutin "ep21_nadoyo07.png",1;
		mes "[Nadoyo]";
		mes "I won five games in a row yesterday.";
		npctalk "Why are you people like this.","",bc_self;
		npctalk "You need to find some joy in life. Especially in these times, everyone has to find their own way to be happy.","Ivan#21ms01",bc_self;
		next;
		cutin "ep21_nadoyo07.png",1;
		mes "[Nadoyo]";
		mes "Did you bring the person that I mentioned?";
		npctalk "Here he is!","Ivan#21ms01",bc_self;
		next;
		cutin "ep21_wilhelm01.png",2;
		mes "[Wilhelm]";
		mes "I'm Wilhelm. I heard you're looking for someone like me, What's the situation?";
		next;
		cutin "ep21_nadoyo01.png",0;
		mes "[Nadoyo]";
		mes "I'm surprised, you really found a person who meets the conditions I mentioned?";
		next;
		cutin "ep21_tan04.png",2;
		mes "[Tan]";
		mes "Why are you surprised? Are you expecting something different?";
		next;
		cutin "ep21_nadoyo02.png",0;
		mes "[Nadoyo]";
		mes "No, nothing like that. You selected well. I'm honestly amazed that you found someone like him.";
		mes "If all things fail, I was already prepared to put a wig on you Tan.";
		npctalk "Did you really brought a wig? Let me see.","Ivan#21ms01",bc_self;
		npctalk "......","",bc_self;
		next;
		cutin "ep21_nadoyo05.png",0;
		mes "[Nadoyo]";
		mes "We don't have time, so I'll quickly go over the plan. I'll only say it once, so listen carefully to avoid any kind of mistakes.";
		next;
		mes "[Nadoyo]";
		mes "Wilhelm, you will pose as Carmigand, a key figure in the cult.";
		next;
		cutin "ep21_yohan01.png",0;
		mes "[Yohan]";
		mes "But Wilhelm... is human...?";
		next;
		cutin "ep21_nadoyo02.png",0;
		mes "[Nadoyo]";
		mes "A high-rank priest closely resemble a human. However, Carmigand is a human.";
		mes "He is an extraordinary figure who rose to the rank of a high priest despite being a human. He is also the high-ranking official that I mentioned who wants to escape.";
		next;
		cutin "ep21_nadoyo02.png",0;
		mes "[Nadoyo]";
		mes "We will use Wilhelm's resemblance to Carmigand to infiltrate the church as someone hoping to join.";
		mes "Since we will be represented by a high-ranking priest, the registration procedures will be simpler, and we will have access to majority of the restricted areas.";
		npctalk "Will it work?","",bc_self;
		npctalk "I guarantee you that it will.","Nadoyo#21ms00",bc_self;
		next;
		cutin "ep21_nadoyo02.png",0;
		mes "[Nadoyo]";
		mes "I'm positive it will work, they have trouble distinguishing human faces, as long as the hair and built are similar.";
		mes "With little training, you will be able to approach even the core members of the cult.";
		next;
		cutin "ep21_wilhelm01.png",2;
		mes "[Wilhelm]";
		mes "It sounds like you're someone familiar about the inside of the cult, correct? I'm fine with whatever, however I need to make something clear.";
		next;
		cutin "ep21_wilhelm05.png",2;
		mes "[Wilhelm]";
		mes "The only reason I'm doing this is because you promised me to help find someone inside the cult. I won't cooperate if you can't keep that promise, got it?";
		next;
		cutin "ep21_nadoyo02.png",0;
		mes "[Nadoyo]";
		mes "Are you looking for someone in the cult? With Carmigand's identity, it should be possible.";
		npctalk "Just how high-ranking is that person...? What an almighty identity...","Yohan#21ms00",bc_self;
		next;
		cutin "ep21_ivan04.png",1;
		mes "[Ivan]";
		mes "I've got a good feeling about this. Let's go in there and go find out what their meal plans are for the next month!";
		next;
		cutin "ep21_nadoyo10.png",0;
		mes "[Nadoyo]";
		mes "Let's move if you're ready. Even if you're not, we still need to go now.";
		mes "Everyone, quietly head to the entrance of the stairs leading to the 2nd floor of the temple and gather there.";
		completequest 17761;
		setquest 17762;
		getitem "Ep21_Wigner_Ticket",15;
		getexp 224735905,55709690;
		add_reputation_points(13,15);
		close3;
	}
	if(isbegin_quest(17762) == 1){
		npctalk "Let's meet at the 2nd floor entrance of the temple. I'll meet you there.","",bc_self;
		end;
	}
	if(isbegin_quest(17765) == 1){
		npctalk "We should listen to Nadoyo. She might have a different information from what we got.","",bc_self;
		end;
	}
	if(isbegin_quest(17766) == 1){
		npctalk "The Jormungandr followers are no pushover.","",bc_self;
		end;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17761) == 1";
end;
}

luna_sf1,45,267,5	script	Yohan#21ms00	EP21_NPC_YOHAN,{
	npctalk "This place should be safe... maybe...","",bc_self;
	end;
}

luna_sf1,50,265,1	script(CLOAKED)	Wilhelm#21ms00	EP21_NPC_WILHELM,{
	npctalk "Why is this happening to me...","",bc_self;
	end;
}

luna_sf1,48,265,7	script(CLOAKED)	Nadoyo#21ms00	EP21_NPC_NADOYO,{
	if(isbegin_quest(17761) == 1){
		npctalk "*Whistling*.","",bc_self;
		end;
	}
	if(isbegin_quest(17762) == 1){
		npctalk "We need to hurry up.","",bc_self;
		end;
	}
	if(isbegin_quest(17765) == 1){
		cutin "ep21_nadoyo10.png",0;
		mes "[Nadoyo]";
		mes "You're a bit late.";
		next;
		cutin "ep21_ivan06.png",1;
		mes "[Ivan]";
		mes "Phew- We made it out somehow.";
		mes "I'm not sure if everything will work out from here on out, but we'll figure something out.";
		npctalk "Well, there is lot, to work on...","Yohan#21ms00",bc_self;
		npctalk "......","Tan#21ms00",bc_self;
		next;
		cutin "ep21_nadoyo05.png",0;
		mes "[Nadoyo]";
		mes "I already considered leaving you after waiting for so long. You seem to have quite a few people with you? What happened?";
		next;
		cutin "ep21_ivan04.png",1;
		mes "[Ivan]";
		mes "Well, that is how it turned out. Ahahaha!";
		npctalk "I've never met someone as tactless as you! How can you just say it out loud like that!","Wilhelm#21ms00",bc_self;
		next;
		cutin "ep21_nadoyo03.png",0;
		mes "[Nadoyo]";
		mes "Don't tell me... that you made a ruckus before going out?";
		mes "Ha- Uhm, can I even go back?";
		npctalk "It just turned out like that...","Wilhelm#21ms00",bc_self;
		next;
		cutin "ep21_ivan02.png",1;
		mes "[Ivan]";
		mes "Well, it's probably fine. I think...?";
		mes "We were spotted on the way out, we didn't mention anything about being connected to you, right?";
		next;
		cutin "ep21_reinhardt07.png",2;
		mes "[Carmigand]";
		mes "Hiasagand was keeping an eye on me.";
		next;
		cutin "ep21_nadoyo03.png",0;
		mes "[Nadoyo]";
		mes "Hiasagand? That guy...?";
		mes "Ah, yeah... that guy, if he was involved, I can understand. There's nothing we could have done about it.";
		npctalk "Are you two rivals? Was it a one-sided competition?","Ivan#21ms01",bc_self;
		next;
		cutin "ep21_tan01.png",2;
		mes "[Tan]";
		mes "We should hurry. Even though we're safe now, there's always a chance that they sent someone to track us down.";
		npctalk "I'd like to go gather some information too...","Yohan#21ms00",bc_self;
		next;
		cutin "ep21_nadoyo04.png",0;
		mes "[Nadoyo]";
		mes "Then, let's go on our own ways for now and meet again on our regular meeting.";
		mes "Also, Carmigand.";
		next;
		cutin "ep21_reinhardt01.png",2;
		mes "[Carmigand]";
		mes "I'm listening. Go ahead.";
		next;
		cutin "ep21_nadoyo05.png",0;
		mes "[Nadoyo]";
		mes "You'll be starting a 3rd chapter of your life. I don't know what path you'll take, but I hope its different from the last.";
		mes "Even if it wasn't your intention, don't forget the people who suffered because they believed in you.";
		next;
		cutin "ep21_reinhardt05.png",2;
		mes "[Carmigand]";
		mes "Of course. I left the church to address that very issue. I won't betray your expectations and trust.";
		mes "I apologize for everything. I will keep in touch.";
		npctalk "......","Wilhelm#21ms00",bc_self;
		next;
		cutin "ep21_ivan01.png",1;
		mes "[Ivan]";
		mes "Alright, then let's split up and head out!! Be careful!";
		completequest 17765;
		setquest 17766;
		getitem "Ep21_Wigner_Ticket",20;
		getexp 449470800,137131550;
		add_reputation_points(13,20);
		close3;
	}
	if(isbegin_quest(17766) == 1){
		npctalk "We better hurry up.","",bc_self;
		end;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17765) == 1";
end;
}

luna_sf1,52,263,1	script(CLOAKED)	Carmigand#21ms00	EP21_NPC_REINHARDT,{
	npctalk "We... made it out safely. Thanks to everyone's effort.","",bc_self;
	end;
}

luna_sf1,43,268,5	script(CLOAKED)	Believer#21ms00	4_EP21_M_WORKER_A,{
	npctalk "Did we really just escape?","",bc_self;
	end;
}

luna_sf1,43,264,7	script(CLOAKED)	Believer#21ms01	4_EP21_F_WORKER_A,{
	npctalk "How am I suppose to live my life from now on...","",bc_self;
	end;
}

luna_sf1,45,263,7	script(CLOAKED)	Believer#21ms02	4_EP21_M_WORKER_B,{
	npctalk "Everything happened so sudden...","",bc_self;
	end;
}

luna_sf1,49,263,1	script(CLOAKED)	Believer#21ms03	4_EP21_F_WORKER_B,{
	npctalk "Will I have a good life? Was it a mistake to leave?","",bc_self;
	end;
}

luna_sf1,47,269,5	script(CLOAKED)	Believer#21ms04	4_EP21_F_WORKER_B,{
	npctalk "Finally!!","",bc_self;
	end;
}

jor_tmple1,186,72,0	script	#21ms10	HIDDEN_WARP_NPC,2,2,{
	end;
	
OnTouch:
	if(isbegin_quest(17752) == 1  || isbegin_quest(17756) == 1){
		pcblock(true);
		cloaknpc("Ivan#21ms10",false,getcharid(0));
		npctalk "Come! This way!","Ivan#21ms10",bc_self;
		sleep2 500;
		cloaknpc("Ivan#21ms10",true,getcharid(0));
		pcblock(false);
		warp "luna_sf2",109,253;
	}
end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17752) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17756) == 1";
end;
}

jor_tmple1,186,72,3	duplicate(dummynpc)	Ivan#21ms10	EP21_NPC_IVAN

luna_sf2,109,253,0	script	#21ms11	HIDDEN_WARP_NPC,2,2,{
	if(isbegin_quest(17752) == 1  || isbegin_quest(17756) == 1){
		cloaknpc("Ivan#21ms11",false,getcharid(0));
		cloaknpc("Tan#21ms10",false,getcharid(0));
		cloaknpc("Yohan#21ms10",false,getcharid(0));
		cloaknpc("#21ms12",false,getcharid(0));
	}
	end;
}

luna_sf2,113,257,5	script(CLOAKED)	Ivan#21ms11	EP21_NPC_IVAN,{
	if(isbegin_quest(17752) == 1){
		cutin "ep21_ivan03.png",0;
		mes "[Ivan]";
		mes "Did everyone made it safely? It seems there's no problem even with just our normal form.";
		npctalk "Why is this working?","Yohan#21ms10",bc_self;
		next;
		cutin "ep21_ivan04.png",0;
		mes "[Ivan]";
		mes "There are humans everywhere. Humans aren't rare around here.";
		mes "Since this is a temple, there must be a lot of human believers as well. Things are going smoothly.";
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "Where should we start? What's the quickest way to get things done and get out of here?";
		next;
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "If a group of unfamiliar faces stick together, It'll look suspicious.";
		npctalk "That's true.","Yohan#21ms10",bc_self;
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "Really? Would it be better for us to split up to gather information? Are we skilled enough and handling bad situations on our own?";
		next;
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "Anyone who gets in the way or notice you. Just get rid of them or tie them up in a secluded place.";
		npctalk "Eh? What? Just like that?","",bc_self;
		next;
		cutin "ep21_ivan06.png",0;
		mes "[Ivan]";
		mes "Tan, could you phrase things a bit more carefully, please? You're really scaring me. Remember this. There are people here with a faint heart!";
		npctalk "Completely getting rid of them... isn't a bad idea though.","Yohan#21ms10",bc_self;
		npctalk "Why is everyone like this? What made you all this way? Was your life that hard?","",bc_self;
		next;
		select("Can I ask about the ghost ship?");
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "We're here to gather information about the ghost ship, it's our top priority.";
		mes "If you meet any humans, it would be wise to subtly ask if they're looking to escape.";
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "Before that, keep in mind what's important. Do you know who is the most dangerous people in this world? It's the people who believe in something so strongly that they lose their sense of reason. The ones with unyielding determination.";
		mes "Put it all together makes it a fanatic. Be careful not to make mistakes.";
		next;
		cutin "ep21_ivan03.png",0;
		mes "[Ivan]";
		mes "It's dangerous to go alone, so let's pair up. I'll go with Yohan. Tan, go with the adventurer.";
		mes "Since you came along as a watcher, you don't have any objections, right?";
		next;
		select("Where should we meet?");
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "We'll meet here after gathering information.";
		next;
		cutin "ep21_ivan01.png",0;
		mes "[Ivan]";
		mes "Alright. This place is discreet and well-suited for secrecy.";
		mes "Alright, let's split up!";
		completequest 17752;
		setquest 17753;
		close2;
		cutin "",255;
		end;
	}
	if(isbegin_quest(17756) == 0){
		npctalk "Let's look around and meet here again.","",bc_self;
		end;
	}
	if(isbegin_quest(17756) == 1){
		cutin "ep21_ivan01.png",0;
		mes "[Ivan]";
		mes "Oh, Tan and the adventurer is here. I was getting really anxious waiting for you. If you two disappeared, we'd be in big trouble.";
		npctalk "Really? You didn't seem anxious at all.","Yohan#21ms10",bc_self;
		npctalk "My jaw hurts from all the shaking. I was worried my teeth would crack from so much shaking.","",bc_self;
		npctalk "Useless talk.","Tan#21ms10",bc_self;
		next;
		cutin "ep21_ivan05.png",0;
		mes "[Ivan]";
		mes "Anyway, did you find anything? We came up empty.";
		next;
		select("Not much on our end...");
		cutin "ep21_yohan01.png",2;
		mes "[Yohan]";
		mes "I heard the phrase, I don't know more than I can count. Maybe we should have asked what they do know.";
		mes "But there's a limit of how much we can ask, when we don't even know where or who to wants to escape...";
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "There's no way all the human believers are here. Where is the rest of them?";
		next;
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "Maybe being in human form isn't enough.";
		npctalk "It might be... It was really difficult to even ask questions...","Yohan#21ms10",bc_self;
		npctalk "Yeah. I couldn't even bring myself to ask anything because it felt uneasy. It was not easy, not at all.","",bc_self;
		next;
		cutin "ep21_ivan05.png",0;
		mes "[Ivan]";
		mes "Don't we seem... reliable enough for people to easily open up to us? Are we that suspicious? Instead of getting information, we were treated like crazy people.";
		npctalk "Looking at us, we look like a group of... thugs...","Yohan#21ms10",bc_self;
		npctalk "Don't lump me with you.","Tan#21ms10",bc_self;
		next;
		cutin "ep21_ivan06.png",0;
		mes "[Ivan]";
		mes "I heard that human believers are treated well, but seeing it firsthand, it feels different. It's more like... They are being looked down upon?";
		npctalk "That's why.. humans can't stand it and try to escape...","Yohan#21ms10",bc_self;
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Are they really humans who want to escape?";
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "It must be, that's why many of them left. We just haven't met any of them yet. There don't seem to be as many humans here as we thought. Have you been to the 2nd floor?";
		mes "It seems that is the place where we can get more reliable information. Adventurer, how was on your side?";
		next;
		select("They were all hostile.");
		cutin "ep21_yohan02.png",2;
		mes "[Yohan]";
		mes "There is a 2nd floor..?";
		next;
		cutin "ep21_ivan06.png",0;
		mes "[Ivan]";
		mes "Sigh... Yohan... Where did you think we are?";
		mes "They said you need a priest to register your name in the registry to get in, without that we would end up in big trouble instead of getting information.";
		next;
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "We came to get informatio, but we don't even know much about this place.";
		npctalk "I thought... we would figure something out once we get in...","Yohan#21ms10",bc_self;
		npctalk "Who even said that anyway?","",bc_self;
		next;
		cutin "ep21_tan04.png",1;
		mes "[Tan]";
		mes "Should we kidnap someone?";
		npctalk "Kidnap? Who? How many?","Yohan#21ms10",bc_self;
		npctalk "Sigh... why are you like this? What did you eating growing up for you to end like this? I'm not being sarcastic, I'm really curious.","",bc_self;
		next;
		select("What should we do?");
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "There's nothing we can do. Let's go back.";
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "It seems like we came here without enough information.";
		mes "We should head back, either bring someone who knows more information about this place, or gather more information. Let's return quickly.";
		next;
		cutin "ep21_yohan01.png",2;
		mes "[Yohan]";
		mes "We came here to get information, now we have to go back to get more information about this place... it's so inefficient.";
		completequest 17756;
		setquest 17757;
		close3;
	}
	npctalk "We have to back. There's nothing we can do. It's discouraging, but we have no choice, don't we?","",bc_self;
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17752) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17756) == 1";
end;
}

luna_sf2,116,256,3	script(CLOAKED)	Tan#21ms10	EP21_NPC_TAN,{
	npctalk "I'll watch you closely.","Tan#21ms10",bc_self;
	end;
}

luna_sf2,116,253,1	script(CLOAKED)	Yohan#21ms10	EP21_NPC_YOHAN,{
	npctalk "The shape of this temple... it looks familiar.","Yohan#21ms10",bc_self;
	end;
}

luna_sf2,105,253,0	script(CLOAKED)	#21ms12	WARPNPC,3,3,{
	end;
	
OnTouch:
	warp "jor_tmple1",182,69;
end;
}

jor_tmple1,110,190,0	script	#21ms13	HIDDEN_WARP_NPC,2,2,{
	end;
	
OnTouch:
	if(isbegin_quest(17753) == 1){
		pcblock(true);
		pctalk "I can hear people talking.";
		sleep2 500;
		pcblock(false);
		warp "luna_sf2",49,148;
	}
end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17753) == 1";
end;
}

luna_sf2,45,152,3	script	Believer#21ms13	4_EP21_M_WORKER_A,{
	if(isbegin_quest(17753) == 1){
		cutin "ep21_worker_m_07.png",2;
		mes "[Believer]";
		mes "I thought today's sermon would be given by lord Carmigand.";
		next;
		cutin "ep21_worker_f_01.png",1;
		mes "[Believer]";
		mes "Yes. Recently, he's the only one giving the sermons.";
		mes "It's a shame. His words are inspiring. I was really moved by his last sermon.";
		next;
		cutin "ep21_tan01.png",0;
		mes "[Tan]";
		mes "They seem to be a devout believers.";
		mes "It might be better to ask about the ghost ship than escaping.";
		next;
		select("Excuse me, I have something to ask.");
		cutin "ep21_worker_m_07.png",1;
		mes "[Believer]";
		mes "Are you a new believer? I haven't seen you before.";
		mes "Welcome to the embrace of Lord Jormungandr. So, what are you curious about?";
		next;
		select("Have you heard of the ghost ship?");
		cutin "ep21_worker_m_07.png",2;
		mes "[Believer]";
		mes "Ghost ship? What's that? Where did you hear that?";
		mes "This is the first time we've heard of it, right?";
		next;
		cutin "ep21_worker_f_01.png",1;
		mes "[Believer]";
		mes "Maybe? It might be my first time hearing it too. If there were such an interesting story, we'd have heard it by now.";
		mes "What's the story?";
		next;
		select("I heard it attacked our ships...");
		cutin "ep21_worker_m_07.png",2;
		mes "[Believer]";
		mes "What? Attacked our ship? Who would dare?";
		mes "Lord Jormungandr... please deliver punishment upon them...";
		next;
		cutin "ep21_worker_f_01.png",1;
		mes "[Believer]";
		mes "So that's why our supply deliveries have not been arriving lately.";
		mes "I hope we won't have anymore major losses...";
		next;
		select("Thank you for your time.");
		cutin "ep21_worker_m_07.png",2;
		mes "[Believer]";
		mes "Not at all. We're actually the ones who should be thanking you for sharing the information.";
		mes "Don't worry too much, we'll look into it. Lord Jormungandr is watching over us.";
		completequest 17753;
		setquest 17754;
		close3;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17753) == 1";
end;
}

luna_sf2,43,152,5	script	Believer#21ms14	4_EP21_F_WORKER_B,{
	npctalk "May you find peace in the embrace of Lord Jormungand.","",bc_self;
	end;
}

luna_sf2,41,150,5	script	Tan#21ms11	EP21_NPC_TAN,{
	npctalk "Let's hear what the believer has to say.","",bc_self;
	end;
}

jor_tmple1,186,228,0	script	#21ms15	HIDDEN_WARP_NPC,2,2,{
	end;
	
OnTouch:
	if(isbegin_quest(17754) == 1){
		pcblock(true);
		pctalk "I can hear people talking.";
		sleep2 500;
		pcblock(false);
		warp "luna_sf2",110,268;
	}
end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17754) == 1";
end;
}

luna_sf2,108,267,0	script	#21ms16	HIDDEN_WARP_NPC,2,2,{
	end;
	
OnTouch:
	if(isbegin_quest(17754) == 1){
		cloaknpc("Believer#21ms10",false,getcharid(0));
		cloaknpc("Believer#21ms11",false,getcharid(0));
		cloaknpc("Believer#21ms12",false,getcharid(0));
		cloaknpc("Tan#21ms12",false,getcharid(0));
		cloaknpc("#21ms17",false,getcharid(0));
	}
end;
}

luna_sf2,118,265,3	script(CLOAKED)	Believer#21ms10	4_EP21_F_WORKER_A,{
	if(isbegin_quest(17754) == 1){
		cutin "ep21_worker_of_06.png",1;
		mes "[Believer]";
		mes "Ugh, my body aches. I wish it would be over.";
		mes "I hope the work today will be over.";
		npctalk "I didn't joined the church for this.","Believer#21ms11",bc_self;
		npctalk "I'm starting to have doubts already.","Believer#21ms12",bc_self;
		next;
		cutin "ep21_tan01.png",2;
		mes "[Tan]";
		mes "These people seems like they might want to escape.";
		next;
		select("Excuse me, I have something to ask.");
		cutin "ep21_worker_of_08.png",0;
		mes "[Believer]";
		mes "Oh, are you a new believer? That's great, really great. We've had many people leave recently, so it's a relief to see new faces.";
		next;
		cutin "ep21_worker_of_06.png",1;
		mes "[Believer]";
		mes "Shh- how can you talk about that in front of newcomers!";
		mes "So, what are you curious about newcomer?";
		next;
		select("Are you looking by any chance to escape?");
		cutin "ep21_worker_of_06.png",1;
		mes "[Believer]";
		mes "What?? Escape?? From where? The church? The temple?";
		npctalk "Shh- lower your voice!","Believer#21ms10",bc_self;
		next;
		cutin "ep21_worker_of_08.png",0;
		mes "[Believer]";
		mes "Why are you asking something like that? Wait? Come to think of it, I have never seen you before?";
		npctalk "Are they really??","Believer#21ms12",bc_self;
		next;
		cutin "ep21_worker_om_06.png",2;
		mes "[Believer]";
		mes "Hold on, don't say a word everyone. This is a trap!";
		mes "I heard there were 2 believers who disappeared after heading into the prayer room on the 2nd floor.";
		next;
		cutin "ep21_worker_of_06.png",1;
		mes "[Believer]";
		mes "Yeah, I heard that too!";
		mes "Rumor has it that the church's guard took them away.";
		next;
		cutin "ep21_worker_of_08.png",0;
		mes "[Believer]";
		mes "Why would they do that to their believers?";
		next;
		cutin "ep21_worker_om_06.png",2;
		mes "[Believer]";
		mes "What else? They're getting rid of the people with such thoughts and using them for something!";
		next;
		cutin "ep21_worker_of_06.png",1;
		mes "[Believer]";
		mes "But these people are humans too, aren't they?";
		next;
		select("It's a misunderstand. We want to help you...");
		cutin "ep21_worker_om_06.png",2;
		mes "[Believer]";
		mes "Get lost, you scum!!";
		mes "We're not falling for this!!";
		next;
		cutin "ep21_tan02.png",2;
		mes "[Tan]";
		mes "It seems that we've caused a misunderstanding.";
		mes "However, they mentioned something about believers disappearing on the 2nd floor, we might be able get information if we go there.";
		completequest 17754;
		setquest 17755;
		close2;
		cutin "",255;
		cloaknpc("Tan#21ms12",true,getcharid(0));
		end;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17754) == 1";
end;
}

luna_sf2,120,262,1	script(CLOAKED)	Believer#21ms11	4_EP21_M_WORKER_B,{
	npctalk "Ha- this is exhausting. I know it's for the better, but...","",bc_self;
	end;
}

luna_sf2,116,263,7	script(CLOAKED)	Believer#21ms12	4_EP21_F_WORKER_B,{
	npctalk "I wonder what will come up today.","",bc_self;
	end;
}

luna_sf2,122,263,1	script(CLOAKED)	Tan#21ms12	EP21_NPC_TAN,{
	npctalk "Those believers over there seems like they might know something.","",bc_self;
	end;
}

luna_sf2,105,267,0	script(CLOAKED)	#21ms17	WARPNPC,3,3,{
	end;
	
OnTouch:
	warp "jor_tmple1",180,228;
end;
}

jor_tmple1,238,268,0	script	#21ms18	HIDDEN_WARP_NPC,2,2,{
	if(isbegin_quest(17755) == 1 || isbegin_quest(17762) == 1 || isbegin_quest(17763) == 1 || isbegin_quest(17764) == 1){
		pcblock(true);
		pctalk "I can hear people's voices inside.";
		sleep2 900;
		pcblock(false);
		warp "luna_sf2",188,251;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17755) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17762) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17763) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17764) == 1";
end;
}

luna_sf2,186,245,0	script	#21ms20	WARPNPC,3,3,{
	end;
	
OnTouch:
	warp "jor_tmple1",237,265;
end;
}

luna_sf2,188,251,0	script	#21ms19	HIDDEN_WARP_NPC,3,3,{
	end;
	
OnTouch:
	if(isbegin_quest(17755) == 1){
		cloaknpc("Tan#21ms15",false,getcharid(0));
		cloaknpc("Believer#21ms16",false,getcharid(0));
		cloaknpc("Believer#21ms17",false,getcharid(0));
		cloaknpc("Believer#21ms18",false,getcharid(0));
		cloaknpc("Believer#21ms19",false,getcharid(0));
		end;
	}
	if(isbegin_quest(17762) == 1){
		cloaknpc("Ivan#21ms13",false,getcharid(0));
		cloaknpc("Tan#21ms13",false,getcharid(0));
		cloaknpc("Yohan#21ms13",false,getcharid(0));
		cloaknpc("Nadoyo#21ms13",false,getcharid(0));
		cloaknpc("Wilhelm#21ms13",false,getcharid(0));	
	}
end;
}

luna_sf2,196,257,7	script(CLOAKED)	Believer#21ms16	4_EP21_F_WORKER_A,{
	if(isbegin_quest(17755) == 1){
		cutin "ep21_worker_of_09.png",0;
		mes "[Believer]";
		mes "Ugh, It's taking too long.";
		mes "It's really hard to even get a prayer.";
		next;
		cutin "ep21_worker_om_04.png",1;
		mes "[Believer]";
		mes "There's nothing we can do, they're saying that the registry disappeared.";
		mes "What's all of this about.";
		next;
		cutin "ep21_tan01.png",2;
		mes "[Tan]";
		mes "They're all gathered here.";
		next;
		select("Why are you gathered here?");
		cutin "ep21_worker_of_09.png",0;
		mes "[Believer]";
		mes "We're here to register our names again on the 2nd floor registry.";
		mes "I haven't seen you before. Are you a new follower?";
		next;
		cutin "ep21_worker_m_01.png",2;
		mes "[Believer]";
		mes "Are you here to get a baptism? Not good. Your timing is bad.";
		mes "The registry to access the 2nd floor has disappeared, that's why we are registering again. As you can see, it's very time consuming to backlog.";
		next;
		cutin "ep21_worker_m_08.png",1;
		mes "[Believer]";
		mes "The backlog isn't the only issue, if you're a new believer, you need to be accompanied by a priest to get registered.";
		mes "Where's the priest that should be with you? It'll be difficult to get in and out without your name on the registry.";
		next;
		select("Where is the registry?");
		cutin "ep21_worker_of_09.png",0;
		mes "[Believer]";
		mes "How should we know. We don't have any use for something like that.";
		mes "It will only be troublesome for us. What is going to happen.";
		next;
		cutin "ep21_tan01.png",2;
		mes "[Tan]";
		mes "It seems it will be difficult to get into the 2nd floor. Even if we manage to enter, moving around will be challenging.";
		mes "Let's head back to our meeting place and discuss a plan.";
		completequest 17755;
		setquest 17756;
		close3;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17755) == 1";
end;
}

luna_sf2,198,254,1	script(CLOAKED)	Tan#21ms15	EP21_NPC_TAN,{
	npctalk "This is the entry place for the 2nd floor.","",bc_self;
	end;
}

luna_sf2,201,256,1	script(CLOAKED)	Believer#21ms17	4_EP21_M_WORKER_A,{
	npctalk "Wait your turn.","",bc_self;
	end;
}

luna_sf2,193,260,5	script(CLOAKED)	Believer#21ms18	4_EP21_M_WORKER_B,{
	npctalk "A new believer?","",bc_self;
	end;
}

luna_sf2,193,256,7	script(CLOAKED)	Believer#21ms19	4_EP21_F_WORKER_B,{
	npctalk "Are you here to be baptized? Or to pray?","",bc_self;
	end;
}

luna_sf2,187,254,5	script(CLOAKED)	Nadoyo#21ms13	EP21_NPC_NADOYO,{
	if(isbegin_quest(17762) == 1){
		cutin "ep21_nadoyo10.png",0;
		mes "[Nadoyo]";
		mes "Alright, let's wait here for a moment.";
		mes "Try to look as natural as possible.";
		next;
		cutin "ep21_tan01.png",2;
		mes "[Tan]";
		mes "We were practically kicked out of the 2nd floor the last time, what's your plan to get in?";
		next;
		cutin "ep21_ivan02.png",2;
		mes "[Ivan]";
		mes "Isn't that why Wilhelm is here?";
		next;
		cutin "ep21_nadoyo10.png",0;
		mes "[Nadoyo]";
		mes "Exactly. Wilhelm. From now on, you're Carmigand.";
		next;
		cutin "ep21_wilhelm02.png",1;
		mes "[Wilhelm]";
		mes "Now? Just like that?";
		mes "You should atleast tell me what to do. Is there a plan? Why are you the only one who knows?";
		next;
		cutin "ep21_nadoyo10.png",0;
		mes "[Nadoyo]";
		mes "It wouldn't make a difference if I tell you now or much earlier.";
		next;
		cutin "ep21_wilhelm04.png",1;
		mes "[Wilhelm]";
		mes "Do you think it's fine to throw me in this without a plan or a strategy?";
		mes "I thought there was a great plan. It seems I'm the only one taking the fall when it fails, right?";
		next;
		cutin "ep21_wilhelm02.png",1;
		mes "[Wilhelm]";
		mes "I wanted to do this on my own. I'm here to find someone, not to be a part of a plan that's sure to fail.";
		next;
		sleep2 317;
		cutin "ep21_nadoyo09.png",0;
		mes "[Nadoyo]";
		mes "Calm down. Are you always this easy to get worked up? I'll need you to be more careful from now on.";
		mes "Carmigand is the type who remains calm and composed no matter the situation is.";
		next;
		cutin "ep21_nadoyo10.png",0;
		mes "[Nadoyo]";
		mes "The reason I didn't tell you my plan is simple.";
		mes "Because the plan is for you to tell those guards that these people are believers who just arrived.";
		mes "After that, they will take care of everything for you.";
		next;
		cutin "ep21_wilhelm02.png",1;
		mes "[Wilhelm]";
		mes "But, I could have practiced something beforehand atleast, something like the way I act, speak, or facial expression?";
		next;
		cutin "ep21_nadoyo10.png",0;
		mes "[Nadoyo]";
		mes "If you don't know what to say, just keep quiet. They'll figure it out and go.";
		npctalk "He's right, we look really unprepared even to me.","Ivan#21ms13",bc_self;
		npctalk "Trust me.","Nadoyo#21ms13",bc_self;
		npctalk "She really sounds like a cultist. Just telling us to trust her.","Yohan#21ms13",bc_self;
		next;
		cutin "ep21_nadoyo10.png",0;
		mes "[Nadoyo]";
		mes "No need to worry. Once we get past the guards, the rest of the 2nd floor will be easy because Wilhelm looks so much like Carmigand.";
		next;
		cutin "ep21_tan01.png",2;
		mes "[Tan]";
		mes "Basically, we just follow Wilhelm and get information?";
		next;
		cutin "ep21_nadoyo10.png",0;
		mes "[Nadoyo]";
		mes "While you're at it, I'll contact the real Carmigand and get him out.";
		npctalk "Is there anything we should be careful about?","Tan#21ms13",bc_self;
		next;
		cutin "ep21_nadoyo10.png",0;
		mes "[Nadoyo]";
		mes "Carmigand is not accompanying you.";
		mes "You'll pretend as someone who just happened to be on the 2nd floor and ran into Carmigand leading a group of new believers.";
		mes "Do you understand?";
		next;
		select("We act like we know nothing.");
		cutin "ep21_nadoyo10.png",0;
		mes "[Nadoyo]";
		mes "Let's go before they get suspicious of us.";
		completequest 17762;
		setquest 17763;
		questinfo_refresh;
		close2;
		cutin "",255;
		cloaknpc("Ivan#21ms13",true,getcharid(0));
		cloaknpc("Tan#21ms13",true,getcharid(0));
		cloaknpc("Yohan#21ms13",true,getcharid(0));
		cloaknpc("Nadoyo#21ms13",true,getcharid(0));
		cloaknpc("Wilhelm#21ms13",true,getcharid(0));
		cloaknpc("Ivan#21ms14",false,getcharid(0));
		cloaknpc("Tan#21ms14",false,getcharid(0));
		cloaknpc("Yohan#21ms14",false,getcharid(0));
		cloaknpc("Nadoyo#21ms14",false,getcharid(0));
		cloaknpc("Wilhelm#21ms14",false,getcharid(0));
		end;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17762) == 1";
end;
}

luna_sf2,193,252,3	script(CLOAKED)	Ivan#21ms13	EP21_NPC_IVAN,{
	npctalk "Ugh, I'm getting nervous.","",bc_self;
	end;
}

luna_sf2,192,249,1	script(CLOAKED)	Tan#21ms13	EP21_NPC_TAN,{
	npctalk "......","",bc_self;
	end;
}

luna_sf2,192,254,3	script(CLOAKED)	Yohan#21ms13	EP21_NPC_YOHAN,{
	npctalk "Oh, huh... why does this place looks really familiar?","",bc_self;
	end;
}

luna_sf2,190,254,3	script(CLOAKED)	Wilhelm#21ms13	EP21_NPC_WILHELM,{
	npctalk "Why am I even here...","",bc_self;
	end;
}

luna_sf2,198,263,5	script	Guard#21ms10	EP21_YORDOS_A,{
	if(isbegin_quest(17763) == 0){
		npctalk "What's going on?","",bc_self;
		end;
	}
	if(isbegin_quest(17763) == 1){
		cloaknpc("Ivan#21ms14",false,getcharid(0));
		cloaknpc("Tan#21ms14",false,getcharid(0));
		cloaknpc("Yohan#21ms14",false,getcharid(0));
		cloaknpc("Nadoyo#21ms14",false,getcharid(0));
		cloaknpc("Wilhelm#21ms14",false,getcharid(0));
		cutin "ep21_yordos.png",0;
		mes "[Guard]";
		mes "Welcome. Lord Carmigand.";
		next;
		cutin "ep21_yordos.png",2;
		mes "[Guard]";
		mes "Those humans... I don't recognize their faces.";
		next;
		cutin "ep21_wilhelm03.png",1;
		mes "[Wilhelm]";
		mes "They are newly inducted followers.";
		next;
		cutin "ep21_yordos.png",0;
		mes "[Guard]";
		mes "Oh, they're here for the doctrinal lessons for new followers. Understood.";
		mes "New followers needs to be registered, state your names.";
		next;
		cutin "ep21_tan05.png",1;
		mes "[Tan]";
		mes "My name is Tantanyon.";
		npctalk "What? TanTan...! What's with the name?","Ivan#21ms14",bc_self;
		next;
		cutin "ep21_yohan04.png",1;
		mes "[Yohan]";
		mes "I'm Yorlei.";
		npctalk "What, you too? Ahm, uhm... uhm...","Ivan#21ms14",bc_self;
		next;
		cutin "ep21_yordos.png",2;
		mes "[Guard]";
		mes "Name!!";
		npctalk "New followers. A piece of advice, you better act quickly.","Guard#21ms11",bc_self;
		next;
		cutin "ep21_ivan06.png",0;
		mes "[Ivan]";
		mes "Oh, Alemdangumsugangsan!";
		next;
		cutin "ep21_yordos.png",2;
		mes "[Guard]";
		mes "TanTanyon, Yorlei, Alemdangumsugangsan?";
		mes "What's with these names?";
		next;
		cutin "ep21_yordos.png",0;
		mes "[Guard]";
		mes "It must be some trend among human these days.";
		mes "And how about you?";
		next;
		select("I'm " + strcharinfo(0));
		npctalk "You alone, that's dirty!","Ivan#21ms14",bc_self;
		cutin "ep21_yordos.png",2;
		mes "[Guard]";
		mes "Nadoyo, do you also have business on the 2nd floor?";
		next;
		cutin "ep21_nadoyo02.png",1;
		mes "[Nadoyo]";
		mes "Yes! Lord Barukagand requested my presence!";
		next;
		cutin "ep21_yordos.png",2;
		mes "[Guard]";
		mes "Understood. Go ahead.";
		next;
		cutin "ep21_nadoyo02.png",1;
		mes "[Nadoyo]";
		mes "Then, Lord Carmigand. I will head first.";
		npctalk "Peace be with you.","Wilhelm#21ms13",bc_self;
		next;
		cloaknpc("Nadoyo#21ms14",true,getcharid(0));
		cutin "ep21_yordos.png",0;
		mes "[Guard]";
		mes "New followers... 4 in total.";
		mes "Doctrinal lessons...";
		next;
		mes "[Guard]";
		mes "Please wait a moment, I'll register you and open the door!";
		next;
		cutin "ep21_wilhelm03.png",1;
		mes "[Wilhelm]";
		mes "We will wait.";
		completequest 17763;
		setquest 17764;
		close3;
	}
	if(isbegin_quest(17764) == 1){
		cutin "ep21_yordos.png",0;
		mes "[Guard]";
		mes "What's the matter?";
		next;
		.@party_id = getcharid(1);
		if(!.@party_id){
			mes "[Guard]";
			mes "You need to go with your group. You can't go in alone.";
			mes "^0000cdYou must form a party of 1 or more to proceed.^000000";
			close3;
		}
		.@md_name$ = "Gimli Infiltration";
		switch(select("Finalize the registration.","Can we head in now?","Cancel.")){
			case 1:
				mes "[Guard]";
				mes "It's almost done, just wait a little longer.";
				if(instance_create(.@md_name$) == -3) 
					instance_warning(2,.@md_name$);
				close3;
			
			case 2:
				if(instance_enter(.@md_name$) != IE_OK){
					mes "[Guard]";
					mes "Where are you going, the registration is not finished. Wait here.";
					close3;
				}
				mes "[Guard]";
				mes "The registration is finished, please head in.";
				mapannounce "luna_sf2", "The new follower " + strcharinfo(0) + " of the party, "+ getpartyname(.@party_id) +" arrived at the Gimli, please give them a huge welcome.", bc_map, "0x00FF99";
				end;
				
			case 3:
				mes "[" + strcharinfo(0) + "]";
				mes "I need to prepare something.";
				close3;		
		}
		end;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17763) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17764) == 1";
end;
}

luna_sf2,204,263,3	script	Guard#21ms11	EP21_YORDOS_C,{
	npctalk "For new followers. It would be wise to act quickly and efficiently.","",bc_self;
	end;
}

luna_sf2,202,261,1	script(CLOAKED)	Nadoyo#21ms14	EP21_NPC_NADOYO,{
	npctalk "Act as natural as possible.","",bc_self;
	end;
}

luna_sf2,198,258,7	script(CLOAKED)	Ivan#21ms14	EP21_NPC_IVAN,{
	npctalk "We're about to enter the heart of the Jormungandr cult.","",bc_self;
	end;
}

luna_sf2,201,257,1	script(CLOAKED)	Tan#21ms14	EP21_NPC_TAN,{
	npctalk "Focus on the task.","",bc_self;
	end;
}

luna_sf2,204,258,1	script(CLOAKED)	Yohan#21ms14	EP21_NPC_YOHAN,{
	npctalk "Results... we need it this time...","",bc_self;
	end;
}

luna_sf2,199,261,7	script(CLOAKED)	Wilhelm#21ms14	EP21_NPC_WILHELM,{
	npctalk "Can we really just do nothing?","",bc_self;
	end;
}

jor_mbase,143,272,0	script	#21ms30	HIDDEN_WARP_NPC,5,5,{
	end;
	
OnTouch:
	if(isbegin_quest(17757) == 1){
		cloaknpc("Tris#21ms20",false,getcharid(0));
		cloaknpc("Tan#21ms20",false,getcharid(0));
		cloaknpc("Ivan#21ms20",false,getcharid(0));
		cloaknpc("Yohan#21ms20",false,getcharid(0));
	}
	if(isbegin_quest(17766) == 1){
		cloaknpc("Tris#21ms20",false,getcharid(0));
		cloaknpc("Tan#21ms20",false,getcharid(0));	
	}
end;
}

jor_mbase,143,272,5	script(CLOAKED)	Tris#21ms20	EP21_NPC_TRIS,{
	if(isbegin_quest(17757) == 1){
		cutin "ep21_tris08.png",0;
		mes "[Tris]";
		mes "You're back. That's good. You're all safe. That's a relief.";
		mes "Did you accomplish anything? Is there believers who wanted to escape? I don't see anyone with you?";
		npctalk "That's how it went.","Tan#21ms20",bc_self;
		npctalk "Yes. That's also how it turned out for us...","Yohan#21ms20",bc_self;
		next;
		cutin "ep21_ivan05.png",1;
		mes "[Ivan]";
		mes "Sigh- don't even ask. We've had such a hard time.";
		mes "If we got something, at least the struggle would have been worth it.";
		mes "Instead, it felt like three times difficult.";
		npctalk "I'm not curious about your struggles, I'm curious about the situation inside.","",bc_self;
		npctalk "Why are you like this. You and Tan are exactly the same! People, this is our captain and vice-captain!!","Ivan#21ms20",bc_self;
		next;
		cutin "ep21_tris01.png",0;
		mes "[Tris]";
		mes "You can complain later, just tell me what happened.";
		next;
		cutin "ep21_ivan05.png",1;
		mes "[Ivan]";
		mes "Alright, listen. We infiltrated the temple, right?";
		mes "There were humans believers, so we confidently went in as humans. Up to that point there were no problems.";
		next;
		cutin "ep21_ivan06.png",1;
		mes "[Ivan]";
		mes "But! When we tried to look for people looking to escape, there wasn't a single one.";
		next;
		select("Everyone seemed busy.");
		cutin "ep21_ivan02.png",1;
		mes "[Ivan]";
		mes "The fanatics were hostile towards other humans. They kept glaring at us when we were talking.";
		next;
		cutin "ep21_tris06.png",0;
		mes "[Tris]";
		mes "Hostile? Didn't you say that the cult treats human believers nicely?";
		next;
		cutin "ep21_yohan01.png",1;
		mes "[Yohan]";
		mes "If that were the case, there wouldn't be so many humans trying to escape.";
		next;
		cutin "ep21_tris01.png",0;
		mes "[Tris]";
		mes "That's true. Did you get any information about the ghost ship?";
		next;
		cutin "ep21_tan02.png",2;
		mes "[Tan]";
		mes "We didn't get even that.";
		next;
		cutin "ep21_tris07.png",0;
		mes "[Tris]";
		mes "So, you're saying you really came back empty-handed?";
		mes "It's not that I'm scolding you, I'm just trying to say. Getting back safely is already a success. Well done.";
		mes "But really, not a single clue? Nothing at all?";
		next;
		cutin "ep21_ivan02.png",1;
		mes "[Ivan]";
		mes "The only place we could actually move and have conversations was on the 1st floor.";
		mes "Yohan said there was some kind of procedure to get to the 2nd floor. They treated us like we're invisible and it was hard to talk to them.";
		npctalk "Eh, did we try?","Yohan#21ms20",bc_self;
		npctalk "Yohan...","Ivan#21ms20",bc_self;
		next;
		cutin "ep21_tris01.png",0;
		mes "[Tris]";
		mes "Yes, that place definitely seems suspicious. There must be someone there who either wants to escape or knows about the ghost ship.";
		next;
		cutin "ep21_ivan06.png",1;
		mes "[Ivan]";
		mes "That's what I'm saying. But it was hard since we're not thieves nor infiltration experts.";
		npctalk "If it was me, I would be able to do it.","Yohan#21ms20",bc_self;
		npctalk "Want to go alone right now?","Ivan#21ms20",bc_self;
		next;
		cutin "ep21_ivan02.png",1;
		mes "[Ivan]";
		mes "We need someone who can guide us to the 2nd floor. Isn't there anyone among the escapees who could help?";
		next;
		cutin "ep21_tris01.png",0;
		mes "[Tris]";
		mes "If they know something like that, they probably know about the ghost ship too.";
		mes "Most of the people who escaped were just laborers of the cult, so they probably don't know much.";
		mes "We need a better plan.";
		npctalk "How about we kidnap...","Tan#21ms20",bc_self;
		npctalk "Tan, don't even mention kidnapping again.","Ivan#21ms20",bc_self;
		next;
		cutin "ep21_tris08.png",0;
		mes "[Tris]";
		mes "Wait a minute...?";
		mes "We need someone who isn't just a regular believer and knows the inside well, right?";
		next;
		cutin "ep21_ivan04.png",1;
		mes "[Ivan]";
		mes "Yes, that's correct. Do you know someone";
		mes "Do we have such a contact?";
		next;
		cutin "ep21_tris08.png",0;
		mes "[Tris]";
		mes "It's someone you know. Tan know her too.";
		npctalk "I do? There's someone like that? Who is it? I'm curious now.","Ivan#21ms20",bc_self;
		next;
		cutin "ep21_tris09.png",0;
		mes "[Tris]";
		mes "The time to meet her is soon actually.";
		npctalk "You even have a schedule to meet her? Who is it?","Ivan#21ms20",bc_self;
		next;
		cutin "ep21_tris08.png",0;
		mes "[Tris]";
		mes "It's Nadoyo.";
		mes "The person who regularly meets with us to provide information about the cult. Remember?";
		next;
		cutin "ep21_ivan03.png",1;
		mes "[Ivan]";
		mes "...Ah!!! Right, there's that person. Someone who knows the inside even though she is not a believer. Perfect.";
		next;
		cutin "ep21_tris01.png",0;
		mes "[Tris]";
		mes "We can ask her to guide us to the 2nd floor. Even if they can't guide us, we can atleast get some information.";
		next;
		cutin "ep21_yohan02.png",1;
		mes "[Yohan]";
		mes "...So instead of rushing into the temple and struggle, wouldn't it have been better to wait and meet Nadoyo??";
		npctalk "......*Silence*.","Ivan#21ms20",bc_self;
		npctalk "Being quiet doesn't erase the fact that it was a stupid move.","Tan#21ms20",bc_self;
		next;
		cutin "ep21_tan01.png",2;
		mes "[Tan]";
		mes "We should go to the usual meeting place.";
		mes "I'll head out first.";
		cloaknpc("Tris#21ms20",true,getcharid(0));
		npctalk "Let's go together!","Ivan#21ms20",bc_self;
		completequest 17757;
		setquest 17758;
		getitem "Ep21_Wigner_Ticket",15;
		getexp 224735905,55709690;
		add_reputation_points(13,15);
		close2;
		cutin "",255;
		cloaknpc("Ivan#21ms20",true,getcharid(0));
		cloaknpc("Yohan#21ms20",true,getcharid(0));
		cloaknpc("Tan#21ms20",true,getcharid(0));
		end;
	}
	if(isbegin_quest(17766) == 1){
		if(isnpccloaked("Ivan#21ms20",getcharid(0))){
			cloaknpc("Ivan#21ms20",true,getcharid(0));
			cloaknpc("Yohan#21ms20",true,getcharid(0));
			cloaknpc("Wilhelm#21ms20",true,getcharid(0));
			cloaknpc("Carmigand#21ms20",true,getcharid(0));
			cloaknpc("Believer#21ms20",true,getcharid(0));
			cloaknpc("Believer#21ms21",true,getcharid(0));
			cloaknpc("Believer#21ms22",true,getcharid(0));
			cloaknpc("Believer#21ms23",true,getcharid(0));
			cloaknpc("Believer#21ms24",true,getcharid(0));
			cloaknpc("Believer#21ms25",true,getcharid(0));
			cloaknpc("Iana#21ms20",true,getcharid(0));
		}
		cutin "ep21_tris01.png",0;
		mes "[Tris]";
		mes "Tan! Also the adventurer. Where are the others?";
		mes "Don't tell me...?";
		next;
		cloaknpc("Ivan#21ms20",false,getcharid(0));
		cloaknpc("Yohan#21ms20",false,getcharid(0));
		cloaknpc("Wilhelm#21ms20",false,getcharid(0));
		cloaknpc("Carmigand#21ms20",false,getcharid(0));
		cloaknpc("Believer#21ms20",false,getcharid(0));
		cloaknpc("Believer#21ms21",false,getcharid(0));
		cloaknpc("Believer#21ms22",false,getcharid(0));
		cloaknpc("Believer#21ms23",false,getcharid(0));
		cloaknpc("Believer#21ms24",false,getcharid(0));
		cloaknpc("Believer#21ms25",false,getcharid(0));
		cutin "ep21_ivan01.png",1;
		mes "[Ivan]";
		mes "Alright, We made it! Rest assured, the cult's influence doesn't reach this place!";
		npctalk "Judging that there's no commotion, it looks like it went well this time.","",bc_self;
		npctalk "What is this place?","Believer#21ms22",bc_self;
		npctalk "Phew- the taste of freedom! I'm free!!","Believer#21ms23",bc_self;
		next;
		cloaknpc("Iana#21ms20",false,getcharid(0));
		cutin "ep21_iana04.png",0;
		mes "[Iana]";
		mes "Oh? Did I arrive just in time?";
		npctalk "I would like to rest. Where should I go?","Believer#21ms20",bc_self;
		npctalk "They've set this place up well.","Believer#21ms21",bc_self;
		next;
		cutin "ep21_yohan04.png",1;
		mes "[Yohan]";
		mes "Ma'am, what are you doing all the way here?";
		npctalk "Yes! Finally!!!","Believer#21ms21",bc_self;
		next;
		cutin "ep21_worker_m_04.png",2;
		mes "[Believer]";
		mes "I, want to go back to my hometown.";
		npctalk "I have nowhere to return to. Where should I go from now.","Believer#21ms25",bc_self;
		npctalk "I just want to rest for now.","Believer#21ms23",bc_self;
		next;
		cutin "ep21_ivan03.png",1;
		mes "[Ivan]";
		mes "Those who have a destination in mind and those who don't, please fill out this simple form with your details.";
		mes "After filling it up, if you want to leave, you are free to do so, and those without a place to go can stay on this places temporary accommodations we've prepared.";
		npctalk "Is it free? Do we have to pay? How much?","Believer#21ms22",bc_self;
		next;
		cutin "ep21_worker_of_03.png",2;
		mes "[Believer]";
		mes "Where exactly are we?";
		mes "Why should I trust you with my personal information?";
		npctalk "Is that really your concern now?","Believer#21ms24",bc_self;
		npctalk "What if we don't? How do we know what you'll do?","Believer#21ms20",bc_self;
		next;
		cutin "ep21_ivan03.png",1;
		mes "[Ivan]";
		mes "Come on, the information is to determine how much aid you'll need and to keep records.";
		mes "Are you comparing me to the cult? Isn't that a bit hurtful? Don't you think?";
		npctalk "Please, don't listen to these people's nonsense.","Believer#21ms25",bc_self;
		next;
		cutin "ep21_ivan06.png",1;
		mes "[Ivan]";
		mes "Trust the one who helped you escape! Can't you do it?";
		mes "I can't turn myself inside out just to prove it.";
		npctalk "The cult tricked us with words like that just to join!","Believer#21ms20",bc_self;
		npctalk "That's true, but these people must be different.","Believer#21ms22",bc_self;
		npctalk "People show their true colors when they're in a tight spot, do they?","Wilhelm#21ms20",bc_self;
		next;
		cutin "ep21_iana01.png",0;
		mes "[Iana]";
		mes "Tris, shouldn't you step in?";
		mes "Isn't there going to be a commotion when this keeps up?";
		npctalk "Yes... seems like it?","Yohan#21ms20",bc_self;
		next;
		cutin "ep21_tris01.png",0;
		mes "[Tris]";
		mes "Everyone, greetings!";
		mes "This place is Lunaforma, where the resistance against Jormungandr cult is gathered.";
		next;
		cutin "ep21_tris08.png",0;
		mes "[Tris]";
		mes "My name is Tris, and I'm in charge here.";
		mes "I understand how you must feel after all that hardship you've endured and suddenly being brought in an unfamiliar place.";
		mes "Of course. You are anxious and unsettled, correct?";
		next;
		cutin "ep21_tris01.png",0;
		mes "[Tris]";
		mes "We've been through the same. We've all experienced what you've gone through.";
		mes "That's why we understand your feelings better than anyone.";
		next;
		mes "[Tris]";
		mes "No one here will persecute you.";
		mes "We are here to bring you warmth and comfort.";
		mes "There is a hope for a better future.";
		next;
		cutin "ep21_tris08.png",0;
		mes "[Tris]";
		mes "We're all in the same situation, so please trust us and follow our lead.";
		npctalk "Is it the truth...","Believer#21ms20",bc_self;
		npctalk "Thank goodness. I was feeling hopeless.","Believer#21ms24",bc_self;
		npctalk "I think we can trust them.","Believer#21ms25",bc_self;
		next;
		cutin "ep21_worker_om_05.png",2;
		mes "[Believer]";
		mes "What about him? Are you just going to let him go?";
		npctalk "Is that really your concern?","Believer#21ms23",bc_self;
		npctalk "......","Carmigand#21ms20",bc_self;
		next;
		cutin "ep21_wilhelm02.png",1;
		mes "[Wilhelm]";
		mes "What are you talking about? Are you suggesting that we execute him here?? What do you think, Tris?";
		npctalk "Please just let me rest!","Believer#21ms21",bc_self;
		next;
		cutin "ep21_tris01.png",0;
		mes "[Tris]";
		mes "That's something that needs to go through the appropriate process.";
		npctalk "It's not something we can easily decide.","Tan#21ms20",bc_self;
		next;
		cutin "ep21_worker_om_03.png",2;
		mes "[Believer]";
		mes "He's a sinner, you can't just let him go!";
		npctalk "Exactly!! He should be sent to prison immediately!!!","Believer#21ms23",bc_self;
		npctalk "No, think about it... he helped us while we are in the cult...","Believer#21ms25",bc_self;
		next;
		cutin "ep21_ivan03.png",1;
		mes "[Ivan]";
		mes "Alright, let them decide his fate, everyone else follow me! I'll guide you to your temporary accommodations!";
		next;
		cloaknpc("Ivan#21ms20",true,getcharid(0));
		cloaknpc("Believer#21ms20",true,getcharid(0));
		cloaknpc("Believer#21ms21",true,getcharid(0));
		cloaknpc("Believer#21ms22",true,getcharid(0));
		cloaknpc("Believer#21ms23",true,getcharid(0));
		cloaknpc("Believer#21ms24",true,getcharid(0));
		cloaknpc("Believer#21ms25",true,getcharid(0));
		cutin "ep21_tris01.png",0;
		mes "[Tris]";
		mes "Let's go somewhere we can talk quietly.";
		completequest 17766;
		setquest 17767;
		close2;
		cutin "",255;
		cloaknpc("Tris#21ms20",true,getcharid(0));
		cloaknpc("Tan#21ms20",true,getcharid(0));
		cloaknpc("Yohan#21ms20",true,getcharid(0));
		cloaknpc("Iana#21ms20",true,getcharid(0));
		cloaknpc("Carmigand#21ms20",true,getcharid(0));
		cloaknpc("Wilhelm#21ms20",true,getcharid(0));
		end;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17757) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17766) == 1";
end;	
}

jor_mbase,147,274,3	script(CLOAKED)	Ivan#21ms20	EP21_NPC_IVAN,{
	if(isbegin_quest(17757) == 1){
		npctalk "Phew- that was tough. Right? It would be nice if we could rest.","",bc_self;
		end;
	}
	if(isbegin_quest(17766) == 1){
		npctalk "Phew- it was rough. Isn't it? I hope we will have the time to rest.","",bc_self;
		end;
	}
	end;
}

jor_mbase,149,273,3	script(CLOAKED)	Tan#21ms20	EP21_NPC_TAN,{
	if(isbegin_quest(17757) == 1){
		npctalk "......","",bc_self;
		end;
	}
	if(isbegin_quest(17766) == 1){
		npctalk "......","",bc_self;
		end;
	}
	end;
}

jor_mbase,146,269,1	script(CLOAKED)	Yohan#21ms20	EP21_NPC_YOHAN,{
	npctalk "Would you like some water?","",bc_self;
	end;
}

jor_mbase,143,269,5	script(CLOAKED)	Iana#21ms20	4_EP21_IANA,{
	npctalk "Good work.","",bc_self;
	end;
}

jor_mbase,150,271,3	script(CLOAKED)	Carmigand#21ms20	EP21_NPC_REINHARDT,{
	npctalk "This is where the other humans are...","",bc_self;
	end;
}

jor_mbase,149,268,1	script(CLOAKED)	Wilhelm#21ms20	EP21_NPC_WILHELM,{
	npctalk "Phew- I can finally catch my breath.","",bc_self;
	end;
}

jor_mbase,147,277,3	script(CLOAKED)	Believer#21ms20	4_EP21_M_WORKER_A,{
	npctalk "Is this place really safe?","",bc_self;
	end;
}

jor_mbase,149,277,3	script(CLOAKED)	Believer#21ms21	4_EP21_F_WORKER_A,{
	npctalk "Phew- I was so nervous... I can relax a little bit. Thank you so much.","",bc_self;
	end;
}

jor_mbase,154,274,1	script(CLOAKED)	Believer#21ms22	4_EP21_M_WORKER_B,{
	npctalk "I hope this isn't another hell... I really hope so!","",bc_self;
	end;
}

jor_mbase,153,268,1	script(CLOAKED)	Believer#21ms23	4_EP21_F_WORKER_B,{
	npctalk "Ah- this is the air of freedom!!","",bc_self;
	end;
}

jor_mbase,145,263,1	script(CLOAKED)	Believer#21ms24	4_EP21_M_WORKER_A,{
	npctalk "Sweet words is poisonous...","",bc_self;
	end;
}

jor_mbase,141,263,7	script(CLOAKED)	Believer#21ms25	4_EP21_F_WORKER_B,{
	npctalk "I want to help out too!","",bc_self;
	end;
}

jor_crk_p,71,86,0	script	#21ms40	HIDDEN_WARP_NPC,5,5,{
	end;
	
OnTouch:
	if(isbegin_quest(17758) == 1 || isbegin_quest(17759) == 1){
		cloaknpc("Tan#21ms30",false,getcharid(0));
		cloaknpc("Ivan#21ms30",false,getcharid(0));
		cloaknpc("Yohan#21ms30",false,getcharid(0));
	}
end;
}

jor_crk_p,71,86,5	script(CLOAKED)	Tan#21ms30	EP21_NPC_TAN,{
	if(isbegin_quest(17758) == 1){
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Stop. This way.";
		sleep2 900;
		cutin "",255;
		npctalk "*Cuckoo, Cuckoo*.","Nadoyo#21ms30",bc_self;
		sleep2 900;
		npctalk "Who's out there making the Cuckoo calls.","Ivan#21ms30",bc_self;
		sleep2 1000;
		npctalk "The Cuckoo lays its eggs in another birds nest.","Nadoyo#21ms30",bc_self;
		npctalk "What is happening...","Yohan#21ms30",bc_self;
		next;
		cloaknpc("Nadoyo#21ms30",false,getcharid(0));
		cutin "ep21_nadoyo05.png",2;
		mes "[Nadoyo]";
		mes "You're here. This time you made it in time.";
		mes "But, there are quite a few of you? Won't this attract too much attention? Are you sure this is fine?";
		next;
		cutin "ep21_nadoyo01.png",2;
		mes "[Nadoyo]";
		mes "Come to think of it... aren't you the one before?";
		mes "You must have been very useful for them to bring you to a place like this. Or maybe, you're on surveillance?";
		next;
		cutin "ep21_tan04.png",1;
		mes "[Tan]";
		mes "It's both. So, hows your position on the inside?";
		npctalk "What do you mean all of a sudden?","Nadoyo#21ms30",bc_self;
		npctalk "Oh, Tan! What are you suddenly saying? Let me handle this.","Ivan#21ms30",bc_self;
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "We need information about the ghost ship that's been attacking the cult.";
		mes "And while we are at it, we're also planning to help the humans escape.";
		npctalk "When we infiltrated last time... wasn't it clear that there are limits to what we can do as human believers...?","Yohan#21ms30",bc_self;
		next;
		cutin "ep21_nadoyo01.png",2;
		mes "[Nadoyo]";
		mes "It sounds like you're asking for a help, so you can move freely inside the temple, right?";
		mes "Then, how about this? Why not have a high-ranking informant who knows every matters within the cult?";
		next;
		cutin "ep21_ivan01.png",0;
		mes "[Ivan]";
		mes "Oh, that would be fantastic~ Who wouldn't want a human encyclopedia on their side, ready to answer every question on the spot~";
		npctalk "Alright. That person, and for this task. Let's help each other.","Nadoyo#21ms30",bc_self;
		next;
		cutin "ep21_nadoyo05.png",2;
		mes "[Nadoyo]";
		mes "There is a high-ranking official within the cult who wants to escape. I mentioned this briefly before, do you remember?";
		mes "At that time, it wasn't certain so I didn't bring it up, but it seems that he made up his mind already.";
		next;
		mes "[Nadoyo]";
		mes "I'll help you get into the temple, but you will help that official escape in return.";
		mes "He have all the information you need.";
		next;
		cutin "ep21_ivan04.png",0;
		mes "[Ivan]";
		mes "Wow~ a deserter? A high-ranking official from the cult who's currently ruling the continent is going to desert?";
		mes "Suddenly, this mission got really interesting.";
		npctalk "I think so too...","Yohan#21ms30",bc_self;
		next;
		cutin "ep21_tan04.png",1;
		mes "[Tan]";
		mes "Wait, what if that person is a spy?";
		next;
		cutin "ep21_nadoyo05.png",2;
		mes "[Nadoyo]";
		mes "That won't happen. I assure you. You'll understand once you meet.";
		npctalk "Alright, bring that person in. It's not hard to make people spill out the truth...","Yohan#21ms30",bc_self;
		next;
		cutin "ep21_nadoyo01.png",2;
		mes "[Nadoyo]";
		mes "This mission might not be suitable for your current party. It seems a bit lacking.";
		next;
		cutin "ep21_tan06.png",1;
		mes "[Tan]";
		mes "Do you think we are lacking in skill?";
		npctalk "I'm starting to feel a bit offended...","Yohan#21ms30",bc_self;
		next;
		cutin "ep21_nadoyo01.png",2;
		mes "[Nadoyo]";
		mes "That's not it. We need someone with a specific look for this mission.";
		next;
		cutin "ep21_nadoyo05.png",2;
		mes "[Nadoyo]";
		mes "We need a young human male with long black hair.";
		mes "Their height should be the same to Tan or a little bit taller, and the body should not be too bulky.";
		mes "A neat appearance with a cold look would be ideal.";
		next;
		cutin "ep21_yohan01.png",1;
		mes "[Yohan]";
		mes "Is there someone like that in Lunaforma...? Where are we supposed to find that kind of person...?";
		mes "Add to that, a long hair out of nowhere... is there a way to grow your hair suddenly...?";
		npctalk "When there's a will, there's a way.","Nadoyo#21ms30",bc_self;
		npctalk "You... sound like a real cultist.","Yohan#21ms30",bc_self;
		npctalk "Hm...","Ivan#21ms30",bc_self;
		next;
		cutin "ep21_nadoyo05.png",2;
		mes "[Nadoyo]";
		mes "Try to find someone quickly. If you can't find someone, Tan can always wear a wig, right?";
		npctalk "I like this plan suddenly.","Yohan#21ms30",bc_self;
		npctalk "......","Tan#21ms30",bc_self;
		npctalk "Hmm...","Ivan#21ms30",bc_self;
		next;
		cutin "ep21_nadoyo01.png",2;
		mes "[Nadoyo]";
		mes "Also, it would be perfect if that person could fight.";
		npctalk "Would it matter if they can't?","Tan#21ms30",bc_self;
		npctalk "If they can't, then your work will be more difficult. Either way, it won't make a big difference.","Nadoyo#21ms30",bc_self;
		next;
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "...Let's meet in front of the temple.";
		next;
		cutin "ep21_nadoyo01.png",2;
		mes "[Nadoyo]";
		mes "Do you mean in the Raised Land? Alright. I'll wait in that area.";
		mes "But, you need to hurry, we don't have much time.";
		next;
		cloaknpc("Nadoyo#21ms30",true,getcharid(0));
		cutin "ep21_yohan01.png",1;
		mes "[Yohan]";
		mes "We need to find someone right away... If we don't have anyone, maybe we can look into the escapees also...";
		mes "Things just got busy.";
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "Uhm, I need to talk for a second.";
		completequest 17758;
		setquest 17759;
		questinfo_refresh;
		close3;
	}
	cutin "ep21_tan02.png",1;
	mes "[Tan]]";
	mes "It looks like Ivan has an idea.";
	close3;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17758) == 1";
end;	
}

jor_crk_p,69,85,5	script(CLOAKED)	Ivan#21ms30	EP21_NPC_IVAN,{
	if(isbegin_quest(17758) == 1){
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "The vice-captain knows the meeting place, right?";
		close3;
	}
	if(isbegin_quest(17759) == 1){
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "About the person Nadoyo mentioned.";
		mes "Actually, there's someone who comes to mind that fits Nadoyo's condition perfectly, I think?";
		npctalk "Who?","Tan#21ms30",bc_self;
		next;
		cutin "ep21_ivan06.png",0;
		mes "[Ivan]";
		mes "As each conditioned was mentioned, a specific face kept popping into my head...";
		mes "Yes, I can't think of anyone else except but that person.";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "If you have someone in mind, is there a problem with us bringing them?";
		next;
		cutin "ep21_ivan06.png",0;
		mes "[Ivan]";
		mes "That person is just someone who's helping the escapees that we are supporting...";
		next;
		select("Oh, a philanthropist.");
		cutin "ep21_ivan05.png",0;
		mes "[Ivan]";
		mes "Uhm, how should I put it... his way of thinking and speaking is well... rather free-spirited.";
		npctalk "Is there a problem with being free-spirited?","Tan#21ms30",bc_self;
		next;
		cutin "ep21_ivan06.png",0;
		mes "[Ivan]";
		mes "He has a bit of a strong personality...";
		npctalk "So he has guts?","Tan#21ms30",bc_self;
		next;
		cutin "ep21_ivan05.png",0;
		mes "[Ivan]";
		mes "The gap between his thoughts and words is around 0.1 second... no, it's like there is no gap at all... from the sidelines it's a bit much...";
		npctalk "So, he is an unpleasant person...?","Yohan#21ms30",bc_self;
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "... in other words, he is a troublemaker. Why is someone like that helping with that kind of work?";
		next;
		cutin "ep21_ivan02.png",0;
		mes "[Ivan]";
		mes "Well. I'm wondering about that too. His personality doesn't match someone who'd do that kind of work.";
		mes "Anyway, that's not the important, he perfectly fits the conditions Nadoyo mentioned.";
		next;
		cutin "ep21_ivan06.png",0;
		mes "[Ivan]";
		mes "Well, I can't get anyone else in mind after all...";
		mes "Am I getting too fixated on him? Is it just me being selfish?";
		npctalk "Let's go talk to him first.","Tan#21ms30",bc_self;
		next;
		cutin "ep21_ivan05.png",0;
		mes "[Ivan]";
		mes "Don't expect him to join right away.";
		mes "Lower your expectation, so you won't be disappointed. Consider yourself warned!";
		completequest 17759;
		setquest 17760;
		close2;
		cutin "",255;
		cloaknpc("Tan#21ms30",true,getcharid(0));
		cloaknpc("Ivan#21ms30",true,getcharid(0));
		cloaknpc("Yohan#21ms30",true,getcharid(0));
		end;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17759) == 1";
end;	
}

jor_crk_p,72,83,1	script(CLOAKED)	Yohan#21ms30	EP21_NPC_YOHAN,{
	npctalk "This place... I'd like to take a closer look sometime...","",bc_self;
	end;
}

jor_crk_p,74,86,3	script(CLOAKED)	Nadoyo#21ms30	EP21_NPC_NADOYO,{
	npctalk "Aren't you well-trusted now?","",bc_self;
	end;
}

jor_mbase,166,302,0	script	#21ms41	HIDDEN_WARP_NPC,5,5,{
	end;
	
OnTouch:
	if(isbegin_quest(17760) == 1){
		cloaknpc("Ivan#21ms40",false,getcharid(0));
		cloaknpc("Tan#21ms40",false,getcharid(0));
		cloaknpc("Yohan#21ms40",false,getcharid(0));
	}
end;
}

jor_mbase,166,302,5	script(CLOAKED)	Ivan#21ms40	EP21_NPC_IVAN,{
	if(isbegin_quest(17760) == 1){
		cutin "ep21_ivan03.png",1;
		mes "[Ivan]";
		mes "Over here. Wait here for a moment.";
		mes "Has anyone seen Wilhelm? Can you bring him over?";
		next;
		cloaknpc("Wilhelm#21ms40",false,getcharid(0));
		cutin "ep21_wilhelm01.png",2;
		mes "[Wilhelm]";
		mes "Ivan? Did you call me? Why? I'm busy.";
		next;
		cutin "ep21_yohan04.png",0;
		mes "[Yohan]";
		mes "...! Vice-captain. Congratulations... you won't need to wear a wig now...";
		mes "I can see why Ivan thought of him right away...";
		next;
		select("He fits the condition perfectly.");
		cutin "ep21_ivan04.png",0;
		mes "[Ivan]";
		mes "Wilhelm. you're not too busy, right? The reason I called you today is because.";
		npctalk "He's lonely.","Yohan#21ms40",bc_self;
		npctalk "Who said that!","Ivan#21ms40",bc_self;
		next;
		cutin "ep21_wilhelm02.png",2;
		mes "[Wilhelm]";
		mes "Did you call me just to joke around? I'm busy, didn't I tell?";
		mes "I'm leaving. Don't call me for this kind of thing again. It's annoying.";
		npctalk "No!! No, No!! I really have something important to discuss.","Ivan#21ms40",bc_self;
		next;
		cutin "ep21_tan04.png",1;
		mes "[Tan]";
		mes "You need to come with us somewhere.";
		next;
		cutin "ep21_ivan03.png",0;
		mes "[Ivan]";
		mes "Oh, Tan! Tan, Tan! If you say it like that, he'll get the wrong idea! Just hold on for a second!";
		mes "The thing is, Wilhelm. I need you to pause what you're currently doing and come with is somewhere.";
		next;
		cutin "ep21_wilhelm01.png",2;
		mes "[Wilhelm]";
		mes "Isn't that the same thing what the vice-captain said?";
		mes "It doesn't concern me.";
		next;
		cutin "ep21_ivan03.png",1;
		mes "[Ivan]";
		mes "No, listen! I haven't told you what we need to do yet.";
		npctalk "What did you ate for lunch that's making you impatient?","Ivan#21ms40",bc_self;
		next;
		cutin "ep21_wilhelm04.png",2;
		mes "[Wilhelm]";
		mes "My job is to help the believers who escaped.";
		mes "I just came from listening to someone complain their spoon is smaller than the person next to them. At this rate, I'll start carving spoon myself.";
		next;
		cutin "ep21_ivan01.png",0;
		mes "[Ivan]";
		mes "Yeah, I get what you're going through. I know you're busy, that's why I didn't want to ask but we have no choice.";
		mes "You're the only one who fits the condition.";
		npctalk "Ivan... why is he so desperate?","Yohan#21ms40",bc_self;
		next;
		cutin "ep21_wilhelm05.png",2;
		mes "[Wilhelm]";
		mes "What conditions? It has nothing to do with me. I'm not interested. I'll just do my job here.";
		npctalk "Wi- wi- wi- Wilhelm, just listen a bit. You might find it interesting, don't you think?","Ivan#21ms40",bc_self;
		next;
		cutin "ep21_tan01.png",0;
		mes "[Tan]";
		mes "Wilhelm, was it? Why are you helping out here?";
		mes "You don't look like the type to work in this kind of place willingly. From what I've heard you've been here quite a while.";
		npctalk "Argh- Tan, why, why are you doing this!","Ivan#21ms40",bc_self;
		next;
		cutin "ep21_wilhelm04.png",2;
		mes "[Wilhelm]";
		mes "Is working here a problem? Are you picking a fight with me?";
		mes "If you want to fight, let's get it over quickly. I don't have time.";
		next;
		cutin "ep21_tan01.png",0;
		mes "[Tan]";
		mes "You're looking for someone that is connected to the cult.";
		mes "...... Are you looking for someone related to you?";
		next;
		cutin "ep21_wilhelm04.png",2;
		mes "[Wilhelm]";
		mes "...Are you spying on me? That's creepy.";
		next;
		cutin "ep21_tan02.png",0;
		mes "[Tan]";
		mes "You don't need a spy to figure it out, it's obvious.";
		mes "There are only two reasons to work at a place that doesn't pay, either you are an extreme philanthropist or you have a purpose.";
		next;
		cutin "ep21_tan01.png",0;
		mes "[Tan]";
		mes "Since this is where most people escaped from the cult gather, you're sticking around hoping to find someone that is related to the cult.";
		npctalk "So, it's not by a bet... that you became a vice-captain...","Yohan#21ms40",bc_self;
		next;
		cutin "ep21_ivan01.png",1;
		mes "[Ivan]";
		mes "Oh~ Is that it? Are you looking for someone among the people who escaped? Who is it?";
		mes "Great. That's perfect because what we wanted to ask you about was joining us in infiltrating the cult's temple.";
		next;
		cutin "ep21_wilhelm01.png",2;
		mes "[Wilhelm]";
		mes "Infiltrating... the cult's temple? How?";
		npctalk "Now... he's suddenly more cooperative...","Yohan#21ms40",bc_self;
		next;
		cutin "ep21_ivan04.png",0;
		mes "[Ivan]";
		mes "Now you're interested, aren't you? Have you heard about the ghost ship?";
		mes "Some of the refugees here were rescued after their ship was attacked by that ghost ship.";
		npctalk "Right. But what does it have to do with infiltrating the cult?","Wilhelm#21ms40",bc_self;
		next;
		cutin "ep21_ivan03.png",0;
		mes "[Ivan]";
		mes "We're trying to get information about the ghost ship by infiltrating the cult, and we need someone who looks like you for the job.";
		mes "Aren't you the only one who looks like yourself? That's the reason we're asking you.";
		mes "This is something only you can do. Do you understand?";
		npctalk "I still don't understand why someone who looks like me is needed to infiltrate the cult.","Wilhelm#21ms40",bc_self;
		next;
		cutin "ep21_ivan01.png",0;
		mes "[Ivan]";
		mes "Don't you use a dagger? Your combat skills will come in handy, it's perfect!";
		next;
		cutin "ep21_wilhelm01.png",2;
		mes "[Wilhelm]";
		mes "I do use a dagger... But are we going to attack the cult? Why do you need someone who looks like me? The more I hear, the less sense it makes.";
		npctalk "Do you think we're going to charge in recklessly with just this people? Don't worry, that's not what we're doing.","Ivan#21ms40",bc_self;
		next;
		cutin "ep21_tan01.png",0;
		mes "[Tan]";
		mes "Our main goal of this mission is to rescue people who wants to escape the cult.";
		next;
		cutin "ep21_ivan03.png",1;
		mes "[Ivan]";
		mes "Exactly. Isn't it pretty straightforward? We are mentioning your skills just in case something happens. Don't worry, just relax.";
		next;
		cutin "ep21_tan01.png",0;
		mes "[Tan]";
		mes "Since you'll be meeting more people at the temple, it's not a bad offer for you either, isn't it?";
		npctalk "Infiltrate... the cult...","Wilhelm#21ms40",bc_self;
		next;
		cutin "ep21_ivan04.png",1;
		mes "[Ivan]";
		mes "Yes. Isn't it great? Come with us. If you haven't found the person you're looking for yet, you might find them there, don't you think? It's the cult's headquarters after all.";
		mes "At the very least, you might meet someone who knows the person you're looking for, right?";
		next;
		cutin "ep21_wilhelm05.png",2;
		mes "[Wilhelm]";
		mes "...Alright. What do I need to do?";
		next;
		cutin "ep21_ivan03.png",0;
		mes "[Ivan]";
		mes "That? We'll figure it out once we're there.";
		mes "If you don't have anything else to prepare, let's go right now.";
		completequest 17760;
		setquest 17761;
		close2;
		cutin "",255;
		cloaknpc("Ivan#21ms40",true,getcharid(0));
		cloaknpc("Tan#21ms40",true,getcharid(0));
		cloaknpc("Yohan#21ms40",true,getcharid(0));
		cloaknpc("Wilhelm#21ms40",true,getcharid(0));
		end;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17760) == 1";
end;
}

jor_mbase,165,304,5	script(CLOAKED)	Tan#21ms40	EP21_NPC_TAN,{
	npctalk "Who are we looking for?","",bc_self;
	end;
}

jor_mbase,163,302,5	script(CLOAKED)	Yohan#21ms40	EP21_NPC_YOHAN,{
	npctalk "That conditions... do you really think there's someone who fits it?","",bc_self;
	end;
}

jor_mbase,169,299,1	script(CLOAKED)	Wilhelm#21ms40	EP21_NPC_WILHELM,{
	npctalk "I'm really busy. It's not like you'll do my job for me.","",bc_self;
	end;
}

mbase_in,118,186,3	script	Reinhardt#21ms50	EP21_NPC_REINHARDT,5,5,{
	if(isbegin_quest(17767) == 1){
		cutin "ep21_reinhardt06.png",2;
		mes "[Carmigand]";
		mes "Wil looks like he's on the verge of exploding.";
		close3;
	}
	if(isbegin_quest(17768) == 1){
		cutin "ep21_reinhardt06.png",0;
		mes "[Reinhardt]";
		mes "The cult refers to that ghost ship as the Blue-Eyed Monster.";
		next;
		cutin "ep21_reinhardt01.png",0;
		mes "[Reinhardt]";
		mes "The surviving sailors from the cult have all testified that a monster with three blue eyes emerges from the fog during the night.";
		mes "Their last memory is seeing those eyes, and when they came to their ship was already shattered.";
		npctalk "The Blue-Eyed Monster? Who named that? It's both romantic and not at the same time.","Wilhelm#21ms50",bc_self;
		npctalk "That name, sounds eerie. Is it really a ghost ship?","Tris#21ms50",bc_self;
		next;
		cutin "ep21_iana02.png",2;
		mes "[Iana]";
		mes "Three blue eyes... It's sounds like the ship's sternlight. The ship that we're looking for has the same feature.";
		next;
		cutin "ep21_reinhardt01.png",0;
		mes "[Reinhardt]";
		mes "The cult suffered significant losses after several of its supply ships were attacked, so they sent out several ships to deal with it, but it all failed.";
		next;
		cutin "ep21_reinhardt06.png",0;
		mes "[Reinhardt]";
		mes "The ships that was sent out were also attacked, increasing the damage. However, they manage to pinpoint the exact location where it attacks and identify some key features.";
		next;
		cutin "ep21_reinhardt01.png",0;
		mes "[Reinhardt]";
		mes "The location is about ten days journey from the southeast of the cult's eastern port.";
		mes "It's where two currents from different seas meet making it a treacherous area to navigate to.";
		next;
		cutin "ep21_iana02.png",2;
		mes "[Iana]";
		mes "Hm, that also matches the testimonies of the rescued sailor.";
		mes "It seems like this is the ship we've been searching for.";
		next;
		cutin "ep21_reinhardt01.png",0;
		mes "[Reinhardt]";
		mes "They had issue dealing with it, so the cult eventually abandoned that route and after conducting trials, they developed a new route.";
		next;
		cutin "ep21_iana02.png",2;
		mes "[Iana]";
		mes "Wait, a new route? It's the first time we've heard of it, right? Wouldn't taking a new route cause more losses?";
		mes "It would mean going farther or establishing a new port of trade.";
		next;
		cutin "ep21_reinhardt06.png",0;
		mes "[Reinhardt]";
		mes "It happened when the cult was also in the process of changing its main trade items, they are planning to increase the number of ships that will use this new route soon.";
		mes "This is related to a shift in the cult's recent policies. Did you notice that the cult seems weaker lately?";
		next;
		cutin "ep21_tris11.png",2;
		mes "[Tris]";
		mes "A little? I did notice that the cult's action seemed less forceful than before. their unity weakened, and there haven't been that many strong figures appearing in disputed areas.";
		next;
		cutin "ep21_reinhardt01.png",0;
		mes "[Reinhardt]";
		mes "Humans are highly sensitive anything related to survival. It seems that the resistance has caught on it and kept pressuring the cult.";
		next;
		cutin "ep21_tan01.png",0;
		mes "[Tan]";
		mes "Did anything happen in the cult recently? Internal conflict? You didn't seem to get along with the other high priest. Is it related to why you left the order?";
		next;
		cutin "ep21_reinhardt07.png",2;
		mes "[Reinhardt]";
		mes "The order has been on the decline lately. Only a select few within the cult know the reason, and I'm not one of the select few.";
		next;
		cutin "ep21_tan01.png",0;
		mes "[Tan]";
		mes "So you betrayed the cult because it was weakening?";
		next;
		cutin "ep21_reinhardt04.png",2;
		mes "[Reinhardt]";
		mes "Quite the opposite. I was only waiting for the right moment to defect.";
		next;
		cutin "ep21_tris05.png",2;
		mes "[Tris]";
		mes "You weren't informed of the internal situation even though you are a high-ranking official and served the cult for a long time.";
		mes "Was it because...";
		next;
		cutin "ep21_reinhardt04.png",0;
		mes "[Reinhardt]";
		mes "Because I'm a human. I knew almost everything related to the cult, but they kept particular information strictly hidden.";
		next;
		cutin "ep21_tris05.png",2;
		mes "[Tris]";
		mes "Because you're a human... it means that it's connected to the cult's main force weakness. It didn't matter what position you were because they can't trust a human priest with that information.";
		next;
		cutin "ep21_reinhardt01.png",0;
		mes "[Reinhardt]";
		mes "The cult found itself walking on thin ice. They started capturing more humans as they were limited Rgans who can actually work.";
		mes "But those captured humans were treated poorly. Many of the human believers were unable to endure the oppression and started leaving in huge numbers.";
		next;
		cutin "ep21_reinhardt06.png",0;
		mes "[Reinhardt]";
		mes "As a result, they got more and more weaker. If they continue to be cornered, they will do whatever it takes to overcome the situation by using any means necessary. It would be wise to prepare for it.";
		npctalk "Hm... the order is getting weak for unknown reason and they're likely to do something drastic soon... it's a tricky situation.","Tan#21ms50",bc_self;
		next;
		cutin "ep21_tris11.png",2;
		mes "[Tris]";
		mes "Tricky situation. There's a weakness, but we don't know what it is.";
		mes "We'll just have to keep doing what we've been doing. Our efforts haven't been in vain so far.";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Alright, let's wrap up this conversation. Priest, take some rest. Wilhelm will stay behind, if you need anything, ask your brother.";
		mes "It would be good to use this time to catch up after all this time.";
		npctalk "What? Me? That's not necessary. I have other things to do you know.","Wilhelm#21ms50",bc_self;
		npctalk "You won't be confined, but you'll still be under surveillance.","Tris#21ms50",bc_self;
		next;
		cutin "ep21_iana02.png",1;
		mes "[Iana]";
		mes "We should head back and report what we've learned about the ghost ship.";
		mes "Let's go, Yohan.";
		completequest 17768;
		setquest 17769;
		questinfo_refresh;
		getitem "Ep21_Wigner_Ticket",30;
		getexp 547793770,239980220;
		add_reputation_points(13,30);
		close2;
		cutin "",255;
		cloaknpc("Tris#21ms50",true,getcharid(0));
		cloaknpc("Tan#21ms50",true,getcharid(0));
		cloaknpc("Iana#21ms50",true,getcharid(0));
		cloaknpc("Yohan#21ms50",true,getcharid(0));
		end;
	}
	if(isbegin_quest(17768) == 2 && isbegin_quest(17770) == 0){
		cutin "ep21_reinhardt07.png",2;
		mes "[Reinhardt]";
		mes "I'm curious about what Wil is thinking.";
		close3;
	}
	if(isbegin_quest(17770) == 1){
		cutin "ep21_reinhardt07.png",2;
		mes "[Reinhardt]";
		mes "I am truly sorry. At the time, I was so disillusioned with everything in my life, I didn't have a choice.";
		next;
		cutin "ep21_reinhardt04.png",2;
		mes "[Reinhardt]";
		mes "I can't even remember what our childhood was like.";
		next;
		cutin "ep21_wilhelm04.png",0;
		mes "[Wilhelm]";
		mes "I spent a warm and happy times with our parents and also with you, brother. But you destroyed all of that.";
		next;
		cutin "ep21_reinhardt02.png",2;
		mes "[Reinhardt]";
		mes "Yes. A harmonious family, a life full of wealth and comfort.";
		mes "I thought everyone lived that way. I was young and naive about the world.";
		next;
		cutin "ep21_reinhardt05.png",2;
		mes "[Reinhardt]";
		mes "It was nothing like that. It was a privilege only a few can enjoy.";
		mes "Many people had to worry about their next meal and their very survival.";
		mes "I wanted to save them all.";
		npctalk "There's no way you could have save all of them. That's arrogance.","Wilhelm#21ms50",bc_self;
		next;
		cutin "ep21_reinhardt02.png",2;
		mes "[Reinhardt]";
		mes "That's the reason why I abandoned everything and devoted myself to the church that promised a paradise for everyone.";
		next;
		cutin "ep21_wilhelm02.png",0;
		mes "[Wilhelm]";
		mes "Look at how that turned out. Did the cult keep any of that promise? Didn't they pave a way to suffering? You were at the center of that.";
		mes "I truly can't understand your thinking. I don't even want to understand it.";
		next;
		cutin "ep21_wilhelm05.png",0;
		mes "[Wilhelm]";
		mes "I'm going to follow our parents advice and think of you as someone who no longer exist. You've always been in my heart, but it's time to bury those feelings.";
		next;
		cutin "ep21_reinhardt05.png",2;
		mes "[Reinhardt]";
		mes "...I thought saving those people would be my most difficult task, but it seems that earning your trust is. I will try my best.";
		next;
		cutin "ep21_wilhelm04.png",0;
		mes "[Wilhelm]";
		mes "There is no need for that. It would be better for both of us to live as if we don't know each other.";
		mes "I'm going to do my work now. Brother, you should rest.";
		next;
		cutin "ep21_reinhardt07.png",2;
		mes "[Reinhardt]";
		mes "I noticed a lot of monsters on the way here. It must have been difficult to deal with them. If people are using that route to escape, they'll likely face the same challenges.";
		next;
		cutin "ep21_reinhardt01.png",2;
		mes "[Reinhardt]";
		mes "The cult will be very vigilant for some time, that route can't be used immediately, but it would be wise to prepare it for future use.";
		npctalk "Are you planning to do it yourself?","Wilhelm#21ms50",bc_self;
		npctalk "If I am able to.","Reinhardt#21ms50",bc_self;
		next;
		cutin "ep21_wilhelm05.png",0;
		mes "[Wilhelm]";
		mes "I will tell the commander, you should rest.";
		next;
		cloaknpc("Wilhelm#21ms50",true,getcharid(0));
		cutin "ep21_reinhardt02.png",2;
		mes "[Reinhardt]";
		mes "......";
		next;
		select("I'll also be on my way...");
		cutin "ep21_reinhardt05.png",2;
		mes "[Reinhardt]";
		mes "Sorry to ask this, but I would appreciate it if you could follow Wilhelm.";
		mes "He must be feeling very conflicted, and it would be good for him to have a companion by his side.";
		next;
		cutin "ep21_reinhardt04.png",2;
		mes "[Reinhardt]";
		mes "He's a very sensitive soul and I'm worried about him. Please take care of him.";
		completequest 17770;
		setquest 17771;
		close3;
	}
	if(isbegin_quest(17771) == 1){
		cutin "ep21_reinhardt05.png",2;
		mes "[Reinhardt]";
		mes "I would appreciate it if you could follow Wilhelm. He's a very sensitive soul and I'm worried about him.";
		close3;
	}
	if(isbegin_quest(17772) == 1){
		cutin "ep21_reinhardt01.png",1;
		mes "[Reinhardt]";
		mes "You're back. How was Wil?";
		mes "What did he say?";
		next;
		select("He went to work without saying anything.");
		cutin "ep21_reinhardt07.png",1;
		mes "[Reinhardt]";
		mes "He must have been hurt a lot. I wanted to talk with him more.";
		mes "To open his heart and gain his trust, it's not easy. It's all because of my foolishness...";
		next;
		cloaknpc("Tris#21ms50",false,getcharid(0));
		cloaknpc("Lunaforma Worker#21ms50",false,getcharid(0));
		cloaknpc("Lunaforma Worker#21ms51",false,getcharid(0));
		cutin "ep21_tris08.png",2;
		mes "[Tris]";
		mes "Reinhardt? Do you have a moment?";
		next;
		cutin "ep21_reinhardt01.png",0;
		mes "[Reinhardt]";
		mes "Welcome. Looks like it's an important matter.";
		mes "Who are these people...?";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "They work at Lunaforma.";
		mes "They said they really want to talk to you, so I brought them here.";
		mes "Please go ahead and talk to them.";
		next;
		cutin "ep21_worker_om_04.png",1;
		mes "[Lunaforma Worker]";
		mes "Hello. Carmigand. Or should we call Reinhardt now? Rumors say that you're the eldest son of the Lugenburg couple, is that true? And Wilhelm is your younger brother.";
		next;
		cutin "ep21_worker_of_04.png",1;
		mes "[Lunaforma Worker]";
		mes "I didn't hear anything about that. No one mentioned it to me.";
		next;
		cutin "ep21_reinhardt06.png",0;
		mes "[Reinhardt]";
		mes "How did you know...";
		mes "That's correct, where did you hear that?";
		next;
		cutin "ep21_worker_of_04.png",1;
		mes "[Lunaforma Worker]";
		mes "The rumors are everywhere. This place is small after all.";
		mes "We were among those who were helped by the Lugenburg couple.";
		next;
		cutin "ep21_worker_om_04.png",1;
		mes "[Lunaforma Worker]";
		mes "There's probably no one in the central area who hasn't received their help.";
		mes "The couple helped many people who were persecuted by the cult. They were good people. After left, we didn't hear anything from them until the news of their passing.";
		next;
		cutin "ep21_worker_of_04.png",1;
		mes "[Lunaforma Worker]";
		mes "But to hear that their sons were also helping people in need, it's a touching story";
		next;
		cutin "ep21_worker_om_04.png",1;
		mes "[Lunaforma Worker]";
		mes "Well, the other one didn't exactly help. He was a high priest in the cult.";
		next;
		cutin "ep21_worker_of_04.png",1;
		mes "[Lunaforma Worker]";
		mes "Still, he still helped people in there. I heard that he's the one who convinced the other people to escape.";
		next;
		cutin "ep21_worker_om_04.png",1;
		mes "[Lunaforma Worker]";
		mes "In the first place, he didn't have to go there. I can't believe someone with such parents ended up becoming a high priest in the cult.";
		next;
		cutin "ep21_tris08.png",2;
		mes "[Tris]";
		mes "Now now, that's not why we are here. If you were going to talk about this, I wouldn't have brought you here.";
		next;
		cutin "ep21_worker_of_04.png",1;
		mes "[Lunaforma Worker]";
		mes "This one talked too much. I apologize. We received a lot of help from your parents, so I wanted to thank you in their stead.";
		next;
		cutin "ep21_reinhardt04.png",0;
		mes "[Reinhardt]";
		mes "I should be the one thanking you. To meet those who were helped by my parents... It's not something I deserve, but I'm sure my parents would understand.";
		next;
		cutin "ep21_worker_of_04.png",1;
		mes "[Lunaforma Worker]";
		mes "You must be tired, so you better rest. I am not someone who forgets a debt. Let me know if you need any help. Just bring it up to me.";
		next;
		cloaknpc("Lunaforma Worker#21ms50",true,getcharid(0));
		cloaknpc("Lunaforma Worker#21ms51",true,getcharid(0));
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Is this your first time hearing this?";
		next;
		cutin "ep21_reinhardt05.png",0;
		mes "[Reinhardt]";
		mes "I'm not worthy of such gratitude.";
		mes "I briefly heard it from Wil, but I never expected to meet someone who was helped by my parents. There's a lot of stories that I don't know...";
		next;
		cutin "ep21_tris09.png",2;
		mes "[Tris]";
		mes "If you don't know, you can just ask. There's someone next to you who knows everything.";
		mes "This is a good chance to introduce you to Lunaforma. Let's go.";
		next;
		cutin "ep21_reinhardt07.png",0;
		mes "[Reinhardt]";
		mes "If I show myself, people will be agitated.";
		mes "It's better to stay here...";
		next;
		cutin "ep21_tris08.png",2;
		mes "[Tris]";
		mes "You need to face it. Depending what you do from now, isn't there a chance that you might change the people's heart?";
		mes "You can't stay here forever. That's really self-imposed judgement.";
		next;
		cutin "ep21_reinhardt04.png",0;
		mes "[Reinhardt]";
		mes "I understand.";
		mes "I will follow you.";
		completequest 17772;
		setquest 17773;
		close2;
		cloaknpc("Tris#21ms50",true,getcharid(0));
		cutin "",255;
		end;
	}
	if(isbegin_quest(17773) == 1){
		cutin "ep21_reinhardt02.png",2;
		mes "[Reinhardt]";
		mes "I'm a bit worried about facing the people.";
		close3;
	}
	cutin "ep21_reinhardt01.png",2;
	mes "[Reinhardt]";
	mes "I'm thinking about what to do here.";
	close3;

OnTouch:
	if(isbegin_quest(17767) == 1 || isbegin_quest(17768) == 1){
		cloaknpc("Wilhelm#21ms50",false,getcharid(0));
		cloaknpc("Tris#21ms50",false,getcharid(0));
		cloaknpc("Tan#21ms50",false,getcharid(0));
		cloaknpc("Iana#21ms50",false,getcharid(0));
		cloaknpc("Yohan#21ms50",false,getcharid(0));
		end;
	}
	if(isbegin_quest(17768) == 2 && isbegin_quest(17770) == 0 || isbegin_quest(17770) == 1 || isbegin_quest(17776) == 2){
		cloaknpc("Wilhelm#21ms50",false,getcharid(0));
		end;
	}
end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17768) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17770) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17772) == 1";
end;
}

mbase_in,115,182,7	duplicate(dummynpc)	Lunaforma Worker#21ms50	4_EP21_M_WORKER_A
mbase_in,115,184,7	duplicate(dummynpc)	Lunaforma Worker#21ms51	4_EP21_F_WORKER_B

mbase_in,116,186,5	script(CLOAKED)	Wilhelm#21ms50	EP21_NPC_WILHELM,{
	if(isbegin_quest(17767) == 1){
		cutin "ep21_wilhelm02.png",0;
		mes "[Wilhelm]";
		mes "Isn't this basically a confinement? Right? It seems like it, yes?";
		next;
		cutin "ep21_wilhelm05.png",0;
		mes "[Wilhelm]";
		mes "Why go to trouble of confining someone? It's not like he's going to run away. I understand the sentiment but the crime hasn't been proven yet.";
		mes "I'm just curious but not complaining. Why go the trouble?";
		next;
		cutin "ep21_tris06.png",2;
		mes "[Tris]";
		mes "Calm down, this is for his safety.";
		mes "Haven't you seen the angry crowd outside? While many still follow him, there is also plenty who holds a grudge against him.";
		next;
		cutin "ep21_tris07.png",2;
		mes "[Tris]";
		mes "Crowds are unpredictable, they could turn on you any moment, and do who knows what.";
		mes "With that said, he won't be treated like a high priest here. There's no reason to.";
		npctalk "I would prefer that.","Reinhardt#21ms50",bc_self;
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Carmigand. We need to talk.";
		next;
		cutin "ep21_reinhardt01.png",1;
		mes "[Carmigand]";
		mes "Yes. Go ahead. I'm listening.";
		next;
		cutin "ep21_tris11.png",2;
		mes "[Tris]";
		mes "I heard that you'll provide us information if we help you escape.";
		next;
		cutin "ep21_reinhardt07.png",1;
		mes "[Carmigand]";
		mes "Before we begin, I need to address something.";
		mes "I've already abandoned the cult, so I'd like you to call me by my name.";
		mes "Reinhardt Lugenburg. It's the name that I left behind before.";
		npctalk "Lugenburg? Then, if that's the case...","Tris#21ms50",bc_self;
		next;
		cutin "ep21_reinhardt05.png",1;
		mes "[Reinhardt]";
		mes "It's embarassing to use the name that I left behind, but please......";
		npctalk "......","Wilhelm#21ms50",bc_self;
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Alright, Reinhardt. Can you provide us information about the cult?";
		next;
		cutin "ep21_reinhardt01.png",1;
		mes "[Reinhardt]";
		mes "As someone who was saved, caused a lot of suffering, and who desires to end all of this tyranny quickly.";
		mes "I'll do my utmost to provide you with all the information that I have.";
		next;
		cutin "ep21_iana02.png",2;
		mes "[Iana]";
		mes "I'm still not entirely convinced that you truly abandoned the cult.";
		mes "Since we are desperate for information. What if you're just pretending to defect to spy on us?";
		next;
		cutin "ep21_wilhelm04.png",0;
		mes "[Wilhelm]";
		mes "You don't have to worry about that. If he were someone who could tolerate even the slightest doubt about his faith, he wouldn't have left everything behind, including his own family.";
		next;
		cutin "ep21_iana01.png",2;
		mes "[Iana]";
		mes "Why do you talk like you know him well? Wait? Now that I look at you, aren't your face alike?";
		next;
		cutin "ep21_yohan02.png",1;
		mes "[Yohan]";
		mes "Yes...? Are you two brothers or something...? Maybe you are like, a long-lost sibling...?";
		next;
		cutin "ep21_wilhelm02.png",0;
		mes "[Wilhelm]";
		mes "... If you're going to make a joke, you might want to consider if what you're saying is probably true.";
		next;
		cutin "ep21_iana01.png",2;
		mes "[Iana]";
		mes "Oh, so it was true?? I didn't know.";
		mes "Yohan didn't mean to offend you. He wouldn't want to make fun of your family history, don't take it too personally.";
		npctalk "Yes, that's right...","Yohan#21ms50",bc_self;
		next;
		cutin "ep21_reinhardt01.png",1;
		mes "[Reinhardt]";
		mes "Wil, It seems that you've built some trust here, letting them know that we are brothers might undermine that.";
		mes "That was a mistake.";
		next;
		cutin "ep21_wilhelm04.png",0;
		mes "[Wilhelm]";
		mes "It's fine. I haven't built enough trust for it to be a concern anyway.";
		npctalk "If you put it that way... It make us look bad...","Yohan#21ms50",bc_self;
		npctalk "Really? Do you really trust me that much? Then, can you lend me some Zeny? Say, about 1 million Zeny?","Wilhelm#21ms50",bc_self;
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Alright, let's verify how much we can trust you by giving us information.";
		mes "We don't have much time. We never know when the ghost ship will appear again.";
		next;
		cutin "ep21_reinhardt06.png",1;
		mes "[Reinhardt]";
		mes "Did you say ghost ship?";
		next;
		cutin "ep21_iana02.png",2;
		mes "[Iana]";
		mes "That's what the recently rescued Jormungandr's followers have been calling it.";
		next;
		cutin "ep21_tan01.png",0;
		mes "[Tan]";
		mes "They said their ship sank after being attacked by an unidentified ship that suddenly appeared in the fog during the night.";
		mes "They have been calling it ghost ship. Do you know anything about it?";
		next;
		cutin "ep21_reinhardt06.png",1;
		mes "[Reinhardt]";
		mes "If it's that... yes I do.";
		completequest 17767;
		setquest 17768;
		questinfo_refresh;
		close3;
	}
	if(isbegin_quest(17768) == 2 && isbegin_quest(17770) == 0){
		cutin "ep21_wilhelm04.png",0;
		mes "[Wilhelm]";
		mes "Wow- this is really awkward. We don't have anything to talk about.";
		mes "...Well, should I get you a book or something? Is there anything you want to do?";
		next;
		cutin "ep21_reinhardt01.png",2;
		mes "[Reinhardt]";
		mes "When... and how, did our parents passed away?";
		next;
		cutin "ep21_wilhelm02.png",0;
		mes "[Wilhelm]";
		mes "Are you really curious about that? When you left everything behind and disappeared, wasn't it because you didn't care what would happen to us?";
		next;
		cutin "ep21_reinhardt02.png",2;
		mes "[Reinhardt]";
		mes "That time, I really didn't have a choice.";
		next;
		cutin "ep21_wilhelm04.png",0;
		mes "[Wilhelm]";
		mes "That's a convenient excuse.";
		mes "Do you really want to know how our parents passed away?";
		next;
		cutin "ep21_wilhelm02.png",0;
		mes "[Wilhelm]";
		mes "After you left, they spent their lives helping those who suffered under the cult, as if they were atoning for something. They passed away because they were oppressed by the cult.";
		mes "They were persecuted by the very insitution that you joined.";
		next;
		cutin "ep21_wilhelm05.png",0;
		mes "[Wilhelm]";
		mes "They never spoke of you after you left. Before they took their last breath, they made me promise not to search for you.";
		next;
		cutin "ep21_wilhelm02.png",0;
		mes "[Wilhelm]";
		mes "I have always wondered why you disappeared and ponder why they said those things, but now I understand. It was all because of what you did.";
		next;
		cutin "ep21_wilhelm04.png",0;
		mes "[Wilhelm]";
		mes "They couldn't bear to tell me, someone who looked up to you, that you had become an enforcer of suffering for the cult.";
		mes "I thought something happened to you... But you are the one leading the way!";
		next;
		cutin "ep21_reinhardt02.png",2;
		mes "[Reinhardt]";
		mes "Wil... Wilhelm.";
		setquest 17770;
		questinfo_refresh;
		close3;
	}
	if(isbegin_quest(17770) == 1){
		cutin "ep21_wilhelm05.png",0;
		mes "[Wilhelm]";
		mes "Did you know? Whenever you called me like that, I could never say anything.";
		close3;
	}
	cutin "ep21_wilhelm05.png",0;
	mes "[Wilhelm]";
	mes "Well, I don't order people around to make them do something.";
	close3;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17767) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17768) == 2 && isbegin_quest(17770) == 0";
end;
}

jor_mbase,140,201,0	script	#21ms70-2	HIDDEN_WARP_NPC,5,5,{
	end;
	
OnTouch:
	if(isbegin_quest(17771) == 1){
		cloaknpc("Wilhelm#21ms70",false,getcharid(0));
		end;
	}
	if(isbegin_quest(17776) == 2){
		cloaknpc("Reinhardt#21ms70",false,getcharid(0));
		cloaknpc("Wilhelm#21ms70",false,getcharid(0));
		end;
	}
end;
}

jor_mbase,140,201,3	script(CLOAKED)	Wilhelm#21ms70	EP21_NPC_WILHELM,{
	if(isbegin_quest(17771) == 1){
		cutin "ep21_wilhelm02.png",2;
		mes "[Wilhelm]";
		mes "Oh! Why isn't the captain here? Where did he go? Even the vice-captain is not here!";
		mes "I don't want to go through this.";
		mes "...Why are you here?";
		next;
		select("Your brother told me to follow you.");
		cutin "ep21_wilhelm05.png",2;
		mes "[Wilhelm]";
		mes "I'm not a kid who needs to be taken care of.";
		mes "He doesn't realize that time has passed. He think he's the only one who aged.";
		next;
		select("You must have been closed when you were young.");
		cutin "ep21_wilhelm01.png",2;
		mes "[Wilhelm]";
		mes "Yes, when we were young it was like that. He was the one who took care of me instead of my parents. Our age gap was big, so I followed him like a puppy.";
		mes "He thought me everything, from studies to self-defense, eating habits, and even letters.";
		next;
		cutin "ep21_wilhelm05.png",2;
		mes "[Wilhelm]";
		mes "He was the coolest and most respectable adult I know in this world. But now... Ha-";
		mes "Now that I'm around the age when he left, as an adult? It's not even close.";
		next;
		cutin "ep21_wilhelm04.png",2;
		mes "[Wilhelm]";
		mes "Looking at it, he was just a rash kid acting impulsively at his young age.";
		next;
		select("He said he had his own reasons.");
		cutin "ep21_wilhelm02.png",2;
		mes "[Wilhelm]";
		mes "Does that change anything? I can't simply forgive him, can't I?";
		mes "What do he want, me defending someone who is a part of that evil cult? Do you agree with that, tell me?";
		next;
		cutin "ep21_wilhelm04.png",2;
		mes "[Wilhelm]";
		mes "Do you know how many times I've imagined meeting him again? What would he look like, what should I say first, I've thought of things like that.";
		mes "Have I grown taller over the time we haven't met each other? I even practiced everything he taught me diligently, hoping that he would praise me.";
		next;
		cutin "ep21_wilhelm02.png",2;
		mes "[Wilhelm]";
		mes "But in those imagination, he was not a high priest of the cult.";
		mes "And it stills annoy me that he is still taller than me! I only thought that he was only tall because he was an adult already, how is he stil taller?";
		next;
		cutin "ep21_wilhelm05.png",2;
		mes "[Wilhelm]";
		mes "We're not even close, why am I even telling you this?";
		next;
		cloaknpc("Tris#21ms70",false,getcharid(0));
		cutin "ep21_tris01.png",0;
		mes "[Tris]";
		mes "Wilhelm? What's going on?";
		next;
		cutin "ep21_wilhelm05.png",2;
		mes "[Wilhelm]";
		mes "Captain. I have a message from my brother. He told me that it would be good for the people escaping the cult to cull the number of monsters for the route's safety.";
		next;
		cutin "ep21_tris01.png",0;
		mes "[Tris]";
		mes "That's a good suggestion. Is there anything else?";
		next;
		cutin "ep21_wilhelm01.png",2;
		mes "[Wilhelm]";
		mes "No. There's nothing else. We just fought. It's a miracle that we didn't pull each other hairs out. I really held back my emotions. I'm practically a saint at this point.";
		mes "You can have whoever is free take care of the monsters on the route, or you can just ignore it if you want.";
		next;
		cutin "ep21_wilhelm05.png",2;
		mes "[Wilhelm]";
		mes "I'll go back to work. This is frustrating.";
		next;
		cloaknpc("Wilhelm#21ms70",true,getcharid(0));
		cutin "ep21_tris05.png",0;
		mes "[Tris]";
		mes "The gap between the brother seems deep. Time might be the only answer.";
		mes "Are you going back to Reinhardt? Can you tell him that there's someone who wants to meet him?";
		completequest 17771;
		setquest 17772;
		close2;
		cloaknpc("Tris#21ms70",true,getcharid(0));
		cutin "",255;
		end;
	}
	if(isbegin_quest(17776) < 2) end;
	callsub(OnFinishCheck,17777,17779);
	callsub(OnFinishCheck,17778,17780);
	cutin "ep21_wilhelm03.png",0;
	mes "[Wilhelm]";
	mes "You're here?";
	mes "Did you come to clear the escape route? Where can you start? On the north? Or south?";
	next;
	switch(select("Clear the Northern Raised Land","Clear the Southern Raised Land","I want to rest.")){
		case 1:
			.@qid = 17777;
			.@cid = 17779;
			break;
			
		case 2:
			.@qid = 17778;
			.@cid = 17780;
			break;
			
		case 3:
			cutin "ep21_wilhelm01.png",0;
			mes "[Wilhelm]";
			mes "Is that so? I won&t force you to work. Well, It's not exactly urgent.";
			mes "But you know... people who are escaping the cult might get attacked by monsters while going through the escape route.";
			npctalk "Wil.","Reinhardt#21ms70",bc_self;
			npctalk "Alright... that's wrong of me to say.","Wilhelm#21ms70",bc_self;
			next;
			cutin "ep21_wilhelm05.png",0;
			mes "[Wilhelm]";
			mes "What I just said, I... apologize.";
			mes "Come back when you've made up your mind.";
			close3;
	}
	switch(checkquest(.@cid,PLAYTIME)){
		case -1:
			break;
		case 0:
		case 1:
			cutin "ep21_wilhelm01.png",0;
			mes "[Wilhelm]";
			mes "Eh? Didn't you just finished clearing that area?";
			mes "Are you some super human or something? Got a lot of energy to spare? I'm jealous. Seriously, take a break and come back tomorrow.";
			close3;
		case 2:
			erasequest getarg(0);
			break;
	}
	if(isbegin_quest(.@qid) == 0){
		cutin "ep21_wilhelm03.png",0;
		mes "[Wilhelm]";
		if(.@qid == 17777)
			mes "You should cull the monsters on the ^0000cdNorthern Raised Land^000000 so people who escapes from the temple can travel safely.";
		else	
			mes "You should cull the monsters on the ^0000cdSouthern Raised Land^000000 so people who escapes from the temple can travel safely.";
		mes "You need to ^0000cdcull about 300 monsters^000000 regardless of what kind it is.";
		next;
		cutin "ep21_reinhardt04.png",2;
		mes "[Reinhardt]";
		mes "It's dangerous work, but it's necessary for everyone's safety.";
		mes "Please be careful.";
		setquest .@qid;
		close3;
	}
	if(isbegin_quest(.@qid) == 1){
		if(checkquest(.@qid,HUNTING) < 2){
			cutin "ep21_wilhelm01.png",0;
			mes "[Wilhelm]";
			if(.@qid == 17777)
				mes "Huh, you want to clear the Northern Raised Land?";
			else	
				mes "Huh, you want to clear the Southern Raised Land?";
			mes "I thought you're working on it already, you just need to take care of about 300 monsters there regardless of what kind it is. Seems like you forgot.";
			close3;
		}
		
	}
	end;
	
OnFinishCheck:
	if(checkquest(getarg(0),HUNTING) == 2){
		cutin "ep21_wilhelm03.png",0;
		mes "[Wilhelm]";
		mes "You're back already? You did well.";
		mes "Rest for today, and come back again tomorrow.";
		next;
		cutin "ep21_reinhardt04.png",2;
		mes "[Reinhardt]";
		mes "We can use the route more safely thanks to you. I appreciate your efforts.";
		erasequest getarg(0);
		setquest getarg(1);
		getitem "Ep21_Wigner_Ticket",10;
		add_reputation_points(13,10);
		getexp 336672990,235209500; // Same exp for both quest
		close3;
	}
	return;
end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17771) == 1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(17776) == 2 && isbegin_quest(17777) == 0 && checkquest(17779,PLAYTIME) == -1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(17776) == 2 && isbegin_quest(17777) == 0 && checkquest(17779,PLAYTIME) == 2";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(17776) == 2 && isbegin_quest(17778) == 0 && checkquest(17780,PLAYTIME) == -1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(17776) == 2 && isbegin_quest(17778) == 0 && checkquest(17780,PLAYTIME) == 2";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"checkquest(17777,HUNTING) == 2";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"checkquest(17778,HUNTING) == 2";
end;
}

jor_mbase,142,200,3	duplicate(dummynpc)	Reinhardt#21ms70	EP21_NPC_REINHARDT

jor_mbase,194,279,7	script(CLOAKED)	Reinhardt#21ms60	EP21_NPC_REINHARDT,{
	if(isbegin_quest(17773) == 1){
		mes "[Reinhardt]";
		mes "This place...";
		close;
	}
	if(isbegin_quest(17774) == 1){
		cutin "ep21_reinhardt04.png",0;
		mes "[Reinhardt]";
		mes "Whatis the matter?";
		next;
		cutin "ep21_worker_om_07.png",1;
		mes "[Believer]";
		mes "Carmigand, you were here?";
		mes "You're safe. Thanks to you we manage to escape in time.";
		mes "I haven't had the chance to thank you amidst that chaos.";
		next;
		cutin "ep21_reinhardt04.png",0;
		mes "[Reinhardt]";
		mes "I didn't do anything. It was all thanks to the people who risked their lives and made the effort.";
		next;
		cutin "ep21_worker_kg_01.png",1;
		mes "[Believer]";
		mes "Even so, if it weren't for you we would still be there, do you think we would escape on our own?";
		next;
		cutin "ep21_worker_m_01.png",1;
		mes "[Believer]";
		mes "That's right. You also kept asking us how we were doing. Thanks to that we were able to gather our courage and escape.";
		next;
		cloaknpc("Believer#21ms64",false,getcharid(0));
		cutin "ep21_worker_of_02.png",1;
		mes "[Believer]";
		mes "Hey, You! What are you doing here! If you have any conscience, you shouldn't be walking around here!";
		next;
		cutin "ep21_worker_om_01.png",1;
		mes "[Believer]";
		mes "Don't say that! If it weren't for him, you would be dead already in the hands of the cult!";
		next;
		cutin "ep21_worker_f_01.png",1;
		mes "[Believer]";
		mes "He's the one who helped us the most. Have you been treated like a human by the order? They treated us like bugs while working us to death.";
		next;
		cutin "ep21_worker_of_06.png",1;
		mes "[Believer]";
		mes "Is it true? Are you the eldest son of the Lugenburg couple? Is is true that you're Wilhelm's brother?";
		next;
		cutin "ep21_worker_om_01.png",1;
		mes "[Believer]";
		mes "What? Really? They're brother? Now that you mention it, they do look alike, my memory is faint but they don't resemble the couple.";
		next;
		cutin "ep21_worker_of_01.png",1;
		mes "[Believer]";
		mes "Your parents, must be so proud of you. The brother have grown well.";
		next;
		cloaknpc("Believer#21ms60",true,getcharid(0));
		cloaknpc("Believer#21ms61",true,getcharid(0));
		cloaknpc("Believer#21ms68",false,getcharid(0));
		cloaknpc("Believer#21ms69",false,getcharid(0));
		cutin "ep21_worker_kb_05.png",1;
		mes "[Believer]";
		mes "Are you really Carmigand?";
		next;
		cloaknpc("Wilhelm#21ms60",true,getcharid(0));
		cloaknpc("Wilhelm#21ms61",false,getcharid(0));
		cutin "ep21_wilhelm01.png",2;
		mes "[Wilhelm]";
		mes "Brother?";
		completequest 17774;
		setquest 17775;
		questinfo_refresh;
		close3;
	}
	if(isbegin_quest(17775) == 1){
		cutin "ep21_reinhardt04.png",0;
		mes "[Reinhardt]";
		mes "I wanted to come without Wil knowing.";
		close3;
	}
	if(isbegin_quest(17776) == 1){
		cutin "ep21_reinhardt04.png",0;
		mes "[Reinhardt]";
		mes "There is still so much to resolve going forward.";
		close3;
	}
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17774) == 1";
end;
}

jor_mbase,197,277,7	script(CLOAKED)	Tris#21ms60	EP21_NPC_TRIS,{
	if(isbegin_quest(17773) == 1){
		cutin "ep21_tris09.png",2;
		mes "[Tris]";
		mes "This is the meal area run by the Wigner Merchants. It's where the believers who escaped from the cult or rescued from the shipwreck stays. The food here is delicious.";
		mes "It's also where Wilhelm works.";
		next;
		cutin "ep21_tris08.png",2;
		mes "[Tris]";
		mes "Ah! There he is.";
		mes "He might seem a bit blunt, but he's a good listener from what I've heard. That's why a lot of people come to Wilhlem and talk about all sort of things.";
		next;
		cutin "ep21_reinhardt04.png",0;
		mes "[Reinhardt]";
		mes "... He has really grown a lot.";
		mes "He was still a little child who's about my waist in my memories, before I knew it he is already helping other people.";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "I didn't notice since I saw you in different times, but now that I see you two together, it's clear that you influenced Wilhelm a lot. From the way he speaks and his actions.";
		mes "Weren't you separated for a long time?";
		next;
		cutin "ep21_reinhardt07.png",0;
		mes "[Reinhardt]";
		mes "Is that so?";
		mes "...It's truly a shame that I couldn't see him grow up. I still ponder how much I missed.";
		mes "Why did I even do it... for what purpose...";
		next;
		cloaknpc("Believer#21ms62",false,getcharid(0));
		cloaknpc("Believer#21ms63",false,getcharid(0));
		npctalk "I saw you being pulled away earlier, are you okay?","Believer#21ms62",bc_self;
		npctalk "I was not sure, but it really was you!","Believer#21ms63",bc_self;
		sleep2 1000;
		cloaknpc("Believer#21ms65",false,getcharid(0));
		npctalk "Are you here for a meal? Let's have it together.","Believer#21ms65",bc_self;
		sleep2 1000;
		cloaknpc("Believer#21ms66",false,getcharid(0));
		cloaknpc("Believer#21ms67",false,getcharid(0));
		npctalk "It's Carmigand!","Believer#21ms66",bc_self;
		npctalk "What brings you here?","Believer#21ms67",bc_self;
		mes "[Believer]";
		mes "Carmigand!";
		completequest 17773;
		setquest 17774;
		questinfo_refresh;
		close3;
	}
	if(isbegin_quest(17774) == 1){
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "What are people gathering around?";
		close3;
	}
	if(isbegin_quest(17775) == 1){
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "It seems Wilhelm is quite worried about his brother.";
		close3;
	}
	if(isbegin_quest(17776) == 1){
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Oh, Reinhardt. I heard about the escape route. The suggestion is to cull out the monsters on the route. Everyone agreed when I brought it up.";
		mes "Do you have any other opinions? Anything is fine. I've heard you know a lot about these things.";
		next;
		cutin "ep21_reinhardt04.png",0;
		mes "[Reinhardt]";
		mes "I can only give you an answer after I take a looka round. Since I'm not familiar here yet, I don't anything yet.";
		next;
		cutin "ep21_tris09.png",2;
		mes "[Tris]";
		mes "Alright. Then, shall we leave the escape route to the adventurers for now?";
		mes "Wilhelm suggested to give the job to whoever is free.";
		mes "Of course Wilhelm will supervise it.";
		next;
		cutin "ep21_wilhelm01.png",2;
		mes "[Wilhelm]";
		mes "Me- Am I not busy enough? Why me? I just came from listening to complaints about a blanket being thinner than the other person.";
		mes "At this rate, I will end up making blankets myself.";
		next;
		cutin "ep21_tris08.png",2;
		mes "[Tris]";
		mes "You can supervise your brother. He can also check out Lunaforma while you're at it. Wilhelm be Reinhardt's guide around Lunaforma.";
		npctalk "That works for me.","Reinhardt#21ms60",bc_self;
		next;
		cutin "ep21_wilhelm02.png",2;
		mes "[Wilhelm]";
		mes "Ah, Captain! Captain?? Isn't this too much? Is this some kind of torture? Why are you doing this to me? Did I do something wrong?";
		next;
		cutin "ep21_tris08.png",2;
		mes "[Tris]";
		mes "You said you needed time, right?";
		next;
		cutin "ep21_wilhelm02.png",1;
		mes "[Wilhelm]";
		mes "What, I didn't say that! You were the one who decided that!";
		next;
		cutin "ep21_tris09.png",2;
		mes "[Tris]";
		mes "Well, I'll be off since I have some things that I need to finish.";
		mes "Take care of everything!";
		next;
		cloaknpc("Tris#21ms60",true,getcharid(0));
		npctalk "Captain! Captain!!! Where are you going! We need to talk!!!","Wilhelm#21ms61",bc_self;
		mes "[Reinhardt]";
		mes "Thank you for everything. I'll see you again soon.";
		cloaknpc("Reinhardt#21ms60",true,getcharid(0));
		cloaknpc("Wilhelm#21ms61",true,getcharid(0));
		completequest 17776;
		questinfo_refresh;
		getitem "Ep21_Wigner_Ticket",10;
		getexp 91298960,59995050;
		add_reputation_points(13,5);
		close2;
		cutin "",255;
		cloaknpc("Wilhelm#21ms70",false,getcharid(0));
		cloaknpc("Reinhardt#21ms70",false,getcharid(0));
		end;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17773) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17776) == 1";
end;
}

jor_mbase,196,280,3	script(CLOAKED)	Wilhelm#21ms61	EP21_NPC_WILHELM,{
	if(isbegin_quest(17775) == 1){
		cutin "ep21_wilhelm01.png",2;
		mes "[Wilhelm]";
		mes "Brother, what's going on? Why are you outside?";
		mes "Even the captain is here? What's with all the commotion? Are these people causing any trouble?";
		next;
		cutin "ep21_worker_m_04.png",1;
		mes "[Believer]";
		mes "What? Wilhelm, what do you take us for? We were just praising how impressive you brothers are.";
		next;
		cutin "ep21_wilhelm01.png",2;
		mes "[Wilhelm]";
		mes "Really? What were you talking about?";
		next;
		cutin "ep21_worker_om_09.png",1;
		mes "[Believer]";
		mes "We were praising you both. Aren't you the second son of the Lugenburg couple? Why haven't you mentioned it? It's disappointing not knowing it.";
		next;
		cutin "ep21_wilhelm03.png",2;
		mes "[Wilhelm]";
		mes "Is it really that disappointing? Does it even matter when I'm working?";
		mes "Is a blanket handed out by Wilhelm Lugenburg much warmer?";
		next;
		cutin "ep21_worker_om_02.png",1;
		mes "[Believer]";
		mes "No, but it's about the feeling! People will look at you differently just by that!";
		next;
		cutin "ep21_wilhelm04.png",2;
		mes "[Wilhelm]";
		mes "Do you see me different now? How were you looking at me before?";
		next;
		cutin "ep21_worker_f_07.png",1;
		mes "[Believer]";
		mes "Carmigand helped us a lot in the cult, and you two are really alike.";
		next;
		cutin "ep21_wilhelm01.png",2;
		mes "[Wilhelm]";
		mes "......Alike?";
		next;
		cutin "ep21_worker_f_07.png",1;
		mes "[Believer]";
		mes "Anyone can see it. Your kindness. Helping a lot of people, it's not easy to do that.";
		next;
		cutin "ep21_wilhelm03.png",2;
		mes "[Wilhelm]";
		mes "...It's almost meal time. Shouldn't you hurry up? You hungry people.";
		next;
		cutin "ep21_worker_m_07.png",1;
		mes "[Believer]";
		mes "Oh no! It's that time already! Off we go then.";
		next;
		cloaknpc("Believer#21ms62",true,getcharid(0));
		cloaknpc("Believer#21ms63",true,getcharid(0));
		cutin "ep21_worker_kb_04.png",1;
		mes "[Believer]";
		mes "Carmigand, please come out often and share your wisdom. Back in the cult, we really relied on your wisdoms.";
		next;
		cutin "ep21_reinhardt04.png",0;
		mes "[Reinhardt]";
		mes "If opportunity arises, I will do so.";
		next;
		cloaknpc("Believer#21ms65",true,getcharid(0));
		cloaknpc("Believer#21ms66",true,getcharid(0));
		cloaknpc("Believer#21ms64",true,getcharid(0));
		cutin "ep21_worker_m_07.png",1;
		mes "[Believer]";
		mes "Have a great time!";
		next;
		cloaknpc("Believer#21ms67",true,getcharid(0));
		cloaknpc("Believer#21ms68",true,getcharid(0));
		cloaknpc("Believer#21ms69",true,getcharid(0));
		cutin "ep21_tris09.png",0;
		mes "[Tris]";
		mes "Did you rush over because you thought they might hurt your brother? You're really a worry wart.";
		next;
		cutin "ep21_wilhelm02.png",2;
		mes "[Wilhelm]";
		mes "It's not like that, just... argh! Can you just stand by and watch violence? Don't you feel the same? Do you?";
		mes "Anyway, now that I know everything's fine, I'll be on my way.";
		next;
		cutin "ep21_reinhardt07.png",0;
		mes "[Reinhardt]";
		mes "Wil, I joined the church to help people like them. I was drawn to the doctrine that promised us to embrace everyone equally.";
		mes "I thought that with the power of a large church, I could help more than I could on my own.";
		next;
		cutin "ep21_reinhardt02.png",0;
		mes "[Reinhardt]";
		mes "But. As you know, the result of my choice was disastrous.";
		mes "My faith was nothing but an illusion, I kept chasing an empty shell.";
		next;
		cutin "ep21_reinhardt03.png",0;
		mes "[Reinhardt]";
		mes "I devoted myself to the church and worked harder than anyone, but it wasn't until recently that I realized that I was wrong and people are suffering because of me.";
		mes "I was the one who knew nothing. I wanted to save other people from suffering... but I ended up the one pushing them into it. As you said, I was too arrogant.";
		next;
		cutin "ep21_reinhardt01.png",0;
		mes "[Reinhardt]";
		mes "Then, I heard about the resistance. I realized that to truly fix every mistake I made, it would be more effective to bring change from the outside rather than the inside, so I decided to escape.";
		next;
		cutin "ep21_reinhardt04.png",0;
		mes "[Reinhardt]";
		mes "And here I found you. It felt as if things were meant to happen.";
		mes "Thank you so much for helping me. I thought of you often. In my thoughts, you were still a little buy, but to think you've grown this much. Even the way you use the dagger is much better compared to before.";
		next;
		cutin "ep21_wilhelm04.png",2;
		mes "[Wilhelm]";
		mes "It's because of what you've taught me brother. I worked hard hoping to show you if we ever meet again, but looking back I shouldn't have bothered.";
		next;
		cutin "ep21_reinhardt07.png",0;
		mes "[Reinhardt]";
		mes "If only I had known there were other ways to do it...";
		mes "But being here now gives me the resolve. I know what I must do from now on.";
		next;
		cutin "ep21_reinhardt04.png",0;
		mes "[Reinhardt]";
		mes "I swore never ot use the name I had abandoned, but seeing how many people relied on that name, I can't let it fade away.";
		next;
		mes "[Reinhardt]";
		mes "I will need your help. There are many things I want to hear.";
		mes "I will help you as well.";
		next;
		cutin "ep21_wilhelm01.png",2;
		mes "[Wilhelm]";
		mes "So you're saying you want to reap the benefits without anything in return. I don't need your help.";
		mes "No matter what color you paint over black, it would still be black. That's how our past is. That's the state of our relationship. You already ruined everything, brother.";
		next;
		cutin "ep21_wilhelm05.png",2;
		mes "[Wilhelm]";
		mes "What will you use to fill those empty memories? Do you know we are no longer the people we once knew? Let's just acknowledge it and live our own lives.";
		next;
		select("You can draw a picture with a black paint.");
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Come one. Even if a relationship was ruined, if there is a will there is a way, you can work to fix it. Even though you're approach was different, you both had the same desire to help other people, right?";
		mes "Even though you've been apart for so long, you are still alike.";
		next;
		cutin "ep21_wilhelm05.png",2;
		mes "[Wilhelm]";
		mes "Ugh, these kinds of talk make me feel uncomfortable. Can you just leave me alone?";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Oh, do you need more time? Alright. Take as much as time as you need and talk it out slowly.";
		mes "A lot of conversation is needed between you two.";
		completequest 17775;
		setquest 17776;
		questinfo_refresh;
		close3;
	}
	if(isbegin_quest(17776) == 1){
		cutin "ep21_wilhelm05.png",2;
		mes "[Wilhelm]";
		mes "We really do look alike...";
		close3;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17775) == 1";
end;
}

jor_mbase,200,285,7	duplicate(dummynpc)	Wilhelm#21ms60	EP21_NPC_WILHELM
jor_mbase,201,288,3	duplicate(dummynpc)	Believer#21ms60	4_EP21_M_WORKER_A
jor_mbase,202,286,3	duplicate(dummynpc)	Believer#21ms61	4_EP21_WORKER_KID_B
jor_mbase,193,283,5	duplicate(dummynpc)	Believer#21ms62	4_EP21_M_WORKER_A
jor_mbase,198,281,3	duplicate(dummynpc)	Believer#21ms63	4_EP21_WORKER_KID_B
jor_mbase,197,283,3	duplicate(dummynpc)	Believer#21ms64	4_EP21_F_WORKER_B
jor_mbase,200,282,3	duplicate(dummynpc)	Believer#21ms65	4_EP21_M_WORKER_B
jor_mbase,199,279,3	duplicate(dummynpc)	Believer#21ms66	4_EP21_F_WORKER_A
jor_mbase,195,284,3	duplicate(dummynpc)	Believer#21ms67	4_EP21_WORKER_KID_A
jor_mbase,195,276,1	duplicate(dummynpc)	Believer#21ms68	4_EP21_WORKER_KID_B
jor_mbase,196,278,1	duplicate(dummynpc)	Believer#21ms69	4_EP21_M_WORKER_A
jor_mbase,138,201,5	duplicate(dummynpc)	Tris#21ms70	EP21_NPC_TRIS

mbase_in,119,182,3	script(CLOAKED)	Tris#21ms50	EP21_NPC_TRIS,{
	npctalk "You've really done well. Let's focus on the topic.","",bc_self;
	end;
}

mbase_in,115,184,7	script(CLOAKED)	Tan#21ms50	EP21_NPC_TAN,{
	npctalk "......","",bc_self;
	end;
}

mbase_in,115,182,7	script(CLOAKED)	Iana#21ms50	4_EP21_IANA,{
	npctalk "We need to listen and analyze the information to see if it's useful.","",bc_self;
	end;
}

mbase_in,117,181,1	script(CLOAKED)	Yohan#21ms50	EP21_NPC_YOHAN,{
	npctalk "The two of them... really look alike...","",bc_self;
	end;
}

jor_albe,190,186,5	script(CLOAKED)	Maristella Walter#ep21_rw03	4_EP21_MARISTELLA,{
	if(isbegin_quest(16816) == 1){
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "There's no need for a discussion.";
		mes "So, shall we prepare for departure?";
		next;
		.@party_id = getcharid(1);
		if(!.@party_id){
			cutin "ep21_maristella01.png",1;
			mes "[Maristella Walter]";
			mes "It's probably best to form a party first with your companions.";
			mes "Even if you're alone, it would be better to be properly equipped.";
			close3;
		}
		cutin "",255;
		.@md_name$ = "Mysterious Ghost Ship";
		switch(select("Set coordinates.","Investigate the Mysterious Ghost Ship.","Explore later.")){
			case 1:
				cutin "ep21_maristella01.png",1;
				mes "[Maristella Walter]";
				mes "Good. Raise the anchor and prepare the sails!";
				mes "We should be able to find it soon. Once you're ready, tell me to 'Investigate the Mysterious Ghost Ship' to begin the exploration.";
				if(instance_create(.@md_name$) == -3) 
					instance_warning(2,.@md_name$);
				close3;

			case 2:
				if(instance_enter(.@md_name$) != IE_OK || getinstancevar('daily,instance_id(IM_PARTY)) == true){
					cutin "ep21_maristella01.png",1;
					mes "[Maristella Walter]";
					mes "We're still finalizing the coordinates. Wait a moment until we locate the ghost ship…….";
					close3;
				}
				mapannounce "jor_albe", strcharinfo(0) + " is boarding the Mysterious Ghost Ship.", bc_map, "0x00FF99";
				end;

			case 3:
				cutin "ep21_maristella01.png",1;
				mes "[Maristella Walter]";
				mes "Do you still have something to prepare?";
				mes "Then, please finish up and return here.";
				close3;
		}
	}
	if(isbegin_quest(16817) == 1){
		cutin "ep21_maristella03.png",1;
		mes "[Maristella Walter]";
		mes "I've returned from the voyage.";
		mes "Uncle Megas, has everything been alright?";
		next;
		cutin "ep21_epesto01.png",2;
		cloaknpc("Epesto Walter Megas#ep3",false,getcharid(0));
		mes "[Epesto Walter Megas]";
		mes "Captain, welcome back.";
		mes "So, did you get the clarity that you needed?";
		next;
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "I'm sure you were curious about the ghost ship too, thank you for protecting Alberta.";
		next;
		cutin "ep21_epesto03.png",2;
		mes "[Epesto Walter Megas]";
		mes "No need to say thanks. It's why I'm here.";
		mes "Anyway, did you find your peace?";
		next;
		cutin "ep21_maristella03.png",1;
		mes "[Maristella Walter]";
		mes "Yes, I've confirmed everything. The Walter, and Captain Howell Megas Walter.";
		mes "Although he didn't return alive, his spirit remained.";
		next;
		cutin "ep21_epesto03.png",2;
		mes "[Epesto Walter Megas]";
		mes "……I see.";
		mes "I think I'll have a glass of rum tonight. Haha.";
		next;
		cutin "ep21_maristella03.png",1;
		mes "[Maristella Walter]";
		mes "Father asked me to pass on his regards to you, Uncle Megas.";
		mes "He said thank you, although it's selfish to ask……, he asked you to continue looking after things.";
		next;
		cutin "ep21_epesto01.png",2;
		mes "[Epesto Walter Megas]";
		mes "……!";
		mes "Captain, have you met Howell?";
		next;
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "The person I met was definitely captain Walter.";
		mes "As for the details…… Hm. Perhaps it would be better to talk it over a drink.";
		next;
		cutin "ep21_epesto01.png",2;
		mes "[Epesto Walter Megas]";
		mes "I'd love to hear it immediately, but it'll have to wait.";
		mes "…… Someone from the <NAVI>[Wigner]<INFO>jor_albe.gat,192,189,0,101,0</INFO></NAVI> has arrived. We should probably hear them out first.";
		completequest 16817;
		setquest 16819;
		questinfo_refresh;
		cloaknpc("Wigner Executive#ep21_rw01",false,getcharid(0));
		close3;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(16816) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(16817) == 1";
end;
}

jor_albe,191,183,7	script(CLOAKED)	Wigner Executive#ep21_rw01	4_M_RUSMAN2,{
	if(isbegin_quest(16819) == 1){
		mes "[Wigner Executive]";
		mes "Greetings, vice-captain, captain of the Walter and " + strcharinfo(0) + ".";
		mes "I have brought the goods for the Mage of Heine.";
		next;
		mes "[Wigner Executive]";
		mes "Here, " + strcharinfo(0) + " this is for you.";
		mes "Adventurer, Heine mentioned that he has a favor to ask of you.";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Is that so? Can it be discussed over the tablet?";
		mes "Our work here is done, it's time to return to Lunaforma.";
		next;
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "Let's return to Lunaforma and see what Heine has to say.";
		mes "Captain, would that be alright?";
		next;
		cutin "ep21_maristella01.png",1;
		mes "[Maristella Walter]";
		mes "It's fine. I'll get everything ready.";
		mes "I'll also gather the item that was left by the former captain, I'll sort out what's useful and send it to Lunaforma.";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Alright, Let's return to <NAVI>[Lunaforma]<INFO>mbase_in.gat,92,123,0,101,0</INFO></NAVI> for now.";
		cloaknpc("Nillem#ep21_rw04",false,getcharid(0));
		npctalk "Nillem : Oh, do you have a moment, could you listen to my story?","Nillem#ep21_rw04",bc_self;
		completequest 16819;
		setquest 16818;
		getitem "Ep21_Wigner_Ticket",70;
		getexp 1573151350,479960440;
		add_reputation_points(13,90);
		close;
	}
	mes "[Wigner Executive]";
	mes "Are you heading back to Lunaforma now?";
	mes "Sigh, I'll have to board the ship again…… Ugh, I still haven't gotten over my seasickness.";
	close;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(16819) == 1";
end;
}

jor_albe,195,186,3	script(CLOAKED)	Tan#ep21_rw01	4_EP21_TAN,{
	if(isbegin_quest(16816) == 1){
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "We should act together. Something feels off. I'm uneasy sending only the people of the Walter.";
		next;
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "I have a feeling that they might need be, not right now but maybe at some point.";
		close3;
	}
	if(isbegin_quest(16818) < 2){
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Let's talk. I can give time for that. But only that much.";
		close3;
	}
	end;
}

jor_albe,191,189,5	script(CLOAKED)	Yohan#ep21_rw03	4_EP21_YOHAN,{
	if(isbegin_quest(16816) == 1){
		cutin "ep21_yohan01.png",2;
		mes "[Yohan]";
		mes "Am I coming too? I'm just an ordinary sailor.";
		close3;
	}
	if(isbegin_quest(16818) < 2){
		cutin "ep21_yohan03.png",2;
		mes "[Yohan]";
		mes "Sob…… captain, captain…….";
		mes "*Sniff*, sob…….";
		close3;
	}
	end;
}

jor_albe,194,189,3	script(CLOAKED)	Iana Operta#ep21_rw02	4_EP21_IANA,{
	if(isbegin_quest(16816) == 1){
		cutin "ep21_iana02.png",1;
		mes "[Iana Operta]";
		mes "Of course Yohan should come along. There might be something only he can discover.";
		close3;
	}
	if(isbegin_quest(16818) < 2){
		cutin "ep21_iana02.png",1;
		mes "[Iana Operta]";
		mes "Yohan. Hold it in, you can do it.";
		next;
		cutin "ep21_yohan03.png",2;
		mes "[Yohan]";
		mes "Come on, *Sniff*…… I'm, not a child anymore……!";
		close3;
	}
	end;
}

jor_albe,194,182,1	script(CLOAKED)	Epesto Walter Megas#ep3	4_EP21_EPESTO,{
	if(isbegin_quest(16818) < 2){
		cutin "ep21_epesto01.png",2;
		mes "[Epesto Walter Megas]";
		mes "There are stories I want to hear.";
		mes "But we should keep everything in order first.";
		close3;
	}
}

mbase_in,92,123,5	script	Tris#ep21_pn_tris03	4_EP21_TRIS,{
	if(isbegin_quest(16818) == 0){
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "These documents are endless... When I first teamed up with Tan, I never imagined I would do this kind of work, you really don't know where life would take you.";
		close3;
	}
	if(isbegin_quest(16818) == 1){
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "I heard you went into the ghost ship? " + strcharinfo(0) + ", you've only recently joined, but you already took on an important task. Good job.";
		next;
		cutin "ep21_tris02.png",2;
		mes "[Tris]";
		mes "I heard that the ghostship was the Walter. What happened? I'd like to hear a brief summary, I'll read the detailed report later.";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "The captain, Howell Megas Walter was inside. Some kind of magic turned the Walter into a ghost ship, and turned the crew into undead.";
		next;
		mes "[Tan]";
		mes "In his final moments, he briefly regained his human consciousness. He said that they attacked the cult's ships to protect the seas where the Walter fleet's move.";
		next;
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "It seems that the captain couldn't was worried, even in death...";
		next;
		cutin "ep21_tris02.png",2;
		mes "[Tris]";
		mes "So that's what happened. We should arrange a memorial for the Walter. We are in debt to the captain. It would be great if we could somehow find a way to repay him...";
		next;
		mes "[Tris]";
		mes "Maristella is probably the most troubled right now. We should give her plenty of time to sort out her emotions.";
		next;
		mes "[Tris]";
		mes "......";
		next;
		cutin "ep21_tris11.png",2;
		mes "[Tris]";
		mes "...Ahem. It's not the time for this. I was lost in thought without even realizing it, keeping busy people wait. I apologize.";
		next;
		mes "[Tris]";
		mes "I was in the middle of something when you arrived, let me sort it out first. I'm almost finished with it, so it won't take long. Wait a moment.";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Sure. Take your time and don't worry about us.";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Alright, I'll make it quick.";
		next;
		mes "[Tris]";
		mes "Heine, hello. Did the supplies arrive? We've completed the checks on our side, I just need you to verify that nothing is missing.";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "*Static*...";
		next;
		cutin "ep21_tris07.png",2;
		mes "[Tris]";
		mes "Huh, what's happening? Heine? Can you hear me?";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "It seems like @#%^@**^%$something is@#^&&&";
		next;
		cutin "ep21_tris07.png",2;
		mes "[Tris]";
		mes "Uhm, The screen looks broken and can't understand you. The screen is also flickering.";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "Wait, @@#^&@% has issue@#@!&^**@";
		next;
		cutin "",255;
		mes "- Disconnects -";
		next;
		cutin "ep21_tris11.png",2;
		mes "[Tris]";
		mes "Ah, it got cut off. This has never happened before. Did Heine say to wait? We should hold on for a bit...";
		completequest 16818;
		setquest 23249;
		close2;
		cutin "",255;
		pcblock(true);
		npctalk "Beep!","Heine Tablet#ep21_pn",bc_self;
		sleep2 400;
		pcblock(false);
		npctalk "Tris: Oh?","",bc_self;
		end;
	}
	if(isbegin_quest(23249) == 1){
		mes "[Tris]";
		mes "Heine? I thought it would take some time, is the connection back already?";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "Tris, how is it? Can you hear me clearly?";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Yes, it's perfect! How did you fix it quickly? As expected of you Heine, you're amazing.";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "It's a temporary fix. I'm not sure how long it will hold. It's a critical problem, it'll take some time to properly repair it.";
		next;
		cutin "ep21_tris05.png",2;
		mes "[Tris]";
		mes "It's been a while since you made this device, but it has never broken down before, right? Very unusual.";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "This artifact is made with such complex magic, so something like this could happen anytime. I've only been handling it well so far.";
		next;
		cutin "ep21_ilse_heine05.png",1;
		mes "[Ilse El Heine]";
		mes "Sigh... I've been putting off the maintenance because it's a hassle, but I guess it's time for a major overhaul. There are a few things that I don't like about it, maybe because I made it a long time ago.";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "I also feel that there's something big coming up. We can't have it breaking down suddenly at a crucial moment, can we?";
		next;
		mes "[Ilse El Heine]";
		mes "I need some assistance, but you're probably Tris. And Tan would just complain the whole time, so no thanks.";
		npctalk "Tan: Good grief...","Tan#ep21_pn_tan02",bc_self;
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Not really, I'm not that busy. I've finished the urgent tasks, so I have some time to spare.";
		next;
		cutin "ep21_ilse_heine02.png",1;
		mes "[Ilse El Heine]";
		mes "No? Think it over. You're probably busy enough. Isn't there someone else free? Like... yes, " + strcharinfo(0) + ". You'd be perfect for the job.";
		next;
		select("Me?");
		mes "[Ilse El Heine]";
		mes "Yes. You.";
		mes "Tris, pass the tablet to " + strcharinfo(0) + " while I repair the remote connection problem.";
		npctalk "Nillem: You've been chosen by Heine, I'm so jealous!","Nillem#ep21_pn_nillem03",bc_self;
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "It as Heine said. You're the leader of the Gaebolg. You don't have to deal with every little task yourself. Leave the small things to your subordinates.";
		next;
		cutin "ep21_tris11.png",2;
		mes "[Tris]";
		mes "I'm not really that busy, atleast not enough that I won't be able to help Heine... but if you both say so, I guess I have no choice.";
		next;
		cutin "ep21_tris09.png",2;
		mes "[Tris]";
		mes "Tan and Heine, you're just looking out for me, right? Thanks! I can't just force my opinion when my comrades are concern for me.";
		next;
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "Think whatever you want...";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "Tris, Do you have a private room that " + strcharinfo(0) + " can use? It needs to be a place free of natural interference and without people to eliminate any suspicious factors.";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "There's a spare room in the headquarters. I'll set it up for you. Is that enough? Do you need anything else?";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "No. If I needed anything else, I'll ask my assistant, so don't worry.";
		pctalk "Assistant?";
		next;
		mes "[Ilse El Heine]";
		mes strcharinfo(0) + ", head there with the tablet immediately. If the connection got lost, we might not be able to reconnect again. Let's avoid unnecessary trouble.";
		next;
		mes "[Ilse El Heine]";
		mes "Tris! If the repairs went wrong and the tablet stops working, bring it to Comodo. It's your job.";
		next;
		cutin "ep21_tris09.png",2;
		mes "[Tris]";
		mes "Got it, leave it to me!";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes strcharinfo(0) + ", head up to the <NAVI>[room on the left]<INFO>mbase_in,21,168,0,101,0</INFO></NAVI>. I'll make sure no one goes in. Good luck!";
		completequest 23249;
		setquest 23250;
		close3;
	}
	if(isbegin_quest(23250) == 1){
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes strcharinfo(0) + ", head up to the <NAVI>[room on the left]<INFO>mbase_in,21,168,0,101,0</INFO></NAVI>. I'll make sure no one goes in. Good luck!";
		close3;
	}
	if(isbegin_quest(23254) == 0){
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Is the repair going well?";
		next;
		cutin "ep21_tris05.png",2;
		mes "[Tris]";
		mes "Still in progress? For Heine, it's taking longer than the usual...";
		close3;
	}
	if(isbegin_quest(23254) == 1){
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Is the repair done? It finished sooner than I thought. It was taking longer than I expected, so I thought it would take a while and started working on something else.";
		next;
		mes "[Tris]";
		mes "Heine, can you wait a little longer on the item check? I was just discussing future plans with lady Aurelie.";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "Okay, also perfect timing. We can check the items anytime. Go ahead and continue your discussion. Where did you leave off?";
		next;
		cutin "ep21_aurelie01.png",1;
		mes "[Aurelie]";
		mes "To summarize... We talked about how the cult's activity weakened after the north started freezing.";
		next;
		mes "[Aurelie]";
		mes "Leon has stayed in Isgard for a while to investigate the phenomenon. It was a slow progress, but it seems he finally found something.";
		next;
		mes "[Aurelie]";
		mes "Leon said, that the cult is prioritizing maintaining the connection to Isgard. The reason is still unclear, but it's likely because Isgard is the core of Jormungandr.";
		next;
		mes "[Aurelie]";
		mes "Leon and I suspected that, the Jormungandr cult is so cornered that they can't sustain their operations without the mana from Isgard.";
		next;
		mes "[Aurelie]";
		mes "If we push the cult without giving them anytime to regroup, we might finally end this war. But we'll need a bit of luck.";
		next;
		mes "[Aurelie]";
		mes "Tris, Tan, and I, have all agreed that this is the best opportunity that we'll have after a long time.";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "By the time we're fully prepared, the cult will have some time to recover. That's why we decided to strike now even if it's risky.";
		next;
		cutin "ep21_tris03.png",2;
		mes "[Tris]";
		mes "...Heine, what do you think?";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "As expected, your insights are impressive. Tris, aren't you making excellent decisions even without me now? I've brought some good news that might help you decide too.";
		npctalk "Tris: I'm getting embarrassed...","Tris#ep21_pn_tris03",bc_self;
		next;
		mes "[Ilse El Heine]";
		mes strcharinfo(0) + " provided a useful information. The Rgans are practically dependent on the magic left in Jormungandr's body. As Aurelie said, the cult can't leave Isgard because they need Jormungand's mana.";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "And, here's some better news for you. This time, I'll be lending my power directly. Isn't it more significant than just me providing supplies?";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "If Heine also agrees, then it's unanimous. We might finally see the end of this long, tiresome war...";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "I modified the tablet to make it able to cast my magic remotely, so don't worry about your forces. I'll support you as much as I can.";
		next;
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "You made that possible? Is that why the repair took so long? To add such a functionality in a short time, Heine, you're amazing!";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "...That is certainly helpful. There's no need to say more. Tris, this is where we end it.";
		npctalk "Heine: That's all your reaction?","Heine Tablet#ep21_pn2",bc_self;
		next;
		cutin "ep21_tris03.png",2;
		mes "[Tris]";
		mes "Yes, Tan.";
		next;
		mes "[Tris]";
		mes "As the captain of the Gaebolg Resistance. I declare that from this moment, the Gaebolg Resistance will prepare for the final battle against the Jormungandr cult.";
		next;
		mes "[???]";
		mes "*Crash*!";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "...What was that noise? Are we under attack?";
		npctalk "Tan: Are we too late...!","Tan#ep21_pn_tan02",bc_self;
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Ahh, What is happening! Hurry up, let's go <NAVI>[outside]<INFO>jor_mbase,201,192,0,101,0</INFO></NAVI>!";
		completequest 23254;
		setquest 23255;
		getitem "Ep21_Wigner_Ticket",50;
		getexp 547793770,239980220;
		add_reputation_points(13,50);
		close3;
	}
	if(isbegin_quest(23255) == 1){
		cutin "ep21_tris03.png",2;
		mes "[Tris]";
		mes strcharinfo(0) + ", Hurry! No time to explain. We need to go <NAVI>[outside]<INFO>jor_mbase,201,192,0,101,0</INFO></NAVI>. Go now.";
		close3;
	}
	if(isbegin_quest(23255) > 0 && isbegin_quest(12656) < 2){
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Huh? About Tan, you say? He's like that because he's been through a lot, that's why, but he's actually quite kind. Really, he is. Once he succeeds in his revenge against the cult, I'm sure that he’ll be brighter than he is now.";
		close3;
	}
	if(isbegin_quest(23255) > 0 && isbegin_quest(12656) == 2){
		cutin "ep21_tris02.png",2;
		mes "[Tris]";
		mes "......";
		next;
		mes "[Tris]";
		mes "Sorry, can we talk later? I can't think of anything right now...";
		close3;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(16818) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23249) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23254) == 1";
end;
}

mbase_in,95,121,3	script	Aurelie#ep21_pn_aurelie0	4_EP21_AURELIE,{
	if(isbegin_quest(23254) == 0 && isbegin_quest(23253) == 1){
		cutin "ep21_aurelie01.png",1;
		mes "[Aurelie]";
		mes "When Leon returns, I'll have to personally introduce you. He is my twin brother.";
		close3;
	}
	if(isbegin_quest(23254) == 1){
		cutin "ep21_aurelie01.png",1;
		mes "[Aurelie]";
		mes "Leon endured for a long time in that harsh land... I'm glad his efforts bore fruit.";
		close3;
	}
	if(isbegin_quest(23255) == 1){
		cutin "ep21_aurelie01.png",1;
		mes "[Aurelie]";
		mes "It's important to stay calm like this. Even if it's not perfect, we've prepared enough. Don't worry.";
		close3;
	}
	if(isbegin_quest(23255) > 0 && isbegin_quest(12656) == 2){
		cutin "ep21_aurelie01.png",1;
		mes "[Aurelie]";
		mes "Could you wait a moment? I will need some time to gather my thoughts...";
		close3;
	}
	cutin "ep21_aurelie01.png",1;
	mes "[Aurelie]";
	mes "My hair has always been red. You sure ask the strangest things.";
	close3;
}

mbase_in,89,103,0	script	#snmset1	HIDDEN_WARP_NPC,3,3,{
	end;
	
OnTouch:
	if(isbegin_quest(16818) == 1 || isbegin_quest(23249) == 1 || isbegin_quest(23254) == 1){
		cloaknpc("Tan#ep21_pn_tan02",false,getcharid(0));
		cloaknpc("Lehar#ep21_pn_rehar03",false,getcharid(0));
		cloaknpc("Nillem#ep21_pn_nillem03",false,getcharid(0));
		cloaknpc("Heine Tablet#ep21_pn2",false,getcharid(0));
		end;
	}
	if(isbegin_quest(23250) > 0 && isbegin_quest(23255) == 0){
		cloaknpc("Tan#ep21_pn_tan02",false,getcharid(0));
		cloaknpc("Lehar#ep21_pn_rehar03",false,getcharid(0));
		cloaknpc("Nillem#ep21_pn_nillem03",false,getcharid(0));
		end;
	}
	if(isbegin_quest(23255) > 0 && isbegin_quest(18360) < 2){
		cloaknpc("Aurelie#ep21_pn_aurelie0",true,getcharid(0));
		cloaknpc("Tris#ep21_pn_tris03",true,getcharid(0));
		end;
	}
end;
}

mbase_in,86,136,0	duplicate(#snmset1)	#snmset2	HIDDEN_WARP_NPC,3,3
mbase_in,105,133,0	duplicate(#snmset1)	#snmset3	HIDDEN_WARP_NPC,3,3
mbase_in,75,134,0	duplicate(#snmset1)	#snmset4	HIDDEN_WARP_NPC,3,3

mbase_in,86,123,5	script(CLOAKED)	Tan#ep21_pn_tan02	4_EP21_TAN,{
	if(isbegin_quest(16818) == 1){
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "......";
		next;
		mes "Tan seems to be in deep thought. Let's not disturb him...";
		close3;
	}
	if(isbegin_quest(23249) == 1){
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Heine, who's often praised as a genius also makes mistakes too, huh.";
		close3;
	}
	if(isbegin_quest(23250) == 1){
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "It seems you earned Heine's trust. Do your best.";
		close3;
	}
	if(isbegin_quest(23254) == 0){
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Is the repair not finished yet? It's taking longer than expected.";
		close3;
	}
	if(isbegin_quest(23254) == 1){
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Our mission is about to end...";
		close3;
	}
	if(isbegin_quest(23255) == 1){
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Damn, those cult bastards!";
		close3;
	}
	end;
}

mbase_in,84,125,5	script(CLOAKED)	Lehar#ep21_pn_rehar03	4_EP19_LEHAR,{
	if(isbegin_quest(16818) == 1){
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Did you return without any issue from the ghost ship search?";
		close3;
	}
	if(isbegin_quest(23249) == 1){
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "What's going on with the Heine tablet all of a sudden? I don't know why, but the sound is eerie...";
		close3;
	}
	if(isbegin_quest(23254) == 0){
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Is there anything I can help with? I'm worried that you might have to do everything alone, adventurer.";
		close3;
	}
	if(isbegin_quest(23254) == 1){
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "It's a strange feeling to see lady Aurelie's past self.";
		close3;
	}
	if(isbegin_quest(23255) == 1){
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Ahh, What is happening! Hurry up, let's go <NAVI>[outside]<INFO>jor_mbase,201,192,0,101,0</INFO></NAVI>!";
		close3;
	}
	end;
}

mbase_in,82,121,5	script(CLOAKED)	Nillem#ep21_pn_nillem03	4_M_NILLEM,{
	if(isbegin_quest(16818) == 1){
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "It was really strange, wasn't it? I'd like to stay in Alberta and study it more, but let's focus on what we need to do for now.";
		close3;
	}
	if(isbegin_quest(23249) == 1){
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "Unbelievable! To witness such historic moments with my own eyes!";
		next;
		select("Is this something from the history books?");
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "Well, maybe, it might be... but that's not what I'm talking about.";
		next;
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "Not only did I get to see an artifact created by the great mage of the past up close, but also witnessed it breaking down in front of me!";
		next;
		cutin "ep172_nillem03.png",0;
		mes "[Nillem]";
		mes "As expected, I'm always followed by luck. I'm going to observe every detail and use it for my research☆";
		close3;
	}
	if(isbegin_quest(23254) == 0){
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "Ahhh~";
		mes "I wish I could also go there when he repairs the tablet!";
		next;
		mes "[Nillem]";
		mes "But the world of magic is mysterious and delicate, so we have to follow Heine's instruction. What else should I do...";
		next;
		mes "[Nillem]";
		mes "By why you, adventurer? Is it because your magical energy has less impact on the tablet?";
		next;
		mes "[Nillem]";
		mes "This Nillem, has so many questions. Promise me that you'll tell me how Heine repaired the tablet! Promise me!";
		close3;
	}
	if(isbegin_quest(23254) == 1){
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "To think that they've already gathered this much information from this time, Lady Aurelie and Leon's insight, isn't it truly amazing?";
		close3;
	}
	if(isbegin_quest(23255) == 1){
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "Surely, this isn't how the final chapter begins? This Nillem, is not ready for it yet!";
		close3;
	}
	end;
}

mbase_in,94,123,3	script(CLOAKED)	Heine Tablet#ep21_pn2	4_EP21_HEINE_TAB,{
	if(isbegin_quest(16818) == 1){
		npctalk "*static sounds*","",bc_self;
		mes "As you get closer, you heard a faint but unsettling sound. It sounds like a wheel that is spinning in a very fast pace.";
		close;
	}
	if(isbegin_quest(23249) == 1){
		mes "A blue screen is displayed. I have a strong feeling that I shouldn't touch it.";
		close;
	}
	if(isbegin_quest(23250) == 1){
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "You heard what Tris said, right? Take the tablet and head to the <NAVI>[room on the left]<INFO>mbase_in,21,168,0,101,0</INFO></NAVI>. It's a delicate device, so handle it with care!";
		close3;
	}
	if(isbegin_quest(23254) == 1){
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "Hehehe. Hahahaha!";
		next;
		mes "[Ilse El Heine]";
		mes "Sometimes, even my own talent is scaring me... Tris is going to be blown away when he sees the new functionality, don't you think?";
		close3;
	}
	if(isbegin_quest(23255) == 1){
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "Hm, I don't sense any of the cult's mana, how? We'll find anyways when we go out~";
		close3;
	}
	end;
}

mbase_in,22,167,0	script	#hw_ep21_pn30	HIDDEN_WARP_NPC,4,4,{
	end;
	
OnTouch:
	if(isbegin_quest(23250) == 1 || isbegin_quest(23251) == 1 || isbegin_quest(23252) == 1 || isbegin_quest(18360) == 2)
		cloaknpc("Heine Tablet#ep21_pn3",false,getcharid(0));
end;
}

mbase_in,21,168,3	script(CLOAKED)	Heine Tablet#ep21_pn3	4_EP21_HEINE_TAB,{
	if(isbegin_quest(23250) == 1){
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "Good, It's much stable than before. As long as we don't leave this room, the connection won't drop.";
		next;
		mes "[Ilse El Heine]";
		mes "So, leave the tablet here and go gather the items that I need for the repair and functionality upgrade.";
		next;
		cutin "ep21_ilse_heine02.png",1;
		mes "[Ilse El Heine]";
		mes "The cause is still unknown, since the tablet and I are physically separated, the only option is to test the things I've theorized, right?";
		next;
		mes "[Ilse El Heine]";
		mes "We'll need plenty of materials for that.";
		next;
		if(select("Is there a hidden agenda...","I'll do as you order.") == 2){
			mes "[Ilse El Heine]";
			mes "That's a good attitude. I like it. When I give you a task, you do it without complain unlike someone else, doesn't that give you any motivation?";
		} else {
			cutin "ep21_ilse_heine05.png",1;
			mes "[Ilse El Heine]";
			mes "Are you doubting me the great arch mage Ilse El Heine ? You dare doubt me?";
			next;
			mes "[Ilse El Heine]";
			mes "I'll let it slide this once...";
		}
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "I need 2 Vellelopy, it should be enough for us to not run on materials. It's a material that you can use multiple times.";
		next;
		mes "[Ilse El Heine]";
		mes "Aren't there Vellelings in that area? I think there are in the northern part of the Raised Lands... If it's not there, I need to ask Tris again.";
		next;
		mes "[Ilse El Heine]";
		mes "The tablet has been temporarily adjust to fit the current environment, so don't move it or anyone else touch it. Be careful.";
		next;
		mes "[Ilse El Heine]";
		mes "Now, go get me my 2 <ITEM>[Vellelopy]<INFO>1001643</INFO></ITEM>, use any means necessary!";
		completequest 23250;
		setquest 23251;
		close3;
	}
	if(isbegin_quest(23251) == 1){
		if(countitem("Vellelopy") < 2){
			cutin "ep21_ilse_heine05.png",1;
			mes "[Ilse El Heine]";
			mes "What, where's the Vellelopy? I'm already tired waiting here...";
			next;
			mes "[Ilse El Heine]";
			mes "I don't care if you have to hunt down Velellings in the northern part of the Raised Lands or steal some from the resistance warehouse, just don't call me unless you have 2 <ITEM>[Vellelopy]<INFO>1001643</INFO></ITEM>!";
			close3;
		}
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "You really do get things done, huh? No need to show me the Vellelopy. I can detect it roughly using the tablet.";
		next;
		mes "[Ilse El Heine]";
		mes "If you place it nearby the tablet, it will absorb the Vellelopy's magic.";
		next;
		cutin "ep21_ilse_heine02.png",1;
		mes "[Ilse El Heine]";
		mes "I've already come up with the new magic to apply to the tablet while you were getting the Vellelopy, let's start modifying it right away.";
		next;
		select("What should I do?");
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "Hm, for now there's nothing. Just stand by in case something happens!";
		next;
		mes "[Ilse El Heine]";
		mes "......";
		next;
		mes "[Ilse El Heine]";
		mes "......";
		mes "......";
		next;
		mes "[Ilse El Heine]";
		mes "......";
		mes "......";
		mes "......";
		next;
		cutin "ep21_ilse_heine04.png",1;
		mes "[Ilse El Heine]";
		mes "I confirmed that the transmission is working normally. While we wait for it to apply to the tablet, how about an old story to pass time?";
		next;
		if(select("Please tell me.","It's fine.") == 1){
			cutin "ep21_ilse_heine02.png",1;
			mes "[Ilse El Heine]";
			mes "I figured that you're curious. Haven't you heard anything from Tris or Tan?";
		} else {
			cutin "ep21_ilse_heine05.png",1;
			mes "[Ilse El Heine]";
			mes "What? I'm being nice here. Do you think that you'll get another chance to hear a story from a great mage? Just listen quietly!";
		}
		next;
		cutin "ep21_ilse_heine04.png",1;
		mes "[Ilse El Heine]";
		mes "Where should I start... The Gaebolg resistance originally began as a small alliance between Tan and Tris. I believe it started when Tris saved Tan, from there they began working together.";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "Both of their influence became increasingly big as they attacked the church, more people who shared their ideals joined them, but their resources and manpower couldn't support their rapidly growing ranks.";
		next;
		mes "[Ilse El Heine]";
		mes "So Tris and Tan came to seek help from none other than me, the great sage of Comodo.";
		next;
		mes "[Ilse El Heine]";
		mes "Although I was bound to Comodo and I couldn't directly assist them, I saw the potential in the two of them, especially T.a.n. That's why I decided to support the resistance.";
		next;
		mes "[Ilse El Heine]";
		mes "Honestly, I won't gain anything from it, but I couldn't stand the tyranny of the Jormungandr cult. So it was a win-win situation.";
		next;
		mes "[Ilse El Heine]";
		mes "Tris is very grateful to me, but Tan on the other hand is a very frustrating guy... No matter how much I look after the resistance, he always has something to complain about...";
		next;
		select("...Ahem!");
		mes "[Ilse El Heine]";
		mes "What? Are you asking how long would this take? Wondering if it's complete already?";
		next;
		cutin "ep21_ilse_heine05.png",1;
		mes "[Ilse El Heine]";
		mes "Listen, " + strcharinfo(0) + ". Advanced magic is like constructing a building. Do you know that waiting for bricks to set in takes longer than stacking them?";
		next;
		mes "[Ilse El Heine]";
		mes "The difference with magic is, you can't tell how it's coming together until it's fully set. So you just have to wait and see.";
		next;
		mes "[Ilse El Heine]";
		mes "Do you think advanced magic is quick to cast and then poof? Great magic comes with great cost. Naturally, that includes a lot of time. Waiting for it to complete is boring.";
		next;
		mes "[Ilse El Heine]";
		mes "You have to watch closely in case something goes wrong...";
		next;
		mes "[Ilse El Heine]";
		mes "Tan, always do the same thing, this is why I can't stand dealing people who don't understand magic.";
		next;
		mes "[Ilse El Heine]";
		mes "The old saying is true, don't take in the black-haired beast, he is never wrong. Things would be much smoother if he acts like Tris, won't it? But, no, he's always grumpy...";
		next;
		mes "[Ilse El Heine]";
		mes "I really don't like it. That Tan, is going to get into trouble in one of these days. I'll make sure he gets the taste of his own medicine someday.";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "Anyways, while we were talking, the transmission is finally finished! I'm really something else. I'll initiate the startup now, so wait a bit.";
		delitem "Vellelopy",2;
		completequest 23251;
		setquest 23252;
		close3;
	}
	if(isbegin_quest(23252) == 1){
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "...What's the problem?";
		next;
		cutin "ep21_ilse_heine05.png",1;
		mes "[Ilse El Heine]";
		mes "Huh, what's with the look? Even a great mage can't always pull of such a magic perfectly on the first try.";
		next;
		mes "[Ilse El Heine]";
		mes "Besides, this tablet is an ancient artifact, that's why I can't use it as I please.";
		next;
		mes "[Ilse El Heine]";
		mes "Do you know how difficult is to repair a relic that was created before the War of the Gods? Attempting is already considered to be an achievement regardless of success.";
		next;
		mes "[Ilse El Heine]";
		mes "Do you even have an idea how old this thing is? It never malfunctioned before, so I barely know how I originally fixed it...";
		next;
		if(select("How old is it?","How long will it take to be fixed?") == 1){
			cutin "ep21_ilse_heine01.png",1;
			mes "[Ilse El Heine]";
			mes "When was it made? Well, if I had to estimate...";
			next;
			cutin "ep21_ilse_heine02.png",1;
			mes "[Ilse El Heine]";
			mes "Hm. Actually. I'm not going to tell you.";
		} else {
			mes "[Ilse El Heine]";
			mes "I was troubleshooting it while we're talking, do you think I was just rambling?";
			next;
			mes "[Ilse El Heine]";
			mes "What do you take the great archmage Ilse El Heine for... I think I figured it out already, so give me a moment.";
		}
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "......";
		next;
		mes "[Ilse El Heine]";
		mes "......";
		mes "......";
		next;
		mes "[Ilse El Heine]";
		mes "......";
		mes "......";
		mes "......";
		next;
		mes "[Ilse El Heine]";
		mes "I hope it works this time...";
		next;
		mes "[Ilse El Heine]";
		mes "You know, sometimes. You can't prepare for certain outcome, right? Like, there's no way that would happen only to be surprised that it did.";
		next;
		mes "[Ilse El Heine]";
		mes "I learned how to consider the chance from 'millionths value from a 0', no matter how unlikely it seems...";
		next;
		mes "[Ilse El Heine]";
		mes "What does it mean? There are things like that.";
		next;
		mes "[Ilse El Heine]";
		mes "...I'm getting bored. Want to hear about the new features that I added while we wait? Yeah, sounds like a good idea.";
		next;
		mes "[Ilse El Heine]";
		mes "First, I've stabilized the basic functionality so we can communicate face-to-face even from a distance.";
		next;
		mes "[Ilse El Heine]";
		mes "I've also dealt with those annoying cases for unexpected situations, this should prevent communication errors.";
		next;
		mes "[Ilse El Heine]";
		mes "But that's nothing compared to this one. I've added a remote spellcasting feature this time.";
		next;
		mes "[Ilse El Heine]";
		mes "Isn't that a huge leap? With the tablet being to cast spells, it's practically having myself with you.";
		next;
		cutin "ep21_ilse_heine02.png",1;
		mes "[Ilse El Heine]";
		mes "I'm really something else...";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "Hm! I've got a good feeling about this. I'll check it again, so stand by for a while.";
		completequest 23252;
		setquest 23253;
		close3;
	}
	if(isbegin_quest(23253) == 1){
		cutin "ep21_ilse_heine04.png",1;
		mes "[Ilse El Heine]";
		mes "I succeeded on the second try...";
		next;
		select("Is that good?","Is that bad?");
		cutin "ep21_ilse_heine05.png",1;
		mes "[Ilse El Heine]";
		mes "Of course it's a bad thing! ";
		next;
		mes "[Ilse El Heine]";
		mes "It's normal for ordinary mages to mess up, but I don't make mistakes. My only mistake that I didn't anticipate that the variable is you.";
		pctalk "Me?";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "Answer me honestly. Though I already figured it from the flow of mana in you, that you are from the future.";
		next;
		mes "[Ilse El Heine]";
		mes "Asking you to gather Bright Eyes was just to confirm it.";
		next;
		mes "[Ilse El Heine]";
		mes "...Why are you in this timeline?";
		next;
		if(select("To drive out the Jormungandr Cult.","To completly eliminate the Rgans") == 1){
			cutin "",255;
			mes "[" + strcharinfo(0) + "]";
			mes "The Jormungandr cult has stubbornly survived, causing harm to humans even in the timeline that I live in.";
		} else {
			cutin "",255;
			mes "[" + strcharinfo(0) + "]";
			mes "The Jormungandr cult continued to survived and the Rgans continued to absorb the mana from Jormungand's body causing harm to humans.";
		}
		next;
		mes "[" + strcharinfo(0) + "]";
		mes "There power has grown too great, and in my timeline, this is the onle way we saw to stop the Jormungandr cult.";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "So, the Rgans survived into the distant future? That's surprising. I calculated that they would likely disappear into history seeing their decline.";
		next;
		mes "[Ilse El Heine]";
		mes "I've always wondered why the Rgans suddenly obtain such strong mana when the cult first appeared. So they're stealing it, that makes sense, I predicted that it was some form of divine powers.";
		next;
		mes "[Ilse El Heine]";
		mes "Hm, if you think about it, isn't the mana left in Jormungandr's body a divine power? It's more surprising that the mana from Jormungandr's body lasted this long. For a discarded body to hold its power for too long...";
		next;
		mes "[Ilse El Heine]";
		mes "If Jormungandr's body had such strong mana, it's only natural that those who would use it become dangerous in the future. So, did you come back to the past to change the course of events? It's a good plan.";
		next;
		mes "[Ilse El Heine]";
		mes "And now is the perfect time. The news we've been waiting for has arrived. I can't wait to see Tris' face when he hear this. Isn't it exciting?";
		next;
		mes "[Ilse El Heine]";
		mes "Don't forget to bring the tablet. It would be pointless to leave it behind. Now, let's go <NAVI>[outside]<INFO>mbase_in,92,123,0,101,0</INFO></NAVI>. ";
		completequest 23253;
		setquest 23254;
		getitem "Ep21_Tab",1;
		close3;
	}
	if(isbegin_quest(23254) == 1){
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "Come on, let's go <NAVI>[outside]<INFO>mbase_in,92,123,0,101,0</INFO></NAVI>. The news you've been waiting for is here.";
		close3;
	}
	if(isbegin_quest(18360) < 2) end;
	switch(checkquest(23257,PLAYTIME)){
		case -1:
			break;

		case 0:
		case 1:
			cutin "ep21_ilse_heine07.png",1;
			mes "[Ilse El Heine]";
			mes "Yawn.... Why are you calling me?";
			next;
			cutin "ep21_ilse_heine04.png",1;
			mes "[Ilse El Heine]";
			mes "Huh? Anything I need help with?";
			next;
			cutin "ep21_ilse_heine05.png",1;
			mes "[Ilse El Heine]";
			mes "No, no... You already gathered the materials. Oh, are you trying to rush me?";
			next;
			mes "[Ilse El Heine]";
			mes "We agreed to do it tomorrow. There's a sequence to everything, so just trust me and wait.";
			next;
			mes "[Ilse El Heine]";
			mes "Rushing things will only mess it up...";
			close3;

		case 2:
			erasequest 23257;
			break;
	}
	if(isbegin_quest(23256) == 0){
		mes "[Ilse El Heine]";
		mes "......";
		next;
		select("Heine!");
		cutin "ep21_ilse_heine06.png",1;
		mes "[Ilse El Heine]";
		mes "Oh.";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "I nodded off...";
		next;
		mes "[Ilse El Heine]";
		mes "It doesn't sit well with me. I've been staying up all night for research, and I just dozed off without realizing...";
		next;
		mes "[Ilse El Heine]";
		mes "There's something wrong with the flow of mana. I felt it when you first appeared in this timeline, but this time it's different.";
		next;
		mes "[Ilse El Heine]";
		mes "Would you believe me if I said that it's something more massive and there is overwhelming distortion of mana?";
		next;
		mes "[Ilse El Heine]";
		mes "Great sages don't make mistakes often, but this time I'm hope I'm wrong. It would be nice if it were just my assumptions.";
		next;
		mes "[Ilse El Heine]";
		mes "At least if I knew this issue was only in this area, I'd feel at ease.";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "But I'm bound to Comodo, I can't monitor the mana of other regions myself...";
		next;
		cutin "ep21_ilse_heine02.png",1;
		mes "[Ilse El Heine]";
		mes "I'll have you help me out, " + strcharinfo(0) + ". It's not a difficult task. I'll save this world, all you have to do is assist me.";
		next;
		mes "[Ilse El Heine]";
		mes "Do you remember the Bright Eyes that you've brought last time? They're not as good as gems, but they'll do as a medium.";
		next;
		mes "[Ilse El Heine]";
		mes "From the experiments that I did with the one you've brought, I'd say about three should be enough.";
		next;
		mes "[Ilse El Heine]";
		mes "Go and collect 3 <ITEM>[Bright Eyes]<INFO>1001641</INFO></ITEM> for me.";
		next;
		if(select("I'll be back.","I'll do it later.") == 2){
			cutin "ep21_ilse_heine05.png",1;
			mes "[Ilse El Heine]";
			mes "Lateeeeeeeeeeer?";
			next;
			mes "[Ilse El Heine]";
			mes "You've got some nerve talking back to a great sage...";
			next;
			mes "[Ilse El Heine]";
			mes "Do as you please. It's not like I can't do it alone. Just come back when you're ready.";
			close3;
		}
		mes "[Ilse El Heine]";
		mes "I'm going to take a nap, wake me up when you return...";
		setquest 23256;
		close3;
	}
	if(isbegin_quest(23256) == 1){
		if(countitem("EP21_Bright_Eye") < 3){
			cutin "ep21_ilse_heine07.png",1;
			mes "[Ilse El Heine]";
			mes "Yawn... You're back already? Didn't I say that I need 3 <ITEM>[Bright Eyes]<INFO>1001641</INFO></ITEM>?";
			next;
			cutin "ep21_ilse_heine01.png",1;
			mes "[Ilse El Heine]";
			mes "What? What's with that look? You think a great sage can't detech such mana?";
			close3;
		}
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "Good job. Now arrange the Bright Eyes in the order displayed on the screen...";
		next;
		mes "[Ilse El Heine]";
		mes "That one is crooked. Proper alignment is important! The direction of the eyes must be perfect. The spacing too.";
		next;
		mes "[Ilse El Heine]";
		mes "Alright. That should do. Leave it like that and let it sit for a day.";
		next;
		select("Only this?");
		mes "[Ilse El Heine]";
		mes "I set it up to record fluctuations in mana. No matter what situation, observation is crucial especially magic.";
		next;
		mes "[Ilse El Heine]";
		mes "I only intervene when there is solid evidence... that's my principle.";
		next;
		mes "[Ilse El Heine]";
		mes "Now, it's just a matter of time. it'll take time to collect data. By 4AM we should have something significant..";
		next;
		mes "[Ilse El Heine]";
		mes "Come back at 4AM if you want to assist me again. Good job.";
		delitem "EP21_Bright_Eye",3;
		erasequest 23256;
		setquest 23257;
		getitem "Ep21_Wigner_Ticket",5;
		getexp 21710000,15120000;
		add_reputation_points(13,3);
		close3;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23250) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23251) == 1 && countitem(\"Vellelopy\") >= 2";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23252) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23253) == 1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(18360) == 2 && isbegin_quest(23256) == 0 && checkquest(23257,PLAYTIME) == -1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(18360) == 2 && isbegin_quest(23256) == 0 && checkquest(23257, PLAYTIME) == 2";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23256) == 1 && countitem(\"EP21_Bright_Eye\") >= 3";
end;
}

jor_mbase,204,190,0	script	#ep21p01evt04	HIDDEN_WARP_NPC,3,3,{
	end;
	
OnTouch:
	if(isbegin_quest(23255) == 1){
		cloaknpc("Nadoyo#ep21nadoyo01",false,getcharid(0));
		cloaknpc("Tris#ep21tris01",false,getcharid(0));
		cloaknpc("Tan#ep21tan01",false,getcharid(0));
		end;
	}
	if(isbegin_quest(18342) == 1){
		cloaknpc("Tris#ep21tris01",false,getcharid(0));
		end;
	}
	if(isbegin_quest(18345) == 1){
		cloaknpc("Nadoyo#ep21nadoyo01",false,getcharid(0));
		cloaknpc("Tris#ep21tris01",false,getcharid(0));
		end;
	}
end;
}

jor_mbase,201,192,5	script(CLOAKED)	Nadoyo#ep21nadoyo01	4_EP21_NADOYO,{
	if(isbegin_quest(23255) == 1){
		cutin "ep21_tris05.png",2;
		mes "[Tris]";
		mes "Nadoyo? What's going on? It's unusual that you're all the way here in Lunaforma, what's the case?";
		next;
		cutin "ep21_nadoyo05.png",0;
		mes "[Nadoyo]";
		mes "Those fools has done something insane.";
		mes "Haven't you received any reports from the scout or information about a giant serpent?";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "What? Say that again.";
		mes "What do you mean by a giant serpent?";
		next;
		cutin "ep21_nadoyo04.png",0;
		mes "[Nadoyo]";
		mes "I'm saying that those lunatics are trying to resurrect Jormungandr!";
		mes "Jormungandr already sank beyond the sea, I have no idea how they're trying to do it..";
		next;
		select("Resurrect Jormungandr...?");
		cutin "ep21_nadoyo05.png",0;
		mes "[Nadoyo]";
		mes "That's what the cult high priest said.";
		mes "Soon our god will appear, punish those humans, and bring order to this continent.. the era of Jormungandr is near!";
		next;
		cutin "ep21_nadoyo03.png",0;
		mes "[Nadoyo]";
		mes "And it suddenly appeared. I only saw the shadow from a distance.";
		mes "It disappeared quickly, but it looked like a giant serpent.";
		next;
		mes "[Nadoyo]";
		mes "I want to confirm what I saw.";
		mes "If someone else saw the serpent, then I wasn't just seeing things, right?";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Nadoyo. Let's go where you saw it.";
		mes "Tris, prepare for any possible situations.";
		next;
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "Even if it's not the resurrection of Jormungandr, there's something significant happening.";
		mes "We might face a major battle.";
		next;
		mes "[Nadoyo]";
		mes "I'll guide you to the place where I saw the serpent.";
		mes "Also, you should listen to the soldiers who've just return to Lunaforma.";
		mes "We should also contact our allies from Alberta and other locations.";
		cutin "ep21_nadoyo01.png",0;
		next;
		cutin "ep21_tris03.png",2;
		mes "[Tris]";
		mes "We'll leave that to " + strcharinfo(0) + ".";
		mes "Let's gather information and meet again here.";
		mes "I'll summon our allies from Alberta and other locations.";
		completequest 23255;
		setquest 18338;
		questinfo_refresh;
		close2;
		cutin "",255;
		pcblock(true);
		npctalk "Tan : I'll see you later.","Tan#ep21tan01",bc_self;
		sleep2 1000;
		npctalk "Nadoyo : This way.","Nadoyo#ep21nadoyo01",bc_self;
		sleep2 1500;
		pcblock(false);
		cloaknpc("Nadoyo#ep21nadoyo01",true,getcharid(0));
		cloaknpc("Tan#ep21tan01",true,getcharid(0));
		end;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23255) == 1";
end;
}

jor_mbase,204,193,3	script(CLOAKED)	Tris#ep21tris01	4_EP21_TRIS,{
	if(isbegin_quest(18338) == 0) end;
	if(isbegin_quest(18342) == 0){
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "See if you can find anyone who witnessed something resembling a serpent.";
		mes "In the meantime, I'll gather our allies and prepare for battle.";
		close3;
	}
	if(isbegin_quest(18342) == 1){
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "I've sent request to our key allies to join us.";
		mes "Have you gathered any information?";
		next;
		cutin "ep21_tris06.png",2;
		mes "[Tris]";
		mes "A giant serpent-like monster appeared, ate people, and then vanished into thin air...?";
		mes "Why didn't we receive any reports like this?";
		next;
		cutin "ep21_tris11.png",2;
		mes "[Tris]";
		mes "Did the witnesses dismissed it because they deemed it as hallucinations?";
		mes "Or maybe they were paralyzed by fear...";
		mes "But from everything that we've learn...";
		next;
		cutin "ep21_tris05.png",2;
		mes "[Tris]";
		mes "The part about it eating people bothers me.";
		mes "We might learn more once Tan and Nadoyo returns....";
		next;
		mes ".....";
		next;
		cutin "ep21_tris02.png",2;
		mes "[Tris]";
		mes "It's already past our designated meeting time, why haven't they returned?";
		next;
		select("Should I go?");
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "Could you help?";
		mes "They might have gone near the cult's village or the Gimli, they might have encountered a danger or that serpent itself, so it would be reassuring if you could go.";
		next;
		cutin "ep21_tris03.png",2;
		mes "[Tris]";
		mes "I'm sure they are safe, but we can't be too complacent...";
		mes "I'm counting on you.";
		mes "In the meantime, I'll make sure our forces are prepared.";
		completequest 18342;
		setquest 18343;
		close3;
	}
	if(isbegin_quest(18343) == 1){
		mes "[Tris]";
		mes "They might have gone near the cult's village or the Gimli.";
		mes "Please check those areas.";
		cutin "ep21_tris02.png",2;
		close3;
	}
	if(isbegin_quest(18345) == 1){
		cutin "ep21_tris04.png",2;
		mes "[Tris]";
		mes "Nadoyo! Why are you so late?";
		mes "Where's Tan? I've gathered everyone, but Reinhardt isn't here either.";
		next;
		cutin "ep21_nadoyo01.png",0;
		mes "[Nadoyo]";
		mes "Were you worried?";
		mes "More importantly, we've identified the location where we believed the serpent is.";
		mes "Tan and Reinhardt are both there now.";
		next;
		cutin "ep21_nadoyo05.png",0;
		mes "[Nadoyo]";
		mes "I'm not sure what the Jormungandr cult created, but they referred to it as one destined to be their god.";
		mes "They said that it absorbs mana from humans.";
		next;
		cutin "ep21_tris04.png",2;
		mes "[Tris]";
		mes "Is that why there are rumors of Jormungandr's resurrection?";
		mes "I understand. It's best that the soldiers doesn't know about this.";
		mes "I don't want to cause unecessary panic. It would only instill more fear from those who escaped from the cult.";
		next;
		cutin "ep21_nadoyo01.png",0;
		mes "[Nadoyo]";
		mes "Are we keeping the battle personnel to a minimum?";
		mes "It's wise to exclude normal soldiers.";
		next;
		cutin "ep21_tris03.png",2;
		mes "[Tris]";
		mes "That's right. If a monster has appeared, it's our responsibility to deal with it.";
		mes "The others have lives to go back to, right?";
		next;
		mes "[Tris]";
		mes strcharinfo(0)+". Thank you for everything until now.";
		mes "We'll take care of what happens next.";
		next;
		select("What does it mean?");
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "You have your purpose for being here, don't you?";
		mes "Facing the giant serpent is our purpose. You need to focus on yours.";
		next;
		mes "[Tris]";
		mes "I've already gathered your comrades.";
		mes "They're waiting on the 2nd floor of the barracks, join them.";
		next;
		cutin "ep21_nadoyo02.png",0;
		mes "[Nadoyo]";
		mes "I'll head to the front line.";
		mes "I'll guide you there.";
		completequest 18345;
		setquest 18346;
		close2;
		cutin "",255;
		cloaknpc("Nadoyo#ep21nadoyo01",true,getcharid(0));
		end;
	}
	if(isbegin_quest(18346) == 1){
		cutin "ep21_tris01.png",2;
		mes "[Tris]";
		mes "I worked you and your friends quite thoroughly.";
		mes "You have your purpose for being here, don't you?";
		next;
		mes "[Tris]";
		mes "Now it's the time to fulfill that.";
		mes "We're going to win. Right?";
		close3;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18342) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18345) == 1";
end;
}

jor_mbase,207,192,3	duplicate(dummynpc)	Tan#ep21tan01	4_EP21_TAN

function	script	ep21_witness_check	{
	for(.@i = 18339; .@i <= 18341; .@i++)
		if(isbegin_quest(.@i) != 1)	return false;
	return true;
}

jor_mbase,189,249,7	script	Exhausted Soldier#ep21pt1ex02	4_EP21_SOLDIER_B,{
	if(isbegin_quest(18338) == 1 && isbegin_quest(18339) == 0){
		cutin "ep21_soldier_b.png",2;
		mes "[Exhausted Soldier]";
		mes "...? Ah... a giant serpent..";
		mes "Yes. It was a giant serpent. It was huge and monstrous.";
		mes "Was that Jormungandr?";
		next;
		mes "[Exhausted Soldier]";
		mes "Well, according to the cult's history books, Jormungandr is supposed to have a a beautiful, pearly white scale....";
		mes "But it was nothing like that. It looked very ominous.";
		next;
		mes "[Exhausted Soldier]";
		mes "But... it was massive.";
		next;
		select("Where is it now?");
		mes "[Exhausted Soldier]";
		mes "Well, I was about to report it, but it suddenly vanished when I took a closer look.";
		mes "Did I just imagine it? Im still wondering.";
		mes "But it wasnt. Since some people were injured by its attack.";
		next;
		mes "[Exhausted Soldier]";
		mes "Are you trying to hunt it down?";
		mes "Sorry I can't be more of a help, but I saw isn't an illusion or a mirage. The giant serpent is real.";
		next;
		cutin "",255;
		setquest 18339;
		if(!ep21_witness_check()){
			mes "Let's look for more witness.";
		} else {
			mes "It seems that I've gathered enough witnesses of the giant serpent.";
			mes "Let's return to Tris and share the information.";
			completequest 18338;
			completequest 18339;
			completequest 18340;
			completequest 18341;
			setquest 18342;
			questinfo_refresh;
		}
		close3;
	}
	cutin "ep21_soldier_b.png",2;
	mes "[Exhausted Soldier]";
	mes "Will there ever be an end to this fight...?";
	mes "There is nothing good about it, I hope it ends soon...";
	close3;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18338) == 1 && isbegin_quest(18339) == 0";
end;
}

jor_mbase,218,298,5	script	Cult Member Escapee#ep21	4_EP21_M_WORKER_B,{
	if(isbegin_quest(18338) == 1 && isbegin_quest(18340) == 0){
		cutin "ep21_worker_m_07.png",0;
		mes "[Cult Member Escapee]";
		mes "Where I came from? I.. came from the church's village.";
		mes "When I was foraging for seafood... I was forced to run away...";
		next;
		select("Why did you run away?");
		mes "[Cult Member Escapee]";
		mes "Well, it was sudden... Listen to my story.";
		mes "It's true I was part of the church, but I didn't think that working for them was wrong...";
		next;
		mes "[Cult Member Escapee]";
		mes "You understand it, right? People clings to things easily. In my case it was the Jormungandr church...";
		next;
		select("Why, what were you running from?");
		mes "[Cult Member Escapee]";
		mes "The priests... they summoned a monster.";
		mes "I saw the monster... eating people... yes... I realized that if I stayed there.. I would be the next meal for it!";
		next;
		mes "[Cult Member Escapee]";
		mes "I ran without looking back.";
		mes "I was certain! I saw a serpent shaped monster eating people!";
		next;
		mes "[Cult Member Escapee]";
		mes "Was it a human? No. .no. It's a serpent. A big serpent.";
		mes "It was a person.. ? but also a serpent..?";
		mes "What? Just what did I see??";
		next;
		mes "[Cult Member Escapee]";
		mes "... Wait... I need to be alone.. just for a moment. Actually, no. Please leave me alone!";
		next;
		cutin "",255;
		mes "He seemed distressed.";
		mes "Let's stop asking questions.";
		next;
		setquest 18340;
		if(!ep21_witness_check()){
			mes "Let's look for more witness.";
		} else {
			mes "It seems that I've gathered enough witnesses of the giant serpent.";
			mes "Let's return to Tris and share the information.";
			completequest 18338;
			completequest 18339;
			completequest 18340;
			completequest 18341;
			setquest 18342;
			questinfo_refresh;
		}
		close3;
	}
	cutin "ep21_worker_m_07.png",0;
	mes "[Cult Member Escapee]";
	mes "Jormungandr is supposed to be a good god... but that thing... that serpent is...";
	close3;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18338) == 1 && isbegin_quest(18340) == 0";
end;
}

jor_mbase,60,196,3	script	Wounded Soldier#ep21pt1ex	4_EP21_SOLDIER_A,{
	if(isbegin_quest(18338) == 1 && isbegin_quest(18341) == 0){
		cutin "ep21_soldier_a.png",2;
		mes "[Wounded Soldier]";
		mes "Ah... I thought I was going to die.";
		mes "What? Do you need something from me?";
		mes "While you're here, can you apply ointment on my back?";
		next;
		select("Where should I apply it?");
		mes "[Wounded Soldier]";
		mes "*Painful hiss*... here's the thing. I was in Gimli, the temple that the cult built, you know it?";
		mes "I was doing my routine patrol there.";
		next;
		mes "[Wounded Soldier]";
		mes "Then suddenly, a massive shadow loomed over me.";
		mes "Have you experienced when a cloud passed on over the sun on a bright sunny day?";
		mes "It was like that....";
		next;
		mes "[Wounded Soldier]";
		mes "It sent chills through my body.. the shadow.. it wriggled in a weird way?";
		mes "I ran away and didn't look back.";
		next;
		mes "[Wounded Soldier]";
		mes "Ah, please on my back. Please apply it.";
		mes "So, while I was running, something attacked me from the back.";
		mes "That's the spot. Right there.";
		next;
		mes "[Wounded Soldier]";
		mes "It sent me rolling to the ground... But I didn't give up, and kept on running. Was it a smart move?";
		mes "Thanks for the ointment.";
		next;
		select("What's the shape of the shadow?");
		mes "[Wounded Soldier]";
		mes "Uhm... A monster with tentacle..? Oh, since it hit my back, shouldn't there be a mark?";
		next;
		mes "There's a faint imprint of serpent scales on his back.";
		mes "That seems to be a sufficient answer.";
		next;
		mes "[Wounded Soldier]";
		mes "What? What was it?";
		mes "A serpent? Was it a serpent....? Is there a serpent that big? I've never seen one before....";
		mes "Anyways, thank you.";
		cutin "",255;
		setquest 18341;
		if(!ep21_witness_check()){
			mes "Let's look for more witness.";
		} else {
			mes "It seems that I've gathered enough witnesses of the giant serpent.";
			mes "Let's return to Tris and share the information.";
			completequest 18338;
			completequest 18339;
			completequest 18340;
			completequest 18341;
			setquest 18342;
			questinfo_refresh;
		}
		close3;
	}
	cutin "ep21_soldier_a.png",2;
	mes "[Wounded Soldier]";
	mes "...Wh-where am I hurt? I think my heart hurts. My heart .. it feels.. really bad.";
	close3;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18338) == 1 && isbegin_quest(18341) == 0";
end;
}

jor_raise1,199,190,3	script	Rock Crevice#ep21p01evt04	4_POINT_BLUE,{
	if(isbegin_quest(18343) == 1){
		cutin "ep21_nadoyo02.png",1;
		mes "[Nadoyo]";
		mes "This way.";
		close2;
		cutin "",255;
		warp "luna_sf1",253,253;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18343) == 1";
end;
}

luna_sf1,253,257,5	script	Nadoyo#21pt1nadoyo02	4_EP21_NADOYO,{
	if(isbegin_quest(18343) == 1){
		cutin "ep21_nadoyo02.png",1;
		mes "[Nadoyo]";
		mes "Perfect timing. I was wondering how should we relay the information to the captain...";
		next;
		select("Is something wrong?");
		cutin "ep21_nadoyo01.png",1;
		mes "[Nadoyo]";
		mes "We investigated the surrounding area, but we didn't find any of the serpent, not a shadow nor a scale.";
		mes "But Reinhardt gave us some advice just as I was about to give up.";
		next;
		cutin "ep21_reinhardt01.png",0;
		mes "[Reinhardt]";
		mes "As a devout member of the church, I rose to the ranks very quickly, but because of that I wasn't able to examine many places.";
		mes "There's a place that comes into mind, so I decided to check it.";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "We ran into each other, and we were about to go there together.";
		mes "I know Tris is waiting, but we need to bring back something useful.";
		next;
		cutin "ep21_nadoyo01.png",1;
		mes "[Nadoyo]";
		mes "The place Reindhart mentioned isn't far from here.";
		mes "Wouldn't it be better that we find some solid evidence about the serpent?";
		next;
		mes "[Nadoyo]";
		mes "The place Reinhardt is talking about is one I never paid attention before.";
		mes "I always thought that door was just something decorative.";
		next;
		select("Decorative door?");
		cutin "ep21_nadoyo05.png",1;
		mes "[Nadoyo]";
		mes "Yes. There are many decorative doors throughout the temple. Some are real doors, and some aren't.";
		mes "The one we're talking about now seemed like it's like just a decorative door.";
		next;
		cutin "ep21_reinhardt01.png",0;
		mes "[Reinhardt]";
		mes "You'll understand once we get there.";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Alright. Let's check it before we return.";
		mes "I heard that the giant serpent disappeared, right?";
		mes "There must be some connection.";
		next;
		cutin "ep21_reinhardt01.png",0;
		mes "[Reinhardt]";
		mes "Exactly. I'll lead the way.";
		mes "Let's head to the temple.";
		completequest 18343;
		setquest 18344;
		close3;
	}
	if(isbegin_quest(18344) == 1){
		mes "[Nadoyo]";
		mes "I'll mark it on your map, so don't worry about getting lost.";
		mes "Let's hurry and see what we can find.";
		cutin "ep21_nadoyo01.png",1;
		close3;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18343) == 1";
end;
}

luna_sf1,255,258,4	script	Tan#21pt1tan02	4_EP21_TAN,{
	if(isbegin_quest(18344) == 1){
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Is Tris preparing the forces?";
		mes "That's good. If we can find it's location, we can engage it full-scale...";
		close3;
	}
	end;
}

luna_sf1,257,257,4	script	Reinhardt#21pt1rnhrd01	4_EP21_REINHARDT,{
	if(isbegin_quest(18344) == 1){
		mes "[Reinhardt]";
		mes "There's a bridge that connects to the annex below the temple.";
		mes "Our destination is there.";
		cutin "ep21_reinhardt01.png",0;
		close3;
	}
	end;
}

jor_raise1,128,326,3	script	Decorative Door#ep21p01evt05	4_POINT_BLUE,{
	if(isbegin_quest(18344) == 1){
		cutin "ep21_reinhardt07.png",0;
		mes "[Reinhardt]";
		mes "Do you see the crack at the center of the door?";
		mes "The plastered section has been split open. This means it's not a simple decorative door and has been opened before.";
		mes "Let's go inside.";
		close2;
		cutin "",255;
		warp "luna_sf2",252,142;
		end;
	}
	if(isbegin_quest(18347) > 0){
		mes "There's a hidden opening in the decorative door.";
		mes "You'll be able to go in.";
		next;
		if(select("Go in now.","Don't go in.") == 2) end;
		warp "luna_sf2",252,142;
		close;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18344) == 1";
end;
}

luna_sf2,252,143,0	script	#ep21pt1evt5	HIDDEN_WARP_NPC,5,5,{
	end;
	
OnTouch:
	if(isbegin_quest(18344) == 1){
		cloaknpc("Tan#21pt1tan03",false,getcharid(0));
		cloaknpc("Nadoyo#21pt1nadoyo03",false,getcharid(0));
		cloaknpc("Reinhardt#21pt1rnhrd02",false,getcharid(0));
		cloaknpc("Cult Priest#21pt1ex05",false,getcharid(0));
		cutin "ep21_nadoyo01.png",0;
		mes "[Nadoyo]";
		mes "There's someone inside!";
		mes "Tan! Go in and subdue him!";
		close3;
	}
	if(isbegin_quest(18347) == 1){
		cloaknpc("Nadoyo#21pt1nadoyo04",false,getcharid(0));
		end;
	}
	if(isbegin_quest(18349) == 1){
		cloaknpc("Nyar#ep21nya04",false,getcharid(0));
		end;
	}
	if(isbegin_quest(18360) == 2)
		cloaknpc("Door#ep21_lastbattle",false,getcharid(0));
end;
}

luna_sf2,270,162,3	script(CLOAKED)	Cult Priest#21pt1ex05	EP21_YORDOS_A,{
	if(isbegin_quest(18344) == 1){
		cutin "ep21_yordos.png",1;
		mes "[Cult Priest]";
		mes "How did you find your way in here?";
		mes "You! And you! Have you betrayed the church?!";
		next;
		cutin "ep21_nadoyo05.png",0;
		mes "[Nadoyo]";
		mes "I have never betrayed the church.";
		next;
		cutin "ep21_yordos.png",1;
		mes "[Cult Priest]";
		mes "Don't lie to me. Why are you intering with me?";
		mes "Why did you bring these disgusting people from the Gaebolg with you?";
		next;
		cutin "ep21_tan01.png",2;
		mes "[Tan]";
		mes "Sorry to disgust you.";
		mes "We didn't mean to interfere.";
		next;
		cutin "ep21_yordos.png",1;
		mes "[Cult Priest]";
		mes "This is a sacred place. Leave now without further interfering.";
		mes "Do it now while I'm still willing to let you go!";
		next;
		cutin "ep21_nadoyo05.png",0;
		mes "[Nadoyo]";
		mes "We didn't intend to disturb you.";
		mes "We only came here because we saw a gap between the decorative door. What exactly are you doing here?";
		next;
		cutin "ep21_tan01.png",2;
		mes "[Tan]";
		mes "This doesn't look like an ordinary storage room.";
		next;
		cutin "ep21_yordos.png",1;
		mes "[Cult Priest]";
		mes "Storage room? Storage room! This is where prepare ourselves, purify our bodies, and wait to be consumed by him!";
		mes "You stupid humans!";
		next;
		cutin "ep21_nadoyo01.png",0;
		mes "[Nadoyo]";
		mes "... By him. Who, Jormungandr?";
		next;
		cutin "ep21_yordos.png",1;
		mes "[Cult Priest]";
		mes "Don't you dare say his name with your unworthy mouth!!!";
		mes "He will become our god! He will become Jormungandr!!!";
		close2;
		cutin "",255;
		pcblock(true);
		specialeffect EF_BEGINSPELL,AREA,"Cult Priest#21pt1ex05";
		sleep2 500;
		specialeffect EF_LINKLIGHT,AREA,"Tan#21pt1tan03";
		specialeffect EF_HIT2,AREA,"Cult Priest#21pt1ex05";
		npctalk "Cult Priest : ... Grr...","Cult Priest#21pt1ex05",bc_self;
		specialeffect EF_HIT3,AREA,"Cult Priest#21pt1ex05";
		sleep2 900;
		pcblock(false);
		npctalk "Tan : ...","Tan#21pt1tan03",bc_self;
		cutin "ep21_reinhardt07.png",0;
		mes "[Reinhardt]";
		mes "Is the priest unconscious?";
		next;
		cutin "ep21_nadoyo01.png",0;
		mes "[Nadoyo]";
		mes "It seems so. Anyways, it looks like we've come to the right place.";
		mes "He mentioned something about being consumed by him, right?";
		next;
		select("A witness said that it eats people.");
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Eating people? What does that mean?";
		mes "Do we know anything about this serpent?";
		next;
		cutin "ep21_nadoyo03.png",0;
		mes "[Nadoyo]";
		mes "Did someone really mention a serpent eating people?";
		mes "Is that true?";
		next;
		cutin "ep21_reinhardt02.png",0;
		mes "[Reinhardt]";
		mes "It's absorbing their mana.";
		mes "When the Jormungandr cult began to rise.. have you ever wondered where did the priests of Odin and Freyja church went?";
		next;
		cutin "ep21_reinhardt01.png",0;
		mes "[Reinhardt]";
		mes "The high priest and shamans absorbed all their power, divine energy, and life force to make it their own.";
		next;
		mes "[Reinhardt]";
		mes "They targeted the priests of Odin and Freyja who were weakened from the War of the Gods before they could even recovered.";
		next;
		cutin "ep21_tan02.png",1;
		mes "[Tan]";
		mes "So the Jormungandr cult took over the abandoned temples and cathedrals...";
		mes "And those maniacs are offering mana to this serpent?";
		next;
		cutin "ep21_nadoyo04.png",0;
		mes "[Nadoyo]";
		mes "The fates of those fanatics is truly terrifying, isn't it?";
		mes "For them, going into a holy war is no different from a sacred ritual.";
		next;
		mes "[Nadoyo]";
		mes "He said that he will become Jormungandr... Jormungandr is a serpent, right?";
		mes "The giant serpent is probably the one he is referring to as Jormungandr...";
		next;
		cutin "ep21_reinhardt01.png",0;
		mes "[Reinhardt]";
		mes "Considering that it needs to absorb mana and it disappear suddenly, it means that it's not complete yet.";
		mes "In other words, this is our chance.";
		next;
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "Alright. I'll deal with it, the rest of you head back to Lunaforma.";
		mes "Tell them to prepare thoroughly. There might be an unfinished serpent beyond that door.";
		next;
		cutin "ep21_reinhardt01.png",0;
		mes "[Reinhardt]";
		mes "I'll stay just in case.";
		mes "The other priests or cult members might come.";
		next;
		mes "[Nadoyo]";
		mes "Then, I'll go with " + strcharinfo(0) + " and report to the captain.";
		mes "Stay safe.";
		cutin "ep21_nadoyo01.png",0;
		completequest 18344;
		setquest 18345;
		close2;
		cutin "",255;
		end;
	}
	if(isbegin_quest(18345) == 1){
		cutin "ep21_tan01.png",1;
		mes "[Tan]";
		mes "We'll handle it here, focus on what you need to do.";
		close3;
	}
	end;
}

luna_sf2,271,159,1	script(CLOAKED)	Tan#21pt1tan03	4_EP21_TAN,{
	npctalk "A giant serpent, I wonder what it looks like.","",bc_self;
	end;
}

luna_sf2,268,146,3	script(CLOAKED)	Reinhardt#21pt1rnhrd02	4_EP21_REINHARDT,{
	npctalk "Be careful.","",bc_self;
	end;
}

luna_sf2,268,158,7	script(CLOAKED)	Nadoyo#21pt1nadoyo03	4_EP21_NADOYO,{
	if(isbegin_quest(18345) == 1){
		mes "[Nadoyo]";
		mes "Let's return to Lunaforma and report to the captain.";
		mes "Follow me.";
		cutin "ep21_nadoyo01.png",1;
		close2;
		cutin "",255;
		warp "jor_mbase",338,148;
		end;
	}
	end;
}

luna_sf2,254,162,3	script(CLOAKED)	Nadoyo#21pt1nadoyo04	4_EP21_NADOYO,{
	if(isbegin_quest(18347) == 1){
		cutin "ep21_nadoyo01.png",0;
		mes "[Nadoyo]";
		mes "Wait, " + strcharinfo(0) + ", what brings you here?";
		mes "Weren't you not joining this battle?";
		next;
		select("Well, I'm here.");
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "Ya-hoo, I didn't have a choice since they wanted to join.";
		mes "I've upgraded the tablet's capabilities, but I need " + strcharinfo(0) + " to utilize it.";
		next;
		cutin "ep21_tris06.png",2;
		mes "[Tris]";
		mes "Nadoyo, aren't you going in?";
		mes strcharinfo(0)+"? What are you doing here?";
		mes "What about your comrades!";
		next;
		cutin "ep21_ilse_heine05.png",1;
		mes "[Ilse El Heine]";
		mes "Well,  You see.. It... just happened that I need help?";
		next;
		cutin "ep21_tris11.png",2;
		mes "[Tris]";
		mes "I'm not sure what's going in, but it's fine if Heine needs you.";
		mes "It must be something important.";
		mes "I'm counting on you. Please prioritize your safety above all else.";
		next;
		cutin "ep21_nadoyo02.png",0;
		mes "[Nadoyo]";
		mes "We can go through this door.";
		mes "I've secured the path ahead.";
		completequest 18347;
		setquest 18348;
		cloaknpc("Door#ep21_lastbattle",false,getcharid(0));
		close3;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18347) == 1";
end;
}

luna_sf2,252,164,3	script(CLOAKED)	Door#ep21_lastbattle	4_POINT_BLUE,{
	if(isbegin_quest(18348) > 0)
		warp "luna_sf2",260,34;
	end;
	
OnInit:
	npc_resize(Size_Medium);
end;
}

luna_sf2,254,150,3	script(CLOAKED)	Nyar#ep21nya04	4_EP20_NYAR,{
	if(isbegin_quest(18349) == 1){
		pcblock(true);
		npctalk "Nyar : Meeeow~~~~","",bc_self;
		sleep2 2000;
		pctalk "What? Where are you trying to bring me? Inside there..!!";
		sleep2 2000;
		npctalk "Nyar : Nya! Nya! Hiss---!","",bc_self;
		sleep2 2000;
		pcblock(false);
		warp "luna_sf2",266,257;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18349) == 1";
end;
}

luna_sf2,260,45,0	script	#hs_wp01	HIDDEN_WARP_NPC,2,2,{
	end;
	
OnTouch:
	if(isbegin_quest(18348) == 1 || isbegin_quest(18348) == 2 && isbegin_quest(12656) == 0 || isbegin_quest(12656) == 1){
		if(isbegin_quest(18348) == 1){
			completequest 18348;
			questinfo_refresh;
		}
		cloaknpc("Heine#md1",false,getcharid(0));
		cloaknpc("Tan#md",false,getcharid(0));
		cloaknpc("Tris#md",false,getcharid(0));
		cloaknpc("Galaxia#md",false,getcharid(0));
		cloaknpc("Gunter#md",false,getcharid(0));
		cloaknpc("Wilhelm#md",false,getcharid(0));
		cloaknpc("Reinhardt#md",false,getcharid(0));
		cloaknpc("Aurelie#md",false,getcharid(0));
		cloaknpc("Maristella#md",false,getcharid(0));
		cloaknpc("Yohan#md",false,getcharid(0));
		cloaknpc("Ivan#md",false,getcharid(0));
		cloaknpc("Richard#md",false,getcharid(0));
		cloaknpc("Nadoyo#md",false,getcharid(0));
		end;
	}
	if(isbegin_quest(18360) == 2){
		cloaknpc("Heine#md2",false,getcharid(0));
		cloaknpc("Tan#md",false,getcharid(0));
		cloaknpc("Tris#md",false,getcharid(0));
		cloaknpc("Galaxia#md",false,getcharid(0));
		cloaknpc("Gunter#md",false,getcharid(0));
		cloaknpc("Wilhelm#md",false,getcharid(0));
		cloaknpc("Reinhardt#md",false,getcharid(0));
		cloaknpc("Aurelie#md",false,getcharid(0));
		cloaknpc("Maristella#md",false,getcharid(0));
		cloaknpc("Yohan#md",false,getcharid(0));
		cloaknpc("Ivan#md",false,getcharid(0));
		cloaknpc("Richard#md",false,getcharid(0));
		cloaknpc("Nadoyo#md",false,getcharid(0));
	}
end;
}

luna_sf2,260,46,4	script(CLOAKED)	Heine#md1	4_EP21_HEINE_TAB,{
	if(isbegin_quest(18348) == 2 && isbegin_quest(12656) == 0){
		cutin "ep21_ilse_heine02.png",2;
		mes "[Heine]";
		mes "Is this the place Reinhardt and Nadoyo were talking about?";
		next;
		cutin "ep21_nadoyo01.png",2;
		mes "[Nadoyo]";
		mes "I can't sense any energy beyond this point. Reinhardt, how about you?";
		next;
		cutin "ep21_reinhardt07.png",2;
		mes "[Reinhardt]";
		mes "I can't sense anything beyond this area too.";
		next;
		cutin "ep21_ilse_heine02.png",2;
		mes "[Heine]";
		mes "So, it's that intense. That means that it's very dangerous. How about we head back, regroup, and come back?";
		next;
		cutin "ep21_tris04.png",2;
		mes "[Tris]";
		mes "We can't retreat now that we've come this far. Let's push forward.";
		next;
		cutin "ep21_tan04.png",2;
		mes "[Tan]";
		mes "I don't feel good about this. I have a very bad feeling. We should proceed with more caution.";
		next;
		cutin "ep21_tris04.png",2;
		mes "[Tris]";
		mes "We don't have that kind of luxury. I know it's risky, but I want to continue the search as planned.";
		next;
		cutin "ep21_ilse_heine02.png",2;
		mes "[Heine]";
		mes "Alright, let's decide by majority vote. If you want to push forward, do say so. If you're against it, make your objection known.";
		close2;
		cutin "",255;
		npctalk "I'm in.","Galaxia#md",bc_self;
		npctalk "I'm against it.","Gunter#md",bc_self;
		npctalk "I'm in.","Wilhelm#md",bc_self;
		npctalk "I'm in.","Reinhardt#md",bc_self;
		npctalk "I'm against it.","Aurelie#md",bc_self;
		sleep2 500;
		npctalk "I'm in.","Maristella#md",bc_self;
		npctalk "I'm in.","Yohan#md",bc_self;
		npctalk "I'm against it.","Ivan#md",bc_self;
		npctalk "I'm against it.","Richard#md",bc_self;
		sleep2 500;
		npctalk "I'm in.","Nadoyo#md",bc_self;
		sleep2 1000;
		cutin "ep21_ilse_heine02.png",2;
		mes "[Heine]";
		mes "Hm, 7 people who agrees. 4 people who are against it.. Including Tris and Tan's votes....";
		next;
		mes "[Heine]";
		mes "That makes it 8 against 5 votes. So we proceed with the search. Are you okay with that, Tan?";
		next;
		cutin "ep21_tan01.png",2;
		mes "[Tan]";
		mes "We have to go with the majority. So, how do we move beyond this point?.";
		next;
		cutin "ep21_ilse_heine02.png",2;
		mes "[Heine]";
		mes "Hehe, this is the perfect time to showcase my life's work, my spacial magic, then Hopi-hop Spacial Jump.";
		close2;
		cutin "",255;
		npctalk "Hopi what?","Tan#md",bc_self;
		npctalk "What's with the weird name?","Maristella#md",bc_self;
		setquest 12656;
		end;
	}
	if(isbegin_quest(12656) == 1){
		.@md_name$ = "Final Battle";
		.@party_id = getcharid(1);
		if(!.@party_id){
			mes "^0000ffPlease speak to me once the party leader has finished the preparation to enter.^000000";
			close;
		}
		if(is_party_leader() && instance_live_info(ILI_NAME,instance_id(IM_PARTY)) != "Final Battle"){
			select("Hopi-hop spacial jump.");
			if(instance_create(.@md_name$) == -3)
				instance_warning(2,.@md_name$);
			end;
		}
		if(instance_live_info(ILI_NAME,instance_id(IM_PARTY)) != "Final Battle"){
			mes "^0000ffPlease speak to me once the party leader has finished the preparation to enter.^000000";
			close;
		}
		select("Begin the Final Battle");
		if(instance_enter(.@md_name$) != IE_OK){
			mes "^0000ffPlease speak to me once the party leader has finished the preparation to enter.^000000";
			close;
		}
		mapannounce "luna_sf2", "The adventurer, " + strcharinfo(0) + " is entering the Final Battle.", bc_map, "0x00FFAA";
		end;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18348) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18348) == 2 && isbegin_quest(12656) == 0";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(12656) == 1";
end;
}

function	script	hasUnlockedHard	{
	for(.@i = 13; .@i <= 19; .@i++){
		if(get_reputation_points(.@i) < 1000)
			return false;
	}
	return true;
}

luna_sf2,260,46,4	script(CLOAKED)	Heine#md2	4_EP21_HEINE_TAB,{
	if(isbegin_quest(18360) < 2) end;
	.@bool = hasUnlockedHard();
	switch(checkquest(12647,PLAYTIME)){
		case -1:
			.@normal = true;
			break;
		case 0:
		case 1:
			if(!.@bool){
				mes "^0000ffEveryone is not moving as if they’re frozen in place. Could time have momentarily stopped?^000000";
				close;
			} else
				.@cd += 1;
			break;
		case 2:
			erasequest 12674;
			.@normal = true;
			break;
	}
	switch(checkquest(12648,PLAYTIME)){
		case -1:
			.@hard = true;
			break;
		case 0:
		case 1:
			if(.@cd){
				mes "^0000ffEveryone is not moving as if they’re frozen in place. Could time have momentarily stopped?^000000";
				close;
			} else
				.@cd += 1;
			break;
		case 2:
			.@hard = true;
			erasequest 12648;
			break;
	}
	if(.@cd == 2){
		mes "^0000ffEveryone is not moving as if they’re frozen in place. Could time have momentarily stopped?^000000";
		close;
	}
	cutin "ep21_ilse_heine02.png",2;
	mes "[Heine]";
	mes "Hehe, this is the perfect time to showcase my life's work, my spacial magic, then Hopi-hop Spacial Jump.";
	close2;
	cutin "",255;
	.@party_id = getcharid(1);
	if(!.@party_id){
		mes "^0000ffPlease speak to me once the party leader has finished the preparation to enter.^000000";
		close;
	}
	npctalk "Hm. I feel like I've heard that before.","Tan#md",bc_self;
	npctalk "I'm feeling the same as well.","",bc_self;
	cutin "",255;
	if(is_party_leader() && instance_live_info(ILI_NAME,instance_id(IM_PARTY)) != "Final Battle(Normal)" && instance_live_info(ILI_NAME,instance_id(IM_PARTY)) != "Final Battle(Hard)"){
		if(select((.@normal == true ? "Prepare for Final Battle(Normal)" : ""),(.@bool == true && .@hard == true ? "Prepare for Final Battle(Hard)" : "")) == 1)
			.@md_name$ = "Final Battle(Normal)";
		else
			.@md_name$ = "Final Battle(Hard)";
		if(instance_create(.@md_name$) == -3)
			instance_warning(2,.@md_name$);
		end;
	}
	if(instance_live_info(ILI_NAME,instance_id(IM_PARTY)) != "Final Battle(Normal)" && instance_live_info(ILI_NAME,instance_id(IM_PARTY)) != "Final Battle(Hard)"){
		mes "^0000ffPlease speak to me once the party leader has finished the preparation to enter.^000000";
		close;
	}
	if(instance_live_info(ILI_NAME,instance_id(IM_PARTY)) == "Final Battle(Normal)"){
		select("Begin the Final Battle(Normal)");
		.@md_name$ = "Final Battle(Normal)";
		if(instance_enter(.@md_name$) != IE_OK){
			mes "^0000ffPlease speak to me once the party leader has finished the preparation to enter.^000000";
			close;
		}
		setquest 12647;
		mapannounce "luna_sf2", "The adventurer, " + strcharinfo(0) + " is entering the Final Battle(Normal).", bc_map, "0x00FFAA";
		end;
	}
	if(instance_live_info(ILI_NAME,instance_id(IM_PARTY)) == "Final Battle(Hard)"){
		if(isbegin_quest(12650) < 2){
			mes "^0000ffPlease speak to me once the party leader has finished the preparation to enter.^000000";
			close;
		}
		select("Begin the Final Battle(Hard)");
		.@md_name$ = "Final Battle(Hard)";
		if(instance_enter(.@md_name$) != IE_OK){
			mes "^0000ffPlease speak to me once the party leader has finished the preparation to enter.^000000";
			close;
		}
		setquest 12648;
		mapannounce "luna_sf2", "The adventurer, " + strcharinfo(0) + " is entering the Final Battle(Normal).", bc_map, "0x00FFAA";
		end;
	}
	end;
	
OnInit:
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(18360) == 2 && checkquest(12647,PLAYTIME) == -1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(18360) == 2 && checkquest(12647,PLAYTIME) == 2";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(18360) == 2 && hasUnlockedHard() == true && checkquest(12648,PLAYTIME) == -1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(18360) == 2 && hasUnlockedHard() == true && checkquest(12648,PLAYTIME) == 2";
end;
}

luna_sf2,265,46,1	script(CLOAKED)	Yohan#md	EP21_NPC_YOHAN,1,1,{
	cutin "ep21_yohan03.png",2;
	mes "[Yohan]";
	mes "Whew... I'm not sure if this is the right decision.";
	close3;
}

luna_sf2,267,44,1	script(CLOAKED)	Nadoyo#md	EP21_NPC_NADOYO,1,1,{
	cutin "ep21_nadoyo01.png",2;
	mes "[Nadoyo]";
	mes "I-…I'm not scared. I can handle this much!";
	close3;
}

luna_sf2,265,42,1	script(CLOAKED)	Richard#md	EP21_NPC_RICHARD,1,1,{
	cutin "ep21_richard01.png",2;
	mes "[Richard]";
	mes "I'm not thinking of turning back.";
	close3;
}

luna_sf2,262,44,1	script(CLOAKED)	Tris#md	EP21_NPC_TRIS,1,1,{
	cutin "ep21_tris04.png",2;
	mes "[Tris]";
	mes "We can't retreat now that we've come this far.";
	close3;
}

luna_sf2,262,40,1	script(CLOAKED)	Ivan#md	EP21_NPC_IVAN,1,1,{
	cutin "ep21_ivan02.png",2;
	mes "[Ivan]";
	mes "If Tan is going through with it, Then I'll lend a hand.";
	close3;
}

luna_sf2,258,40,7	script(CLOAKED)	Aurelie#md	4_EP21_AURELIE,1,1,{
	cutin "ep21_aurelie01.png",2;
	mes "[Aurelie]";
	mes "There won't be any major issues. Let's hold on to hope.";
	close3;
}

luna_sf2,258,44,7	script(CLOAKED)	Tan#md	EP21_NPC_TAN,1,1,{
	cutin "ep21_tan04.png",2;
	mes "[Tan]";
	mes "I have a bad feeling about this.";
	close3;
}

luna_sf2,256,42,7	script(CLOAKED)	Galaxia#md	EP21_NPC_GALAXIA,1,1,{
	cutin "ep21_galaxia_a.png",2;
	mes "[Galaxia]";
	mes "I can't feel anything. That means its very dangerous.";
	close3;
}

luna_sf2,253,43,7	script(CLOAKED)	Wilhelm#md	EP21_NPC_WILHELM,1,1,{
	cutin "ep21_wilhelm01.png",2;
	mes "[Wilhelm]";
	mes "I'm against it. That's what my rational mind tells me, but…";
	close3;
}

luna_sf2,255,45,7	script(CLOAKED)	Maristella#md	EP21_NPC_MARISTELLA,1,1,{
	cutin "ep21_maristella01.png",2;
	mes "[Maristella]";
	mes "We can't turn back now. But…";
	close3;
}

luna_sf2,255,47,7	script(CLOAKED)	Reinhardt#md	EP21_NPC_REINHARDT,1,1,{
	cutin "ep21_reinhardt07.png",2;
	mes "[Reinhardt]";
	mes "I think we should stop Tris.";
	close3;
}

luna_sf2,251,46,7	script(CLOAKED)	Gunter#md	EP21_NPC_GUNTER,1,1,{
	cutin "ep21_gunter01.png",2;
	mes "[Gunter]";
	mes "Will we able to return?";
	close3;
}

mbase_in,85,141,3	script	Small Door#ep21_mbase_room	4_POINT_BLUE,{
	if(isbegin_quest(18346) == 1){
		warp "mbase_in",66,182;
		end;
	}
	mes "The door is closed.";
	close;
	
OnInit:
	questinfo QTYPE_CLICKME,QMARK_YELLOW,"isbegin_quest(18346) == 1";
end;
}

mbase_in,64,184,4	script	Nyar#ep21nya03	4_EP20_NYAR,{
	if(isbegin_quest(18346) == 1){
		cutin "ep20_nyar03.png",1;
		mes "[Nyar]";
		mes "Meoow....";
		next;
		select("What is Nyar saying?");
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Is it that time already?";
		mes "I noticed that the key figures of history have gathered, do you know what's going on?";
		next;
		select("We found a giant serpent.");
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "A giant serpent? Ah... The one that the 12 heroes supposedly defeated, Is it Jormungandr?";
		next;
		cutin "ep20_nyar02.png",1;
		mes "[Nyar]";
		mes "Hiss-!";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Oh no. I forgot, Lord Jormungandr is here.";
		mes "When the books mentioned that they fought Jormungandr, maybe it's just a referring to the Jormungandr group?";
		next;
		cutin "ep172_nillem04.png",0;
		mes "[Nillem]";
		mes "Well, it looks like it's not a simple founding myth, yes?";
		mes "So our 12 ancestral heroes will be off to face this giant serpent that will be later known as Jormungandr...";
		next;
		cutin "ep20_nyar04.png",1;
		mes "[Nyar]";
		mes "Meow. Nya.";
		mes "Meoow.";
		next;
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "Alright. We need to find the place where Jormungandr's mana truly flows.";
		mes "Ah, activating the Nillem radar-☆";
		next;
		select("I want to join this battle.");
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Me too. Can I come along? Aren't we running out of time?";
		mes "Maybe we can stop Jormungandr's curse from spreading through the Gaebolg!";
		next;
		cutin "ep20_nyar05.png",1;
		mes "[Nyar]";
		mes "Maw. Mreow.";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "I agree. I share with Nyar's opinion. I'm against participating in this battle.";
		mes "Do you know why?";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "Because what must happen, should happen.";
		mes "Indeed. Are you a wise wizard too?";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Ah! That startled me!";
		mes "Where is that coming from?";
		next;
		cutin "ep21_ilse_heine04.png",1;
		mes "[Ilse El Heine]";
		mes "You've been pressing the contact button repeatedly...";
		mes "Was it a mistake?";
		mes "Anyway, it doesn't matter. I heard an interesting story.";
		next;
		select("What do you mean when you said that?");
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "To put it simply, if something that was supposed to happen in the past didn't happen, it will create a divergent timeline...";
		mes "In other words, you can't just erase an event that is supposed to occur.";
		next;
		mes "[Ilse El Heine]";
		mes "Yes. Like the curse of the Gaebolg that you were just talking about.";
		mes "I don't know what that curse is, but if it suddenly disappeared, the dimensions will create a rift.";
		next;
		cutin "ep21_ilse_heine04.png",1;
		mes "[Ilse El Heine]";
		mes "Didn't you want to connect a moment in the past with the future?";
		mes "Then, let things flow as it should.";
		mes "This is something living in this time to deal with.";
		next;
		cutin "ep20_nyar03.png",1;
		mes "[Nyar]";
		mes "Meooow... Purr.";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "It seems that the cat is pleased with my answer.";
		mes "Ah, but I allow this one to participate in the battle.";
		next;
		select("What?");
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "But doesn't that contradict what you've just said...?";
		next;
		cutin "ep21_ilse_heine03.png",1;
		mes "[Ilse El Heine]";
		mes "No, I'm the one joining the battle.";
		mes "This one is just going to be my carrier.";
		mes "Someone has to do it, and " + strcharinfo(0) + " has the best mana compatibility with me right now.";
		next;
		select("So that's how it is.");
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "I guess there's no helping it.";
		mes "I would love to witness the battle myself, but I'll leave it to you, adventurer...";
		mes "We'll go track the flow of Jormungandr's mana-☆";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "How do we find you at the right time, adventurer?";
		next;
		cutin "ep20_nyar05.png",1;
		mes "[Nyar]";
		mes "Meow. Nya.";
		next;
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "Yes. Nyar will handle it somehow.";
		mes "Right?";
		mes "Good luck to you!";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "Alright. Let's go join Tris.";
		mes "Tris won't be thrilled to see you, but he said you know where the meeting place, do you?";
		mes "Let's head there directly.";
		next;
		cutin "ep20_nyar03.png",1;
		mes "[Nyar]";
		mes "Meow~ ";
		next;
		cutin "",255;
		mes "With Nyar's blessing, let's head out there..!";
		completequest 18346;
		setquest 18347;
		getitem "Ep21_Wigner_Ticket",10;
		getexp 224735900,119990000;
		add_reputation_points(13,50);
		close3;
	}
	if(isbegin_quest(18347) == 1){
		cutin "ep20_nyar02.png",1;
		mes "[Nyar]";
		mes "Nyaaa....";
		next;
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "Leave this to us and head to the giant serpent.";
		mes "He said you know where it is, right?";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "In the meantime, we'll search for the source of Lasgand's mana.";
		mes "As soon as we find it, we'll send Nyar to you!";
		mes "Stay safe!";
		close3;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18346) == 1";
end;
}

mbase_in,66,185,5	script	Nillem#ep21nlm04	4_M_NILLEM,{
	npctalk "Nillem : So today was the day....","",bc_self;
	end;
}

mbase_in,68,184,3	script	Lehar#ep21rhr04	4_EP19_LEHAR,{
	npctalk "Lehar : Are we doing the right thing?","",bc_self;
	end;
}

luna_sf2,258,257,3	script	Nyar#ep21nya05	4_EP20_NYAR,{
	if(isbegin_quest(18349) == 1){
		cutin "ep20_nyar02.png",1;
		mes "[Nyar]";
		mes "Meow~";
		next;
		select("What are you doing all of a sudden!");
		cutin "ep172_nillem03.png",0;
		mes "[Nillem]";
		mes "Adventurer, you're here?";
		mes "Want to check out what we've found?";
		mes "We've followed the concentrated flow of Jormungandr's mana, and it led us here-☆";
		next;
		select("What is this place?");
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Do you remember the central altar of this temple?";
		mes "There was a decorative door behind it, and we found a trail of mana leading to it, so we opened it and..";
		next;
		mes "[Lehar]";
		mes "Ta-da, we've found this suspicious room.";
		mes "And that book there looks pretty suspicious too!";
		next;
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "By the way, how did the final battle go? It it as epic as the history portrays?";
		next;
		select("Not really...");
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "... So, that's what happened?";
		mes "I see... It must have been difficult. And for those who got left behind....";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Hmm... Ah. Aren't you a bit too empathic than usual?";
		mes "We already knew how it would end.";
		mes "You knew that there would be casualties in the final battle, and you knew that Tan would be the one, right?";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "...? Oh... yes...? Maybe.. That's true...?";
		mes "Still... when you saw them alive and was just moving right in front of you, doesn't it feel different?";
		next;
		cutin "ep20_nyar03.png",1;
		mes "[Nyar]";
		mes "Meow. Purr Purr.";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "We just need to do our job and return to our original time.";
		mes "We can't prevent the disasters that already happened. Let's move quickly, so that his sacrifice won't be in vain!";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "That's right. We were just about to investage that book.";
		mes "Actually it looks more like a device than a book, that's why we waited for you before investigating it... Should we press it?";
		next;
		cutin "ep172_nillem03.png",0;
		mes "[Nillem]";
		mes "Come, you should be the one to press it.";
		next;
		select("Press the book?");
		mes "[Nillem]";
		mes "Place your hands on each side of the open pages and press down hard-☆";
		mes "I looked at it earlier, and it seems to work that way.";
		next;
		cutin "ep20_nyar02.png",1;
		mes "[Nyar]";
		mes "Meow!";
		completequest 18349;
		setquest 18350;
		questinfo_refresh;
		close3;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18349) == 1";
end;
}

luna_sf2,255,257,3	script	Suspicious Book#ep21_md2_evt0	4_POINT_BLUE,{
	if(isbegin_quest(18350) == 1){
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Oh, look over there!";
		mes "There's something glowing down at the bottom! Let's go check it out!";
		next;
		cutin "ep20_nyar02.png",1;
		mes "[Nyar]";
		mes "Meow! Mrrrow!";
		next;
		completequest 18350;
		setquest 18351;
		questinfo_refresh;
		.@party_id = getcharid(1);
		if(!.@party_id) instance_warning(1);
		if(!is_party_leader()) instance_warning(4);
		.@md_name$ = "Secret Altar";
		cutin "",255;
		mes "As you press down on the book with both hands, you heard something clicking, and the shelf holding the book lowers itself.";
		if(instance_create(.@md_name$) == -3) 
			instance_warning(2,.@md_name$);
		close3;
	}
	if(isbegin_quest(18351) == 1){
		cloaknpc("Shining Door#ep21_md2_evt0",false,getcharid(0));
		.@party_id = getcharid(1);
		if(!.@party_id) instance_warning(1);
		if(!is_party_leader()) instance_warning(4);
		.@md_name$ = "Secret Altar";
		mes "As you press down on the book with both hands, you heard something clicking, and the shelf holding the book lowers itself.";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Oh, look over there!";
		mes "There's something glowing down at the bottom! Let's go check it out!";
		next;
		cutin "ep20_nyar02.png",1;
		mes "[Nyar]";
		mes "Meow! Mrrrow!";
		if(instance_create(.@md_name$) == -3) 
			instance_warning(2,.@md_name$);
		close3;
	}
	end;

OnInit:
	questinfo QTYPE_CLICKME,QMARK_YELLOW,"isbegin_quest(18350) == 1";
	questinfo QTYPE_CLICKME,QMARK_YELLOW,"isbegin_quest(18351) == 1";
end;
}

luna_sf2,250,257,3	script(CLOAKED)	Shining Door#ep21_md2_evt0	GATE_SKYBLUE,{
	if(isbegin_quest(18351) == 1 || isbegin_quest(18352) == 1){
		mes "[Lehar]";
		mes "A suspicious door.";
		mes "Beyond this must be the source of Lasgand's power.";
		mes "It's likely where Jormungadr's power is concentrated, right?";
		cutin "ep19_lehar01.png",2;
		next;
		.@party_id = getcharid(1);
		if(!.@party_id) instance_warning(1);
		.@md_name$ = "Secret Altar";
		if(instance_enter(.@md_name$) != IE_OK){
			mes "[Lehar]";
			mes "Hmm... Nothing happened? Should we press that book again...";
			cutin "ep19_lehar01.png",2;
			close3;
		}
		if(isbegin_quest(18351) == 1){
			completequest 18351;
			setquest 18352;
		}
		mapannounce "luna_sf2", strcharinfo(0) + " of the party, "+ getpartyname(.@party_id) +", is entering the " + .@md_name$ + ".", bc_map, "0x00FF99";
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18351) == 1";
end;
}

luna_sf2,259,258,3	script	Lehar#ep21rhr05	4_EP19_LEHAR,{
	cutin "ep19_lehar01.png",2;
	mes "[Lehar]";
	mes "I'm both excited and scared to see what might happen.";
	close3;
}

luna_sf2,257,259,3	script	Nillem#ep21nlm05	4_M_NILLEM,{
	if(isbegin_quest(18350) == 1 || isbegin_quest(18351) == 1){
		cutin "ep172_nillem03.png",1;
		mes "[Nillem]";
		mes "Quickly, place your hands on each side of the open pages and press down hard!";
		close3;
	}
	end;
}

jor_mbase,129,43,3	script	Bushes#ep21	CLEAR_NPC,{
	if(isbegin_quest(18354) == 1){
		mes "I found the new tablet Heine hid in the bushes.";
		mes "I placed down the old tablet";
		mes "and picked up the new one.";
		next;
		cutin "ep21_ilse_heine06.png",1;
		mes "[Ilse El Heine]";
		mes "Ahh, can you hear me well?";
		mes "This one. I made it with some ancient fragments and fixed it up to make another one.";
		next;
		cutin "ep21_ilse_heine01.png",1;
		mes "[Ilse El Heine]";
		mes "It doesn't have any amazing features or allow me to cast magic through communication, but it'll work nicely.";
		mes "Do you like it?";
		next;
		cutin "ep21_ilse_heine04.png",1;
		mes "[Ilse El Heine]";
		mes "Now that you received your gift, get out of here!";
		mes "It was fun working with you, I hope I don't meet you again!";
		completequest 18354;
		setquest 18355;
		delitem "Ep21_Tab",1;
		getitem "C_Heine_Tab_1",1;
		close2;
		cutin "",255;
		warp "jor_crk_p",79,69;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18354) == 1";
end;
}

jor_twig,122,164,3	script	Nyar Clone#ep21	4_EP20_NYAR,5,5,{
	if(isbegin_quest(18356) == 0){
		cutin "ep20_nyar03.png",1;
		mes "[Nyar]";
		mes "Meow.";
		close3;
	}
	if(isbegin_quest(18356) == 1){
		cutin "ep19_voglinde01.png",1;
		mes "[Voglinde]";
		mes "Lehar, you have returned.";
		mes "Leon mentioned that there were a sudden change in the flow of mana, so I came to check.";
		next;
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "The connection is stable.";
		mes "The Lasgand inside is likely not the one we once knew.";
		mes "It's time to break this old curse.";
		next;
		cutin "ep19_lehar03.png",2;
		mes "[Lehar]";
		mes "The Lasgand inside is not the one we know, what do you mean?";
		mes "Has Lasgand completely changed???";
		next;
		cutin "ep19_aurelie02.png",0;
		mes "[Aurelie]";
		mes "No no. The timeline we remember remains unchanged, so it's still the Lasgand that we're dealing with daily.";
		next;
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "But you'll find him much more weaker, he suddenly lost his source of power.";
		mes "However, there's something that still concerns me...";
		next;
		cutin "ep19_voglinde03.png",1;
		mes "[Voglinde]";
		mes "What is it?";
		mes "Isn't it just simply defeating Lasgand?";
		next;
		cutin "ep19_aurelie03.png",0;
		mes "[Aurelie]";
		mes "It's the power of the Heart of Ymir that Bagot fused in him.";
		mes "The adventurer has worked hard to prevent Lasgand from fully absorbing it, right?";
		mes "But it could become another variable.";
		next;
		cutin "ep20_nyar03.png",1;
		mes "[Nyar]";
		mes "Meow. Mreeow. Nya.";
		next;
		cutin "ep19_aurelie03.png",0;
		mes "[Aurelie]";
		mes "Even when his powers were balanced, he couldn't control it and it went wild.";
		mes "But now Lasgand lost his power, do you think that there might be a chance that he absorbs it?";
		next;
		cutin "ep19_aurelie04.png",0;
		mes "[Aurelie]";
		mes "Or worse, he could be consumed by that power instead!";
		mes "Anyways, let's go break the curse.";
		next;
		select("Alright.");
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "No, you should stay this time.";
		mes "The curse should be broken by those who are involved. Who knows what might happen when the curse is released...";
		mes "Wouldn't it be bad for you if the curse spread on you?";
		next;
		cutin "ep19_voglinde01.png",1;
		mes "[Voglinde]";
		mes "Correct. This time leave it to us.";
		mes "Even if a curse worse than this one is born from breaking this one, it must be a Gaebolg who must carry it.";
		mes "Lehar, are you ready?";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Yes! I'm ready!";
		mes "We'll finish this quickly!";
		mes "Adventurer, trust us and wait here!";
		next;
		cutin "ep20_nyar04.png",1;
		mes "[Nyar]";
		mes "Meow~";
		completequest 18356;
		setquest 18357;
		close2;
		cutin "",255;
		pcblock(true);
		sleep2 1000;
		npctalk "Then. Nyar. Please send us in.","Voglinde#ep21twig",bc_self;
		sleep2 1000;
		npctalk "We'll be back soon!","Lehar#ep21twig",bc_self;
		sleep2 2000;
		npctalk "Meow~","Nyar Clone#ep21",bc_self;
		sleep2 1000;
		specialeffect EF_BLUELINE,AREA,"Voglinde#ep21twig";
		specialeffect EF_BLUELINE,AREA,"Lehar#ep21twig";
		sleep2 1000;
		cloaknpc("Voglinde#ep21twig",true,getcharid(0));
		cloaknpc("Lehar#ep21twig",true,getcharid(0));
		pcblock(false);
		end;
	}
	if(isbegin_quest(18357) == 1){
		if(checkquest(18357,PLAYTIME) < 2){
			cutin "ep20_nyar05.png",1;
			mes "[Nyar]";
			mes "Meow?";
			next;
			mes "It seems that I need to wait a bit longer.";
		} else {
			cloaknpc("Aurelie#ep21twig",false,getcharid(0));
			cloaknpc("Voglinde#ep21twig",false,getcharid(0));
			cloaknpc("Lehar#ep21twig",false,getcharid(0));
			specialeffect EF_ENTRY,AREA,"Voglinde#ep21twig";
			specialeffect EF_ENTRY,AREA,"Lehar#ep21twig";
			pcblock(true);
			sleep2 2000;
			npctalk "Something felt off...","Voglinde#ep21twig",bc_self;
			sleep2 2000;
			npctalk "Hmmm...","Lehar#ep21twig",bc_self;
			sleep2 1500;
			pcblock(false);
			cutin "ep19_aurelie03.png",0;
			mes "[Aurelie]";
			mes "How was it? Why the long face?";
			mes "Don't tell me you.. that can't be.";
			mes "This flow of energy doesn't indicate that you've failed.";
			next;
			cutin "ep19_voglinde02.png",1;
			mes "[Voglinde]";
			mes "It is exactly as you think.";
			mes "When we defeated Lasgand, I felt a gust of wind that sweep through my heart and body.";
			mes "The curse of the Gaebolg bloodline has been broken.";
			next;
			cutin "ep19_lehar03.png",2;
			mes "[Lehar]";
			mes "But something is wrong. Very wrong.";
			mes "Lasgand is still resurrecting....";
			next;
			cutin "ep20_nyar02.png",1;
			mes "[Nyar]";
			mes "...Grrr..Nyaa...";
			next;
			cutin "ep19_aurelie01.png",0;
			mes "[Aurelie]";
			mes "Indeed. Nyar is still maintaining the barrier.";
			mes "If the curse was lifted, Lasgand should be dead.";
			mes "But why is he coming back to life?";
			next;
			select("The heart of Ymir!");
			cutin "ep19_lehar03.png",2;
			mes "[Lehar]";
			mes "Didn't you mention that the heart of Ymir could be a variable?";
			mes "What do we do now? Does that mean that he'll live forever?";
			mes "Did we suceed on breaking the curse? Did we fail?";
			next;
			select("I've seen it before.");
			cutin "ep19_voglinde01.png",1;
			mes "[Voglinde]";
			mes "Child, where did you see such things?";
			mes "Will you tell us?";
			next;
			cutin "",255;
			mes "You shared the story of what happened with the other fragment of the heart of Ymir, the experiments that took place in the Bio Laboratory, and the other countless formless beings that resulted from it.";
			next;
			cutin "ep19_voglinde04.png",1;
			mes "[Voglinde]";
			mes "Goodness.... so much has happened.";
			mes "The heart of Ymir, a fragment from a god. To think that it has that kind of power.";
			mes "So is the Lasgand in there is now something else, but he took Lasgand's form...?";
			next;
			select("I need to check it.");
			cutin "ep19_aurelie01.png",0;
			mes "[Aurelie]";
			mes "In that case, would you join me to check it?";
			mes "We also need to decide for how long should Nyar maintain the barrier....";
			mes "And whether that thing is a threat to this continent.";
			next;
			cutin "ep20_nyar02.png",1;
			mes "[Nyar]";
			mes "Meow!";
			next;
			cutin "ep19_aurelie01.png",0;
			mes "[Aurelie]";
			mes "Once you're ready, ask Nyar to let us inside the barrier.";
			completequest 18357;
			setquest 18358;
		}
		close3;
	}
	if(isbegin_quest(18358) == 1){
		cloaknpc("Aurelie#ep21twig",false,getcharid(0));
		cloaknpc("Voglinde#ep21twig",false,getcharid(0));
		cloaknpc("Lehar#ep21twig",false,getcharid(0));
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "Are you ready?";
		mes "Once you're prepared, I'll prepare the connection to send you to the sanctuary in Nyar's place.";
		mes "The actual transfer will happen after I finished preparing it.";
		next;
		.@party_id = getcharid(0);
		if(!.@party_id){
			cutin "ep19_aurelie01.png",0;
			mes "[Aurelie]";
			mes "Isn't it dangerous to be alone?";
			mes "If you have companions, go form a party first.";
			next;
			cutin "",255;
			instance_warning(1);
			end;
		}
		.@md_name$ = "Silent Sanctuary";
		switch(select("Ok! Connect me to the 'Silent Sanctuary'!","Enter the 'Silent Sanctuary'!","I need more time to prepare.")){
			case 1:
				mes "[Aurelie]";
				mes "Alright. No need to rush.";
				mes "Tell me when you're ready.";
				if(instance_create(.@md_name$) == -3) 
					instance_warning(2,.@md_name$);
				next;
				mes "[Aurelie]";
				mes "If you can't see me, tell Nyar here to call me.";
				mes "I'll come right away.";
				close3;

			case 2:
				if(instance_enter(.@md_name$) != IE_OK){
					cutin "ep19_aurelie01.png",0;
					mes "[Aurelie]";
					mes "Hold on, the connection to the sanctuary is not yet established...";
					close3;
				}
				mapannounce "jor_twig", strcharinfo(0) + " of the party, "+ getpartyname(.@party_id) +", is entering the " + .@md_name$ + ".", bc_map, "0x00FF99";
				end;

			case 3:
				close3;
		}
	}
	if(isbegin_quest(18359) == 1){
		cutin "ep19_voglinde01.png",1;
		mes "[Voglinde]";
		mes "Child, what do you think after seeing it yourself?";
		mes "Is it really not Lasgand?";
		next;
		select("I'm sure he's not.");
		cutin "ep19_voglinde03.png",1;
		mes "[Voglinde]";
		mes "Even if he's not, should we consider it a dangerous entity?";
		mes "Considering that has the power from the heart of Ymir....";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "Didn't we retrieve the heart last time?";
		mes "Didn't we resolve it back then?";
		next;
		cutin "ep19_aurelie03.png",0;
		mes "[Aurelie]";
		mes "What we retrieved isn't a complete heart fragment.";
		mes "The part that is still attached to Lasgand is still running wild...";
		mes "Which means we'll have to watch over Lasgand's shell going forward.";
		next;
		cutin "ep20_nyar05.png",1;
		mes "[Nyar]";
		mes "Mreow...";
		next;
		cutin "ep19_aurelie03.png",0;
		mes "[Aurelie]";
		mes "Right. It's not Lasgand anymore, but an unknown being that has learned everything about him.";
		mes "And the remnants of it's power have turned into Rgans wandering around...";
		next;
		cutin "ep19_voglinde01.png",1;
		mes "[Voglinde]";
		mes "But we manage to pass a major hurdle, right?";
		mes "We should hurry and deliver this good news to Prontera.";
		next;
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "Congratulations. Voglinde. Please extend my congratulations to Vellgunde too.";
		mes "Shall we head back?";
		next;
		cutin "ep19_aurelie04.png",0;
		mes "[Aurelie]";
		mes "I'll return to the castle and discuss our next move with Leon.";
		mes "Maybe we'll meet again in Prontera. Adventurer.";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Wow... so are we going to leave Isgard now?";
		mes "Auntie, are you going to return now?";
		next;
		cutin "ep19_voglinde04.png",1;
		mes "[Voglinde]";
		mes "I won't be returning dear. I'm sure Vellgunde won't either.";
		mes "We play to stay here and continue to erase the remnants of Rgans.";
		next;
		cutin "ep19_voglinde03.png",1;
		mes "[Voglinde]";
		mes "The power of Lasgand is still scattered and are creating Rgans, isn't it?";
		mes "It's my duty to clear it.";
		mes "Lehar, my dear. Are you going to join me?";
		next;
		cutin "ep19_lehar02.png",2;
		mes "[Lehar]";
		mes "Of course! I'd rather be here than back in the monastery!";
		next;
		cutin "ep19_iwin_diver02.png",2;
		mes "[Diver Fapa]";
		mes "Hello, sorry for intruding.";
		mes "The wizard on Scale Island would like to hear your thoughts...";
		next;
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "Wizard? Nillem?";
		mes "Weren't they suppose to close the rift on Scale Island?";
		mes "Let's see what's going on. Sounds like fun~";
		next;
		cutin "ep19_voglinde01.png",1;
		mes "[Voglinde]";
		mes "I'll return to the Ice Castle.";
		mes "Lehar, child, take care.";
		next;
		cutin "ep19_iwin_diver02.png",2;
		mes "[Diver Fapa]";
		mes "Then, I'll bring you directly to Scale Island.";
		completequest 18359;
		setquest 18360;
		close2;
		cutin "",255;
		warp "jor_crk",137,137;
		end;
	}
	if(isbegin_quest(18360) == 1){
		cutin "ep20_nyar03.png",1;
		mes "[Nyar]";
		mes "Meow.";
		close3;
	}
	end;
	
OnTouch:
	if(isbegin_quest(18356) == 1 || isbegin_quest(18358) == 1 || isbegin_quest(18359) == 1){
		cloaknpc("Aurelie#ep21twig",false,getcharid(0));
		cloaknpc("Voglinde#ep21twig",false,getcharid(0));
		cloaknpc("Lehar#ep21twig",false,getcharid(0));
		end;
	}
end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18356) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"checkquest(18357,PLAYTIME) == 2";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18358) == 1";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18359) == 1";
end;
}

jor_twig,120,161,5	script(CLOAKED)	Aurelie#ep21twig	4_EP19_AURELIE,{
	if(isbegin_quest(18357) == 1){
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "You should rest for now, can I ask you trust Voglinde and Lehar?";
		mes "When the time comes, they'll safely come out with the help of Nyar.";
		close3;
	}
	if(isbegin_quest(18358) == 1){
		cutin "ep19_aurelie01.png",0;
		mes "[Aurelie]";
		mes "Nyar will handle the connection to the sanctuary where Lasgand is sealed.";
		mes "I will be joining you to keep eye on things.";
		close3;
	}
	if(isbegin_quest(18359) == 1){
		mes "[Aurelie]";
		mes "Shall we discuss everything we saw at the sanctuary with everyone?";
		cutin "ep19_aurelie01.png",0;
		close3;
	}
	end;
}

jor_twig,124,165,3	script(CLOAKED)	Voglinde#ep21twig	4_EP19_VOGLINDE,{
	if(isbegin_quest(18356) == 1){
		cutin "ep19_voglinde01.png",1;
		mes "[Voglinde]";
		mes "You have returned safely! Can you tell us the details?";
		close3;
	}
	if(isbegin_quest(18358) == 1){
		npctalk "It seems like we need Nyar's advice.","",bc_self;
		end;
	}
	if(isbegin_quest(18359) == 1){
		npctalk "The world is full of things that are truly incomprehensible.","",bc_self;
		end;
	}
	end;
}

jor_twig,126,163,3	script(CLOAKED)	Lehar#ep21twig	4_EP19_LEHAR,{
	if(isbegin_quest(18356) == 1){
		npctalk "Let's share our accomplishment quickly!","",bc_self;
		end;
	}
	if(isbegin_quest(18356) == 1){
		npctalk "...? What did I just see?","",bc_self;
		end;
	}
	if(isbegin_quest(18359) == 1){
		npctalk "What happened?","",bc_self;
		end;
	}
	end;
}

jor_base,318,138,4	script	Libra#ep21	4_EP21_WORKER_KID_A,{
	if(isbegin_quest(23242) == 0){
		mes "Life must have been tough, they are sleeping while standing.";
		next;
		cutin "",255;
		mes "- This quest cannot be performed yet. -";
		close;
	}
	if(isbegin_quest(19195) == 0){
		cutin "ep21_worker_kg_07.png",2;
		emotion ET_HUK,getnpcid(0,"Libra#ep21");
		mes "[Libra]";
		mes "H.. hey. ";
		next;
		mes "[Libra]";
		mes "Hey~ You there! Over here~";
		next;
		if(select("React to her.","Ignore her.") == 2){
			emotion ET_HNG,getnpcid(0,"Libra#ep21");
			mes "[Libra]";
			mes "Argh! You! Don't ignore me!";
			close3;
		}
		mes "[Libra]";
		mes "You don't seem like you're part of the cult, how are you walking around so freely? Ah, no! Who cares about that!! What important is you can freely roam around.";
		next;
		mes "[Libra]";
		mes "Listen. This place is dangerous. I'll keep it brief, can you deliver something to a person trapped near the central area?";
		next;
		if(select("Sure.","It would be difficult.") == 2){
			mes "[Libra]";
			mes "Come on! Hurry and leave then. This area is dangerous.";
			close3;
		}
		emotion ET_GO,getnpcid(0,"Libra#ep21");
		setquest 19195;
		completequest 19195;
		setquest 19196;
		questinfo_refresh;
		getitem "Ep21_Crumple_Paper",1;
		mes "[Libra]";
		mes "Oh! Thanks! Thank you very much~! Please deliver this item to the man trapped near the central area.";
		close3;
	}
	switch(checkquest(19197,PLAYTIME)){
		case -1:
			break;

		case 0:
		case 1:
			cutin "ep21_worker_kg_07.png",2;
			emotion ET_BEST,getnpcid(0,"Libra#ep21");
			mes "[Libra]";
			mes "*sniff sniff*~ It smells like dad! You really delivered it. Did you receive a reward from dad too? Well done! Good! Please help me again tomorrow.";
			close3;

		case 2:
			erasequest 19197;
			break;
	}
	if(isbegin_quest(19196) == 0){
		mes "[Libra]";
		mes "Hello~ Welcome back~! Can you deliver the same item that I gave you to the man in the center again today?";
		next;
		if(select("I'll deliver it.","Today is a bit difficult.") == 2){
			emotion ET_BEST,getnpcid(0,"Libra#ep21");
			mes "[Libra]";
			mes "Ah.. I see you're quite busy today.. can't be helped. I hope there will be another passerby. I'll ask you again next time.";
			close3;
		}
		setquest 19196;
		questinfo_refresh;
		getitem "Ep21_Crumple_Paper",1;
		emotion ET_CHUP,getnpcid(0,"Libra#ep21");
		mes "[Libra]";
		mes "Thank! Thank! Thank you~! It's a dangerous area, so be careful and deliver it quickly.";
		close3;
	}
	if(isbegin_quest(19196) == 1){
		cutin "ep21_worker_kg_07.png",2;
		mes "[Libra]";
		mes "It's a dangerous area, so be careful and deliver it quickly.";
		close3;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23242) > 0 && isbegin_quest(19195) == 0";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(19195) == 2 && isbegin_quest(19196) == 0 && checkquest(19197,PLAYTIME) == 2";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(19195) == 2 && isbegin_quest(19196) == 0 && checkquest(19197,PLAYTIME) == -1";
end;
}

jor_base,318,125,4	script	Slave Kuleg#ep21	4_EP21_M_WORKER_B,{
	mes "[Slave Kuleg]";
	mes "Does the kid in the next cage realize that they've been caught? Why is she that cheerful, it's exhausting..";
	next;
	mes "[Slave Kuleg]";
	mes "What's with her seriously? Am I the only one struggling?";
	close;
}

jor_base,134,182,4	script	Parex#ep21	4_EP21_M_WORKER_A,{
	if(isbegin_quest(19195) == 0){
		cutin "ep21_worker_m_01.png",2;
		mes "[Parex]";
		mes "Ugh.. I feel like I'm dying. Hm?";
		next;
		mes "[Parex]";
		mes "Who? You dont smell like someone from the cult.. Aren't you lucky to be wandering around?";
		next;
		emotion ET_SMILE,getnpcid(0,"Parex#ep21");
		mes "[Parex]";
		mes "Be careful, you might end up in a cage like me. The labor here is really tough.";
		close3;
	}
	if(isbegin_quest(19196) == 1){
		cutin "ep21_worker_m_01.png",2;
		mes "[Parex]";
		mes "Ugh.. I feel like I'm dying. Hm?";
		next;
		mes "[Parex]";
		mes "*sniff sniff*…. I can faintly smell my daughters scent on a stranger? Oh, sorry for doing that, I'm nearly blind.";
		next;
		select("I have something to deliver.");
		mes "[Parex]";
		mes "You have something to deliver? *Sniff*.. Oh, it's a note from my daughter!!";
		next;
		mes "[Parex]";
		mes "Ah! How did I know before you even show it to me? Haha.. That's a secret between father and daughter!!";
		next;
		mes "[Parex]";
		mes "Anyways, thank you for delivering it. Oh! there's something I have here. This should fit through the bars.";
		next;
		if(countitem("Ep21_Crumple_Paper"))
			delitem "Ep21_Crumple_Paper",1;
		erasequest 19196;
		setquest 19197;
		getitem "Ep21_Wigner_Ticket",2;
		getexp 21710000,15120000;
		add_reputation_points(13,2);
		mes "- You received a reward from Parex through the bars.";
		next;
		mes "[Parex]";
		mes "My memory is not good, so I might not recognize your scent next time, but If I do, let's have a little chat~";
		close3;
	}
	if(isbegin_quest(19197) == 1){
		cutin "ep21_worker_m_01.png",2;
		mes "[Parex]";
		mes "Ugh.. It feel like I'm dying. Oh?";
		next;
		mes "[Parex]";
		mes "*sniff sniff*.. Aren't there a lot of people passing by today? I can faintly smell my daughter's scent, you are the one who delivered my daughter's note a while ago.";
		next;
		emotion ET_SMILE,getnpcid(0,"Parex#ep21");
		mes "[Parex]";
		mes "Be careful, you might end up in a cage like me. The labor here is really tough.";
		close3;
	}

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(19196) == 1";
end;
}

jor_mbase,300,151,3	script	Mercenary Member#ep21_serv1	4_EP21_SOLDIER_A,{
	if(isbegin_quest(24019) == 1){
		cutin "ep21_soldier_a.png",2;
		mes "[Mercenary Member]";
		mes "Ah!";
		mes "Did lady Valdaris sent you?";
		mes "I asked around the area, and they said that there is a shortage of people for ^e5555eship repairs^000000 and it's becoming a problem.";
		next;
		mes "[Mercenary Member]";
		mes "Please inform lady Valdaris that the repairs are urgent since it's the only means of transportation to the outside.";
		next;
		mes "[Mercenary Member]";
		mes "I'll be helping with the ship repairs for now, it would great if you could check on the other ^e5555emercenaries^000000 as well.";
		completequest 24019;
		setquest 24020;
		questinfo_refresh;
		close2;
		cutin "",255;
		navigateto("jor_mbase",198,251);
		end;
	}
	if(isbegin_quest(24020) == 1){
		cutin "ep21_soldier_a.png",2;
		mes "[Mercenary Member]";
		mes "Please inform lady Valdaris that the repairs are urgent since it's the only means of transportation to the outside.";
		next;
		mes "[Mercenary Member]";
		mes "I'll be helping with the ship repairs for now, it would great if you could check on the other ^e5555emercenaries^000000 as well.";
		close2;
		cutin "",255;
		navigateto("jor_mbase",198,251);
		end;
	}
	cutin "ep21_soldier_a.png",2;
	mes "[Mercenary Member]";
	mes "I definitely signed up as a combat mercenary, so why am I repairing ships?";
	mes "And why am I so good at it?";
	close3;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24019) == 1";
end;
}

jor_mbase,198,251,3	script	Mercenary Member#ep21_serv2	4_EP21_SOLDIER_B,{
	if(isbegin_quest(24020) == 1){
		cutin "ep21_soldier_b.png",2;
		mes "[Mercenary Member]";
		mes "Sigh…";
		mes "They keep telling us to stay strong, but everyone's so down that it's hard to stay positive.";
		next;
		mes "[Mercenary Member]";
		mes "Places that needs help?";
		mes "I'm not sure either.";
		mes "Maybe if we ate something nice, we'd feel a bit better?";
		mes "Instead of preserve foods, maybe something ^e5555efresh^000000.";
		next;
		mes "[Mercenary Member]";
		mes "Sigh… I have no idea!";
		mes "Just go ask ^e5555esomeone else^000000 if they need anything.";
		completequest 24020;
		setquest 24021;
		questinfo_refresh;
		close2;
		cutin "",255;
		navigateto("jor_mbase",133,128);
		end;
	}
	if(isbegin_quest(24021) == 1){
		cutin "ep21_soldier_b.png",2;
		mes "[Mercenary Member]";
		mes "Sigh… I have no idea!";
		mes "Just go ask ^e5555esomeone else^000000 if they need anything.";
		close2;
		cutin "",255;
		navigateto("jor_mbase",133,128);
		end;
	}
	cutin "ep21_soldier_b.png",2;
	mes "[Mercenary Member]";
	mes "<FONT SIZE = 16><B>Ugh…</B></FONT>";
	mes "<FONT SIZE = 16><B>I want to go home.</B></FONT>";
	close3;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24020) == 1";
end;
}

jor_mbase,133,128,5	script	Mercenary Member#ep21_serv3	4_EP21_SOLDIER_A,{
	if(isbegin_quest(24021) == 1){
		cutin "ep21_soldier_a.png",2;
		mes "[Mercenary Member]";
		mes "Help?";
		mes "There's no place that doesn't need help. Right now…";
		next;
		mes "[Mercenary Member]";
		mes "Medicine is the most urgent one.";
		mes "We can't solely rely on the acolytes, it's often easier to treat small illnesses with simple remedies before they become something serious.";
		next;
		mes "[Mercenary Member]";
		mes "We need to be cautious with children and elderlies, they tend not to speak about it.";
		next;
		mes "[Mercenary Member]";
		mes "Please tell Valdaris that we need to not only secure medicine but also provide education on the importance of taking it.";
		next;
		mes "[Mercenary Member]";
		mes "Also can you ask the ^e5555eperson in charge^000000 if there are any leftover medicines.";
		erasequest 24021;
		setquest 24022;
		questinfo_refresh;
		close2;
		cutin "",255;
		navigateto("jor_mbase",248,103);
		end;
	}
	if(isbegin_quest(24022) == 1){
		mes "[Mercenary Member]";
		mes "Also can you ask the ^e5555eperson in charge^000000 if there are any leftover medicines.";
		close2;
		cutin "",255;
		navigateto("jor_mbase",248,103);
		end;
	}
    cutin "ep21_soldier_a.png",2;
	mes "[Mercenary Member]";
	mes "If I had known the situation would be like this, I would have just gotten a job at the guild.";
	close3;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24021) == 1";
end;
}

jor_mbase,248,103,3	script	Mercenary Member#ep21_serv4	4_EP21_SOLDIER_B,{
	if(isbegin_quest(24022) == 1){
		cutin "ep21_soldier_b.png",2;
		mes "[Mercenary Member]";
		mes "Huff…huff…";
		mes "So… the mercenaries have been finally dispatched?";
		next;
		select("I'm investigating what the people need.");
		mes "[Mercenary Member]";
		mes "Help?";
		mes "As you can see, we're severely short on manpower to organize the supplies.";
		mes "It's so busy that it's making me sad, but I don't have the time to feel sad, and that makes me even more sad.";
		next;
		mes "[Mercenary Member]";
		mes "Medicine?";
		mes "There should be some.";
		mes "Probably…";
		mes "If you want to find it, tell them to send ^e5555esome mercenaries^000000 to help with organizing it.";
		completequest 24022;
		setquest 24023;
		close2;
		cutin "",255;
		navigateto("mbase_in",302,123);
		end;
	}
	if(isbegin_quest(24023) == 1){
		cutin "ep21_soldier_b.png",2;
		mes "[Mercenary Member]";
		mes "Medicine?";
		mes "There should be some.";
		mes "Probably…";
		mes "If you want to find it, tell them to send ^e5555esome mercenaries^000000 to help with organizing it.";
		close2;
		cutin "",255;
		navigateto("mbase_in",302,123);
		end;
	}
    cutin "ep21_soldier_b.png",2;
	mes "[Mercenary Member]";
	mes "Cough…Cough…";
	close3;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24022) == 1";
end;
}

jor_mbase,306,140,7	script	Mercenary Recruit#ep21_1	4_EP18_GW_MAN01,{
	if(isbegin_quest(24024) > 0 && isbegin_quest(24029) == 0){
		.@id = atoi(replacestr(strnpcinfo(2),"ep21_",""));
		switch(.@id){
			case 1:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> Sing";
				mes "<B>Job :</B> Assassin";
				mes "<B>Specialty :</B> Assassination";
				mes "<B>Reason for application :</B> To eliminate traitors";
				break;
			case 2:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> ???";
				mes "<B>Job :</B> Shaman";
				mes "<B>Specialty :</B> Curse";
				mes "<B>Reason for application :</B> To curse who lacks faith";
				break;
			case 3:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> Yuth";
				mes "<B>Job :</B> Mage";
				mes "<B>Specialty :</B> Elemental Spell";
				mes "<B>Reason for application :</B> To make Zeny";
				.@pass = true;
				break;
			case 4:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> Anne";
				mes "<B>Job :</B> Acolyte";
				mes "<B>Specialty :</B> Healing and Buffs";
				mes "<B>Reason for application :</B> To not be unemployed";
				.@pass = true;
				break;
			case 5:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> Rose";
				mes "<B>Job :</B> Shaman";
				mes "<B>Specialty :</B> Curse";
				mes "<B>Reason for application :</B> To curse who lacks faith";
				break;
			case 6:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> Noir";
				mes "<B>Job :</B> Mage";
				mes "<B>Specialty :</B> Elemental Spell";
				mes "<B>Reason for application :</B> For work";
				.@pass = true;
				break;
			case 7:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> Coin";
				mes "<B>Job :</B> None";
				mes "<B>Specialty :</B> None";
				mes "<B>Reason for application :</B> I am a devoted follower of Odin, I constantly pray and give thanks for the peace and prosperity of this world. If they will it I won't hesitate to sacrifice myself. I wish to become a member of the Richard Mercenary Group to fulfill both my dream and his.";
				break;
			case 8:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> Kilik";
				mes "<B>Job :</B> Merchant";
				mes "<B>Specialty :</B> Calculation Work";
				mes "<B>Reason for application :</B> I want to help defeat the cult.";
				.@pass = true;
				break;
			case 9:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> Jack";
				mes "<B>Job :</B> None";
				mes "<B>Specialty :</B> None";
				mes "<B>Reason for application :</B> To make Zeny";
				.@pass = true;
				break;
			case 10:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> Kil";
				mes "<B>Job :</B> None";
				mes "<B>Specialty :</B> None";
				mes "<B>Reason for application :</B> To help the Gaebolg.";
				.@pass = true;
				break;
			case 11:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> Jig";
				mes "<B>Job :</B> Merchant";
				mes "<B>Specialty :</B> Calculating Zeny";
				mes "<B>Reason for application :</B> Revenge";
				.@pass = true;
				break;
			case 12:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> Ria";
				mes "<B>Job :</B> Merchant";
				mes "<B>Specialty :</B> Combat";
				mes "<B>Reason for application :</B> I want to crush the cult.";
				.@pass = true;
				break;
			case 13:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> Lia";
				mes "<B>Job :</B> Merchant";
				mes "<B>Specialty :</B> Zeny Calculation";
				mes "<B>Reason for application :</B> Revenge";
				break;
			case 14:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> Kiri";
				mes "<B>Job :</B> Priest";
				mes "<B>Specialty :</B> Holy Spells";
				mes "<B>Reason for application :</B> I want to help Gaebolg.";
				.@pass = true;
				break;
			case 15:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> Ran";
				mes "<B>Job :</B> Merchant";
				mes "<B>Specialty :</B> None";
				mes "<B>Reason for application :</B> Revenge.";
				@pass = true;
				break;
			case 16:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> Yin";
				mes "<B>Job :</B> Mercenary";
				mes "<B>Specialty :</B> Always follow orders.";
				mes "<B>Reason for application :</B> Following someone else's order.";
				break;
			case 17:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> Lily";
				mes "<B>Job :</B> Acolyte";
				mes "<B>Specialty :</B> Healing and Buffs";
				mes "<B>Reason for application :</B> Revenge.";
				.@pass = true;
				break;
			case 18:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> Ben";
				mes "<B>Job :</B> Merchant";
				mes "<B>Specialty :</B> Calculation";
				mes "<B>Reason for application :</B> Make Zeny";
				.@pass = true;
				break;
			case 19:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> Nor";
				mes "<B>Job :</B> Sage";
				mes "<B>Specialty :</B> Support Spells";
				mes "<B>Reason for application :</B> For Work";
				.@pass = true;
				break;
			case 20:
				mes "<B>[Richard Mercenary Group Application Form]</B>";
				mes "<B>Name :</B> Bokgil";
				mes "<B>Job :</B> Blacksmith";
				mes "<B>Specialty :</B> Crafting and Repair";
				mes "<B>Reason for application :</B> I want to help defeat the cult.";
				.@pass = true;
				break;
		}
		next;
		if(select("Accept the application.","Reject it.") == 2)
			goto OnBusy;
		if(!.@pass){
			mes "[" + strcharinfo(0) + "]";
			mes "Wait something is suspicious?";
			npctalk "Mercenary Applicant : Tch! Did I get caught?","Mercenary Recruit#ep21_" + .@id,bc_self;
		} else {
			mes "[Mercenary Applicant]";
			mes "<FONT SIZE = 14><B>Thank you!</B></FONT>";
			mes "<FONT SIZE = 14><B>I'll do my best!</B></FONT>";
			for(.@i = 24024; .@i <= 24028; .@i++){
				if(isbegin_quest(.@i) == 1){
					completequest .@i;
					setquest .@i + 1;
					break;
				}
			}
		}
		if(isbegin_quest(24029) == 1){
			next;
			mes "- That's all for today's mercenary application.";
			mes "Let's return to ^e5555eValdaris^000000. -";
		}
		hideonnpc strnpcinfo(0);
		initnpctimer;
		close;
	}
	mes "[Mercenary Recruit]";
	mes "Hmm…";
	mes "Is this how you write the documents?";
	close;

OnBusy:
	mes "[Mercenary Applicant]";
	mes "<FONT SIZE = 14><B>?!!!</B></FONT>";
	mes "I don't understand!";
	hideonnpc strnpcinfo(0);
	initnpctimer;
	close;

OnTimer60000:
	stopnpctimer;
	hideoffnpc strnpcinfo(0);
end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(24024) > 0 && isbegin_quest(24029) == 0";
end;
}

jor_mbase,268,197,3	duplicate(Mercenary Recruit#ep21_1)	Mercenary Recruit#ep21_2	4_M_EINMAN2
jor_mbase,274,237,3	duplicate(Mercenary Recruit#ep21_1)	Mercenary Recruit#ep21_3	4_M_RACHMAN2
jor_mbase,243,246,1	duplicate(Mercenary Recruit#ep21_1)	Mercenary Recruit#ep21_4	4W_M_03
jor_mbase,211,232,5	duplicate(Mercenary Recruit#ep21_1)	Mercenary Recruit#ep21_5	4_F_GODEMOM
jor_mbase,183,197,5	duplicate(Mercenary Recruit#ep21_1)	Mercenary Recruit#ep21_6	4_M_LGTPOOR
jor_mbase,128,186,5	duplicate(Mercenary Recruit#ep21_1)	Mercenary Recruit#ep21_7	1_F_ORIENT_02
jor_mbase,133,137,5	duplicate(Mercenary Recruit#ep21_1)	Mercenary Recruit#ep21_8	4_MAL_SOLDIER
jor_mbase,100,114,5	duplicate(Mercenary Recruit#ep21_1)	Mercenary Recruit#ep21_9	1_M_ORIENT01
jor_mbase,148,98,7	duplicate(Mercenary Recruit#ep21_1)	Mercenary Recruit#ep21_10	4W_F_01
jor_mbase,159,129,5	duplicate(Mercenary Recruit#ep21_1)	Mercenary Recruit#ep21_11	4_M_THAIONGBAK
jor_mbase,172,158,3	duplicate(Mercenary Recruit#ep21_1)	Mercenary Recruit#ep21_12	4_M_06
jor_mbase,217,133,5	duplicate(Mercenary Recruit#ep21_1)	Mercenary Recruit#ep21_13	4_F_CHNDRESS3
jor_mbase,228,98,3	duplicate(Mercenary Recruit#ep21_1)	Mercenary Recruit#ep21_14	1_M_YOUNGKNIGHT
jor_mbase,202,70,5	duplicate(Mercenary Recruit#ep21_1)	Mercenary Recruit#ep21_15	4_M_RASWORD
jor_mbase,219,47,3	duplicate(Mercenary Recruit#ep21_1)	Mercenary Recruit#ep21_16	4_MAL_SOLDIER
jor_mbase,278,52,5	duplicate(Mercenary Recruit#ep21_1)	Mercenary Recruit#ep21_17	1_F_PUBGIRL
jor_mbase,351,85,5	duplicate(Mercenary Recruit#ep21_1)	Mercenary Recruit#ep21_18	4_F_LGTGIRL
jor_mbase,185,125,3	duplicate(Mercenary Recruit#ep21_1)	Mercenary Recruit#ep21_19	4_M_SAGE_A
jor_mbase,137,258,5	duplicate(Mercenary Recruit#ep21_1)	Mercenary Recruit#ep21_20	1_F_GYPSY

jor_mbase,213,280,2	script	Volunteer Vallen Wok#ep21	4_M_RUSBALD,{
    if(isbegin_quest(23247) < 2){
	    mes "[Volunteer Vallen Wok]";
	    mes "Ku hahahaha-";
	    mes "Another out of luck adventurer? Hey, it's far from meal distribution time yet!";
	    next;
	    mes "- This quest cannot be performed yet. -";
	    close;
    }
	if(isbegin_quest(19198) == 0){
		emotion ET_BLABLA,getnpcid(0,"Volunteer Vallen Wok#ep21");
		mes "[Vallen Wok]";
		mes "Ku hahahaha-";
		mes "Another out of luck adventurer? Hey, it's far from meal distribution time yet!";
		next;
		mes "[Vallen Wok]";
		mes "I feel bad telling this to hungry people, but hang in there a little bit longer. I hear today's meal is going to taste amazing..";
		next;
		if(select("I'll come back during meal time.","Can I help with anything?") == 1){
			emotion ET_BLABLA,getnpcid(0,"Volunteer Vallen Wok#ep21");
			mes "[Vallen Wok]";
			mes "Ku hahahaha- Okay! Make sure to come back to get some!";
			close;
		}
		mes "[Vallen Wok]";
		mes "Ki-yah- During this hard times, it's rare to see an adventurer who just doesn't take things from granted.";
		next;
		mes "[Vallen Wok]";
		mes "That's right, aren't you an interesting one? Food tastes better when you lend a hand making it. I personally proven that method!";
		next;
		mes "[Vallen Wok]";
		mes "Anyway, as for something you can help with..";
		next;
		mes "[Vallen Wok]";
		mes "Oh! I think it should be that..";
		mes "As you can see, Lunaforma looks empty, but there are a lots of adventurers who come and go here.";
		next;
		mes "[Vallen Wok]";
		mes "Moreover, with all the refugees pouring in from time to time, food is always scarce. We need to secure what we can so so everyone can have a share even when there's not enough.";
		next;
		mes "[Vallen Wok]";
		mes "I was thinking of asking you to secure some food. Can you handle it?";
		next;
		mes "[Vallen Wok]";
		mes "I know! I know! You're probably thinking what kind of a wild idea that is, right? But there's a method. Even though Lunaforma looks like a barren land, it's place where people live.";
		next;
		mes "[Vallen Wok]";
		mes "If you look around, there's plenty to eat. Let me show you how to find food in Lunaforma.";
		next;
		mes "[Vallen Wok]";
		mes "We don't need to gather much, just a little to add to the shared meals.. You get what I'm saying right?";
		next;
		setquest 19198;
		completequest 19198;
		mes "[Vallen Wok]";
		mes "Alright! Just like pulling out a goat's horn, let's get started right away! I'll start by asking for some non-urgent ingredients, I'll check what I need, so talk to me again later!";
		close;
	}
	switch(checkquest(19199,PLAYTIME)){
		case -1:
			break;
		case 0:
		case 1:
			mes "[Vallen Wok]";
			mes "Haven't you already lent a hand already? Go ahead and take care of your own tasks for now, and come back tomorrow to help again. If you have the time, feel free to gather food in advance.";
			close;
		case 2:
			erasequest 19199;
			for(.@i = 19200; .@i <= 19203; .@i++)
				erasequest .@i;
			break;
	}
	emotion ET_BLABLA,getnpcid(0,"Volunteer Vallen Wok#ep21");
	mes "[Vallen Wok]";
	mes "Ku hahahaha-";
	mes "Is the incredible adventurer prepared?";
	next;
	for(.@i = 19200; .@i <= 19201; .@i++){
		if(isbegin_quest(.@i) == 1)
			.@active_qid = .@i;
	}
	switch(select(.@active_qid == 0 ? "Gather insufficient food" : "",.@active_qid == 19200 ? "Food Procurement/Fishing)" : "",.@active_qid == 19201 ? "Food Procurement(Herb Gathering)" : "",.@active_qid == 19202 ? "Food Procurement (Natural Seasonings)" : "",.@active_qid == 19203 ? "Food Procurement (Natural Seasonings)" : "","Just here to say hi.")){
		case 1:
			.@qid = rand(19200,19201);
			mes "[Vallen Wok]";
			mes "Hm. What. Should. We. Do. Today..";
			switch(.@qid){
				case 19200:
					mes "Hehehe today is fishing.. fishing..!! Go procure food through fishing!";
					next;
					emotion ET_BEST,getnpcid(0,"Volunteer Vallen Wok#ep21");
					mes "[Vallen Wok]";
					mes "There should be several places to fish along the Lunaforma beach. Gather 10 of the same kind of ingredient, understand?";
					break;
				case 19201:
					mes "Hehehe today is herb gathering.. gathering..!! Go around Lunaforma and have fun picking herbs!";
					next;
					emotion ET_BEST,getnpcid(0,"Volunteer Vallen Wok#ep21");
					mes "[Vallen Wok]";
					mes "If you gather herbs around Lunaforma, you should be able to find something edible. Gather 10 of the same kind of ingredient, understand?";			
					break;
			}
			setquest .@qid;
			close2;
			open_quest_ui(.@qid);
			end;

		case 2:
			mes "[Vallen Wok]";
			mes "Didn't I ask you to gather food through fishing today? If you brought me 10 of the same kind of ingredient, I'll let you know if it's edible or not.";
			next;
			setarray .@item_id$,"Ep21_Luna_Shrimp","Ep21_Luna_Calamari","Ep21_Luna_Seaweed","Ep21_Luna_Fish","Ep21_Luna_Oyster";
			for(.@i = 0; .@i < getarraysize(.@item_id$); .@i++)
				.@menu$ += (countitem(.@item_id$[.@i]) < 10 ? "^777777" : "") + getitemname(.@item_id$[.@i]) + (countitem(.@item_id$[.@i]) < 10 ? "^000000" : "") + ((.@i != getarraysize(.@item_id$) - 1) ? ":" : "");
			.@s = select(.@menu$) - 1;
			if(countitem(.@item_id$[.@s]) < 10){
				mes "[Vallen Wok]";
				mes "Didn't I tell you to bring 10 of the same ingredient? Go and bring me 10.";
				close;
			}
			if(.@s == 4){
				delitem "Ep21_Luna_Oyster",countitem(.@item_id$[.@s]);
				mes "[Vallen Wok]";
				mes "Huh, you've brought Lunaforma Oysters.";
				mes "Oysters are usually packed with nutrients, but it's different here. If you eat them, you'll experience extreme stomach pains.";
				mes "I'll dispose of this. You did well, but please bring something else next time.";
				close;
			}
			erasequest 19200;
			break;

		case 3:
			mes "[Vallen Wok]";
			mes "Didn't I ask you to gather food through herb gathering today? If you brought me 10 of the same kind of ingredient, I'll let you know if it's edible or not.";
			next;
			setarray .@item_id$,"Ep21_Luna_Grass","Ep21_Luna_KKatnip";
			for(.@i = 0; .@i < getarraysize(.@item_id$); .@i++)
				.@menu$ += (countitem(.@item_id$[.@i]) < 10 ? "^777777" : "") + getitemname(.@item_id$[.@i]) + (countitem(.@item_id$[.@i]) < 10 ? "^000000" : "") + ((.@i != getarraysize(.@item_id$) - 1) ? ":" : "");
			.@s = select(.@menu$) - 1;
			if(countitem(.@item_id$[.@s]) < 10){
				mes "[Vallen Wok]";
				mes "Didn't I tell you to bring 10 of the same ingredient? Go and bring me 10.";
				close;
			}
			if(.@s == 0){
				mes "[Vallen Wok]";
				mes "You've brought a Long Grass.";
				mes "Unfortunately, this grass scores zero as food. It's very tough.. even if you boil it.. the toughness won't change and it's bitter. Anyone who enjoys eating this must have serious issues with their taste buds.";
				next;
				delitem "Ep21_Luna_Grass",countitem(.@item_id$[.@s]);
				mes "[Vallen Wok]";
				mes "I'll dispose of this. You did well, but please bring something else next time.";
				close;
			}
			erasequest 19201;
			break;

		default:
			emotion ET_BLABLA,getnpcid(0,"Volunteer Vallen Wok#ep21");
			mes "[Vallen Wok]";
			mes "Ku hahahaha-";
			mes "Yes, yes. I hope the incredible adventurer has a great day.";
			close;
	}
	delitem .@item_id$[.@s],10;
	setquest 19199;
	getitem "Ep21_Wigner_Ticket",3;
	add_reputation_points(13,3);
	getexp 18259790,12000000;
	end;

OnInit:
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(19198) == 2 && isbegin_quest(19200) == 0 && isbegin_quest(19201) == 0 && checkquest(19199,PLAYTIME) == -1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(19198) == 2 && isbegin_quest(19200) == 0 && isbegin_quest(19201) == 0 && checkquest(19199,PLAYTIME) == 2";
	setarray .@fish$,"Ep21_Luna_Shrimp","Ep21_Luna_Calamari","Ep21_Luna_Seaweed","Ep21_Luna_Fish","Ep21_Luna_Oyster";
	for(.@i = 0; .@i < getarraysize(.@fish$); .@i++)
		.@fishing$ += " countitem(\"" + .@fish$[.@i] + "\") >= 10" + (.@i == (getarraysize(.@fish$) - 1) ? "" : "|");
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23247) == 2 && isbegin_quest(19198) == 0";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(19200) == 1 &&" + .@fishing$;
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(19201) == 1 && countitem(\"Ep21_Luna_Grass\") >= 10 || countitem(\"Ep21_Luna_KKatnip\") >= 10";
end;
}

jor_mbase,339,194,4	script	#f01_ep21	4_POINT_BLUE,{
	if(isbegin_quest(19198) < 2){
		pctalk "A fishing rod is ready. Is someone fishing here?";
		end;
	}
	cutin "2013_summer_fish_1.bmp",2;
	mes "- On the spot -";
	mes "- There's a fishing rod ready. -";
	mes "- Should I start fishing? -";
	next;
	select("Begin fishing.");
	cutin "2013_summer_fish_2.bmp",2;
	while(rand(1,10) <= 5){
		switch(rand(1,5)){
			case 1: mes "- ^82B3EDThere's no movement.^000000  -"; break;
			case 2: mes "- ^82B3EDThere's no movement on the shore..^000000 -"; break;
			case 3: mes "- ^82B3EDThere are birds flying over the sea.^000000 -"; break;
			case 4: mes "- ^82B3EDYou began to lost in thoughts.^000000 -"; break;
			case 5: mes "- ^82B3EDYou're smiling absent mindedly.^000000 -"; break;
		}
		sleep2 2000;
	}
	function fishing_cutins;
	mes "- ^FF0000There's a bite!!^000000 -";
	emotion ET_SURPRISE,getcharid(3);
	.@last_cutin = 4;
	.@last_cutin = fishing_cutins(5,.@last_cutin);
	select("Reel in a little","Reel in moderately","Reel in a lot");
	.@last_cutin = fishing_cutins(3,.@last_cutin);
	mes "- ^82B3EDThe fish's movements seems suspicious!.^000000 -";
	.@last_cutin = fishing_cutins(4,.@last_cutin);
	select("Reel in a little","Reel in moderately","Reel in a lot");
	.@last_cutin = fishing_cutins(3,.@last_cutin);
	mes "- ^82B3EDThe fish trashes and pulls in the line!^000000 -";
	.@last_cutin = fishing_cutins(4,.@last_cutin);
	select("Pull the rod to the left","Pull the rod to the right","Pull the rod backward");
	.@last_cutin = fishing_cutins(3,.@last_cutin);
	mes "- ^FF0000The fishing rod feels light...^000000 -";
	emotion ET_QUESTION,getcharid(3);
	next;
	select("Pull in the line to check the fish.");
	progressbar_npc "FFFF00",1;
	if(rand(1,10) <= 5){
		cutin "2013_summer_fish_6.bmp",2;
		specialeffect2 EF_DECAGILITY;
		mes "- ^006400Nothing^000000 was caught -";
	} else {
		cutin "2013_summer_fish_5.bmp",2;
		specialeffect2 EF_ENHANCE;
		.@fish = rand(1001619,1001623);
		switch(.@fish){
			case 1001619: .@fish$ = "shrimp";
			case 1001620: .@fish$ = "calamari";
			case 1001621: .@fish$ = "seaweed";
			case 1001622: .@fish$ = "fish";
			case 1001623: .@fish$ = "oyster";
		}
		getitem .@fish,1;
		mes "- You've caught a ^006400" + .@fish$ + "^000000!! -";
	}
	cutin "2013_summer_fish_5.bmp",2;
	close3;

function	fishing_cutins	{
	.@current = getarg(1);
	for(.@i = 0; .@i < getarg(0); .@i++){
		sleep2 400;
		if((.@current % 2) + .@i)
			cutin "2013_summer_fish_3.bmp",2;
		else
			cutin "2013_summer_fish_4.bmp",2;
	}
	return (.@i % 2) + 3;
}

OnInit:
	questinfo QTYPE_CLICKME,QMARK_YELLOW,"isbegin_quest(19200) == 1";
end;
}

jor_mbase,20,151,4	duplicate(#f01_ep21)	#f02_ep21	4_POINT_BLUE
jor_mbase,295,297,4	duplicate(#f01_ep21)	#f03_ep21	4_POINT_BLUE
jor_mbase,189,18,4	duplicate(#f01_ep21)	#f04_ep21	4_POINT_BLUE
jor_mbase,14,105,4	duplicate(#f01_ep21)	#f05_ep21	4_POINT_BLUE

jor_mbase,227,245,4	script	#p01_ep21	4_POINT_YELLOW,{
	if(isbegin_quest(19198) < 2){
		pctalk "It's a common plant that you can find on the side of a road.";
		end;
	}
	pctalk "It's a common plant found in Lunaforma. Could it be edible?";
	switch(select("Leave it.","Grab and pull it out.","Tear off a leaf.")){
		case 1:
			end;

		case 2:
			.@timer = 1;
			.@chance = 3;
			break;

		case 3:
			.@timer = 2;
			.@chance = 5;
			break;
	}
	progressbar_npc "FFFF00",.@timer;
	if(rand(1,10) > .@chance){
		getitem "Ep21_Luna_Grass",1;
		.@grass$ = "Long Grass";
	} else {
		getitem "Ep21_Luna_KKatnip",1;
		.@grass$ = "Wide Grass";
	}
	pctalk "You obtained a " + .@grass$ + ".";
	cloaknpc(strnpcinfo(0),true,getcharid(0));
	end;
	
OnInit:
	questinfo QTYPE_CLICKME,QMARK_YELLOW,"isbegin_quest(19201) == 1";
end;
}

jor_mbase,268,67,4	duplicate(#p01_ep21)	#p02_ep21	4_POINT_YELLOW
jor_mbase,236,53,4	duplicate(#p01_ep21)	#p03_ep21	4_POINT_YELLOW
jor_mbase,138,46,4	duplicate(#p01_ep21)	#p05_ep21	4_POINT_YELLOW
jor_mbase,111,46,4	duplicate(#p01_ep21)	#p06_ep21	4_POINT_YELLOW
jor_mbase,91,53,4	duplicate(#p01_ep21)	#p07_ep21	4_POINT_YELLOW
jor_mbase,40,39,4	duplicate(#p01_ep21)	#p08_ep21	4_POINT_YELLOW
jor_mbase,44,121,4	duplicate(#p01_ep21)	#p09_ep21	4_POINT_YELLOW
jor_mbase,63,134,4	duplicate(#p01_ep21)	#p10_ep21	4_POINT_YELLOW
jor_mbase,48,172,4	duplicate(#p01_ep21)	#p11_ep21	4_POINT_YELLOW
jor_mbase,111,213,4	duplicate(#p01_ep21)	#p13_ep21	4_POINT_YELLOW
jor_mbase,153,245,4	duplicate(#p01_ep21)	#p14_ep21	4_POINT_YELLOW
jor_mbase,264,265,4	duplicate(#p01_ep21)	#p16_ep21	4_POINT_YELLOW
jor_mbase,258,236,4	duplicate(#p01_ep21)	#p17_ep21	4_POINT_YELLOW
jor_mbase,276,184,4	duplicate(#p01_ep21)	#p18_ep21	4_POINT_YELLOW
jor_mbase,300,133,4	duplicate(#p01_ep21)	#p19_ep21	4_POINT_YELLOW
jor_mbase,317,94,4	duplicate(#p01_ep21)	#p20_ep21	4_POINT_YELLOW

jor_albe,160,137,4	script	Counselor Wool#ep21	4_M_01,{
    if(isbegin_quest(23247) < 2){
	    mes "- He looks very busy. -";
	    next;
	    mes "[Counselor Wool]";
	    mes "Sigh.. I'm sorry.";
	    mes "There are too many people who are struggling mentally these days. It's a hard time for everyone, I do understand.. I hope this chaos ends soon.";
	    next;
	    mes "- This quest cannot be performed yet. -";
	    close;
    }
	if(isbegin_quest(19184) == 0){
		mes "- He looks very busy. -";
		next;
		mes "[Counselor Wool]";
		mes "Oh.. I'm sorry.";
		mes "Now that I look at you, is this your first time here in the village? Are you an adventurer? You're quite impressive to be able to continue adventuring in such chaotic times.";
		next;
		mes "[Counselor Wool]";
		mes "To be honest, with the situation right now, I would like to just drop everything and go on a trip somewhere. It seems like everyone is going through tough too..";
		next;
		mes "[Counselor Wool]";
		mes "With all these counseling requests piling up, I feel like I'm the one going to collapse from assisting everyone.";
		next;
		select("Counciling requests?");
		mes "[Counselor Wool]";
		mes "Ah.. you might not be familiar. You're probably not aware of the big war with Jormungandr cult..";
		next;
		mes "[Counselor Wool]";
		mes "The entire continent became a warzone, Alberta is considered to be in a relatively safe location, that's why refugees have been flooding here.";
		next;
		mes "[Counselor Wool]";
		mes "Of course, it's not just refugees, there's also the people who were rescued from the Jormungandr cult and brought here.. there's also the ordinary people who've been traumatized by the horrors that they've witnessed in the war..";
		next;
		mes "[Counselor Wool]";
		mes "A variety of people are struggling for different reasons and are requesting counseling.";
		next;
		mes "[Counselor Wool]";
		mes "Well.. counseling isn't hard, all you need is to listen to their stories.. but no matter how much I divide my time, there's still only one of me.";
		next;
		emotion ET_QUESTION,getnpcid(0,"Counselor Wool#ep21");
		select("Can I help?");
		emotion ET_FRET,getnpcid(0,"Counselor Wool#ep21");
		mes "[Counselor Wool]";
		mes "I feel like I'm starting to be abrupt.. it's probably because I'm already on the edge.";
		next;
		mes "[Counselor Wool]";
		mes "Anyways. A help is exactly what I need right now.";
		mes "Voluntary help! Voluntary participation! These are necessary virtues in these confusing times.";
		next;
		mes "[Counselor Wool]";
		mes "I'll connect you with someone in the village who needs counseling. As for what you need to do..";
		next;
		mes "[Counselor Wool]";
		mes "You just need to give occasional encouraging words when appropriate and listen to them until they are satisfied.";
		next;
		pctalk "Well… I'll try..";
		mes "[Counselor Wool]";
		mes "For someone without professional training, that should be enough. Do you understand?";
		next;
		mes "[Counselor Wool]";
		mes "Now that I think about it, we haven't introduced ourselves yet.. What's your name adventurer?";
		next;
		select("My name is..");
		pctalk "My name is " + strcharinfo(0) + ".";
		mes "[Counselor Wool]";
		mes "Wow.. that's a difficult name. To be honest, I don't think I can remember it. I'm good at remembering my patient's name.. for some reason I'm not good with the others.. I wonder why..";
		next;
		pctalk "Huh?";
		mes "[Counselor Wool]";
		mes "I might be bad with names, but I'm great with numbers.";
		next;
		setquest 19184;
		completequest 19184;
		emotion ET_BEST,getnpcid(0,"Counselor Wool#ep21");
		mes "[Counselor Wool]";
		mes "I'll just call you Counselor Oil from now on. I look forward working with you.";
		close;
	}
	for(.@i = 19186; .@i <= 19189; .@i++){
		if(isbegin_quest(.@i) == 1){
			.@active_qid = .@i;
			break;
		}
	}
	switch(.@active_qid){
		case 19186: .@name$ = "Yuctor Pupu"; break;
		case 19187: .@name$ = "Totoro Amber"; break;
		case 19188: .@name$ = "George Sansha"; break;
		case 19189: .@name$ = "Fira Shina"; break;
		default: break;
	}
	switch(checkquest(19185,PLAYTIME)){
		case -1:
			break;
		case 0:
		case 1:
			.@cooldown = true;
			.@quest$ = "^777777[Wait] People tormented by nightmares^000000";
			break;
		case 2:
			break;
	}
	if(isbegin_quest(19190) == 0 && .@active_qid == 0 && .@cooldown == false)
		.@quest$ = "^000000People tormented by nightmares^000000";
	else if(isbegin_quest(19190) == 0 && .@active_qid)
		.@quest$ = "^777777[Ongoing] About " + .@name$ + "..^000000";
	else if(isbegin_quest(19190) == 1)
		.@quest$ = "^000000[Completed] People tormented by nightmares^000000";
	switch(select(.@quest$,"How to conduct counseling","Reason for working as counselor","Greet him")){
		case 1:
			switch(checkquest(19185,PLAYTIME)){
				case -1:
					break;
				case 0:
				case 1:
					mes "[Counselor Wool]";
					mes "Todays counseling is over~ We're done!";
					close;
				case 2:
					erasequest 19185;
					break;
			}
			if(isbegin_quest(19190) == 0 && .@active_qid == 0){
				.@qid = rand(19186,19189);
				mes "[Counselor Wool]";
				mes "Counselor Oil, I think this person would be good for today's session.";
				next;
				setquest .@qid;
				mes "[Counselor Wool]";
				switch(.@qid){
					case 19186: .@name$ = "Yuctor Pupu"; break;
					case 19187: .@name$ = "Totoro Amber"; break;
					case 19188: .@name$ = "George Sansha"; break;
					case 19189: .@name$ = "Fira Shina"; break;
				}
				mes "Please take care of ^085EF8" + .@name$ + "^000000's counseling. Please check the request form for the location and any reference information.";
				next;
				mes "[Counselor Wool]";
				mes "I look forward to your excellent counseling today.";
				close2;
				open_quest_ui .@qid;
				questinfo_refresh;
				end;
			}
			if(isbegin_quest(19190) == 0 && .@active_qid){
				mes "[Counselor Wool]";
				mes  .@name$ + " is the same with the others, they were captured by the cult and suffered hardships. From our past conversations.. oh.. I don't want to give you any preconceptions.";
				next;
				mes "[Counselor Wool]";
				mes "Please take care of today's counseling.";
				close;
			}
			if(isbegin_quest(19190) == 1 && .@active_qid){
				mes "[Counselor Wool]";
				mes "Counselor Oil, thank you for your hardwork. I see you've finished your session with " + .@name$ + ".";
				next;
				erasequest 19190;
				erasequest .@active_qid;
				setquest 19185;
				getitem "Ep21_Wigner_Ticket",3;
				getexp 22473590,11900000;
				add_reputation_points(13,2);
				mes "[Counselor Wool]";
				mes "You did a great job with today's counseling. This is just a small token, but I'd like to ask for your help again..";
				next;
				mes "[Counselor Wool]";
				mes "Today's counseling is over. It's finally over~ Yes!";
				close;
			}
			end;
		case 2:
			mes "[Counselor Wool]";
			mes "The method? It's simple. You just need to listen sincerely to what the other person is saying.";
			next;
			mes "[Counselor Wool]";
			mes "Counseling can become endlessly complicated if you dig too deep, but for someone who is struggling, just having someone listen to them brings them comfort.";
			next;
			mes "[Counselor Wool]";
			mes "Even in our daily lives, doesn't it upset you if someone you're talking to you is not earnestly listening?";
			next;
			mes "[Counselor Wool]";
			mes "So make a gesture to show that you're listening and hear them out.";
			next;
			mes "[Counselor Wool]";
			mes "For people who are in suffering even trivial things might bring them pain.";
			next;
			mes "[Counselor Wool]";
			mes "Of course, it's not always like that.. for that kind of issues, I won't ask your help for something like that.";
			close;
		case 3:
			mes "[Counselor Wool]";
			mes "It might be a long story.. Would you still like to hear it?";
			next;
			if(select("Listen.","I won't listen.") == 2){
				mes "[Counselor Wool]";
				mes "Okay~!";
				close;
			}
			mes "[Counselor Wool]";
			mes "If you insist.. I used to work as a counselor in a well-known city.";
			next;
			mes "[Counselor Wool]";
			mes "Listening to others as a councelor, but it started to wear down my mental strength..";
			next;
			mes "[Counselor Wool]";
			mes "My daily life became exhausting, and I realized. Ah! At this rate, I'll be the one who gets burnt out first.";
			next;
			mes "[Counselor Wool]";
			mes "Then, I took a vacation and call all the way here to Alberta to relax.";
			next;
			mes "[Counselor Wool]";
			mes "While I was enjoying my vacation, the war with the Jormungandr cult broke out on the continent and in the middle of the situation, returning would be hard..";
			next;
			mes "[Counselor Wool]";
			mes "And that's how I decided! To stay in Alberta and to fully rest my body.";
			next;
			mes "[Counselor Wool]";
			mes "First it was just that.. but the war dragged on, and people who had experienced the war started coming here.";
			next;
			mes "[Counselor Wool]";
			mes "What can I do? I kept seeing people who are struggling in front of me.. That's why I started counseling them..";
			next;
			mes "[Counselor Wool]";
			mes "I didn't realize that there would be this many.. I dug my own grave, now I'm just going along with it..";
			next;
			mes "[Counselor Wool]";
			mes "But being this busy also has it's perk. The days pass by like a wind, I don't feel the same emptiness that I used to feel when I was in the city.";
			next;
			mes "[Counselor Wool]";
			mes "Back there, I was just one of many counselors.";
			next;
			mes "[Counselor Wool]";
			mes "So that's how it came to be! That's the story of Councelor Wool working in Alberta.";
			next;
			mes "[Counselor Wool]";
			mes "Thnak you for listening.";
			close;
		case 4:
			mes "[Counselor Wool]";
			mes "Couselor Oil, the see breeze in Alberta is especially nice today. If you have the time, you should walk around.";
			next;
			mes "[Counselor Wool]";
			mes "Making time for yourself is also important.";
			close;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23247) == 2 && isbegin_quest(19184) == 0";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(19184) == 2 && isbegin_quest(19186) == 0 && isbegin_quest(19187) == 0 && isbegin_quest(19188) == 0 && isbegin_quest(19189) == 0 && checkquest(19185,PLAYTIME) == -1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(19184) == 2 && isbegin_quest(19186) == 0 && isbegin_quest(19187) == 0 && isbegin_quest(19188) == 0 && isbegin_quest(19189) == 0 && checkquest(19185,PLAYTIME) == 2";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(19190) == 1";
end;
}

jor_albe,89,103,6	script	Yuctor Pupu#ep21	4_M_RACHMAN1,{
	if(isbegin_quest(19186) == 1 && isbegin_quest(19190) == 0){
		if(isbegin_quest(19191) == 0){
			mes "[Yuctor Pupu]";
			mes "Were you sent by Counselor Wool?";
			next;
			mes "[Yuctor Pupu]";
			mes "Nice to meet you. My name is Yuctor Pupu. You can just call me Pupu, without using my last name.";
			next;
			mes "[Yuctor Pupu]";
			mes "Some people joke about my name and call me Poopoo. I personally hate that nickname so please refrain from using it";
			setquest 19191;
			completequest 19191;
		} else {
			mes "[Yuctor Pupu]";
			mes "Were you sent by Counselor Wool?";
		}
		next;
		select("Shall we begin the consultation?");
		mes "[Yuctor Pupu]";
		mes "Alright. I doubt it would be of much help..";
		while(.@correct < 3){
			.@topic = rand(1,4);
			while(.@topic == .@last_topic)
				.@topic = rand(1,4);
			.@last_topic = .@topic;
			next;
			mes "[Yuctor Pupu]";
			mes "Hm.. what should we talk about..";
			next;
			switch(.@topic){
				case 1: //About hometown
					mes "[Yuctor Pupu]";
					mes "Shall we talk about my hometown?";
					mes "Alberta has a lot of water because of the surrounding sea, but my hometown is a desert with very little water.";
					next;
					mes "[Yuctor Pupu]";
					mes "Unlike Alberta, which gives you the image of blue, my hometown gives you images of yellow.";
					next;
					mes "[Yuctor Pupu]";
					mes "I used to run a big business in my hometown, everyone knew about it. But the cult's oppression gew and I ended up abandoning everything and fled here.";
					next;
					mes "[Yuctor Pupu]";
					mes "I practically lost all my wealth when I fled. Personally, I believe trust is the most important thing for a merchant, but I abandoned the trust I've built over time along with my money.";
					next;
					mes "[Yuctor Pupu]";
					mes "Damn that cult.. I spent my whole life in the desert and always enduring sandstorms..";
					next;
					mes "[Yuctor Pupu]";
					mes "I always thought that I'd die and be buried in desert sand.. the sea breeze here is too cold for me..";
					next;
					mes "[Yuctor Pupu]";
					mes "Alberta is without a doubt a nice place. But living comfortably is different from having a peace of mind!";
					next;
					mes "[Yuctor Pupu]";
					mes "At my old age! In this place! Here! Why do I have to start over!! Why?! Why do I need to..";
					next;
					mes "[Yuctor Pupu]";
					mes "... ... ... ... ... ...";
					next;
					emotion ET_SLEEPY,getcharid(3);
					mes "[Yuctor Pupu]";
					mes "Phew.. I let my emotions get the better of for the moment. Are you even listening to my story?";
					next;
					mes "[Yuctor Pupu]";
					mes "What color did I say my hometown reminded me of?";
					next;
					if(select("Image of Blue","Image of Yellow") == 1){
						mes "[Yuctor Pupu]";
						mes "That's not it. if we're going to do this counseling, please pay attention.";
					} else {
						mes "[Yuctor Pupu]";
						mes "Hmm hmm... So you were paying attention.";
						.@correct++;
					}
					break;

				case 2: //About business
					mes "[Yuctor Pupu]";
					mes "Shall we talk about my business in my home town?";
					next;
					mes "[Yuctor Pupu]";
					mes "I personally believe that for a merchant, it's not what you sell matters, but rather how well you sell trust to your customers.";
					next;
					mes "[Yuctor Pupu]";
					mes "If you can't sell trust? Sure, you might make money in the short term.. but in 10 years? 20 years? It won't last that much.";
					next;
					mes "[Yuctor Pupu]";
					mes "If you want to run a stable business in a place, you need to build trust with your customer and continue to do so to make money.";
					next;
					mes "[Yuctor Pupu]";
					mes "You shouldn't pick and choose your customers either. That kind of behavior eventually eats away the customer's trust.. sigh.. it doesn't matter now..";
					next;
					mes "[Yuctor Pupu]";
					mes "Damn it, if it weren't for the cult.. I would have continue running my business like I always had.. but my business principles didn't work with them at all..";
					next;
					mes "[Yuctor Pupu]";
					mes "It still stings.. I took on a big order from the cult, delivered the goods, and got a promissory note in return. In the end, the cult never paid up.";
					next;
					mes "[Yuctor Pupu]";
					mes "Haha.. Those cult folks never intended to pay in the first place.";
					next;
					mes "[Yuctor Pupu]";
					mes "The cult took the goods and disappeared without a trace, the promisory note was nothing more than a piece of paper.";
					next;
					mes "[Yuctor Pupu]";
					mes "To put it simply. The cult scammed me. I had been tricked..";
					next;
					mes "[Yuctor Pupu]";
					mes "The due date for the payment came around.. I sold everything I had to pay for the goods. There was nothing I cold do..";
					next;
					mes "[Yuctor Pupu]";
					mes "Phew.. I need to calm down.. are you even listening to my story?";
					next;
					emotion ET_KEK,getcharid(3);
					mes "[Yuctor Pupu]";
					mes "What did I say I experienced at the hands of the cult?";
					next;
					if(select("You were forced to buy stuffs.","You were scammed.") == 1){
						mes "[Yuctor Pupu]";
						mes "That's not it. if we're going to do this counseling, please pay attention.";
					} else {
						mes "[Yuctor Pupu]";
						mes "Hmm hmm... So you were paying attention.";
						.@correct++;
					}
					break;

				case 3: //About likes
					mes "[Yuctor Pupu]";
					mes "Shall we talk about the things that I like?";
					next;
					mes "[Yuctor Pupu]";
					mes "I never really liked anything in particular. If I had to pick it would be... Zeny? Atleast that's what kept me from going hungry, you can say that I liked it.";
					next;
					mes "[Yuctor Pupu]";
					mes "Yes, that's right. I started my business because I liked money. I bought small goods like vases, polished them until they shined, and sold them.";
					next;
					mes "[Yuctor Pupu]";
					mes "I gradually moved on to selling bigger goods.. There were things that a merchant shouldn't sell, and I didn't which caused me to lose profits.";
					next;
					mes "[Yuctor Pupu]";
					mes "It was fun. To watch my savings slowly grow.. It prevented me from going hungry, and with what I had, I was able to help orphaned kids like me.";
					next;
					mes "[Yuctor Pupu]";
					mes "In my hometown, there were a lot of kids like me who are alone without parents. Now that I think about, I wonder how they're doing?";
					next;
					mes "[Yuctor Pupu]";
					mes "When I fled my hometown, It was heart-breaking to leave them behind. I was worried that they might suffer because of me..";
					next;
					mes "[Yuctor Pupu]";
					mes "But I left them money to survive, they should make it if they worked hard, right? They should be fine, right?";
					next;
					mes "[Yuctor Pupu]";
					mes "I thought I was telling a touching story.. Are you even paying attention?";
					next;
					emotion ET_SLEEPY,getcharid(3);
					mes "[Yuctor Pupu]";
					mes "What did I say the one thing that I probably liked?";
					next;
					if(select("It was food","It was Zeny") == 1){
						mes "[Yuctor Pupu]";
						mes "That's not it. if we're going to do this counseling, please pay attention.";
					} else {
						mes "[Yuctor Pupu]";
						mes "Hmm hmm... So you were paying attention.";
						.@correct++;
					}
					break;

				case 4:
					mes "[Yuctor Pupu]";
					mes "Shall we talk about how I left my hometown to come to Alberta?";
					next;
					mes "[Yuctor Pupu]";
					mes "After being tricked by the cult and losing all my wealth, I sold everything I had to pay off the debt for the goods to maintain my honor as a merchant.";
					next;
					mes "[Yuctor Pupu]";
					mes "Though I had lost my life savings, I didn't have the idea of leaving my hometown.";
					next;
					mes "[Yuctor Pupu]";
					mes "I was confident that I can rebuild and succeed again. Hahaha, but it seems the cult still saw me as someone they could exploit.";
					next;
					mes "[Yuctor Pupu]";
					mes "After being tricked, I had one of my informants infiltrate the cult and reported me that they scheming against me again.";
					next;
					mes "[Yuctor Pupu]";
					mes "Later, I found out that not only me, but most merchants who were rumored to have some wealth were also targeted. I was lucky.";
					next;
					mes "[Yuctor Pupu]";
					mes "Unlike the other merchants, I had no family. My escape was easy.";
					next;
					mes "[Yuctor Pupu]";
					mes "I carried it out in secret. During those times, I was grateful to be alone. If I had a family, I wouldn't have been able to escape.";
					next;
					mes "[Yuctor Pupu]";
					mes "After leaving the hometown where I had spent my entire life. To avoid the cult's radar. I crossed mountains, rivers, traverse deserts, and passed through a great forest.";
					next;
					mes "[Yuctor Pupu]";
					mes "That's how I ended up in Alberta. Were you listening to my story?";
					next;
					emotion ET_SLEEPY,getcharid(3);
					mes "[Yuctor Pupu]";
					mes "Where did I say I crossed?";
					next;
					select("You crossed mountains.","You crossed rivers.");
					mes "[Yuctor Pupu]";
					mes "Hmm hmm... So you were paying attention.";
					.@correct++;
					break;
			}
		}
		next;
		setquest 19190;
		questinfo_refresh;
		mes "[Yuctor Pupu]";
		mes "Do you think the counseling session is enough for today? My throat hurts from talking for so long.";
		next;
		mes "[Yuctor Pupu]";
		mes "Thank you for listening. Now that I've said those stories, I feel like my heart is a bit at easy.";
		close2;
		open_quest_ui 19190;
		end;
	}
	if(isbegin_quest(19190) == 1 && isbegin_quest(19186) > 0){
		mes "[Yuctor Pupu]";
		mes "Thank you for listening. Now that I've said those stories, I feel like my heart is a bit at easy.";
		close;
	}
	mes "[Yuctor Pupu]";
	mes "The sea breeze in Alberta feels cold and relaxing, unlike the desert winds from my homeland.";
	close;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(19190) == 0 && isbegin_quest(19186) == 1";
end;
}

jor_albe,136,196,6	script	Totoro Amber#ep21	4_M_NFMAN,{
	if(isbegin_quest(19187) == 1 && isbegin_quest(19190) == 0){
		if(isbegin_quest(19192) == 0){
			mes "[Totoro Amber]";
			mes "Hello?";
			mes "I asked for Counselor Wool's, but it seems that you're here in his stead, right?";
			next;
			mes "[Totoro Amber]";
			mes "Well, Counselor Wool has been incredibly busy lately. But, I can't help feeling disppointed.";
			next;
			mes "[Totoro Amber]";
			mes "Oh! My name is Totoro Amber. Please call me Amber.";
			setquest 19192;
			completequest 19192;
		} else {
			mes "[Totoro Amber]";
			mes "Alright?";
			mes "I asked for Counselor Wool's, but it seems that you're here in his stead, right?";
		}
		next;
		select("Amber, shall we begin our counseling?");
		mes "[Totoro Amber]";
		mes "Alright. Should we start?";
		next;
		mes "[Totoro Amber]";
		mes "There is some story that I want to tell.";
		next;
		while(.@correct < 3){
			.@topic = rand(1,3);
			while(.@topic == .@last_topic)
				.@topic = rand(1,3);
			.@last_topic = .@topic;
			next;
			mes "[Totoro Amber]";
			mes "Hm.. what should we talk about..";
			next;
			switch(.@topic){
				case 1: //Resistance against the cult
					mes "[Totoro Amber]";
					mes "Adventurer, do you know about the resistance who's fighting the cult?";
					next;
					mes "[Totoro Amber]";
					mes "I've heard rumors that captain Walter is also fighting with the resistance..";
					next;
					mes "[Totoro Amber]";
					mes "I don't know much as a normal citizen, but I do know that they are risking their lives for the greater cause.";
					next;
					mes "[Totoro Amber]";
					mes "I believe that captain Walter would never do anything that would harm us.";
					next;
					mes "[Totoro Amber]";
					mes "The resistance issue is something that they only can handle! The real problem that we are facing here is the sudden increase in population of Alberta.";
					next;
					mes "[Totoro Amber]";
					mes "Small disputes are arising over lodging, meals, and bathroom facilities for the refugees. It's not a major issue for now.. but given a little more time..";
					next;
					mes "[Totoro Amber]";
					mes "I'm sure it will escalate into something bigger. Someone needs to step up before that happens..";
					next;
					mes "[Totoro Amber]";
					mes "Adventurer, excuse me? Are you listening?";
					next;
					emotion ET_SLEEPY,getcharid(3);
					mes "[Totoro Amber]";
					mes "What did I say that captain Walter is fighting?";
					next;
					if(select("Fighting the resistance.","Fighting the cult.") == 1){
						mes "[Totoro Amber]";
						mes "... I have no words. Please focus and continue the counseling.";
					} else {
						mes "[Totoro Amber]";
						mes "You're a good listener. I thought your mind is elsewhere..";
						.@correct++;
					}

				case 2: //About Alberta
					mes "[Totoro Amber]";
					mes "Alberta is a small fishing village where not many people know each other. Well, it used to be a small fishing village.";
					next;
					mes "[Totoro Amber]";
					mes "It was such a quiet place that we'd only see outsiders once or twice a year, but somehow this small vilage has become well-known as the rear base of the war.";
					next;
					mes "[Totoro Amber]";
					mes "Because of that our quiet village became crowded. A lot of new faces came into town.";
					next;
					mes "[Totoro Amber]";
					mes "By the way, have you heard the rumors? I only learned it recently too.";
					next;
					mes "[Totoro Amber]";
					mes "Apparently Alberta is the safest place to route ships to Lunaforma, which is the frontlines, so a lot of resources and people are transported here by sea.";
					next;
					mes "[Totoro Amber]";
					mes "Right now it's mostly refugees, It's.. sigh.. ever since they came, I've been having nightmares and plagued by extreme guilt.";
					next;
					mes "[Totoro Amber]";
					mes "Sigh.. even if I don't want it, Alberta will probably grow and develop more after the war between the cult and the resistance end, won't it?";
					next;
					mes "[Totoro Amber]";
					mes "I really hope the refugees can find peace and happiness soon.. adventurer?";
					next;
					mes "[Totoro Amber]";
					mes "Are you listening to me?";
					next;
					emotion ET_SLEEPY,getcharid(3);
					mes "[Totoro Amber]";
					mes "Is Alberta the frontline? Or the rear?";
					next;
					if(select("The rear.","The frontline.") == 2){
						mes "[Totoro Amber]";
						mes "... I have no words. Please focus and continue the counseling.";
					} else {
						mes "[Totoro Amber]";
						mes "You're a good listener. I thought your mind is elsewhere..";
						.@correct++;
					}
					break;

				case 3:
					//About family
					mes "[Totoro Amber]";
					mes "I'd like to talk about my family.";
					next;
					mes "[Totoro Amber]";
					mes "My family has lived in Alberta for generations, and as far as I know, we've been involved in the fishing industry for a long time.";
					next;
					mes "[Totoro Amber]";
					mes "My father often sails out for long periods, leaving the house quite empty for some time..";
					next;
					mes "[Totoro Amber]";
					mes "But when my father and my uncles who go with him come home, they help with the chores and play with me, that's why I learn not to mind his absence too much.";
					next;
					mes "[Totoro Amber]";
					mes "Sometimes, a huge smelly box gets delivered to our house, but my father and uncles quickly move it to a shed near the house so the smell doesn't spread into our house.";
					next;
					mes "[Totoro Amber]";
					mes "Judging from the frequency of fresh fish dishes that we have, I'm sure my father is running a large fishing operation.";
					next;
					mes "[Totoro Amber]";
					mes "It's a bit embarassing, but I've never gone to see how my father works. Well, I suppose once I'm older, don't you think he'll take me to show me the ropes?";
					next;
					mes "[Totoro Amber]";
					mes "Adventurer, are you listening to my story?";
					next;
					emotion ET_KEK,getcharid(3);
					mes "[Totoro Amber]";
					mes "What is the thing I mention about being smelly?";
					next;
					if(select("A box that gets delivered..","Fishes gets delivered..") == 1){
						mes "[Totoro Amber]";
						mes "... I have no words. Please focus and continue the counseling.";
					} else {
						mes "[Totoro Amber]";
						mes "You're a good listener. I thought your mind is elsewhere..";
						.@correct++;
					}
					break;
			}
		}
		next;
		setquest 19190;
		questinfo_refresh;
		mes "[Totoro Amber]";
		mes "Wow.. after sharing my stories with you, It feels like my heart has lightened a bit.";
		next;
		mes "[Totoro Amber]";
		mes "Thank you for your counseling efforts.";
		close2;
		open_quest_ui 19190;
		end;
	}
	if(isbegin_quest(19190) == 1 && isbegin_quest(19187) > 0){
		mes "[Totoro Amber]";
		mes "Is it because of the counseling? just like the Alberta that I know, the noise in my heart has quieted down.";
		close;
	}
	mes "[Totoro Amber]";
	mes "Alberta is a quiet seaside village. It seems like a lot of people have come into this village because the other parts of the world is in chaos.";
	close;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(19190) == 0 && isbegin_quest(19187) == 1";
end;
}

jor_albe,49,244,4	script	George Sansha#ep21	4_M_THAIAYO,{
	if(isbegin_quest(19188) == 1 && isbegin_quest(19190) == 0){
		if(isbegin_quest(19193) == 0){
			mes "[George Sansha]";
			mes "Sigh.. That guy.. Did he send another councelor after all?";
			next;
			mes "[George Sansha]";
			mes "Ah.. seriously.. haven't I told him that I don't need counseling?";
			setquest 19193;
			completequest 19193;
		} else {
			mes "[George Sansha]";
			mes "Ah.. seriously.. haven't I told him that I don't need counseling?";
		}
		next;
		select("Shall we begin?");
		mes "[George Sansha]";
		mes "Sigh.. Fine.. Let's do it!";
		next;
		while(.@correct < 3){
			.@topic = rand(1,3);
			while(.@topic == .@last_topic)
				.@topic = rand(1,3);
			.@last_topic = .@topic;
			next;
			mes "[Totoro Amber]";
			mes "Alright~ For our topic..";
			next;
			switch(.@topic){
				case 1: //About Life
					mes "[George Sansha]";
					mes "Shall we talk about my life recently?";
					next;
					mes "[George Sansha]";
					mes "It's peaceful~ relaxing~ have decent meals~ when I feel tired, I can sleep freely~";
					next;
					mes "[George Sansha]";
					mes "Sometimes I even wonder if it's okay for me to live like this. Is this how a normal person would live..";
					next;
					mes "[George Sansha]";
					mes "Don't they get bored? It makes me think a lot of things.. like identifying unapprove vulnerable items in the neighborhood..";
					next;
					mes "[George Sansha]";
					mes "or figuring out possible escape routes.. Of course, not that I'd do that.. But I could inform the neighborhood, right?";
					next;
					mes "[George Sansha]";
					mes "In my own way, I could put my skills from my former job to use and prevent things in the area. Wouldn't that benefit everyone?";
					next;
					mes "[George Sansha]";
					mes "And here I am, discussing my grand and glorious plan, and you're thinking about something else, don't you?";
					next;
					emotion ET_SLEEPY,getcharid(3);
					mes "[George Sansha]";
					mes "Ever since I came here, what did I start thinking about";
					next;
					if(select("Moving object from a location.","Figuring out an escape route.") == 1){
						mes "[George Sansha]";
						mes "Hey- we are just wasting time here, atleast do it with sincerity!";
					} else {
						mes "[George Sansha]";
						mes "I thought you were zoning out~ I figured you were slacking off. Sorry for doubting you";
						.@correct++;
					}
					break;

				case 2: //About Jormungandr
					mes "[George Sansha]";
					mes "Shall we talk about the Jormungandr cult?";
					next;
					mes "[George Sansha]";
					mes "Considering that I almost ended up becoming a slave while trying to steal some items there, I'm not really in a position to say much..";
					next;
					mes "[George Sansha]";
					mes "But those guys are shady. They disguise themselves as a religion.. But they're no different from thugs.";
					next;
					mes "[George Sansha]";
					mes "When I infiltrated the cult to steal some items, I heard..";
					next;
					mes "[George Sansha]";
					mes "that a guy who handles the cult's dirty work scammed a merchant. They must've hit the jackpot, as they were laughing among themselves..";
					next;
					mes "[George Sansha]";
					mes "Damn, I should've been the one who hit the jackpot.. Looking back on my life, I think I faled because I only aimed for small things. I should've gone big like those cult thugs..";
					next;
					mes "[George Sansha]";
					mes "Now that I've decided to have a fresh start, I'll be patien t with the small stuff and aim for a bigger one in the future.";
					next;
					mes "[George Sansha]";
					mes "Don't worry, I'll make sure aim the big score legally!";
					next;
					mes "[George Sansha]";
					mes "Hey, are you even listening? Are you asleep?";
					next;
					emotion ET_SLEEPY,getcharid(3);
					mes "[George Sansha]";
					mes "I think those cult guys are shady. Did I say that they're no different from street thugs and?";
					next;
					if(select("Disguise themselves with mask.","Disguise themselves as a religion.") == 1){
						mes "[George Sansha]";
						mes "Hey- we are just wasting time here, atleast do it with sincerity!";
					} else {
						mes "[George Sansha]";
						mes "I thought you were zoning out~ I figured you were slacking off. Sorry for doubting you";
						.@correct++;
					}
					break;

				case 3:
					mes "[George Sansha]";
					mes "Let's talk about the war~";
					next;
					mes "[George Sansha]";
					mes "Lower class people like us don't know the exact reason, but from what I've gathered, it was a war where the resistance rose up agains the tyranny of the cult.";
					next;
					mes "[George Sansha]";
					mes "Sigh.. If I hadn't been caught by the cult I would've made a fortune.. If only I succeeded stealing that item from them..";
					next;
					mes "[George Sansha]";
					mes "By now, I would be living large in some unknown city.. Tsk..";
					next;
					mes "[George Sansha]";
					mes "Ugh.. thinking about it makes me angry.. it still flashes before my eyes..";
					next;
					mes "[George Sansha]";
					mes "Sigh.. failing to steal it was my biggest regret! Damn! If only I hadn't been caught.. sigh..";
					next;
					mes "[George Sansha]";
					mes "What's the point now.. Huh? Hello? Are you sleeping counselor?";
					next;
					emotion ET_SLEEPY,getcharid(3);
					mes "[George Sansha]";
					mes "Here's a question~ What was I doing when I got caught by the cult?";
					next;
					if(select("I borrowed an item.","I stole an item.") == 1){
						mes "[George Sansha]";
						mes "Hey- we are just wasting time here, atleast do it with sincerity!";
					} else {
						mes "[George Sansha]";
						mes "I thought you were zoning out~ I figured you were slacking off. Sorry for doubting you";
						.@correct++;
					}
					break;
			}
		}
		next;
		setquest 19190;
		mes "[George Sansha]";
		mes "Oh! Counselor, don't you think now is the perfect time to stop the counseling?";
		next;
		mes "[George Sansha]";
		mes "Go back to Wool and tell him that we're done today.";
		close2;
		open_quest_ui 19190;
		end;
	}
	if(isbegin_quest(19190) == 1 && isbegin_quest(19188) > 0){
		mes "[George Sansha]";
		mes "Go back to Wool and tell him that we're done today.";
		close;
	}
	mes "[George Sansha]";
	mes "Pwoo- ?! What are you looking at? Never seen someone spit before?";
	close;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(19190) == 0 && isbegin_quest(19188) == 1";
end;
}

jor_albe,116,214,4	script	Fira Shina#ep21	4_F_MALAYA,{
	if(isbegin_quest(19190) == 0 && isbegin_quest(19189) == 1){
		if(isbegin_quest(19194) == 0){
			mes "[Fira Shina]";
			mes "Ee-e-ek!!";
			mes "I'm.. sorry. You suddenly started talking to me.. sorry for screaming suddenly..";
			next;
			mes "[Fira Shina]";
			mes "A.. are you the counselor sent by Wool? I.. I'm Fira Shina. Nice to meet you. Please call me shield.";
			next;
			mes "[Fira Shina]";
			mes "I.. I've been stuttering since that day.. P.. please don't mind it.";
			next;
			setquest 19194;
			completequest 19194;
		} else {
			mes "[Fira Shina]";
			mes "Ee-e-ek!!";
			mes "I'm.. sorry. You suddenly started talking to me.. sorry for screaming suddenly..";
		}
		next;
		select("Shall we start the counseling?");
		mes "[Fira Shina]";
		mes "Yes.. let's get started.";
		next;
		while(.@correct < 3){
			.@topic = rand(1,4);
			while(.@topic == .@last_topic)
				.@topic = rand(1,4);
			.@last_topic = .@topic;
			next;
			mes "[Fira Shina]";
			mes "For.. the topic..";
			next;
			switch(.@topic){
				case 1: //Jormungandr and Resistance
					mes "[Fira Shina]";
					mes "I.. I'm going to talk about the Jormungandr cult.. and the resistance.";
					next;
					mes "[Fira Shina]";
					mes "The Jormungandr cult pr.. preaches for the restoration.. of the Midgard continent.. making it habitable for every li-living beings, because of the sacrifice of Jormungandr.. Th-that's why we must server and follow.. the Jormungandr cult.";
					next;
					mes "[Fira Shina]";
					mes "B-but.. the cult.. in my village.. sigh.. I-if you're not a believers.. Th.. they're impose brutal punishments.";
					next;
					mes "[Fira Shina]";
					mes "There were even rumors that they feed non-believers as.. f-food for monsters. That's why the resistance was formed..th-that's how the war began.";
					next;
					mes "[Fira Shina]";
					mes "The resistance soldiers also rescued me when I wa.. was capture by the cult. Since being brought to Alberta.. everyday feels like a dream.";
					next;
					mes "[Fira Shina]";
					mes "After that long nightmare.. it felt like I fi-finally have given hope.. I also th-think I found.. the thing I want to do.";
					next;
					mes "[Fira Shina]";
					mes "I don't know who are they for.. but I want to make clothes.. to gift it to the person who saved me.";
					next;
					mes "[Fira Shina]";
					mes "That person mu-must be.. really amazing. B.. but.. uhm.. counselor? A.. are you listening?";
					next;
					emotion ET_KEK,getcharid(3);
					mes "[Fira Shina]";
					mes "C.. counselor.. can you tell me what.. the cult worships again?";
					next;
					if(select("They worship Yormungandr.","They worship Jormungandr.") == 1){
						mes "[Fira Shina]";
						mes "Ah.. never mind. This is.. a counseling se-session.. can you please listen carefully?";
					} else {
						mes "[Fira Shina]";
						mes "O.. Okay. You.. were listening carefully.";
						.@correct++;
					}
					break;

				case 2: //Nightmares
					mes "[Fira Shina]";
					mes "I'd like.. to talk about my nightmares.. I've been having lately.";
					next;
					mes "[Fira Shina]";
					mes "The nightmares always start in.. a dark wa-wagon. I.. I'm loaded in the wagon, not knowing where I was being taken..";
					next;
					mes "[Fira Shina]";
					mes "Everytime the wagon.. jo.. jolts.. I'm also being tossed.. rolled and dragged inside.. like a luggage.";
					next;
					mes "[Fira Shina]";
					mes "I kept.. rolling around in the wa-wagon.. over and over.. Until I finally.. wake up from it.";
					next;
					mes "[Fira Shina]";
					mes "BVut recently.. the nightmare ha-hasn't been terrifying. In the past.. I didn't know when the ni-nightmare would end..";
					next;
					mes "[Fira Shina]";
					mes "But, now.. I-I know that someone will open up the dark wagon.. and rescue me.";
					next;
					mes "[Fira Shina]";
					mes "B.. but.. c.. counselor? A.. are you listening?";
					next;
					emotion ET_KEK,getcharid(3);
					mes "[Fira Shina]";
					mes "W.. where did I say.. my nightmare.. always begin?";
					next;
					if(select("In a dark cave..","In a dark wagon..") == 1){
						mes "[Fira Shina]";
						mes "Ah.. never mind. This is.. a counseling se-session.. can you please listen carefully?";
					} else {
						mes "[Fira Shina]";
						mes "O.. Okay. You.. were listening carefully.";
						.@correct++;
					}
					break;

				case 3: //Old Life
					mes "[Fira Shina]";
					mes "I.. I'm going to talk about.. my p-past life. About when.. I was still living a.. n-normal life.";
					next;
					mes "[Fira Shina]";
					mes "The village I grew.. I can't no longer return.. It was a small village with less than 100 pe-people.. it's even smaller than Alberta.";
					next;
					mes "[Fira Shina]";
					mes "There, I quietly.. made clothes. The village was always.. p-peaceful, and I made a living making clothes.. b-by selling it to merchants.";
					next;
					mes "[Fira Shina]";
					mes "It.. it was just a normal day.. a merchant came into the village. Just like the usual.. b-but it felt odd. Instead of giving price to the goods.. we-we're offering..";
					next;
					mes "[Fira Shina]";
					mes "It was as if.. t-they were evaluating our worth? It.. was like a snake gaze.. observing its prey.";
					next;
					mes "[Fira Shina]";
					mes "That night our village got attacked.. m-most people were killed.. unlike me, I was loaded into a wagon. My.. village.. I wonder.. what happen.. to everyone?";
					next;
					mes "[Fira Shina]";
					mes "They.. were too cruel. We were like they're play thing.. there was no e-escape.. or run.";
					next;
					mes "[Fira Shina]";
					mes "B.. but.. c.. counselor? A.. are you listening?";
					next;
					emotion ET_SLEEPY,getcharid(3);
					mes "[Fira Shina]";
					mes "W.. what did I say.. that I m-made.. and sold.. in my peaceful village?";
					next;
					if(select("You made food.","You made clothes.") == 1){
						mes "[Fira Shina]";
						mes "Ah.. never mind. This is.. a counseling se-session.. can you please listen carefully?";
					} else {
						mes "[Fira Shina]";
						mes "O.. Okay. You.. were listening carefully.";
						.@correct++;
					}
					break;

				case 4: //New Life
					mes "[Fira Shina]";
					mes "I'd like to t.. talk about my n-new life in Alberta.";
					next;
					mes "[Fira Shina]";
					mes "I miss my hometown, but.. I-I'm also satisfied with my.. new life here in Alberta. They provide us.. with various conveniences, like this counseling session..";
					next;
					mes "[Fira Shina]";
					mes "B-but.. there's a problem. I-it's too.. secretive. We.. we don't know who is helping.. and supporting us..";
					next;
					mes "[Fira Shina]";
					mes "I.. I can't figure out.. w-who rescued us.. and brought us in Alberta.";
					next;
					mes "[Fira Shina]";
					mes "I'd.. like to find out w-who helped me.. and.. atleast.. thank them, but w-we have too little information..";
					next;
					mes "[Fira Shina]";
					mes "We are even j-joking.. that w-we might be spy.. sent by the cult.";
					next;
					mes "[Fira Shina]";
					mes "I.. sometimes wonder.. if.. I would be able.. to meet them.. counselor? A.. are you listening?";
					next;
					emotion ET_SLEEPY,getcharid(3);
					mes "[Fira Shina]";
					mes "W.. what did I j-joke about.. with the other rescued people?";
					next;
					if(select("That you are spies?","That you are being isolated?") == 1){
						mes "[Fira Shina]";
						mes "Ah.. never mind. This is.. a counseling se-session.. can you please listen carefully?";
					} else {
						mes "[Fira Shina]";
						mes "O.. Okay. You.. were listening carefully.";
						.@correct++;
					}
					break;
			}
		}
		next;
		setquest 19190;
		mes "[Fira Shina]";
		mes "Sigh.. I think that's enough f-for today.";
		next;
		mes "[Fira Shina]";
		mes "T.. thank you for.. the counseling session. I feel much more.. at ease now.";
		close2;
		open_quest_ui 19190;
		end;
	}
	if(isbegin_quest(19190) == 1 && isbegin_quest(19189) > 0){
		mes "[Fira Shina]";
		mes "T.. thank you for.. the counseling session. I feel much more.. at ease now.";
		close;
	}
	mes "[Fira Shina]";
	mes "Ee-e-ek!!";
	next;
	mes "[Fira Shina]";
	mes "I'm.. sorry. You suddenly started talking to me.. sorry for screaming suddenly..";
	close;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(19190) == 0 && isbegin_quest(19189) == 1";
end;
}

jor_mbase,217,172,3	script	Mandel#21ms00	4_M_HUOLDARMY,{
	if(isbegin_quest(18360) < 2){
		mes "[Mandel]";
		mes "You seem a bit inexperienced to be securing supplies. It's actually quite a bit harder than it looks, you know?";
		close;
	}
	if(isbegin_quest(17781) == 0){
		mes "[Mandel]";
		mes "Hello! I was wondering when you'd come and see me.";
		mes "How are you? Are you adjusting to the life here? Spending time in Lunaforma isn't exactly easy, isn't it?";
		next;
		mes "[Mandel]";
		mes "I don't know where you came from, but compared to that place, Lunaforma probably lacks a lot more. And the is a sole reason for it. The times are tough.";
		mes "That's why supplies here are extremely important. I'm Mandel of the Wigner Merchant Guild, the one in charge of the supplies.";
		next;
		mes "[Mandel]";
		mes "However, obtaining supplies is a challenge. I think you might be able to help me. I don't simply offer this to anyone, you know?";
		mes "It shouldn't bee to difficult for you. All you need is to bring back the items you find while traveling around. ";
		next;
		mes "[Mandel]";
		mes "Of course it's not for free.";
		mes "If you bring supplies once a day, I'll provide you with good reward.";
		next;
		mes "[Mandel]";
		mes "If you diligently bring enough supplies, I can offer you various kinds of power that you might need.";
		mes "It's called the Blessing of Lunaforma, and it's available as long as you bring the Wigner Merchant Guild Voucher.";
		next;
		mes "[Mandel]";
		mes "First, let's see what we need...";
		next;
		mes "[Mandel]";
		mes "The ^0000cdGaebolg Commander^000000 wants a ^0000cd" + getitemname(1001629) + "^000000.";
		mes "They want to collect everything scattered across the continent for analysis. It's natural that knowing your enemy gives you advantage";
		mes "If you bring enough doctrines, you will receive the blessing that ^0000cdIncreases your Attack Power^000000.";
		next;
		mes "[Mandel]";
		mes "^0000cdGalaxia Nerius^000000... wants a sweet snack?";
		mes "^0000cd" + getitemname(1001648) + "^000000 will do. It taste delicious. It seems that her power comes from sweets. Alright, noted!";
		mes "If you bring enough of it, you can receive a blessing that ^0000cdIncreases your speed^000000.";
		next;
		mes "[Mandel]";
		mes "^0000cdIlse El Heine^000000 is looking for ^0000cd" + getitemname(1001639) + "^000000. The reason is written in detail here on this note.";
		mes "Hmm... It's three pages. To summarize it, he need a lot of it to power up the magic tools that he created.";
		next;
		mes "[Mandel]";
		mes "As luck would have it, the shamans of the Jormungandr cult have a lot of different jeweled ornament, right? Just take from them. It's two bird with one stone.";
		mes "If you bring enough of it, you can receive a blessing that ^0000cdIncreases your power against Dragon and Plant enemies^000000.";
		next;
		mes "[Mandel]";
		mes "The ^0000cdLugenburg brothers^000000... Hm... they want a ^0000cd" + getitemname(1001637) + "^000000.";
		mes "They plan to melt down the weapons used by the cult to make various tools. The cult took all the metal they could find. So, it's time to take it back.";
		mes "If you bring enough of it, you can receive a blessing that ^0000cdIncreases your power against Demon and Undead enemies^000000.";
		next;
		mes "[Mandel]";
		mes "The ^0000cdWalter Sailors^000000 is looking a sour fruit.";
		mes "I know why they need it. When sailing, there's a risk of being sea sick. Let's see... since it's hard to find fruits here, we can substitute it with ^0000cd" + getitemname(1001646) + "^000000.";
		mes "If you bring enough of it, you can receive a blessing that ^0000cdIncreases your power against Formless and Fish enemies^000000.";
		next;
		mes "[Mandel]";
		mes "The ^0000cdWigner Merchant Guild^000000... Of course, Of course. We are looking for ^0000cd" + getitemname(1001642) + "^000000.";
		mes "Nothing boost crops production like it. Increased crop production is the beginning of abundant resources.";
		next;
		mes "[Mandel]";
		mes "Bring everything that you can find, don't even think of hiding it. You have no use for it anyway";
		mes "If you bring enough of it, you can receive a blessing that ^0000cdIncreases your power against Brute and Angel enemies^000000.";
		next;
		mes "[Mandel]";
		mes "The ^0000cdRichard Mercenaries^000000 are looking for ^0000cd" + getitemname(1001645) + "^000000.";
		mes "Have you seen the road of Lunaforma? The mercenaries works really hard to keep those roads from freezing.";
		next;
		mes "[Mandel]";
		mes "Spreading the material on the road melts the snow and prevents freezing, making it great for maintaining the road condition.";
		mes "If you bring enough of it, you can receive a blessing that ^0000cdIncreases your power against Demihuman and Insect enemies^000000.";
		next;
		mes "[Mandel]";
		mes "I think that covers everything we need. If you're interested, please lend a hand.";
		mes "It's not a losing deal isn't it? You're doing a good deed and get rewarded, isn't that a win-win? If I were you I'd do it right away.";
		mes "Think about it!";
		setquest 17781;
		completequest 17781;
		close;
	}
	setarray .@name$,"Gaebolg","Nerius","Heine","Lugenburg","Walter","Wigner","Richard";
	setarray .@target$,"Jormi Evangelist","Ice Seahorse","Jordos Shaman","Jordos Executioner","Cliolima","Seawind","Letterster";
	setarray .@item_id,1001629,1001648,1001639,1001637,1001646,1001642,1001645;
	for(.@i = 17782; .@i <= 17788; .@i++){
		if(isbegin_quest(.@i) == 1){
			if(countitem(.@item_id[.@x]) >= 10){
				mes "[Mandel]";
				mes "That's enough for today. You did well.";
				mes "Now, take a good rest, and if it's alright, I'll expect your help again tomorrow. Goodbye!";
				delitem .@item_id[.@x],10;
				erasequest .@i;
				erasequest 17790;
				setquest 17789;
				getitem "Ep21_Wigner_Ticket",10;
				add_reputation_points((13 + .@x),100);
				close;
			}
		}
		.@x++;
	}
	mes "[Mandel]";
	mes "Hello! What brings you here today?";
	next;
	switch(checkquest(17789,PLAYTIME)){
		case -1:
			break;
			
		case 0:
		case 1:
			.@cooldown = true;
			break;
			
		case 2:
			erasequest 17789;
			break;
	}
	if(!.@cooldown){
		for(.@i = 0; .@i < getarraysize(.@name$); .@i++)
			.@menu$ += (isbegin_quest(17782 + .@i) ? "^0000CD" : "") + .@name$[.@i] + " Supply Procurement" + (isbegin_quest(17782 + .@i) ? " - In Progress^000000" : "") + ":";
	} else {
		for(.@i = 0; .@i < getarraysize(.@name$); .@i++)
			.@menu$ +=  "^999999" + .@name$[.@i] + " Supply Procurement - Wait^000000" + ":";
	}
	for(.@i = 13; .@i <= 19; .@i++){
		if(get_reputation_points(.@i) >= 1000){
			.@blessing = true;
			break;
		}
	}
	.@menu$ += (.@blessing ? "Get Blessing" : "");
	.@menu$ += ":I'll think about it.";
	.@s = select(.@menu$);
	switch(.@s){
		default:
			switch(checkquest(17789,PLAYTIME)){
				case -1:
					break;
					
				case 0:
				case 1:
					mes "[Mandel]";
					mes "It hasn't been that long since you've brought the last supplies, right?";
					mes "Don't push yourself too hard. We also need some time to sort the other supplies out, you should come back after dawn. Got it?";
					close;
					
				case 2:
					erasequest 17789;
					break;
			}
			.@qid = 17781 + .@s;
			.@idx = .@s - 1;
			if(isbegin_quest(17790) == 1 && isbegin_quest(.@qid) == 0 || isbegin_quest(17790) == 1 && isbegin_quest(.@qid) == 1 && countitem(.@item_id[.@idx]) < 10){
				mes "[Mandel]";
				mes "Wait a moment? Haven't you received the supply request already?";
				mes "Come back after you have the supply from your request.";
				close;
			}
			mes "[Mandel]";
			mes "Oh, are you going to procure the requested supplies for the ^0000cd" + .@name$[.@idx] + "^000000?";
			mes "Do you know ^0000cd" + getitemname(.@item_id[.@idx]) + "^000000?";
			next;
			if(select("Yes.","I'll rest today.") == 2){
				mes "Sure. Everyone needs a break. I understand.";
				mes "Rest well, and come back tomorrow. Goodbye!";
				close;
			}
			mes "[Mandel]";
			mes "Great. Your help are always welcome.";
			mes "Then, bring me ^0000cd10 " + getitemname(.@item_id[.@idx])  + "^000000 by hunting ^0000cd" + .@target$[.@idx] + "^000000. I'll be waiting for it!";
			setquest .@qid;
			setquest 17790;
			end;

		case 8:
			mes "[Mandel]";
			mes "We are providing blessings from the leaders of the Gaebolg resistance.";
			mes "But, we are requiring 5 <ITEM>[Wigner Merchant Guild Voucher]<INFO>1001618</INFO></ITEM> as compensation.";
			next;
			setarray .@sc,SC_CONTENTS_4,SC_CONTENTS_5,SC_CONTENTS_6,SC_CONTENTS_7,SC_CONTENTS_8,SC_CONTENTS_9,SC_CONTENTS_10;
			setarray .@name$,"Gaebolg","Nerius","Heine","Lugenburg","Walter","Wigner","Richard";
			setarray .@effect$,"ATK + 10%, MATK + 10%","Attack Speed + 10%, Walking Speed + 10%","Increase Damage to Dragon and Plant Enemies + 15%","Increase Damage to Demon and Undead Enemies + 15%","Increase Damage to Formless and Fish Enemies + 15%","Increase Damage to Brute and Angel Enemies + 15%","Increase Damage to Demihuman and Insect Enemies + 15%";
			for(.@i = 0; .@i < getarraysize(.@name$); .@i++){
				if(get_reputation_points(13 + .@i) >= 1000)
					.@buff$ += .@name$[.@i] + " Blessing" + ":";
				else
					.@buff$ += ":";
			}
			.@buff$ += "I'll think about it.";
			.@s = select(.@buff$);
			switch(.@s){
				default:
					.@idx = .@s - 1;
					mes "[Mandel]";
					mes "Let's see, let's see.";
					mes "^0000CD" + .@name$[.@idx] + " Blessing^000000 " + ".";
					mes "^0000CD" + .@effect$[.@idx] + "^000000";
					next;
					if(select("Request for Blessing.","Cancel.") == 2){
						mes "[Mandel]";
						mes "I guess this kind of blessing is not for almighty adventurers like you.";
						close;
					}
					if(countitem(1001618) < 5){
						mes "[Mandel]";
						mes "You don't have enough ticket...";
						mes "Come back when you have enough, we also need to make a living here.";
						close;
					}
					delitem 1001618,5;
					specialeffect2 EF_POTION_BERSERK;
					specialeffect2 EF_HASTEUP;
					mes "[Mandel]";
					mes "May the power of Odin be with you.";
					sc_start .@sc[.@idx],3600000,0;
					close;

				case 8:
					break; //fallthrough
			}
			
		case 9:
			mes "[Mandel]";
			mes "I'll think about it.";
			mes "Rest well, you can always do it next time. Goodbye!";
			close;
	}
	end;

OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(18360) == 2 && isbegin_quest(17781) == 0";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(17781) == 2 && isbegin_quest(17790) == 0 && checkquest(17789,PLAYTIME) == -1";
	questinfo QTYPE_DAILYQUEST,QMARK_YELLOW,"isbegin_quest(17781) == 2 && isbegin_quest(17790) == 0 && checkquest(17789,PLAYTIME) == 2";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17782) == 1 && countitem(1001629) >= 10";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17783) == 1 && countitem(1001648) >= 10";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17784) == 1 && countitem(1001639) >= 10";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17785) == 1 && countitem(1001637) >= 10";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17786) == 1 && countitem(1001646) >= 10";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17787) == 1 && countitem(1001642) >= 10";
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(17788) == 1 && countitem(1001645) >= 10";
end;
}

//WARPS
jor_mbase,121,26,3	script	Small Boat#ep21_luna_to_cr	4_POINT_BLUE,{
	mes "A small boat is tied up.";
	mes "Should you ride it to Scale Island?";
	next;
	if(select("Go to Scale Island.","Quit.") == 1)
	    warp "jor_crk_p",77,66;
	end;
}

jor_crk_p,75,57,3	script	Small Boat#ep21_crkp_to_lu	4_POINT_BLUE,{
	mes "A small boat is tied up.";
	mes "Should you ride it to Lunaforma?";
	next;
	select("Go to Lunaforma.","Quit.");
	    warp "jor_mbase",124,28;
	end;
}

jor_mbase,343,148,3	script	Walter Sailor#ep21luna_to_a	1_M_03,{
	mes "[Walter Sailor]";
	mes "This ship is going to Alberta. Are you going to ride?";
	next;
	if(select("Go to Alberta.","Quit.") == 2){
	    mes "[Walter Sailor]";
        mes "If you need to ride a ship, feel free to ask anytime.";
	    close;
    }
	mes "[Walter Sailor]";
	mes "We are going to set sail. Get on board~";
	close2;
	warp "jor_albe",200,197;
	end;
}

jor_albe,201,200,3	script	Walter Sailor#ep21ab_to_lun	1_M_03,{
	mes "[Walter Sailor]";
	mes "We can take Gaebolg members to Lunaforma everytime.";
	mes "Should we depart?";
	next;
	if(select("Go to Lunaforma.","Quit.") == 2)
		end;
	mes "[Walter Sailor]";
	mes "We are going to set sail. Get on board~";
	close2;
	warp "jor_mbase",338,148;
	if ( isbegin_quest(8916) == 1 )
		cloaknpc("Ivan#ep21p605",false,getcharid(0));
	end;
}

jor_mbase,161,343,3	script	Walter Sailor#ep21luna_to_r	1_M_03,{
	mes "[Walter Sailor]";
	mes "I can take you to the southern coast of the Raised Land.";
	mes "When you want to return, please use the small hidden boat nearby from where we will arrive.";
	next;
	if(select("Go to Raised Land.","Quit.") == 2)
		end;
	mes "[Walter Sailor]";
	mes "We are going to set sail. Get on board~";
	close2;
	warp "jor_raise2",103,30;
	end;
}


jor_raise2,100,26,3	script	Hidden Boat#ep21_raise2_t	4_POINT_BLUE,{
	mes "There is a hidden boat.";
	mes "Should I use this to return to Lunaforma?";
	next;
	if(select("Return to Lunaforma.","Quit.") == 2)
		end;
	warp "jor_mbase",161,338;
	close;
	
OnInit:
	npc_resize(Size_Small);
end;
}

jor_raise1,152,323,0	script	#ep21_raise1_to_tmple1	WARPNPC,1,1,{
	if(isbegin_quest(17752) == 0){
		mes "The entrance is closed.";
		close;
	}
	warp "jor_tmple1",170,62;
	end;
}

//= Merchants / Others
jor_mbase,220,165,3	script	Nyar#store1	4_EP20_NYAR,{
	if(isbegin_quest(23247) < 2){
		npctalk "Meow~","",bc_self;
		end;
	}
	if(isbegin_quest(18361) == 0){
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "Huh? Nyar?";
		mes "Why are you all the way here?";
		mes "Can the other people here see you too?";
		next;
		cutin "ep20_nyar03.png",1;
		mes "[Nyar]";
		mes "Meeoow...";
		mes "(Nyar is showing a pouch from its belly.)";
		next;
		cutin "ep172_nillem02.png",0;
		mes "[Nillem]";
		mes "Wow~ A primordial pouch!";
		mes "Wait...? Nyar, why do I feel dimensional power from that white, soft, and squishy primordial pouch?";
		next;
		cutin "ep20_nyar05.png",1;
		mes "[Nyar]";
		mes "Mya. Maow. Memeow.";
		mes "(Nyar puts in a stone in the primordial pouch and pulled out an 'old book' from it!)";
		next;
		cutin "ep19_lehar05.png",2;
		mes "[Lehar]";
		mes "That is! Why is a book coming out from there?!";
		mes "That's the one in my storage!";
		next;
		cutin "ep20_nyar03.png",1;
		mes "[Nyar]";
		mes "*Purpurpur*";
		next;
		cutin "ep172_nillem03.png",0;
		mes "[Nillem]";
		mes "Oh! I see.";
		mes "Nyar connected its pouch to our storage for our convenience! Am I right?";
		next;
		cutin "ep20_nyar02.png",1;
		mes "[Nyar]";
		mes "Gururu Meow~";
		next;
		cutin "ep172_nillem01.png",0;
		mes "[Nillem]";
		mes "But does it mean it needs an appropriate item for exchange?";
		mes "Will coin work? Will Zeny do? How kind of you-☆";
		next;
		cutin "ep19_lehar01.png",2;
		mes "[Lehar]";
		mes "That's a relief. It puts my mind at ease!";
		mes "I can use the things that I stored in my storage. Thank you. Nyar!";
		next;
		cutin "ep20_nyar03.png",1;
		mes "[Nyar]";
		mes "Meow.";
		setquest 18361;
		completequest 18361;
		close3;
	}
OnStorage:
	cutin "ep20_nyar03.png",1;
	mes "[Nyar]";
	mes "Meow meow~";
	mes "(Nyar proudly shows its primordial pouch.)";
	next;
	//KRO by default has 3 storage
	select("Touch the top pouch.","Touch the middle pouch.","Touch the bottom pouch.");
	if(Zeny >= 500){
		mes "[Nyar]";
		mes "*Purpurpur*~";
		close2;
		cutin "",255;
		Zeny -= 500;
		openstorage;
	} else {
		cutin "ep20_nyar02.png",1;
		mes "[Nyar]";
		mes "Meooooow.....";
		mes "(The minimum amount for equivalent exchange seems to be at around 500z.)";
		close2;
		cutin "",255;
	}
	end;
	
OnInit:
	questinfo QTYPE_QUEST,QMARK_YELLOW,"isbegin_quest(23247) == 2 && isbegin_quest(18361) == 0";
end;
}

jor_albe,62,150,3	duplicate(Nyar#store1)	Nyar#store2	4_EP20_NYAR

mbase_in,231,131,3	script	Storage Box#store1	CLEAR_NPC,{
	if(isbegin_quest(23247) < 2){
		mes "- I shouldn't use the facilities here without permission. -";
		close;	
	}
	mes "Nyar suddenly appeared when I opened the storage box...!";
	next;
	cutin "ep20_nyar03.png",1;
	mes "[Nyar]";
	mes "Meow meow~";
	mes "(Nyar proudly shows its primordial pouch.)";
	next;
	//KRO by default has 3 storage
	select("Touch the top pouch.","Touch the middle pouch.","Touch the bottom pouch.");
	if(Zeny >= 500){
		mes "[Nyar]";
		mes "*Purpurpur*~";
		close2;
		cutin "",255;
		Zeny -= 500;
		openstorage;
	} else {
		cutin "ep20_nyar02.png",1;
		mes "[Nyar]";
		mes "Meooooow.....";
		mes "(The minimum amount for equivalent exchange seems to be at around 500z.)";
		close2;
		cutin "",255;
	}
	end;
}

mbase_in,380,128,3	script	Bed#mbase	CLEAR_NPC,{
	if(isbegin_quest(23247) < 2){
		mes "- I shouldn't use the facilities here without permission. -";
		close;
	}
	mes "It's a bed for the Gaebolg soldiers to rest.";
	next;
	if(select("Save","Quit") == 2)
		end;
	mes "You saved to this location.";
	savepoint "mbase_in",376,128;
	close;
}

jalbe_in,32,142,3	script	Inn Keeper#joralbe	1_M_INNKEEPER,{
	npctalk "Welcome. This is the 'Fishermen's house' Inn.","",bc_self;
	mes "[Inn Keeper]";
	mes "Welcome. This is the 'Fishermen's house' Inn.";
	mes "How may I help you?";
	next;
	switch(select("Save","Rest - 5000z","Cancel")){
		case 1:
			mes "[Inn Keeper]";
			mes "Saved!";
			mes "Please check out our facilities!";
			savepoint "jalbe_in",27,143;
			close;
			
		case 2:
			if(Zeny < 5000){
				mes "[Inn Keeper]";
				mes "The fee for the stay is 5000z!";
				mes "Please check it!";
				close;
			} else {
				mes "[Inn Keeper]";
				mes "I'll take the 5000z!";
				mes "Have a great rest!";
				close2;
				Zeny -= 5000;
				warp "jalbe_in",26,142;
			}
			end;
			
		case 3:
			end;
	}
}

jor_albe,118,150,5	shop	Tool Dealer#jor_albe	4_M_02,611:-1,602:-1,601:-1,23280:-1,23288:-1,645:-1,656:-1,657:-1,501:-1,502:-1,503:-1,504:-1,506:-1,610:-1,713:-1,717:-1,1771:-1
mbase_in,217,126,4	shop	Tool Dealer#jor_mbase	4_M_01,611:-1,602:-1,601:-1,23280:-1,23288:-1,645:-1,656:-1,657:-1,501:-1,502:-1,503:-1,504:-1,506:-1,610:-1,713:-1,717:-1,1771:-1

mbase_in,220,127,4	script	Wigner Merchant Popo#ep21	8_F_GIRL,{
	if(isbegin_quest(18360) < 2) end;
	mes "[Merchant Popo]";
	mes "We just got some great goods. Would you like to take a look?";
	if(get_reputation_points(13) >= 1000)
		mes "There are also some new arrival from our supply ship.";
	close2;
	if(get_reputation_points(13) >= 1000){
		if(select("Look at standard goods.:Look at the new arrivals.") == 2){
			callshop "EP21_Store2",1;
			end;
		}
	}
	callshop "EP21_Store",1;
	end;
}

mbase_in,228,131,3	script	Mage Lobelia#ep21	4_RAGFES_08,{
	if(isbegin_quest(18360) < 2) end;
	mes "[Mage Lobelia]";
	mes "Excuse me! Do you need a magic on your armor?";
	mes "It's a magic called enchant, I learned it from Heine!";
	mes "I can't give you the mana stones required for it, but I can exchange them for you.";
	next;
	.@s = select("Mana Stone Exchange","Enchant Gaebolg Armor/Robe","Enchant Gaebolg Manteau/Muffler","Enchant Gaebolg Boots/Shoes","Enchant Gaebolg Accessories");
	switch(.@s){
		case 1:
			mes "[Mage Lobelia]";
			mes "These are the mana stones needed for the enchantment.";
			mes "I'll show you now.";
			close2;
			callshop "EP21_Exchange",1;
			break;
			
		default:
			.@id = 141 + .@s;
			mes "I'll show it to you now.";
			mes "Leave it to me.";
			close2;
			item_enchant(.@id);
			break;
	}
	end;
}

jor_mbase,217,263,5	script	Brave Dog#21ms00	4_DOG01,{
	if(isbegin_quest(18360) < 2) end;
	for(.@i = 13; .@i <= 19; .@i++){
		if(get_reputation_points(.@i) < 1000)
			end;
	}
	callshop "EP21_Store3",1;
	end;
}

-	marketshop	EP21_STORE4	-1,103501:1500:-1,103502:1500:-1

mbase_in,232,122,3	script	Wigner Merchant Operator#ep21	1_F_03,{
	if(isbegin_quest(18360) < 2) end;
	mes "[Operator]";
	mes "I have a variety of items prepared for adventurers like you.";
	mes "I have fly wings that can be used at the Yorscalp and I also have some craftables.";
	next;
	switch(select("Buy Yorscalp Fly Wings","Exchange Card Fragments","Exchange Yorscalp Crowns")){
		case 1:
			mes "[Operator]";
			mes "I've heard that Fly wings doesn't work in Yorscalp.";
			mes "Is it because of some powerful mana?";
			mes "We have a mage that crafted a special flywing and sent them over.";
			mes "We have plenty of stocks, so feel free to buy as many as you need.";
			close2;
			callshop "EP21_STORE4",1;
			end;
		case 2:
			mes "[Operator]";
			mes "If you found some card fragments, I can combine them for you.";
			close2;
			callshop "EP21_STORE5",1;
			end;
		case 3:
			mes "[Operator]";
			mes "Have you seen the ceremonial crowns by the cult's high priest?";
			mes "I thought they could be of use, so I've repaired some of them.";
			mes "But they require a few materials.";
			mes "Let me show them to you, if you have materials, feel free to use them.";
			close2;
			callshop "EP21_STORE6",1;
			end;	
	}
}

mbase_in,232,125,3	script	Blacksmith Sansan#ep21	4_RAGFES_15,{
	if(isbegin_quest(18360) < 2) end;
	mes "[Sansan]";
	mes "Are you in need of enchanting or upgrading your Jorscalp equipments?";
	next;
	switch(select("Enchant Jorscalp Armor/Robe","Enchant Jorscalp Manteau/Muffler","Enchant Jorscalp Boots/Shoes","Enchant Jorscalp Accessories","Enchant Jorscalp Headgears","Jorscalp Equipment Upgrade")){
		case 1:
			mes "[Sansan]";
			mes "Let me enchant your Jorscalp Armor and Robe.";
			mes "Here's the list of enchantable equipments.";
			mes "^i[450412] ^i[450413]";
			close2;
			item_enchant(152);
			end;
		case 2:
			mes "[Sansan]";
			mes "Let me enchant your Jorscalp Manteau and Muffler.";
			mes "Here's the list of enchantable equipments.";
			mes "^i[480495] ^i[480496]";
			close2;
			item_enchant(153);
			end;
		case 3:
			mes "[Sansan]";
			mes "Let me enchant your Jorscalp Boots and Shoes.";
			mes "Here's the list of enchantable equipments.";
			mes "^i[470303] ^i[470304]";
			close2;
			item_enchant(154);
			end;
		case 4:
			mes "[Sansan]";
			mes "Let me enchant your Jorscalp Accessories.";
			mes "Here's the list of enchantable equipments.";
			mes "^i[490620] ^i[490621] ^i[490622] ^i[490623]";
			close2;
			item_enchant(155);
			end;
		case 5:
			mes "[Sansan]";
			mes "Let me enchant your Jorscalp Headgears.";
			mes "Here's the list of enchantable equipments.";
			mes "^i[400723] ^i[400724]";
			close2;
			item_enchant(156);
			end;	
		case 6:
			mes "[Sansan]";
			mes "Do you have all the materials needed?";
			mes "Shall we get started?";
			close2;
			item_reform(103503);
			end;
	}
}

//Soldier
jor_mbase,74,42,5	script	Lunaforma Soldier#21ms00	4_EP21_SOLDIER_A,{
	npctalk "Sigh- I want to sleep. I want to lie down. I want to sleep for 3 days.","",bc_self;
	end;
}

jor_mbase,63,45,1	script	Lunaforma Soldier#21ms01	4_EP21_SOLDIER_B,{
	npctalk "Is this amount of water enough? Do we need more? How many did we load on the ship?","",bc_self;
	end;
}

jor_mbase,53,46,7	script	Lunaforma Soldier#21ms02	4_EP21_SOLDIER_B,{
	npctalk "I maintain it whenever I get the chance, but I can't fix the existing damages just by myself.","",bc_self;
	end;
}

jor_mbase,54,36,5	script	Lunaforma Soldier#21ms03	4_EP21_SOLDIER_A,{
	npctalk "Sweet Potato~ Sweet Potato~ Roasted Sweet Potato~","",bc_self;
	end;
}

jor_mbase,64,34,3	script	Lunaforma Soldier#21ms04	4_EP21_SOLDIER_B,{
	npctalk "What's that smell?","",bc_self;
	sleep2 100;
	npctalk "I'm grilling a fish, why?","Lunaforma Soldier#21ms05",bc_self;
	sleep2 1000;
	npctalk "Isn't the smell too strong?","",bc_self;
	sleep2 100;
	npctalk "Isn't the smell coming from the shoes that you left there to dry?","Lunaforma Soldier#21ms05",bc_self;
	end;
}

jor_mbase,66,32,3	script	Lunaforma Soldier#21ms05	4_EP21_SOLDIER_A,{
	npctalk "When will my shoes dry... My sock have a hole in it... I hope no one notices...","Lunaforma Soldier#21ms05",bc_self;
	sleep2 100;
	npctalk "Hey, everyone!!! This guy has a hole in his sock!!!","Lunaforma Soldier#21ms04",bc_self;
	sleep2 1000;
	npctalk "No!!!","Lunaforma Soldier#21ms05",bc_self;
	end;
}

jor_mbase,18,67,5	script	Lunaforma Soldier#21ms06	4_EP21_SOLDIER_B,{
	npctalk "There is nothing happening unusual elsewhere, right?","",bc_self;
	end;
}

jor_mbase,244,232,3	script	Lunaforma Soldier#21ms07	4_EP21_SOLDIER_B,{
	npctalk "There has been an increase in rats lately, it's a big problem. We already don't have supply as it is.","",bc_self;
	end;
}

jor_mbase,259,143,3	script	Lunaforma Soldier#21ms08	4_EP21_SOLDIER_A,{
	npctalk "If you need anything, please speak to the commander.","",bc_self;
	end;
}

jor_mbase,126,351,5	script	Lunaforma Soldier#21ms09	4_EP21_SOLDIER_B,{
	npctalk "There's no suspicious activity here!","",bc_self;
	end;
}

//Worker
jor_mbase,304,107,3	script	Lunaforma Worker#21ms00	4_M_SITDOWN,{
	npctalk "Phew- Finally, I cant take a breather. It was insanely busy.","",bc_self;
	end;
}

jor_mbase,300,108,5	script	Lunaforma Worker#21ms01	4_F_SITDOWN,{
	npctalk "This is the elixir of life...! It's my first time sitting down today. Is there more work to do? What is it?","",bc_self;
	end;
}

jor_mbase,280,115,5	script	Lunaforma Worker#21ms02	4_EP21_F_WORKER_B,{
	npctalk "Oh, there's another sack of potatoes here. I told them to gather it in one place.","",bc_self;
	end;
}

jor_mbase,59,206,7	script	Lunaforma Worker#21ms03	4_F_SHABBY,{
	npctalk "Should I add more beef jerky? Or not? What do you think? Would adding more make it taste better? It would be delicious...","",bc_self;
	end;
}

jor_mbase,51,197,5	script	Lunaforma Worker#21ms04	4_M_05,{
	npctalk "I miss my hometown... Will I ever be able to return...","",bc_self;
	end;
}

jor_mbase,56,186,3	script	Lunaforma Worker#21ms05	4_M_ALCHE_A,{
	npctalk "Why is it so hard to manage stuffs?","",bc_self;
	end;
}

jor_mbase,87,33,1	script	Lunaforma Worker#21ms06	4_EP21_SOLDIER_B,{
	npctalk "Who's there! Ah, an adventurer? You're not doing anything out of the usual, right?","",bc_self;
	end;
}

jor_mbase,56,47,1	script	Lunaforma Worker#21ms07	4_M_DWARF,{
	npctalk "Is this all everything that needs repairs?","",bc_self;
	sleep2 100;
	npctalk "No, there's more over there. Should I bring it here?","Lunaforma Soldier#21ms02",bc_self;
	end;
}

jor_mbase,60,105,7	script	Lunaforma Worker#21ms08	4_F_04,{
	npctalk "Who put this here again?","",bc_self;
	sleep2 1000;
	npctalk "...Me? Is it me?","",bc_self;
	end;
}

jor_mbase,141,125,3	script	Lunaforma Worker#21ms09	1_M_ORIENT01,{
	npctalk "This place? It's where we grow herbs. Smells nice, right?","",bc_self;
    sleep2 100;
	npctalk "It's precious medicine that's used to treat the injured who come here.","Lunaforma Worker#21ms10",bc_self;
	end;
	
}

jor_mbase,138,125,5	script	Lunaforma Worker#21ms10	2_M_PHARMACIST,{
	npctalk "Try this. I added a bit more mint.","",bc_self;
    sleep2 100;
	npctalk "Hm... didn't you add a little too much? It feels like the whole Ice Cave is in my mouth!","Lunaforma Worker#21ms09",bc_self;
	end;
}

jor_mbase,183,183,1	script	Lunaforma Worker#21ms11	4_EP21_WORKER_KID_A,{
	npctalk "Look at the color of the campfire. Do you know that the color of the campfires here are different? Do you know why?","",bc_self;
	end;
}

jor_mbase,289,203,3	script	Lunaforma Worker#21ms12	1_ETC_01,{
	npctalk "I'm having a cup of tea. I did a good job.","",bc_self;
	end;
}

jor_mbase,297,154,7	script	Lunaforma Worker#21ms13	4_EP21_F_WORKER_A,{
	npctalk "Isn't it awesome? It will look more awesome after it floats on the sea. That's the reason why I build ships.","",bc_self;
	end;
}

jor_mbase,293,183,5	script	Lunaforma Worker#21ms14	4_EP21_M_WORKER_A,{
	npctalk "Should I move this? Is this all for today?","",bc_self;
	end;
}

jor_mbase,292,169,5	script	Lunaforma Worker#21ms14-2	4_EP21_M_WORKER_A,{
	npctalk "Hey, you there! Where do you think you're going?","Lunaforma Worker#21ms14-2",bc_self;
	end;
}

jor_mbase,291,184,5	script	Lunaforma Worker#21ms15	4_EP21_M_WORKER_B,{
	npctalk "Should I bring more carts?","",bc_self;
	end;
}

jor_mbase,292,187,5	script	Lunaforma Worker#21ms16	4_EP21_F_WORKER_A,{
	npctalk "Let's clean up quickly and rest! Heave-ho!!","",bc_self;
	end;
}

jor_mbase,289,187,5	script	Lunaforma Worker#21ms17	4_EP21_F_WORKER_B,{
	npctalk "Let's get it done before the next ship comes!","",bc_self;
	end;
}

jor_mbase,243,229,7	script	Lunaforma Worker#21ms18	4_EP21_F_WORKER_A,{
	npctalk "Two bundles of firewood, a sack of beef jerky, bag of salt... this is everything.","",bc_self;
	sleep2 100;
	npctalk "Yes! Everything is confirmed! Good work!","Lunaforma Soldier#21ms07",bc_self;
	end;
}

jor_mbase,225,158,5	script	Lunaforma Worker#21ms19	4_EP21_F_WORKER_B,{
	npctalk "I'm busy, can you leave me alone?","",bc_self;
	sleep2 100;
	npctalk "Just give me one. Just one...","Lunaforma Worker#21ms20",bc_self;
	end;
}

jor_mbase,237,148,1	script	Lunaforma Worker#21ms20	4_EP21_M_WORKER_A,{
	npctalk "Give me one. Just one. I'll report it later. It's something urgent.","",bc_self;
	sleep2 100;
	npctalk "Oh, come on! I already said no!","Lunaforma Worker#21ms19",bc_self;
	end;
}

jor_mbase,55,188,3	script	Lunaforma Worker#21ms21	4_F_GODEMOM,{
	npctalk "Look closely, why is this here? Wasn't I clear when I said that it should be loaded on the dock? Why is it here? What's your excuse?","",bc_self;
	sleep2 100;
	npctalk "No, I'm sure you told me to put it here, can't you remember? This is driving me crazy.","Lunaforma Worker#21ms05",bc_self;
	end;
}

jor_mbase,140,301,3	script	Lunaforma Worker#ep21ex08	4_EP21_M_WORKER_B,{
	npctalk "It's nice that we are able to get warm meals here.","",bc_self;
	end;
}

//Others
jor_mbase,82,151,3	script	Lunaforma Resident#ep21_pn_e_0	1_M_INNKEEPER,{
	npctalk "Is it another Freyja believer again?","Lunaforma Resident#ep21_pn_e_0",bc_self;
	sleep2 500;
	npctalk "How do they live with so many inconveniences?","Lunaforma Resident#ep21_pn_e_1",bc_self;
	end;
}

jor_mbase,82,154,3	script	Lunaforma Resident#ep21_pn_e_1	1_M_02,{
	npctalk "Why is it so noisy?","Lunaforma Resident#ep21_pn_e_1",bc_self;
	sleep2 500;
	npctalk "There's never a single quiet day!","Lunaforma Resident#ep21_pn_e_0",bc_self;
	end;
}

jor_mbase,181,150,1	duplicate(dummynpc2)	Cat#21ms00	4_LAM
jor_mbase,178,148,7	duplicate(dummynpc2)	Dog#21ms00	4_LAM
jor_mbase,204,129,3	duplicate(dummynpc2)	Dark Dragon#21ms00	4_DONKEY
jor_mbase,205,126,7	duplicate(dummynpc2)	Light Knight#21ms00	4_DONKEY
jor_mbase,202,123,5	duplicate(dummynpc2)	Food Dragon#21ms00	4_DONKEY
jor_mbase,204,124,5	duplicate(dummynpc2)	Baby Dragon#21ms00	4_DONKEY
jor_mbase,248,107,5	duplicate(dummynpc2)	Tiger#21ms00	4_BULL
jor_mbase,243,103,7	duplicate(dummynpc2)	Mouse#21ms01	4_WHITE_COW
jor_mbase,245,100,3	duplicate(dummynpc2)	Lion#21ms00	4_BULL

jor_mbase,252,146,1	script	Hansu#kid07	4_EP21_WORKER_KID_B,{
	npctalk "You should hide better, I can see your hair over there...","",bc_self;
	end;
}

jor_mbase,145,180,3	script	Combat Instructor#sol10	4_EP21_SOLDIER_A,3,3,{
	cutin "ep21_soldier_a.png",2;
	mes "[Combat Instructor]";
	mes "Do you know what's the most efficient weapon for non-combatant?";
	mes "It's a spear!";
	close3;
}

jor_mbase,176,254,1	script	Gaebolg Soldier#mbase	4_EP21_SOLDIER_A,{
	cutin "ep21_soldier_a.png",2;
	mes "[Gaebolg Soldier]";
	mes "If you want to rest, use the barracks over there.";
	mes "You can also store your things over there, I think?";
	close3;
}

jor_mbase,138,303,4	script	Gaebolg Soldier#ep21ex0	4_EP21_SOLDIER_A,{
	cutin "ep21_soldier_a.png",1;
	mes "[Soldier]";
	mes "Is it me or it's getting colder and colder?";
	mes "No matter how far north we are, I don't think it was ever this cold.";
	next;
	cutin "ep21_worker_om_04.png",2;
	mes "[Old Worker]";
	mes "Jorvill was already freezing.";
	mes "If we stayed there any longer, we would have been frozen to death. Haha.";
	next;
	cutin "ep21_soldier_a.png",1;
	mes "[Soldier]";
	mes "But old man, it's been a while since you left the cult, why do you insist on wearing that hood?";
	mes "The children and adults alike can't seem to let go of it?";
	next;
	cutin "ep21_worker_om_04.png",2;
	mes "[Old Worker]";
	mes "Well. This hood is enchanted.";
	mes "The cult gave to us to make sure we could work harder without getting as tired.";
	mes "Magic isn't a bad thing, it's the people who use it that turns in into one.";
	next;
	cutin "ep21_soldier_a.png",1;
	mes "[Soldier]";
	mes "I tried wearing one before after hearing that, but I didn't notice anything at all?";
	next;
	cutin "ep21_worker_om_04.png",2;
	mes "[Old Worker]";
	mes "Does adding a one spoonful of water to a bowl make a difference?";
	mes "For us, that spoonful is a big thing. Haha.";
	next;
	cutin "ep21_soldier_a.png",1;
	mes "[Soldier]";
	mes "Is that so? Anyway, stay a bit further away from the fire. Your beard might catch on fire.";
	close3;
}

jor_mbase,143,177,0	duplicate(dummynpc2)	Gaebolg Soldier#sol01	4_EP21_SOLDIER_B
jor_mbase,145,177,0	duplicate(dummynpc2)	Gaebolg Soldier#sol02	4_EP21_SOLDIER_B
jor_mbase,147,177,0	duplicate(dummynpc2)	Gaebolg Soldier#sol03	4_EP21_SOLDIER_B
jor_mbase,143,174,0	duplicate(dummynpc2)	Gaebolg Soldier#sol04	4_EP21_SOLDIER_B
jor_mbase,145,174,0	duplicate(dummynpc2)	Gaebolg Soldier#sol05	4_EP21_SOLDIER_B
jor_mbase,147,174,0	duplicate(dummynpc2)	Gaebolg Soldier#sol06	4_EP21_SOLDIER_B
jor_mbase,143,171,0	duplicate(dummynpc2)	Gaebolg Soldier#sol07	4_EP21_SOLDIER_B
jor_mbase,145,171,0	duplicate(dummynpc2)	Gaebolg Soldier#sol08	4_EP21_SOLDIER_B
jor_mbase,147,171,0	duplicate(dummynpc2)	Gaebolg Soldier#sol09	4_EP21_SOLDIER_B

jor_mbase,163,269,3	script	Seeker#ep21ex03	4_EP21_WORKER_KID_B,{
	npctalk "A little bit! Just a bit more!!","",bc_self;
	sleep2 1000;
	npctalk "You only have one more chance~!","Challenger Kid#ep21ex05",bc_self;
	end;
}

jor_mbase,162,263,7	script	Challenger Kid#ep21ex05	4_EP21_WORKER_KID_A,{
	npctalk "Hey! Follow the rhytm right!","Challenger Kid#ep21ex05",bc_self;
	sleep2 1000;
	npctalk "Okay~","Seeker#ep21ex03",bc_self;
	sleep2 500;
	npctalk "The Hibiscus has bloomed!","Seeker#ep21ex03",bc_self;
	sleep2 1000;
	npctalk "What, it's too fast.","Backup Kid#ep21ex06",bc_self;
	end;
}

jor_mbase,165,262,1	script	Backup Kid#ep21ex06	4_EP21_WORKER_KID_B,{
	npctalk "I'm invincible!","Backup Kid#ep21ex06",bc_self;
	sleep2 1000;
	npctalk "Alright, team invincible! We're going to rescue the prisoners!","Challenger Kid#ep21ex05",bc_self;
	sleep2 1000;
	npctalk "Wahahaha!","",bc_self;
	end;
}

jor_mbase,222,249,5	script	Kid#21ms00	4_EP21_WORKER_KID_A,{
	npctalk "Customer~ This way? That way? Where should we go?","Kid#21ms00",bc_self;
	sleep2 100;
	npctalk "Everywhere!!","Kid#21ms01",bc_self;
	end;
}

jor_mbase,224,250,3	script	Kid#21ms01	4_EP21_WORKER_KID_B,{
	npctalk "What should we do today?","Kid#21ms01",bc_self;
	sleep2 100;
	npctalk "It's always just the two of us playing, it's no fun.","Kid#21ms00",bc_self;
	end;
}

jor_mbase,225,262,3	script	Wigner Shop#ep21ex01	4_BULLETIN_BOARD2,1,4,{
OnTouch:
	npctalk "Wigner Shop","Wigner Shop#ep21ex01",bc_self;
end;
}

jor_mbase,232,280,4	script	Mamari#ep21p6	4_M_HUMAN_02,{
	mes "[Mamari]";
	mes "This outfit?";
	mes "Lord Ivan gave it to us when we came here.";
	mes "He said we employees need to stand out, so he gave every each one of us uniforms.";
	next;
	mes "[Mamari]";
	mes "Lord Ivan told us that it doesn't matter even if we are good at we do, if we don't stand out.";
	mes "Once we started wearing our uniform, the deserters have someone to come to when they needed something.";
	next;
	mes "[Mamari]";
	mes "It doesn't suit me well, but I'm fine with it.";
	close;
}

jor_mbase,297,284,5	script	Drunked Dog#ep21_p	4_DOG01,{
	npctalk "Grunts...","",bc_self;
	end;
}

jor_mbase,126,64,7	script	Hungry Dog#ep21_pn_e	4_DOG01,{
	npctalk "Drools...","",bc_self;
	end;
}

jor_mbase,265,257,7	script	Surveyor#01	4_EP21_M_WORKER_B,{
	npctalk "I'm glad we found a land like this...","",bc_self;
	end;
}

jor_mbase,267,260,3	script	Surveyor#02	4_EP21_F_WORKER_B,{
	npctalk "With this much supply, it won't be difficult.","",bc_self;
	end;
}

jor_mbase,197,310,5	script	Wigner Merchant Staff#01	4_M_HUMAN_02,{
	mes "[Wigner Guild Disaster Prevention Staff]";
	mes "Yes, is there something I can help you with?";
	mes "For shortages of building materials, please consult our staff Mamari, the one in front of the cauldron.";
	close;
}

jor_mbase,268,253,3	duplicate(Wigner Merchant Staff#01)	Wigner Merchant Staff#02	4_M_HUMAN_02

jor_mbase,245,234,7	script	Laura#kid05	4_EP21_WORKER_KID_A,{
	npctalk "Snore... Snore...","",bc_self;
	sleep2 100;
	npctalk "She fell asleep while we are playing hide-and-seek. Let her be.","Jimin#kid06",bc_self;
	end;
}

jor_mbase,243,236,3	script	Jimin#kid06	4_EP21_WORKER_KID_B,{
	npctalk "I like the sun. I don't like playing hide-and-seek.","Jimin#kid06",bc_self;
	end;
}

jor_mbase,280,215,1	script	Cult Deserter#01	4_EP21_F_WORKER_B,{
	mes "Most of us are staring at the campfire and cry endlessly.";
	mes "It's best to leave us alone.";
	close;
}

jor_mbase,275,211,1	script	Cult Deserter#02	4_EP21_F_WORKER_B,{
	cutin "ep21_worker_f_03.png",2;
	mes "[Cult Deserter]";
	mes "If you're worried, please get her some water.";
	mes "...You seem busier than me, so I'll do it. It's fine. Just leave us alone.";
	close3;
}

jor_mbase,293,95,5	script	Cult Deserter#03	4_EP21_F_WORKER_A,{
	cutin "ep21_worker_f_08.png",2;
	mes "[Cult Deserter]";
	mes "I'm so glad we have clean water...";
	mes "It's not abundant, but at least we don't have to dig a well for it.";
	mes "It's a blessing.";
	close3;
}

jor_mbase,295,227,7	script	Mila#kid03	4_EP21_WORKER_KID_B,{
	npctalk "Shhh... I'm playing hide-and-seek.","Mila#kid03",bc_self;
	end;
}

jor_mbase,287,203,3	duplicate(dummynpc2)	Master Hunter#21ms01	4_CAT

jor_mbase,312,74,3	script	Repairman#21ms00	4_EP21_M_WORKER_B,{
	npctalk "What am I doing? I'm repairing the ship. The ships always get damaged in different places. Call me the ship doctor! Hahahahaha!","",bc_self;
	end;
}

jor_mbase,309,75,5	script	Repairman#21ms01	4_EP21_F_WORKER_A,{
	npctalk "Hm... about 2 weeks. The lumber... about this much...","",bc_self;
	end;
}

jor_mbase,300,60,7	duplicate(dummynpc)	Repairman#21ms02	4_M_ORIENT01

jor_mbase,314,42,3	script	Mischievous Dog#ep21_pn	4_DOG01,{
	npctalk "Growl...","Mischievous Dog#ep21_pn",bc_self;
	end;
}

jor_mbase,280,36,3	script	Lunaforma Worker#ep21ex09	4_EP21_F_WORKER_B,{
	cutin "ep21_worker_of_06.png",2;
	mes "[Worker]";
	mes "Wow! There's food everywhere here.";
	mes "I'll take some and wrap it, and I'll use it to prepare some soup later.";
	close3;
}

jor_mbase,229,264,7	script	Merchant Guild Worker#ep21ex02	4_EP21_M_WORKER_A,{
	cutin "ep21_worker_m_04.png",2;
	mes "[Merchant Guild Worker]";
	mes "Even though the work is the same, it feels different when you're doing it for the battle against the cult.";
	mes "That's why I'm doing it for myself.";
	next;
	mes "[Merchant Guild Worker]";
	mes "If you need anything, go inside.";
	mes "We are selling almost everything in there.";
	close3;
}

jor_mbase,189,312,4	script	Believer#ep21p680	4_EP21_M_WORKER_A,{
	cutin "ep21_worker_m_04.png",2;
	mes "[Believer]";
	mes "This hat...?";
	mes "Wearing it gives me a little bit of strength.";
	mes "It's nothing special but...";
	mes "I feel like... with it I can get by with less food, I think?";
	next;
	mes "[Believer]";
	mes "That's why everyone is wearing it.";
	mes "At least that's what the assistant priest would say... It doesn't seem like it takes control of anything.";
	mes "He said, do you think they could make something that advanced?";
	close3;
}

jor_albe,67,194,3	script	Old Villager#ep21_rw01	2_M_PHARMACIST,{
	mes "[Old Villager]";
	mes "If a war breaks out, you have to go and fight, it's obvious! When I was young……!";
	next;
	mes "[Old Villager]";
	mes "It was only natural to step up to protect the weak!";
	next;
	mes "[Old Villager]";
	mes "Young people these days have become so weak. During my time……!";
	close;
}

jor_albe,62,232,3	script	Village Girl#ep21_rw01	4_F_RUSCHILD,{
	mes "[Village Girl]";
	mes "I'm waiting for a friend since I promised that we'd go have tea together.";
	mes "We're going to a great place to enjoy tea while reading books and listening to music.";
	next;
	mes "[Village Girl]";
	mes "Is this your first time in Alberta? Then make sure you stop by Edel's Teahouse.";
	mes "The tea there is very delicious.";
	close;
}

jor_albe,172,228,5	script	Village Girl#ep21_rw02	4_F_HUGIRL,{
	mes "[Village Girl]";
	mes "My father is a sailor for the Walter Merchant Fleet.";
	next;
	mes "[Village Girl]";
	mes "It's normal for them to be in the sea for months when they go on a voyage, but recently it's making me worry.";
	next;
	mes "[Village Girl]";
	mes "Don't you think that there's a chance that they would meet a ship from the cult and get into a battle? My father is already quite old.";
	next;
	mes "[Village Girl]";
	mes "This voyage, why is it taking this long.";
	close;
}

jalbe_in,127,47,3	script	Village Girl#ep21_rw03	1_M_SIZ,{
	mes "[Village Girl]";
	mes "What book am I reading? I'm reading a book called. Predict Love like Magic!";
	next;
	mes "[Village Girl]";
	mes "Apparently by following this book, you'll be able to predict if a person likes you.";
	next;
	mes "[Village Girl]";
	mes "I oftenly visit this place, it has tons of interesting books and I also love the sounds of the piano here.";
	close;
}

jor_albe,34,180,5	script	Village Lady#ep21_rw01	4_F_EINWOMAN,{
	mes "[Village Lady]";
	mes "Did you see the refugees who arrived by the ship yesterday? My lord, they looked so frail with frightened eyes glancing around, it looks like they haven't had a decent meal in a long time, it was heartbreaking to look at.";
	next;
	mes "[Village Lady]";
	mes "Do you think this small village has enough to provide housing and feed all the refugees? If they don't mind my shabby house, I'd welcome them, give them a place to sleep and something to eat.";
	close;
}

jor_albe,214,110,5	script	Village Lady#ep21_rw02	4_F_01,{
	mes "[Village Lady]";
	mes "Argh! It's not easy to shake the sand out of your shoes. Be mindful of where you're walking.";
	next;
	mes "[Village Lady]";
	mes "I've been cleaning it up as I see it, but with so many people coming and going lately, the pier has gotten quite dirty.";
	next;
	mes "[Village Lady]";
	mes "But what can I do, Everyone's just trying to survive, I can't simply turn them away. Tsk.";
	close;
}

jor_albe,145,195,7	script	Refugee Girl#ep21_rw01	4_F_CAPEGIRL,{
	mes "[Refugee Girl]";
	mes "Oh, the grilled fish skewers smells so nice. It smells very delicious.";
	next;
	mes "[Refugee Girl]";
	mes "If only I hadn't drop my pouch while fleeing…….";
	close;
}

jor_albe,203,149,3	script	Refugee Man#ep21_rw01	1_M_SMITH,{
	mes "[Refugee Man]";
	mes "Do you have work for me? Even if I look like this, my body is strong!";
	next;
	mes "[Refugee Man]";
	mes "I'll do any kind of work. As long as you compensate me of course.";
	next;
	mes "[Refugee Man]";
	mes "Sigh, it's not easy find a job here either…….";
	close;
}

jor_albe,33,253,7	script	Village Elder#ep21_rw01	4_M_DEWOLDMAN,{
	mes "[Village Elder]";
	mes "Ah, young one. Can you ready what's written here for me?";
	next;
	mes "[Village Elder]";
	mes "The more the times are uncertain, the more we must stay informed about the village news, but my eyes aren't what they used to be, I can't read the small letters from the posters.";
	next;
	if(select("Read the posters.","Don't read the posters.") == 1){
		mes "[Village Elder]";
		mes "I see, 'A ship carrying refugees will arrive by tomorrow'. Thank you, young one.";
		next;
		mes "[Village Elder]";
		mes "If you don't stay informed and adapt, you will age quickly.";
		next;
		mes "[Village Elder]";
		mes "That's why even at my age, I always keep my ears open.";
	} else {
		mes "[Village Elder]";
		mes "Huh? Can't you read? Well, there's nothing I can do about that. Take care.";
	}
	close;
}

jor_albe,248,80,5	script	Village Elder#ep21_rw02	4_EP18_GW_OLD01,{
	mes "[Village Elder]";
	mes "Hehe. I have been fishing for a long time. Watching the slow flow of the water while holding my fishing rod brings me peace.";
	next;
	mes "[Village Elder]";
	mes "I see a lot of people struggling recently. I wish I could help them, even just a little bit.";
	next;
	mes "[Village Elder]";
	mes "Isn't there some way where we could all work together to help the refugees? Shouldn't we should discuss this on the village meeting?";
	close;
}

jor_albe,158,208,3	script	Alberta Resident#ep21_rw01	4W_F_01,{
	mes "[Alberta Resident]";
	mes "I heard a ghost ship appeared again. Is it really a ghost ship?";
	mes "What kind of grudge does it hold to continue wandering the sea?";
	close;
}

jor_albe,156,207,7	script	Alberta Resident#ep21_rw02	4W_SAILOR,{
	mes "[Alberta Resident]";
	mes "I heard that the Walter's captain is diligently searching for the ghost ship.";
	mes "Don't tell me that ghost ship is…… Wah, who are you! Why are you listening to my thoughts?";
	close;
}

jor_albe,214,133,3	script	Alberta Resident#ep21_rw03	4W_M_03,{
	mes "[Alberta Resident]";
	mes "Sigh……. I can't sleep with these ghost stories floating around…….";
	mes "But what if it's a ghost ship that only attacks the cult, then maybe it's an ally?";
	next;
	mes "[Alberta Resident]";
	mes "Oh! You scared me.";
	mes "You just standing there quietly almost give a heart attack!";
	close;
}

jor_albe,179,143,3	script	Alberta Resident#ep21_rw04	4W_KID,{
	mes "[Alberta Resident]";
	mes "The village is generally quiet, don't you think?";
	mes "There a lot of sailors who went on a voyage because of the cult's ships.";
	next;
	mes "[Alberta Resident]";
	mes "Recently, the number of the cult's ship around has decreased.";
	mes "The reason is…… Uhm, I heard about it, but I forgot!";
	close;
}

jor_albe,47,147,5	script	Village Youth#ep21_rw01	4_M_RUSMAN2,{
	mes "[Village Youth]";
	mes "The village hasn't changed from what it used to be…… but it's definitely different. I'm quite anxious. Especially with the atmosphere recently…….";
	next;
	mes "[Village Youth]";
	mes "The war is coming closer to the village. Refugees are scattered everywhere. Honestly speaking…… I'm so scared.";
	next;
	mes "[Village Youth]";
	mes "Of course, I want to help as much as I can……. But I don't want to lose the peace of our village…….";
	close;
}

jor_albe,149,199,3	script	Village Youth#ep21_rw02	4_M_EINMAN,{
	mes "[Village Youth]";
	mes "Come, we are selling delicious grilled fish skewers.";
	next;
	mes "[Village Youth]";
	mes "Freshness that you won't find anywhere else! Enjoy the salty and savory taste of a freshly caught grilled fish!";
	next;
	mes "[Village Youth]";
	mes "It's a specialty you can only get here in Alberta, where the fishing boats catches fresh fish every morning.";
	close;
}

jalbe_in,56,52,7	script	Village Youth#ep21_rw03	4_EP18_GW_MIDDLE01,{
	mes "[Village Youth]";
	mes "Tick Tock, Tick Tock, Tick Tock…….";
	next;
	mes "[Village Youth]";
	mes "What am I doing? It might look like I'm only looking at the clock, but I'm something important.";
	next;
	mes "[Village Youth]";
	mes "I'm meticulously recording the times when the tide rise and recede…… and when the sun rise and sets. That's my job.";
	next;
	mes "[Village Youth]";
	mes "You don't think this is important? This records will pile up and one day become a treasure. Trust me!";
	close;
}

jor_albe,221,88,3	script	Village Youth#ep21_rw04	4_M_04,{
	mes "[Village Youth]";
	mes "Don't touch it! That wagon, is not something to be thrown away.";
	next;
	mes "[Village Youth]";
	mes "Oh, you're not here to take it away? Sorry for suddenly raising my voice. There were a lot of people who mistaken it for something to be discarded and touched it carelessly.";
	next;
	mes "[Village Youth]";
	mes "I know that I left it in the corner for a long time, but it's an important property of mine.";
	next;
	mes "[Village Youth]";
	mes "I need to take good care of it so that eventually I'll be able to join the Wigner Merchant Guild and head out on a trade expedition.";
	close;
}

jalbe_in,120,44,1	script	Village Woman#ep21_rw01	2_F_MAGICMASTER,{
	mes "[Village Woman]";
	mes "The chocolates from Edel Teahouse are very delicious! Especially the chocolate cookies.";
	next;
	mes "[Village Woman]";
	mes "It's a limited product, it's hard to purchase when you go late in the afternoon. Everybody wants to eat them.";
	next;
	mes "[Village Woman]";
	mes "I went early in the morning and was able to buy some! Mmm~ I love the rich sweetness.";
	close;
}

jalbe_in,132,55,1	script	Village Boy#ep21_rw01	4_KID01,{
	mes "[Village Boy]";
	mes "There's a kid who comes to Edel Teahouse everyday and read at the same spot…… I'm curious to what book she is reading.";
	next;
	mes "[Village Boy]";
	mes "I want to know more about them. I should muster up my courage and approach her. Maybe I should ask if we could exchange letters…….";
	next;
	mes "[Village Boy]";
	mes "Ah! Did I say that out loud? What if she heard me?";
	close;
}

jalbe_in,16,18,3	script	Warehouse Worker#ep21_rw01	4_M_02,{
	mes "[Warehouse Worker]";
	mes "Ah! I'm the professor's assistant. The professor is quite busy right now.";
	next;
	mes "[Warehouse Worker]";
	mes "If you have something important business with him, you have to tell it through me.";
	next;
	select("I don't have any important business.");
	mes "[Warehouse Worker]";
	mes "Oh! Is that so? That's a relief! To be honest, I'm still new to this, so I was afraid that you might have something important for me to handle.";
	next;
	mes "[Warehouse Worker]";
	mes "Of course, I remember what I learned~ However, there are so many possibilities that may happen.";
	close;
}

jalbe_in,69,147,3	script	Mamasina#ep21p6	4_M_HUMAN_02,{
	npctalk "...","",bc_self;
	end;
}

jalbe_in,69,146,3	script	Toril#ep21p6	4_M_HUMAN_02,{
	npctalk "Show proper respect to the guild leader, adventurer.","",bc_self;
	end;
}

jalbe_in,68,134,1	script	Miyogi#ep21p6	4_M_HUMAN_02,{
	npctalk "Guild leader, it seems an adventurer has arrived.","",bc_self;
	end;
}

//= Warps
jor_base,240,42,0	warp	ep21_jorbase_to_raise1	1,1,jor_raise1,276,386
jor_mbase,204,196,0	warp	ep21_mbase_center_in	1,1,mbase_in,89,101
jor_mbase,222,264,0	warp	ep21_mbase_store_in	1,1,mbase_in,221,112
jor_mbase,321,115,0	warp	ep21_mbase_lichard_in	1,1,mbase_in,285,124
jor_mbase,170,248,0	warp	ep21_mbase_house_in	1,1,mbase_in,375,134
jor_raise2,118,414,0	warp	ep21_raise2_to_raise1	1,1,jor_raise1,301,10
jor_raise1,301,6,0	warp	ep21_raise1_to_raise2	1,1,jor_raise2,118,410
jor_raise1,276,394,0	warp	ep21_raise1_to_jorbase	1,1,jor_base,240,46
jor_tmple1,170,55,0	warp	ep21_tmple1_to_raise1	1,1,jor_raise1,152,319
jor_tmple1,40,205,0	warp	ep21_tmple1_to_tmple2_wu	1,1,jor_tmple2,24,173
jor_tmple1,40,134,0	warp	ep21_tmple1_to_tmple2_wd	1,1,jor_tmple2,25,128
jor_tmple1,299,205,0	warp	ep21_tmple1_to_tmple2_wu2	1,1,jor_tmple2,276,173
jor_tmple1,299,134,0	warp	ep21_tmple1_to_tmple2_wu3	1,1,jor_tmple2,276,128
jor_tmple2,20,173,0	warp	ep21_tmple2_to_tmple1_wu	1,1,jor_tmple1,44,205
jor_tmple2,20,128,0	warp	ep21_tmple2_to_tmple1_wd	1,1,jor_tmple1,44,134
jor_tmple2,280,173,0	warp	ep21_tmple1_to_tmple2_wu4	1,1,jor_tmple1,294,205
jor_tmple2,280,128,0	warp	ep21_tmple1_to_tmple2_wu5	1,1,jor_tmple1,294,134


jor_raise1,113,334,0	script	#ep21_raise1_to_sklf1	WARPNPC,1,1,{
	end;
	
OnTouch:
	if(isbegin_quest(18360) < 2) end;
	warp "jor_sklf1",298,170;
end;
}

jor_sklf1,299,134,0	warp	#ep21_sklf1_to_sklf2_wu	1,1,jor_sklf2,276,128
jor_sklf2,280,128,0	warp	#ep21_sklf2_to_sklf1_wu	1,1,jor_sklf1,294,134
mbase_in,89,98,0	warp	ep21_mbase_center_out	1,1,jor_mbase,204,192
mbase_in,111,128,0	warp	ep21_mbase_room2_in	1,1,mbase_in,165,169
mbase_in,162,169,0	warp	ep21_mbase_room2_out	1,1,mbase_in,108,127
mbase_in,66,114,0	warp	ep21_mbase_room8_in	1,1,mbase_in,22,79
mbase_in,25,80,0	warp	ep21_mbase_room8_out	1,1,mbase_in,70,114
mbase_in,66,120,0	warp	ep21_mbase_room9_in	1,1,mbase_in,22,123
mbase_in,25,124,0	warp	ep21_mbase_room9_out	1,1,mbase_in,70,120
mbase_in,68,128,0	warp	ep21_mbase_room10_in	1,1,mbase_in,22,167
mbase_in,25,168,0	warp	ep21_mbase_room10_out	1,1,mbase_in,71,128
mbase_in,221,109,0	warp	ep21_mbase_store_out	1,1,jor_mbase,222,260
mbase_in,282,124,0	warp	ep21_mbase_lichard_out	1,1,jor_mbase,317,115
mbase_in,375,137,0	warp	ep21_mbase_house_out	1,1,jor_mbase,170,253
mbase_in,117,178,0	warp	#21ms51	1,1,mbase_in,94,138
mbase_in,162,126,0	warp	out_richard	1,1,mbase_in,109,120
mbase_in,162,82,0	warp	out_galaxia	1,1,mbase_in,109,114
mbase_in,65,178,0	warp	ep21_mbase_room11_out	1,1,mbase_in,85,137
jor_albe,86,219,0	warp	ep21_albe_to_wh01	1,1,jalbe_in,65,133
jor_albe,93,237,0	warp	ep21_albe_to_wh02	1,1,jalbe_in,70,141
jor_albe,114,145,0	warp	ep21_albe_to_market	1,1,jalbe_in,76,43
jor_albe,72,138,0	warp	ep21_albe_to_inn	1,1,jalbe_in,17,141
jor_albe,197,101,0	warp	ep21_albe_to_house1	1,1,jalbe_in,23,30
jor_albe,66,237,0	warp	ep21_albe_to_house2	1,1,jalbe_in,117,50
jor_albe,113,87,0	warp	ep21_albe_to_house3	1,1,jalbe_in,117,98
jalbe_in,65,130,0	warp	ep21_wh01_to_albe	1,1,jor_albe,87,216
jalbe_in,73,141,0	warp	ep21_wh02_to_albe	1,1,jor_albe,96,237
jalbe_in,65,153,0	warp	ep21_wh_to_room	1,1,jalbe_in,65,173
jalbe_in,65,170,0	warp	ep21_room_to_wh	1,1,jalbe_in,65,150
jalbe_in,79,43,0	warp	ep21_market_to_albe	1,1,jor_albe,118,145
jalbe_in,63,57,0	warp	ep21_market_to_wroom1	1,1,jalbe_in,23,57
jalbe_in,23,54,0	warp	ep21_wroom1_to_market	1,1,jalbe_in,63,54
jalbe_in,63,30,0	warp	ep21_market_to_wroom2	1,1,jalbe_in,65,110
jalbe_in,65,113,0	warp	ep21_wroom2_to_market	1,1,jalbe_in,63,33
jalbe_in,14,141,0	warp	ep21_inn_to_albe	1,1,jor_albe,69,138
jalbe_in,21,153,0	warp	ep21_inn_to_room1	1,1,jalbe_in,21,173
jalbe_in,21,170,0	warp	ep21_room1_to_inn	1,1,jalbe_in,21,150
jalbe_in,21,130,0	warp	ep21_inn_to_room2	1,1,jalbe_in,21,110
jalbe_in,21,113,0	warp	ep21_room2_to_inn	1,1,jalbe_in,21,133
jalbe_in,23,33,0	warp	ep21_house1_to_albe	1,1,jor_albe,200,104
jalbe_in,114,50,0	warp	ep21_house2_to_albe	1,1,jor_albe,63,237
jalbe_in,114,98,0	warp	ep21_house3_to_albe	1,1,jor_albe,110,88

//Yorscalp Update Warps

jor_sklf1,303,170,0	warp	#ep21_sklf1_to_raise1	1,1,jor_raise1,117,334
jor_sklf1,299,205,0	warp	#ep21_jor_sklf1_to_jor_sklf2_wu2	1,1,jor_sklf2,276,173
jor_sklf1,299,134,0	warp	#ep21_jor_sklf1_to_jor_sklf2_wu3	1,1,jor_sklf2,276,128
jor_sklf1,40,205,0	warp	#ep21_jor_sklf1_to_jor_sklf2_wu	1,1,jor_sklf2,24,173
jor_sklf1,40,134,0	warp	#ep21_jor_sklf1_to_jor_sklf2_wd	1,1,jor_sklf2,25,128
jor_sklf2,20,173,0	warp	#ep21_jor_sklf2_to_jor_sklf1_wu	1,1,jor_sklf1,44,205
jor_sklf2,20,128,0	warp	#ep21_jor_sklf2_to_jor_sklf1_wd	1,1,jor_sklf1,44,134
jor_sklf2,280,173,0	warp	#ep21_jor_sklf2_to_jor_sklf1_wu4	1,1,jor_sklf1,294,205
jor_sklf2,280,128,0	warp	#ep21_jor_sklf2_to_jor_sklf1_wu5	1,1,jor_sklf1,294,134

//Todo - Change me after zone change by aleos is merged
jor_sklf1	mapflag	nowarp
jor_sklf2	mapflag	nowarp

mbase_in,94,141,0	script	#21ms50	WARPNPC,1,1,{
	end;
	
OnTouch:
	if(isbegin_quest(17767) == 0){
		mes "- The room is locked. -";
		close;
	}
	warp "mbase_in",117,181;
end;
}

luna_sf1,30,267,0	warp	#21ms02w	2,2,jor_raise1,318,66
luna_sf2,55,141,0	warp	#21ms14w	2,2,jor_tmple1,104,190
luna_sf1,249,249,0	warp	#outsf1pt1	2,2,jor_raise1,196,188
luna_sf2,252,136,0	warp	#out_lastbattleready	2,2,jor_raise1,128,323
luna_sf2,270,257,0	warp	#ep21_md2enter_out	2,2,jor_tmple1,170,307
luna_sf2,260,29,0	warp	#out_lastbattle	2,2,luna_sf2,252,160

jor_tmple1,170,303,0	script	#ep21md2gateopen	HIDDEN_WARP_NPC,5,5,{
	end;
	
OnTouch:
	if(isbegin_quest(18349) < 1) end;
	cloaknpc("Decorative Door#ep21_md2enter_in",false,getcharid(0));
end;
}

jor_tmple1,170,312,3	script	Decorative Door#ep21_md2enter_in	4_POINT_BLUE,{
	if(isbegin_quest(18349) < 1) end;
	mes "There is a suspicious decorative door.";
	next;
	if(select("Open it.","Quit.") == 2)
		end;
	warp "luna_sf2",266,257;
	end;
	
OnInit:
	questinfo QTYPE_CLICKME,QMARK_YELLOW,"isbegin_quest(18349) == 1";
	questinfo QTYPE_CLICKME,QMARK_YELLOW,"isbegin_quest(18350) == 1";
	questinfo QTYPE_CLICKME,QMARK_YELLOW,"isbegin_quest(18351) == 1";
	questinfo QTYPE_CLICKME,QMARK_YELLOW,"isbegin_quest(18352) == 1";
end;
}

//Monster Spawn
jor_raise1,0,0	monster	--ja--	22313,50,5000
jor_raise1,0,0	monster	--ja--	22314,60,5000
jor_raise1,0,0	monster	--ja--	22315,50,5000
jor_raise1,0,0	monster	--ja--	22316,60,5000
jor_raise1,0,0	monster	--ja--	22317,50,5000
jor_raise1,0,0	monster	--ja--	22323,20,5000
jor_raise1,0,0	monster	--ja--	22325,20,5000
jor_raise1,0,0	monster	--ja--	22327,20,5000

jor_raise2,0,0	monster	--ja--	22313,70,5000
jor_raise2,0,0	monster	--ja--	22318,60,5000
jor_raise2,0,0	monster	--ja--	22319,80,5000
jor_raise2,0,0	monster	--ja--	22320,70,5000
jor_raise2,0,0,0,0	boss_monster	--ja--	22362,1,12600000,1800000,0

jor_tmple1,0,0	monster	--ja--	22323,40,5000
jor_tmple1,0,0	monster	--ja--	22324,40,5000
jor_tmple1,0,0	monster	--ja--	22325,40,5000
jor_tmple1,0,0	monster	--ja--	22326,40,5000
jor_tmple1,0,0	monster	--ja--	22327,40,5000
jor_tmple1,0,0	monster	--ja--	22353,45,5000
jor_tmple1,0,0	monster	--ja--	22354,45,5000
jor_tmple1,0,0	monster	--ja--	22355,20,5000
jor_tmple1,0,0	monster	--ja--	22356,20,5000
jor_tmple1,0,0	monster	--ja--	22357,20,5000
jor_tmple1,0,0,0,0	boss_monster	--ja--	22363,1,19800000,1800000,0

jor_tmple2,0,0	monster	--ja--	22355,60,5000
jor_tmple2,0,0	monster	--ja--	22356,60,5000
jor_tmple2,0,0	monster	--ja--	22357,60,5000
jor_tmple2,0,0	monster	--ja--	22358,40,5000
jor_tmple2,0,0	monster	--ja--	22359,40,5000
jor_tmple2,0,0	monster	--ja--	22360,40,5000
jor_tmple2,0,0	monster	--ja--	22361,40,5000
jor_tmple2,0,0,0,0	boss_monster	--ja--	22364,1,19800000,1800000,0

jor_base,0,0	monster	--ja--	22321,160,5000
jor_base,0,0	monster	--ja--	22322,160,5000
jor_base,0,0	monster	--ja--	22313,40,5000
jor_base,0,0	monster	--ja--	22326,30,5000
jor_base,0,0	monster	--ja--	22324,30,5000

jor_sklf1,0,0	monster	--ja--	22414,60,5000
jor_sklf1,0,0	monster	--ja--	22415,60,5000
jor_sklf1,0,0	monster	--ja--	22416,60,5000
jor_sklf1,0,0	monster	--ja--	22417,40,5000
jor_sklf1,0,0	monster	--ja--	22418,40,5000
jor_sklf1,0,0,0,0	boss_monster	--ja--	22421,1,19800000,1800000,0

jor_sklf2,0,0	monster	--ja--	22412,40,5000
jor_sklf2,0,0	monster	--ja--	22413,40,5000
jor_sklf2,0,0	monster	--ja--	22414,60,5000
jor_sklf2,0,0	monster	--ja--	22415,60,5000
jor_sklf2,0,0	monster	--ja--	22416,60,5000
jor_sklf2,0,0	monster	--ja--	22419,40,5000
jor_sklf2,0,0	monster	--ja--	22420,40,5000
jor_sklf2,0,0,0,0	boss_monster	--ja--	22422,1,19800000,1800000,0
